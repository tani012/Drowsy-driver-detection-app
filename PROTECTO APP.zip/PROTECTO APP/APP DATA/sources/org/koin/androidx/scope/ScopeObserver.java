package org.koin.androidx.scope;

import p176d.p242n.C5781e;
import p176d.p242n.C5785g;
import p176d.p242n.C5794o;
import p285k.p286a.p293c.C6123a;
import p285k.p286a.p293c.C6128f;
import p285k.p286a.p293c.p294g.C6130b;
import p285k.p286a.p293c.p294g.C6131c;

public final class ScopeObserver implements C5785g, C6128f {
    /* renamed from: a */
    public C6123a mo12699a() {
        C6130b bVar = C6131c.f21126a;
        if (bVar != null) {
            return bVar.get();
        }
        throw new IllegalStateException("No Koin Context configured. Please use startKoin or koinApplication DSL. ".toString());
    }

    @C5794o(C5781e.C5782a.ON_DESTROY)
    public final void onDestroy() {
        if (C5781e.C5782a.ON_DESTROY == null) {
            throw null;
        }
    }

    @C5794o(C5781e.C5782a.ON_STOP)
    public final void onStop() {
        if (C5781e.C5782a.ON_STOP == null) {
            throw null;
        }
    }
}
