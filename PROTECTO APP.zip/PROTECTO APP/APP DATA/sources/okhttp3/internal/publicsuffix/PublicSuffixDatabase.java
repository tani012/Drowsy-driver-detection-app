package okhttp3.internal.publicsuffix;

import java.io.InputStream;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.atomic.AtomicBoolean;
import p274i.p275i0.C5963c;
import p284j.C6098l;
import p284j.C6101o;
import p284j.C6105r;
import p284j.C6111x;

public final class PublicSuffixDatabase {

    /* renamed from: e */
    public static final byte[] f21193e = {42};

    /* renamed from: f */
    public static final String[] f21194f = new String[0];

    /* renamed from: g */
    public static final String[] f21195g = {"*"};

    /* renamed from: h */
    public static final PublicSuffixDatabase f21196h = new PublicSuffixDatabase();

    /* renamed from: a */
    public final AtomicBoolean f21197a = new AtomicBoolean(false);

    /* renamed from: b */
    public final CountDownLatch f21198b = new CountDownLatch(1);

    /* renamed from: c */
    public byte[] f21199c;

    /* renamed from: d */
    public byte[] f21200d;

    /* renamed from: a */
    public static String m17893a(byte[] bArr, byte[][] bArr2, int i) {
        int i2;
        boolean z;
        byte b;
        int i3;
        byte[] bArr3 = bArr;
        byte[][] bArr4 = bArr2;
        int length = bArr3.length;
        int i4 = 0;
        while (i4 < length) {
            int i5 = (i4 + length) / 2;
            while (i5 > -1 && bArr3[i5] != 10) {
                i5--;
            }
            int i6 = i5 + 1;
            int i7 = 1;
            while (true) {
                i2 = i6 + i7;
                if (bArr3[i2] == 10) {
                    break;
                }
                i7++;
            }
            int i8 = i2 - i6;
            int i9 = i;
            boolean z2 = false;
            int i10 = 0;
            int i11 = 0;
            while (true) {
                if (z2) {
                    b = 46;
                    z = false;
                } else {
                    z = z2;
                    b = bArr4[i9][i10] & 255;
                }
                i3 = b - (bArr3[i6 + i11] & 255);
                if (i3 == 0) {
                    i11++;
                    i10++;
                    if (i11 == i8) {
                        break;
                    } else if (bArr4[i9].length != i10) {
                        z2 = z;
                    } else if (i9 == bArr4.length - 1) {
                        break;
                    } else {
                        i9++;
                        i10 = -1;
                        z2 = true;
                    }
                } else {
                    break;
                }
            }
            if (i3 >= 0) {
                if (i3 <= 0) {
                    int i12 = i8 - i11;
                    int length2 = bArr4[i9].length - i10;
                    while (true) {
                        i9++;
                        if (i9 >= bArr4.length) {
                            break;
                        }
                        length2 += bArr4[i9].length;
                    }
                    if (length2 >= i12) {
                        if (length2 <= i12) {
                            return new String(bArr3, i6, i8, C5963c.f20563i);
                        }
                    }
                }
                i4 = i2 + 1;
            }
            length = i6 - 1;
        }
        return null;
    }

    /* renamed from: b */
    public final void mo12751b() {
        InputStream resourceAsStream = PublicSuffixDatabase.class.getResourceAsStream("publicsuffixes.gz");
        if (resourceAsStream != null) {
            C6105r rVar = new C6105r(new C6098l(C6101o.m17755f(resourceAsStream, new C6111x())));
            try {
                byte[] bArr = new byte[rVar.readInt()];
                rVar.mo12685b(bArr);
                byte[] bArr2 = new byte[rVar.readInt()];
                rVar.mo12685b(bArr2);
                synchronized (this) {
                    this.f21199c = bArr;
                    this.f21200d = bArr2;
                }
                this.f21198b.countDown();
            } finally {
                C5963c.m17299f(rVar);
            }
        }
    }
}
