package kotlinx.coroutines;

import p257h.p259n.C5857f;

public interface CoroutineExceptionHandler extends C5857f.C5858a {

    /* renamed from: c */
    public static final C6162a f21185c = C6162a.f21186a;

    /* renamed from: kotlinx.coroutines.CoroutineExceptionHandler$a */
    public static final class C6162a implements C5857f.C5860b<CoroutineExceptionHandler> {

        /* renamed from: a */
        public static final /* synthetic */ C6162a f21186a = new C6162a();
    }

    void handleException(C5857f fVar, Throwable th);
}
