package kotlinx.coroutines.internal;

import java.util.List;
import p168c.p169a.C4783z0;

public interface MainDispatcherFactory {
    /* renamed from: a */
    String mo12740a();

    /* renamed from: b */
    C4783z0 mo12741b(List<? extends MainDispatcherFactory> list);

    /* renamed from: c */
    int mo12742c();
}
