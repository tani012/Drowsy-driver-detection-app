package kotlinx.coroutines.android;

import android.os.Looper;
import java.util.List;
import kotlinx.coroutines.internal.MainDispatcherFactory;
import p168c.p169a.C4783z0;
import p168c.p169a.p171j1.C4728a;
import p168c.p169a.p171j1.C4730c;

public final class AndroidDispatcherFactory implements MainDispatcherFactory {
    /* renamed from: a */
    public String mo12740a() {
        return "For tests Dispatchers.setMain from kotlinx-coroutines-test module can be used";
    }

    /* renamed from: b */
    public C4783z0 mo12741b(List list) {
        return new C4728a(C4730c.m14667a(Looper.getMainLooper(), true), "Main", false);
    }

    /* renamed from: c */
    public int mo12742c() {
        return 1073741823;
    }
}
