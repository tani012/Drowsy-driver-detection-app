package com.google.ads.mediation;

import android.app.Activity;
import p002b.p011c.p012a.p013d.C0135a;
import p002b.p011c.p012a.p013d.C0136b;
import p002b.p011c.p012a.p013d.C0138d;
import p002b.p011c.p012a.p013d.C0139e;
import p002b.p011c.p012a.p013d.C0142f;

@Deprecated
public interface MediationInterstitialAdapter<ADDITIONAL_PARAMETERS extends C0142f, SERVER_PARAMETERS extends C0139e> extends C0136b<ADDITIONAL_PARAMETERS, SERVER_PARAMETERS> {
    /* synthetic */ void destroy();

    /* synthetic */ Class<ADDITIONAL_PARAMETERS> getAdditionalParametersType();

    /* synthetic */ Class<SERVER_PARAMETERS> getServerParametersType();

    void requestInterstitialAd(C0138d dVar, Activity activity, SERVER_PARAMETERS server_parameters, C0135a aVar, ADDITIONAL_PARAMETERS additional_parameters);

    void showInterstitial();
}
