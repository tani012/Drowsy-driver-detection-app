package com.google.ads.mediation.customevent;

import android.app.Activity;
import android.os.RemoteException;
import android.view.View;
import com.google.ads.mediation.MediationBannerAdapter;
import com.google.ads.mediation.MediationInterstitialAdapter;
import com.google.android.gms.common.annotation.KeepName;
import p002b.p011c.p012a.C0132a;
import p002b.p011c.p012a.C0134c;
import p002b.p011c.p012a.p013d.C0135a;
import p002b.p011c.p012a.p013d.C0137c;
import p002b.p011c.p012a.p013d.C0138d;
import p002b.p011c.p012a.p013d.p014g.C0143a;
import p002b.p011c.p012a.p013d.p014g.C0144b;
import p002b.p011c.p012a.p013d.p014g.C0145c;
import p002b.p011c.p015b.p028b.p029a.p041y.p042w.C0424c;
import p002b.p011c.p015b.p028b.p053e.p061r.C0605f;
import p002b.p011c.p015b.p028b.p068i.p069a.C0706bc;
import p002b.p011c.p015b.p028b.p068i.p069a.C0833ec;
import p002b.p011c.p015b.p028b.p068i.p069a.C0877fc;
import p002b.p011c.p015b.p028b.p068i.p069a.C1741ym;
import p002b.p011c.p015b.p028b.p068i.p069a.zh2;

@KeepName
public final class CustomEventAdapter implements MediationBannerAdapter<C0424c, C0145c>, MediationInterstitialAdapter<C0424c, C0145c> {

    /* renamed from: a */
    public CustomEventBanner f17340a;

    /* renamed from: b */
    public CustomEventInterstitial f17341b;

    /* renamed from: com.google.ads.mediation.customevent.CustomEventAdapter$a */
    public static final class C4793a implements C0143a {
        public C4793a(CustomEventAdapter customEventAdapter, C0137c cVar) {
        }
    }

    /* renamed from: com.google.ads.mediation.customevent.CustomEventAdapter$b */
    public class C4794b implements C0144b {
        public C4794b(CustomEventAdapter customEventAdapter, CustomEventAdapter customEventAdapter2, C0138d dVar) {
        }
    }

    /* renamed from: a */
    public static <T> T m14817a(String str) {
        try {
            return Class.forName(str).newInstance();
        } catch (Throwable th) {
            String message = th.getMessage();
            StringBuilder sb = new StringBuilder(String.valueOf(message).length() + String.valueOf(str).length() + 46);
            sb.append("Could not instantiate custom event adapter: ");
            sb.append(str);
            sb.append(". ");
            sb.append(message);
            C0605f.m1109f5(sb.toString());
            return null;
        }
    }

    public final void destroy() {
        CustomEventBanner customEventBanner = this.f17340a;
        if (customEventBanner != null) {
            customEventBanner.destroy();
        }
        CustomEventInterstitial customEventInterstitial = this.f17341b;
        if (customEventInterstitial != null) {
            customEventInterstitial.destroy();
        }
    }

    public final Class<C0424c> getAdditionalParametersType() {
        return C0424c.class;
    }

    public final View getBannerView() {
        return null;
    }

    public final Class<C0145c> getServerParametersType() {
        return C0145c.class;
    }

    public final void requestBannerAd(C0137c cVar, Activity activity, C0145c cVar2, C0134c cVar3, C0135a aVar, C0424c cVar4) {
        C0137c cVar5 = cVar;
        C0145c cVar6 = cVar2;
        C0424c cVar7 = cVar4;
        CustomEventBanner customEventBanner = (CustomEventBanner) m14817a(cVar6.f776b);
        this.f17340a = customEventBanner;
        Object obj = null;
        if (customEventBanner == null) {
            C0132a aVar2 = C0132a.INTERNAL_ERROR;
            C0706bc bcVar = (C0706bc) cVar5;
            if (bcVar != null) {
                String valueOf = String.valueOf(aVar2);
                StringBuilder sb = new StringBuilder(valueOf.length() + 47);
                sb.append("Adapter called onFailedToReceiveAd with error. ");
                sb.append(valueOf);
                C0605f.m1030T4(sb.toString());
                C1741ym ymVar = zh2.f11224j.f11225a;
                if (!C1741ym.m8000m()) {
                    C0605f.m995O4("#008 Must be called on the main UI thread.", (Throwable) null);
                    C1741ym.f10953b.post(new C0833ec(bcVar, aVar2));
                    return;
                }
                try {
                    bcVar.f2126a.mo2396o0(C0605f.m1132j0(aVar2));
                } catch (RemoteException e) {
                    C0605f.m995O4("#007 Could not call remote method.", e);
                }
            } else {
                throw null;
            }
        } else {
            if (cVar7 != null) {
                obj = cVar7.f1350a.get(cVar6.f775a);
            }
            Activity activity2 = activity;
            this.f17340a.requestBannerAd(new C4793a(this, cVar), activity2, cVar6.f775a, cVar6.f777c, cVar3, aVar, obj);
        }
    }

    public final void requestInterstitialAd(C0138d dVar, Activity activity, C0145c cVar, C0135a aVar, C0424c cVar2) {
        CustomEventInterstitial customEventInterstitial = (CustomEventInterstitial) m14817a(cVar.f776b);
        this.f17341b = customEventInterstitial;
        Object obj = null;
        if (customEventInterstitial == null) {
            C0132a aVar2 = C0132a.INTERNAL_ERROR;
            C0706bc bcVar = (C0706bc) dVar;
            if (bcVar != null) {
                String valueOf = String.valueOf(aVar2);
                StringBuilder sb = new StringBuilder(valueOf.length() + 47);
                sb.append("Adapter called onFailedToReceiveAd with error ");
                sb.append(valueOf);
                sb.append(".");
                C0605f.m1030T4(sb.toString());
                C1741ym ymVar = zh2.f11224j.f11225a;
                if (!C1741ym.m8000m()) {
                    C0605f.m995O4("#008 Must be called on the main UI thread.", (Throwable) null);
                    C1741ym.f10953b.post(new C0877fc(bcVar, aVar2));
                    return;
                }
                try {
                    bcVar.f2126a.mo2396o0(C0605f.m1132j0(aVar2));
                } catch (RemoteException e) {
                    C0605f.m995O4("#007 Could not call remote method.", e);
                }
            } else {
                throw null;
            }
        } else {
            if (cVar2 != null) {
                obj = cVar2.f1350a.get(cVar.f775a);
            }
            Activity activity2 = activity;
            this.f17341b.requestInterstitialAd(new C4794b(this, this, dVar), activity2, cVar.f775a, cVar.f777c, aVar, obj);
        }
    }

    public final void showInterstitial() {
        this.f17341b.showInterstitial();
    }
}
