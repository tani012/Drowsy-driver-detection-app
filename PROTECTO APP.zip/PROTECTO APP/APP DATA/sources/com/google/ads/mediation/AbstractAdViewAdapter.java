package com.google.ads.mediation;

import android.content.Context;
import android.location.Location;
import android.os.Bundle;
import android.os.RemoteException;
import android.view.View;
import com.google.ads.mediation.admob.AdMobAdapter;
import com.google.android.gms.ads.mediation.MediationBannerAdapter;
import com.google.android.gms.ads.mediation.MediationNativeAdapter;
import com.google.android.gms.ads.reward.mediation.MediationRewardedVideoAdAdapter;
import com.google.android.gms.internal.ads.zzbif;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;
import p002b.p011c.p012a.p013d.C0146h;
import p002b.p011c.p012a.p013d.C0147i;
import p002b.p011c.p015b.p028b.p029a.C0297c;
import p002b.p011c.p015b.p028b.p029a.C0300d;
import p002b.p011c.p015b.p028b.p029a.C0301d0;
import p002b.p011c.p015b.p028b.p029a.C0302e;
import p002b.p011c.p015b.p028b.p029a.C0305f;
import p002b.p011c.p015b.p028b.p029a.C0307h;
import p002b.p011c.p015b.p028b.p029a.C0310k;
import p002b.p011c.p015b.p028b.p029a.C0316q;
import p002b.p011c.p015b.p028b.p029a.C0318r;
import p002b.p011c.p015b.p028b.p029a.p031b0.C0295c;
import p002b.p011c.p015b.p028b.p029a.p031b0.p032d.C0296a;
import p002b.p011c.p015b.p028b.p029a.p034s.C0319a;
import p002b.p011c.p015b.p028b.p029a.p035t.C0328d;
import p002b.p011c.p015b.p028b.p029a.p035t.C0330e;
import p002b.p011c.p015b.p028b.p029a.p035t.C0331f;
import p002b.p011c.p015b.p028b.p029a.p035t.C0332g;
import p002b.p011c.p015b.p028b.p029a.p035t.C0334h;
import p002b.p011c.p015b.p028b.p029a.p035t.C0336i;
import p002b.p011c.p015b.p028b.p029a.p035t.C0340k;
import p002b.p011c.p015b.p028b.p029a.p035t.C0342l;
import p002b.p011c.p015b.p028b.p029a.p035t.C0343m;
import p002b.p011c.p015b.p028b.p029a.p041y.C0404e;
import p002b.p011c.p015b.p028b.p029a.p041y.C0407h;
import p002b.p011c.p015b.p028b.p029a.p041y.C0410k;
import p002b.p011c.p015b.p028b.p029a.p041y.C0412m;
import p002b.p011c.p015b.p028b.p029a.p041y.C0414o;
import p002b.p011c.p015b.p028b.p029a.p041y.C0415p;
import p002b.p011c.p015b.p028b.p029a.p041y.C0416q;
import p002b.p011c.p015b.p028b.p029a.p041y.C0417r;
import p002b.p011c.p015b.p028b.p029a.p041y.C0419t;
import p002b.p011c.p015b.p028b.p029a.p041y.C0420u;
import p002b.p011c.p015b.p028b.p029a.p041y.C0429y;
import p002b.p011c.p015b.p028b.p053e.p061r.C0605f;
import p002b.p011c.p015b.p028b.p064f.C0621a;
import p002b.p011c.p015b.p028b.p064f.C0624b;
import p002b.p011c.p015b.p028b.p068i.p069a.C0738c3;
import p002b.p011c.p015b.p028b.p068i.p069a.C0774d;
import p002b.p011c.p015b.p028b.p068i.p069a.C0823e2;
import p002b.p011c.p015b.p028b.p068i.p069a.C0911g3;
import p002b.p011c.p015b.p028b.p068i.p069a.C1019ih;
import p002b.p011c.p015b.p028b.p068i.p069a.C1206n0;
import p002b.p011c.p015b.p028b.p068i.p069a.C1208n2;
import p002b.p011c.p015b.p028b.p068i.p069a.C1251o4;
import p002b.p011c.p015b.p028b.p068i.p069a.C1473t4;
import p002b.p011c.p015b.p028b.p068i.p069a.C1527u4;
import p002b.p011c.p015b.p028b.p068i.p069a.C1571v4;
import p002b.p011c.p015b.p028b.p068i.p069a.C1578va;
import p002b.p011c.p015b.p028b.p068i.p069a.C1579vb;
import p002b.p011c.p015b.p028b.p068i.p069a.C1616w4;
import p002b.p011c.p015b.p028b.p068i.p069a.C1679x4;
import p002b.p011c.p015b.p028b.p068i.p069a.C1721y4;
import p002b.p011c.p015b.p028b.p068i.p069a.C1735yg;
import p002b.p011c.p015b.p028b.p068i.p069a.C1741ym;
import p002b.p011c.p015b.p028b.p068i.p069a.C1760z4;
import p002b.p011c.p015b.p028b.p068i.p069a.C1767zb;
import p002b.p011c.p015b.p028b.p068i.p069a.ek2;
import p002b.p011c.p015b.p028b.p068i.p069a.el2;
import p002b.p011c.p015b.p028b.p068i.p069a.fh2;
import p002b.p011c.p015b.p028b.p068i.p069a.gk2;
import p002b.p011c.p015b.p028b.p068i.p069a.ih2;
import p002b.p011c.p015b.p028b.p068i.p069a.ik2;
import p002b.p011c.p015b.p028b.p068i.p069a.kh2;
import p002b.p011c.p015b.p028b.p068i.p069a.ki2;
import p002b.p011c.p015b.p028b.p068i.p069a.ni2;
import p002b.p011c.p015b.p028b.p068i.p069a.oh2;
import p002b.p011c.p015b.p028b.p068i.p069a.qh2;
import p002b.p011c.p015b.p028b.p068i.p069a.rh2;
import p002b.p011c.p015b.p028b.p068i.p069a.th2;
import p002b.p011c.p015b.p028b.p068i.p069a.ug2;
import p002b.p011c.p015b.p028b.p068i.p069a.uh2;
import p002b.p011c.p015b.p028b.p068i.p069a.wg2;
import p002b.p011c.p015b.p028b.p068i.p069a.wj2;
import p002b.p011c.p015b.p028b.p068i.p069a.zg2;
import p002b.p011c.p015b.p028b.p068i.p069a.zh2;
import p176d.p178b.p179k.C4851q;

public abstract class AbstractAdViewAdapter implements MediationBannerAdapter, MediationNativeAdapter, C0419t, C0429y, MediationRewardedVideoAdAdapter, zzbif {
    public static final String AD_UNIT_ID_PARAMETER = "pubid";
    public C0307h zzmi;
    public C0310k zzmj;
    public C0300d zzmk;
    public Context zzml;
    public C0310k zzmm;
    public C0296a zzmn;
    public final C0295c zzmo = new C0147i(this);

    /* renamed from: com.google.ads.mediation.AbstractAdViewAdapter$a */
    public static class C4787a extends C0416q {

        /* renamed from: k */
        public final C0334h f17331k;

        public C4787a(C0334h hVar) {
            String str;
            String str2;
            String str3;
            this.f17331k = hVar;
            C0911g3 g3Var = (C0911g3) hVar;
            String str4 = null;
            if (g3Var != null) {
                try {
                    str = g3Var.f3671a.mo2540f();
                } catch (RemoteException e) {
                    C0605f.m1157m4("", e);
                    str = null;
                }
                this.f1330e = str.toString();
                this.f1331f = g3Var.f3672b;
                try {
                    str2 = g3Var.f3671a.mo2541g();
                } catch (RemoteException e2) {
                    C0605f.m1157m4("", e2);
                    str2 = null;
                }
                this.f1332g = str2.toString();
                C1208n2 n2Var = g3Var.f3673c;
                if (n2Var != null) {
                    this.f1333h = n2Var;
                }
                try {
                    str3 = g3Var.f3671a.mo2543h();
                } catch (RemoteException e3) {
                    C0605f.m1157m4("", e3);
                    str3 = null;
                }
                this.f1334i = str3.toString();
                try {
                    str4 = g3Var.f3671a.mo2547u();
                } catch (RemoteException e4) {
                    C0605f.m1157m4("", e4);
                }
                this.f1335j = str4.toString();
                this.f1318a = true;
                this.f1319b = true;
                try {
                    if (g3Var.f3671a.getVideoController() != null) {
                        g3Var.f3674d.mo1060b(g3Var.f3671a.getVideoController());
                    }
                } catch (RemoteException e5) {
                    C0605f.m1157m4("Exception occurred while getting video controller", e5);
                }
                this.f1321d = g3Var.f3674d;
                return;
            }
            throw null;
        }

        /* renamed from: a */
        public final void mo1281a(View view) {
            if (view instanceof C0330e) {
                ((C0330e) view).setNativeAd(this.f17331k);
            }
            if (C0331f.f1161a.get(view) != null) {
                C0621a aVar = (C0621a) this.f17331k.mo1090a();
                C0605f.m1109f5("NativeAdViewHolder.setNativeAd containerView doesn't exist, returning");
            }
        }
    }

    /* renamed from: com.google.ads.mediation.AbstractAdViewAdapter$b */
    public static class C4788b extends C0415p {

        /* renamed from: m */
        public final C0332g f17332m;

        public C4788b(C0332g gVar) {
            String str;
            String str2;
            String str3;
            String str4;
            String str5;
            String str6;
            this.f17332m = gVar;
            C0738c3 c3Var = (C0738c3) gVar;
            String str7 = null;
            if (c3Var != null) {
                try {
                    str = c3Var.f2362a.mo1824f();
                } catch (RemoteException e) {
                    C0605f.m1157m4("", e);
                    str = null;
                }
                this.f1322e = str.toString();
                this.f1323f = c3Var.f2363b;
                try {
                    str2 = c3Var.f2362a.mo1825g();
                } catch (RemoteException e2) {
                    C0605f.m1157m4("", e2);
                    str2 = null;
                }
                this.f1324g = str2.toString();
                this.f1325h = c3Var.f2364c;
                try {
                    str3 = c3Var.f2362a.mo1827h();
                } catch (RemoteException e3) {
                    C0605f.m1157m4("", e3);
                    str3 = null;
                }
                this.f1326i = str3.toString();
                if (gVar.mo1102b() != null) {
                    this.f1327j = gVar.mo1102b().doubleValue();
                }
                try {
                    str4 = c3Var.f2362a.mo1835w();
                } catch (RemoteException e4) {
                    C0605f.m1157m4("", e4);
                    str4 = null;
                }
                if (str4 != null) {
                    try {
                        str6 = c3Var.f2362a.mo1835w();
                    } catch (RemoteException e5) {
                        C0605f.m1157m4("", e5);
                        str6 = null;
                    }
                    this.f1328k = str6.toString();
                }
                try {
                    str5 = c3Var.f2362a.mo1833r();
                } catch (RemoteException e6) {
                    C0605f.m1157m4("", e6);
                    str5 = null;
                }
                if (str5 != null) {
                    try {
                        str7 = c3Var.f2362a.mo1833r();
                    } catch (RemoteException e7) {
                        C0605f.m1157m4("", e7);
                    }
                    this.f1329l = str7.toString();
                }
                this.f1318a = true;
                this.f1319b = true;
                try {
                    if (c3Var.f2362a.getVideoController() != null) {
                        c3Var.f2365d.mo1060b(c3Var.f2362a.getVideoController());
                    }
                } catch (RemoteException e8) {
                    C0605f.m1157m4("Exception occurred while getting video controller", e8);
                }
                this.f1321d = c3Var.f2365d;
                return;
            }
            throw null;
        }

        /* renamed from: a */
        public final void mo1281a(View view) {
            if (view instanceof C0330e) {
                ((C0330e) view).setNativeAd(this.f17332m);
            }
            C0331f fVar = C0331f.f1161a.get(view);
            if (fVar != null) {
                fVar.mo1100a(this.f17332m);
            }
        }
    }

    /* renamed from: com.google.ads.mediation.AbstractAdViewAdapter$c */
    public static final class C4789c extends C0297c implements C0319a, ug2 {

        /* renamed from: e */
        public final AbstractAdViewAdapter f17333e;

        /* renamed from: f */
        public final C0407h f17334f;

        public C4789c(AbstractAdViewAdapter abstractAdViewAdapter, C0407h hVar) {
            this.f17333e = abstractAdViewAdapter;
            this.f17334f = hVar;
        }

        /* renamed from: a */
        public final void mo1022a() {
            C1579vb vbVar = (C1579vb) this.f17334f;
            if (vbVar != null) {
                C4851q.C4862i.m15152n("#008 Must be called on the main UI thread.");
                C0605f.m1030T4("Adapter called onAdClosed.");
                try {
                    vbVar.f9972a.mo2379H();
                } catch (RemoteException e) {
                    C0605f.m995O4("#007 Could not call remote method.", e);
                }
            } else {
                throw null;
            }
        }

        /* renamed from: b */
        public final void mo1023b(int i) {
            ((C1579vb) this.f17334f).mo4634b(this.f17333e, i);
        }

        /* renamed from: e */
        public final void mo1025e() {
            C1579vb vbVar = (C1579vb) this.f17334f;
            if (vbVar != null) {
                C4851q.C4862i.m15152n("#008 Must be called on the main UI thread.");
                C0605f.m1030T4("Adapter called onAdLeftApplication.");
                try {
                    vbVar.f9972a.mo2385S();
                } catch (RemoteException e) {
                    C0605f.m995O4("#007 Could not call remote method.", e);
                }
            } else {
                throw null;
            }
        }

        /* renamed from: f */
        public final void mo840f() {
            C1579vb vbVar = (C1579vb) this.f17334f;
            if (vbVar != null) {
                C4851q.C4862i.m15152n("#008 Must be called on the main UI thread.");
                C0605f.m1030T4("Adapter called onAdLoaded.");
                try {
                    vbVar.f9972a.mo2386T();
                } catch (RemoteException e) {
                    C0605f.m995O4("#007 Could not call remote method.", e);
                }
            } else {
                throw null;
            }
        }

        /* renamed from: g */
        public final void mo1026g() {
            C1579vb vbVar = (C1579vb) this.f17334f;
            if (vbVar != null) {
                C4851q.C4862i.m15152n("#008 Must be called on the main UI thread.");
                C0605f.m1030T4("Adapter called onAdOpened.");
                try {
                    vbVar.f9972a.mo2381L();
                } catch (RemoteException e) {
                    C0605f.m995O4("#007 Could not call remote method.", e);
                }
            } else {
                throw null;
            }
        }

        /* renamed from: o */
        public final void mo1027o() {
            C1579vb vbVar = (C1579vb) this.f17334f;
            if (vbVar != null) {
                C4851q.C4862i.m15152n("#008 Must be called on the main UI thread.");
                C0605f.m1030T4("Adapter called onAdClicked.");
                try {
                    vbVar.f9972a.mo2395o();
                } catch (RemoteException e) {
                    C0605f.m995O4("#007 Could not call remote method.", e);
                }
            } else {
                throw null;
            }
        }

        /* renamed from: x */
        public final void mo1065x(String str, String str2) {
            C1579vb vbVar = (C1579vb) this.f17334f;
            if (vbVar != null) {
                C4851q.C4862i.m15152n("#008 Must be called on the main UI thread.");
                C0605f.m1030T4("Adapter called onAppEvent.");
                try {
                    vbVar.f9972a.mo2400x(str, str2);
                } catch (RemoteException e) {
                    C0605f.m995O4("#007 Could not call remote method.", e);
                }
            } else {
                throw null;
            }
        }
    }

    /* renamed from: com.google.ads.mediation.AbstractAdViewAdapter$d */
    public static class C4790d extends C0420u {

        /* renamed from: o */
        public final C0340k f17335o;

        /* JADX WARNING: Removed duplicated region for block: B:44:0x0089 A[Catch:{ RemoteException -> 0x008e }] */
        /* JADX WARNING: Removed duplicated region for block: B:51:0x00a1 A[Catch:{ RemoteException -> 0x00ad }] */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public C4790d(p002b.p011c.p015b.p028b.p029a.p035t.C0340k r7) {
            /*
                r6 = this;
                java.lang.String r0 = ""
                r6.<init>()
                r6.f17335o = r7
                b.c.b.b.i.a.o4 r7 = (p002b.p011c.p015b.p028b.p068i.p069a.C1251o4) r7
                r1 = 0
                if (r7 == 0) goto L_0x00b8
                b.c.b.b.i.a.n4 r2 = r7.f6621a     // Catch:{ RemoteException -> 0x0013 }
                java.lang.String r2 = r2.mo3759f()     // Catch:{ RemoteException -> 0x0013 }
                goto L_0x0018
            L_0x0013:
                r2 = move-exception
                p002b.p011c.p015b.p028b.p053e.p061r.C0605f.m1157m4(r0, r2)
                r2 = r1
            L_0x0018:
                r6.f1336a = r2
                java.util.List<b.c.b.b.a.t.c$b> r2 = r7.f6622b
                r6.f1337b = r2
                b.c.b.b.i.a.n4 r2 = r7.f6621a     // Catch:{ RemoteException -> 0x0025 }
                java.lang.String r2 = r2.mo3760g()     // Catch:{ RemoteException -> 0x0025 }
                goto L_0x002a
            L_0x0025:
                r2 = move-exception
                p002b.p011c.p015b.p028b.p053e.p061r.C0605f.m1157m4(r0, r2)
                r2 = r1
            L_0x002a:
                r6.f1338c = r2
                b.c.b.b.i.a.n2 r2 = r7.f6623c
                r6.f1339d = r2
                b.c.b.b.i.a.n4 r2 = r7.f6621a     // Catch:{ RemoteException -> 0x0037 }
                java.lang.String r2 = r2.mo3762h()     // Catch:{ RemoteException -> 0x0037 }
                goto L_0x003c
            L_0x0037:
                r2 = move-exception
                p002b.p011c.p015b.p028b.p053e.p061r.C0605f.m1157m4(r0, r2)
                r2 = r1
            L_0x003c:
                r6.f1340e = r2
                b.c.b.b.i.a.n4 r2 = r7.f6621a     // Catch:{ RemoteException -> 0x0045 }
                java.lang.String r2 = r2.mo3771u()     // Catch:{ RemoteException -> 0x0045 }
                goto L_0x004a
            L_0x0045:
                r2 = move-exception
                p002b.p011c.p015b.p028b.p053e.p061r.C0605f.m1157m4(r0, r2)
                r2 = r1
            L_0x004a:
                r6.f1341f = r2
                b.c.b.b.i.a.n4 r2 = r7.f6621a     // Catch:{ RemoteException -> 0x005e }
                double r2 = r2.mo3768m()     // Catch:{ RemoteException -> 0x005e }
                r4 = -4616189618054758400(0xbff0000000000000, double:-1.0)
                int r4 = (r2 > r4 ? 1 : (r2 == r4 ? 0 : -1))
                if (r4 != 0) goto L_0x0059
                goto L_0x0062
            L_0x0059:
                java.lang.Double r2 = java.lang.Double.valueOf(r2)     // Catch:{ RemoteException -> 0x005e }
                goto L_0x0063
            L_0x005e:
                r2 = move-exception
                p002b.p011c.p015b.p028b.p053e.p061r.C0605f.m1157m4(r0, r2)
            L_0x0062:
                r2 = r1
            L_0x0063:
                r6.f1342g = r2
                b.c.b.b.i.a.n4 r2 = r7.f6621a     // Catch:{ RemoteException -> 0x006c }
                java.lang.String r2 = r2.mo3775w()     // Catch:{ RemoteException -> 0x006c }
                goto L_0x0071
            L_0x006c:
                r2 = move-exception
                p002b.p011c.p015b.p028b.p053e.p061r.C0605f.m1157m4(r0, r2)
                r2 = r1
            L_0x0071:
                r6.f1343h = r2
                b.c.b.b.i.a.n4 r2 = r7.f6621a     // Catch:{ RemoteException -> 0x007a }
                java.lang.String r2 = r2.mo3770r()     // Catch:{ RemoteException -> 0x007a }
                goto L_0x007f
            L_0x007a:
                r2 = move-exception
                p002b.p011c.p015b.p028b.p053e.p061r.C0605f.m1157m4(r0, r2)
                r2 = r1
            L_0x007f:
                r6.f1344i = r2
                b.c.b.b.i.a.n4 r2 = r7.f6621a     // Catch:{ RemoteException -> 0x008e }
                b.c.b.b.f.a r2 = r2.mo3765j()     // Catch:{ RemoteException -> 0x008e }
                if (r2 == 0) goto L_0x0092
                java.lang.Object r1 = p002b.p011c.p015b.p028b.p064f.C0624b.m1273A2(r2)     // Catch:{ RemoteException -> 0x008e }
                goto L_0x0092
            L_0x008e:
                r2 = move-exception
                p002b.p011c.p015b.p028b.p053e.p061r.C0605f.m1157m4(r0, r2)
            L_0x0092:
                r6.f1346k = r1
                r0 = 1
                r6.f1348m = r0
                r6.f1349n = r0
                b.c.b.b.i.a.n4 r0 = r7.f6621a     // Catch:{ RemoteException -> 0x00ad }
                b.c.b.b.i.a.wj2 r0 = r0.getVideoController()     // Catch:{ RemoteException -> 0x00ad }
                if (r0 == 0) goto L_0x00b3
                b.c.b.b.a.q r0 = r7.f6624d     // Catch:{ RemoteException -> 0x00ad }
                b.c.b.b.i.a.n4 r1 = r7.f6621a     // Catch:{ RemoteException -> 0x00ad }
                b.c.b.b.i.a.wj2 r1 = r1.getVideoController()     // Catch:{ RemoteException -> 0x00ad }
                r0.mo1060b(r1)     // Catch:{ RemoteException -> 0x00ad }
                goto L_0x00b3
            L_0x00ad:
                r0 = move-exception
                java.lang.String r1 = "Exception occurred while getting video controller"
                p002b.p011c.p015b.p028b.p053e.p061r.C0605f.m1157m4(r1, r0)
            L_0x00b3:
                b.c.b.b.a.q r7 = r7.f6624d
                r6.f1345j = r7
                return
            L_0x00b8:
                throw r1
            */
            throw new UnsupportedOperationException("Method not decompiled: com.google.ads.mediation.AbstractAdViewAdapter.C4790d.<init>(b.c.b.b.a.t.k):void");
        }

        /* renamed from: a */
        public final void mo1284a(View view, Map<String, View> map, Map<String, View> map2) {
            if (view instanceof C0342l) {
                ((C0342l) view).setNativeAd(this.f17335o);
                return;
            }
            C0331f fVar = C0331f.f1161a.get(view);
            if (fVar != null) {
                C1251o4 o4Var = (C1251o4) this.f17335o;
                C0621a aVar = null;
                if (o4Var != null) {
                    try {
                        aVar = o4Var.f6621a.mo3773v();
                    } catch (RemoteException e) {
                        C0605f.m1157m4("", e);
                    }
                    fVar.mo1101b(aVar);
                    return;
                }
                throw null;
            }
        }
    }

    /* renamed from: com.google.ads.mediation.AbstractAdViewAdapter$e */
    public static final class C4791e extends C0297c implements C0332g.C0333a, C0334h.C0335a, C0336i.C0337a, C0336i.C0338b, C0340k.C0341a {

        /* renamed from: e */
        public final AbstractAdViewAdapter f17336e;

        /* renamed from: f */
        public final C0412m f17337f;

        public C4791e(AbstractAdViewAdapter abstractAdViewAdapter, C0412m mVar) {
            this.f17336e = abstractAdViewAdapter;
            this.f17337f = mVar;
        }

        /* renamed from: a */
        public final void mo1022a() {
            C1579vb vbVar = (C1579vb) this.f17337f;
            if (vbVar != null) {
                C4851q.C4862i.m15152n("#008 Must be called on the main UI thread.");
                C0605f.m1030T4("Adapter called onAdClosed.");
                try {
                    vbVar.f9972a.mo2379H();
                } catch (RemoteException e) {
                    C0605f.m995O4("#007 Could not call remote method.", e);
                }
            } else {
                throw null;
            }
        }

        /* renamed from: b */
        public final void mo1023b(int i) {
            ((C1579vb) this.f17337f).mo4636d(this.f17336e, i);
        }

        /* renamed from: d */
        public final void mo1024d() {
            C1579vb vbVar = (C1579vb) this.f17337f;
            if (vbVar != null) {
                C4851q.C4862i.m15152n("#008 Must be called on the main UI thread.");
                C0414o oVar = vbVar.f9973b;
                C0420u uVar = vbVar.f9974c;
                if (vbVar.f9975d == null) {
                    if (oVar == null && uVar == null) {
                        C0605f.m995O4("#007 Could not call remote method.", (Throwable) null);
                        return;
                    } else if ((uVar != null && !uVar.f1348m) || (oVar != null && !oVar.f1318a)) {
                        C0605f.m1030T4("Could not call onAdImpression since setOverrideImpressionRecording is not set to true");
                        return;
                    }
                }
                C0605f.m1030T4("Adapter called onAdImpression.");
                try {
                    vbVar.f9972a.mo2387V();
                } catch (RemoteException e) {
                    C0605f.m995O4("#007 Could not call remote method.", e);
                }
            } else {
                throw null;
            }
        }

        /* renamed from: e */
        public final void mo1025e() {
            C1579vb vbVar = (C1579vb) this.f17337f;
            if (vbVar != null) {
                C4851q.C4862i.m15152n("#008 Must be called on the main UI thread.");
                C0605f.m1030T4("Adapter called onAdLeftApplication.");
                try {
                    vbVar.f9972a.mo2385S();
                } catch (RemoteException e) {
                    C0605f.m995O4("#007 Could not call remote method.", e);
                }
            } else {
                throw null;
            }
        }

        /* renamed from: f */
        public final void mo840f() {
        }

        /* renamed from: g */
        public final void mo1026g() {
            C1579vb vbVar = (C1579vb) this.f17337f;
            if (vbVar != null) {
                C4851q.C4862i.m15152n("#008 Must be called on the main UI thread.");
                C0605f.m1030T4("Adapter called onAdOpened.");
                try {
                    vbVar.f9972a.mo2381L();
                } catch (RemoteException e) {
                    C0605f.m995O4("#007 Could not call remote method.", e);
                }
            } else {
                throw null;
            }
        }

        /* renamed from: o */
        public final void mo1027o() {
            C1579vb vbVar = (C1579vb) this.f17337f;
            if (vbVar != null) {
                C4851q.C4862i.m15152n("#008 Must be called on the main UI thread.");
                C0414o oVar = vbVar.f9973b;
                C0420u uVar = vbVar.f9974c;
                if (vbVar.f9975d == null) {
                    if (oVar == null && uVar == null) {
                        C0605f.m995O4("#007 Could not call remote method.", (Throwable) null);
                        return;
                    } else if ((uVar != null && !uVar.f1349n) || (oVar != null && !oVar.f1319b)) {
                        C0605f.m1030T4("Could not call onAdClicked since setOverrideClickHandling is not set to true");
                        return;
                    }
                }
                C0605f.m1030T4("Adapter called onAdClicked.");
                try {
                    vbVar.f9972a.mo2395o();
                } catch (RemoteException e) {
                    C0605f.m995O4("#007 Could not call remote method.", e);
                }
            } else {
                throw null;
            }
        }
    }

    /* renamed from: com.google.ads.mediation.AbstractAdViewAdapter$f */
    public static final class C4792f extends C0297c implements ug2 {

        /* renamed from: e */
        public final AbstractAdViewAdapter f17338e;

        /* renamed from: f */
        public final C0410k f17339f;

        public C4792f(AbstractAdViewAdapter abstractAdViewAdapter, C0410k kVar) {
            this.f17338e = abstractAdViewAdapter;
            this.f17339f = kVar;
        }

        /* renamed from: a */
        public final void mo1022a() {
            ((C1579vb) this.f17339f).mo4633a(this.f17338e);
        }

        /* renamed from: b */
        public final void mo1023b(int i) {
            ((C1579vb) this.f17339f).mo4635c(this.f17338e, i);
        }

        /* renamed from: e */
        public final void mo1025e() {
            C1579vb vbVar = (C1579vb) this.f17339f;
            if (vbVar != null) {
                C4851q.C4862i.m15152n("#008 Must be called on the main UI thread.");
                C0605f.m1030T4("Adapter called onAdLeftApplication.");
                try {
                    vbVar.f9972a.mo2385S();
                } catch (RemoteException e) {
                    C0605f.m995O4("#007 Could not call remote method.", e);
                }
            } else {
                throw null;
            }
        }

        /* renamed from: f */
        public final void mo840f() {
            ((C1579vb) this.f17339f).mo4637e(this.f17338e);
        }

        /* renamed from: g */
        public final void mo1026g() {
            ((C1579vb) this.f17339f).mo4639g(this.f17338e);
        }

        /* renamed from: o */
        public final void mo1027o() {
            C1579vb vbVar = (C1579vb) this.f17339f;
            if (vbVar != null) {
                C4851q.C4862i.m15152n("#008 Must be called on the main UI thread.");
                C0605f.m1030T4("Adapter called onAdClicked.");
                try {
                    vbVar.f9972a.mo2395o();
                } catch (RemoteException e) {
                    C0605f.m995O4("#007 Could not call remote method.", e);
                }
            } else {
                throw null;
            }
        }
    }

    private final C0302e zza(Context context, C0404e eVar, Bundle bundle, Bundle bundle2) {
        Class<AdMobAdapter> cls = AdMobAdapter.class;
        C0302e.C0303a aVar = new C0302e.C0303a();
        Date b = eVar.mo1272b();
        if (b != null) {
            aVar.f1112a.f4274g = b;
        }
        int g = eVar.mo1277g();
        if (g != 0) {
            aVar.f1112a.f4277j = g;
        }
        Set<String> d = eVar.mo1274d();
        if (d != null) {
            for (String add : d) {
                aVar.f1112a.f4268a.add(add);
            }
        }
        Location f = eVar.mo1276f();
        if (f != null) {
            aVar.f1112a.f4278k = f;
        }
        if (eVar.mo1273c()) {
            C1741ym ymVar = zh2.f11224j.f11225a;
            aVar.f1112a.f4271d.add(C1741ym.m7992e(context));
        }
        if (eVar.mo1275e() != -1) {
            int i = 1;
            if (eVar.mo1275e() != 1) {
                i = 0;
            }
            aVar.f1112a.f4282o = i;
        }
        aVar.f1112a.f4283p = eVar.mo1271a();
        Bundle zza = zza(bundle, bundle2);
        aVar.f1112a.f4269b.putBundle(cls.getName(), zza);
        if (cls.equals(cls) && zza.getBoolean("_emulatorLiveAds")) {
            aVar.f1112a.f4271d.remove("B3EEABB8EE11C2BE770B684D95219ECB");
        }
        return new C0302e(aVar, (C0301d0) null);
    }

    public String getAdUnitId(Bundle bundle) {
        return bundle.getString(AD_UNIT_ID_PARAMETER);
    }

    public View getBannerView() {
        return this.zzmi;
    }

    public Bundle getInterstitialAdapterInfo() {
        Bundle bundle = new Bundle();
        bundle.putInt("capabilities", 1);
        return bundle;
    }

    public wj2 getVideoController() {
        C0316q videoController;
        C0307h hVar = this.zzmi;
        if (hVar == null || (videoController = hVar.getVideoController()) == null) {
            return null;
        }
        return videoController.mo1061c();
    }

    public void initialize(Context context, C0404e eVar, String str, C0296a aVar, Bundle bundle, Bundle bundle2) {
        this.zzml = context.getApplicationContext();
        this.zzmn = aVar;
        C1019ih ihVar = (C1019ih) aVar;
        if (ihVar != null) {
            C4851q.C4862i.m15152n("#008 Must be called on the main UI thread.");
            C0605f.m1030T4("Adapter called onInitializationSucceeded.");
            try {
                ihVar.f4517a.mo2171X6(new C0624b(this));
            } catch (RemoteException e) {
                C0605f.m995O4("#007 Could not call remote method.", e);
            }
        } else {
            throw null;
        }
    }

    public boolean isInitialized() {
        return this.zzmn != null;
    }

    public void loadAd(C0404e eVar, Bundle bundle, Bundle bundle2) {
        Context context = this.zzml;
        if (context == null || this.zzmn == null) {
            C0605f.m1095d5("AdMobAdapter.loadAd called before initialize.");
            return;
        }
        C0310k kVar = new C0310k(context);
        this.zzmm = kVar;
        kVar.f1129a.f4549i = true;
        kVar.mo1055c(getAdUnitId(bundle));
        C0310k kVar2 = this.zzmm;
        C0295c cVar = this.zzmo;
        ik2 ik2 = kVar2.f1129a;
        if (ik2 != null) {
            try {
                ik2.f4548h = cVar;
                if (ik2.f4545e != null) {
                    ik2.f4545e.mo1248s0(cVar != null ? new C1735yg(cVar) : null);
                }
            } catch (RemoteException e) {
                C0605f.m995O4("#007 Could not call remote method.", e);
            }
            C0310k kVar3 = this.zzmm;
            C0146h hVar = new C0146h(this);
            ik2 ik22 = kVar3.f1129a;
            if (ik22 != null) {
                try {
                    ik22.f4547g = hVar;
                    if (ik22.f4545e != null) {
                        ik22.f4545e.mo1246q0(new fh2(hVar));
                    }
                } catch (RemoteException e2) {
                    C0605f.m995O4("#007 Could not call remote method.", e2);
                }
                this.zzmm.mo1053a(zza(this.zzml, eVar, bundle2, bundle));
                return;
            }
            throw null;
        }
        throw null;
    }

    public void onDestroy() {
        C0307h hVar = this.zzmi;
        if (hVar != null) {
            gk2 gk2 = hVar.f1128e;
            if (gk2 != null) {
                try {
                    if (gk2.f3846h != null) {
                        gk2.f3846h.destroy();
                    }
                } catch (RemoteException e) {
                    C0605f.m995O4("#007 Could not call remote method.", e);
                }
                this.zzmi = null;
            } else {
                throw null;
            }
        }
        if (this.zzmj != null) {
            this.zzmj = null;
        }
        if (this.zzmk != null) {
            this.zzmk = null;
        }
        if (this.zzmm != null) {
            this.zzmm = null;
        }
    }

    public void onImmersiveModeUpdated(boolean z) {
        C0310k kVar = this.zzmj;
        if (kVar != null) {
            kVar.mo1056d(z);
        }
        C0310k kVar2 = this.zzmm;
        if (kVar2 != null) {
            kVar2.mo1056d(z);
        }
    }

    public void onPause() {
        C0307h hVar = this.zzmi;
        if (hVar != null) {
            gk2 gk2 = hVar.f1128e;
            if (gk2 != null) {
                try {
                    if (gk2.f3846h != null) {
                        gk2.f3846h.mo1250t();
                    }
                } catch (RemoteException e) {
                    C0605f.m995O4("#007 Could not call remote method.", e);
                }
            } else {
                throw null;
            }
        }
    }

    public void onResume() {
        C0307h hVar = this.zzmi;
        if (hVar != null) {
            gk2 gk2 = hVar.f1128e;
            if (gk2 != null) {
                try {
                    if (gk2.f3846h != null) {
                        gk2.f3846h.mo1226I();
                    }
                } catch (RemoteException e) {
                    C0605f.m995O4("#007 Could not call remote method.", e);
                }
            } else {
                throw null;
            }
        }
    }

    public void requestBannerAd(Context context, C0407h hVar, Bundle bundle, C0305f fVar, C0404e eVar, Bundle bundle2) {
        Object obj;
        C0307h hVar2 = new C0307h(context);
        this.zzmi = hVar2;
        hVar2.setAdSize(new C0305f(fVar.f1123a, fVar.f1124b));
        this.zzmi.setAdUnitId(getAdUnitId(bundle));
        this.zzmi.setAdListener(new C4789c(this, hVar));
        C0307h hVar3 = this.zzmi;
        C0302e zza = zza(context, eVar, bundle2, bundle);
        gk2 gk2 = hVar3.f1128e;
        ek2 ek2 = zza.f1111a;
        if (gk2 != null) {
            try {
                if (gk2.f3846h == null) {
                    if ((gk2.f3844f == null || gk2.f3849k == null) && gk2.f3846h == null) {
                        throw new IllegalStateException("The ad size and ad unit ID must be set before loadAd is called.");
                    }
                    Context context2 = gk2.f3850l.getContext();
                    kh2 h = gk2.m3016h(context2, gk2.f3844f, gk2.f3851m);
                    if ("search_v2".equals(h.f5367e)) {
                        obj = new th2(zh2.f11224j.f11226b, context2, h, gk2.f3849k).mo1660b(context2, false);
                    } else {
                        obj = new qh2(zh2.f11224j.f11226b, context2, h, gk2.f3849k, gk2.f3839a).mo1660b(context2, false);
                    }
                    ni2 ni2 = (ni2) obj;
                    gk2.f3846h = ni2;
                    ni2.mo1220D1(new zg2(gk2.f3841c));
                    if (gk2.f3842d != null) {
                        gk2.f3846h.mo1242j4(new wg2(gk2.f3842d));
                    }
                    if (gk2.f3845g != null) {
                        gk2.f3846h.mo1235a2(new oh2(gk2.f3845g));
                    }
                    if (gk2.f3847i != null) {
                        gk2.f3846h.mo1243j6(new C1206n0(gk2.f3847i));
                    }
                    if (gk2.f3848j != null) {
                        gk2.f3846h.mo1231P5(new C0774d(gk2.f3848j));
                    }
                    gk2.f3846h.mo1221E(new el2(gk2.f3853o));
                    gk2.f3846h.mo1245p2(gk2.f3852n);
                    try {
                        C0621a c7 = gk2.f3846h.mo1237c7();
                        if (c7 != null) {
                            gk2.f3850l.addView((View) C0624b.m1273A2(c7));
                        }
                    } catch (RemoteException e) {
                        C0605f.m995O4("#007 Could not call remote method.", e);
                    }
                }
                if (gk2.f3846h.mo1228K5(ih2.m3448a(gk2.f3850l.getContext(), ek2))) {
                    gk2.f3839a.f9965e = ek2.f3253i;
                }
            } catch (RemoteException e2) {
                C0605f.m995O4("#007 Could not call remote method.", e2);
            }
        } else {
            throw null;
        }
    }

    public void requestInterstitialAd(Context context, C0410k kVar, Bundle bundle, C0404e eVar, Bundle bundle2) {
        C0310k kVar2 = new C0310k(context);
        this.zzmj = kVar2;
        kVar2.mo1055c(getAdUnitId(bundle));
        this.zzmj.mo1054b(new C4792f(this, kVar));
        this.zzmj.mo1053a(zza(context, eVar, bundle2, bundle));
    }

    public void requestNativeAd(Context context, C0412m mVar, Bundle bundle, C0417r rVar, Bundle bundle2) {
        C0328d dVar;
        C0300d dVar2;
        C0774d dVar3;
        C4791e eVar = new C4791e(this, mVar);
        String string = bundle.getString(AD_UNIT_ID_PARAMETER);
        C4851q.C4862i.m15173u(context, "context cannot be null");
        rh2 rh2 = zh2.f11224j.f11226b;
        C1578va vaVar = new C1578va();
        if (rh2 != null) {
            uh2 uh2 = new uh2(rh2, context, string, vaVar);
            boolean z = false;
            ki2 ki2 = (ki2) uh2.mo1660b(context, false);
            try {
                ki2.mo3352v6(new zg2(eVar));
            } catch (RemoteException e) {
                C0605f.m918D4("Failed to set AdListener.", e);
            }
            C1767zb zbVar = (C1767zb) rVar;
            if (zbVar.f11172g == null) {
                dVar = null;
            } else {
                C0328d.C0329a aVar = new C0328d.C0329a();
                C0823e2 e2Var = zbVar.f11172g;
                aVar.f1154a = e2Var.f3056f;
                aVar.f1155b = e2Var.f3057g;
                aVar.f1157d = e2Var.f3058h;
                if (e2Var.f3055e >= 2) {
                    aVar.f1159f = e2Var.f3059i;
                }
                C0823e2 e2Var2 = zbVar.f11172g;
                if (e2Var2.f3055e >= 3 && (dVar3 = e2Var2.f3060j) != null) {
                    aVar.f1158e = new C0318r(dVar3);
                }
                dVar = new C0328d(aVar, (C0343m) null);
            }
            if (dVar != null) {
                try {
                    ki2.mo3345S3(new C0823e2(dVar));
                } catch (RemoteException e2) {
                    C0605f.m918D4("Failed to specify native ad options", e2);
                }
            }
            List<String> list = zbVar.f11173h;
            if (list != null && list.contains("6")) {
                try {
                    ki2.mo3341B2(new C1760z4(eVar));
                } catch (RemoteException e3) {
                    C0605f.m918D4("Failed to add google native ad listener", e3);
                }
            }
            List<String> list2 = zbVar.f11173h;
            if (list2 != null && (list2.contains("2") || zbVar.f11173h.contains("6"))) {
                try {
                    ki2.mo3348i7(new C1721y4(eVar));
                } catch (RemoteException e4) {
                    C0605f.m918D4("Failed to add app install ad listener", e4);
                }
            }
            List<String> list3 = zbVar.f11173h;
            if (list3 != null && (list3.contains("1") || zbVar.f11173h.contains("6"))) {
                try {
                    ki2.mo3344N5(new C1679x4(eVar));
                } catch (RemoteException e5) {
                    C0605f.m918D4("Failed to add content ad listener", e5);
                }
            }
            List<String> list4 = zbVar.f11173h;
            if (list4 != null && list4.contains("3")) {
                z = true;
            }
            if (z) {
                for (String next : zbVar.f11175j.keySet()) {
                    C1527u4 u4Var = new C1527u4(eVar, zbVar.f11175j.get(next).booleanValue() ? eVar : null);
                    try {
                        ki2.mo3351u2(next, new C1571v4(u4Var, (C1473t4) null), u4Var.f9163b == null ? null : new C1616w4(u4Var, (C1473t4) null));
                    } catch (RemoteException e6) {
                        C0605f.m918D4("Failed to add custom template ad listener", e6);
                    }
                }
            }
            try {
                dVar2 = new C0300d(context, ki2.mo3350o2());
            } catch (RemoteException e7) {
                C0605f.m1157m4("Failed to build AdLoader.", e7);
                dVar2 = null;
            }
            this.zzmk = dVar2;
            C0302e zza = zza(context, rVar, bundle2, bundle);
            if (dVar2 != null) {
                try {
                    dVar2.f1110b.mo2608l4(ih2.m3448a(dVar2.f1109a, zza.f1111a));
                } catch (RemoteException e8) {
                    C0605f.m1157m4("Failed to load ad.", e8);
                }
            } else {
                throw null;
            }
        } else {
            throw null;
        }
    }

    public void showInterstitial() {
        this.zzmj.mo1057e();
    }

    public void showVideo() {
        this.zzmm.mo1057e();
    }

    public abstract Bundle zza(Bundle bundle, Bundle bundle2);
}
