package com.google.ads.mediation.customevent;

import android.app.Activity;
import p002b.p011c.p012a.C0134c;
import p002b.p011c.p012a.p013d.C0135a;
import p002b.p011c.p012a.p013d.p014g.C0143a;

@Deprecated
public interface CustomEventBanner {
    /* synthetic */ void destroy();

    void requestBannerAd(C0143a aVar, Activity activity, String str, String str2, C0134c cVar, C0135a aVar2, Object obj);
}
