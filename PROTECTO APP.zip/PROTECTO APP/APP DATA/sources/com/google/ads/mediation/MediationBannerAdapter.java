package com.google.ads.mediation;

import android.app.Activity;
import android.view.View;
import p002b.p011c.p012a.C0134c;
import p002b.p011c.p012a.p013d.C0135a;
import p002b.p011c.p012a.p013d.C0136b;
import p002b.p011c.p012a.p013d.C0137c;
import p002b.p011c.p012a.p013d.C0139e;
import p002b.p011c.p012a.p013d.C0142f;

@Deprecated
public interface MediationBannerAdapter<ADDITIONAL_PARAMETERS extends C0142f, SERVER_PARAMETERS extends C0139e> extends C0136b<ADDITIONAL_PARAMETERS, SERVER_PARAMETERS> {
    /* synthetic */ void destroy();

    /* synthetic */ Class<ADDITIONAL_PARAMETERS> getAdditionalParametersType();

    View getBannerView();

    /* synthetic */ Class<SERVER_PARAMETERS> getServerParametersType();

    void requestBannerAd(C0137c cVar, Activity activity, SERVER_PARAMETERS server_parameters, C0134c cVar2, C0135a aVar, ADDITIONAL_PARAMETERS additional_parameters);
}
