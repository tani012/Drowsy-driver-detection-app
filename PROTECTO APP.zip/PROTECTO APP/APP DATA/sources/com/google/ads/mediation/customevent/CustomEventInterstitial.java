package com.google.ads.mediation.customevent;

import android.app.Activity;
import p002b.p011c.p012a.p013d.C0135a;
import p002b.p011c.p012a.p013d.p014g.C0144b;

@Deprecated
public interface CustomEventInterstitial {
    /* synthetic */ void destroy();

    void requestInterstitialAd(C0144b bVar, Activity activity, String str, String str2, C0135a aVar, Object obj);

    void showInterstitial();
}
