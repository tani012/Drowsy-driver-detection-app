package com.google.android.gms.vision.face;

import com.google.android.gms.vision.face.internal.client.FaceParcel;
import p002b.p011c.p015b.p028b.p064f.C0621a;
import p002b.p011c.p015b.p028b.p068i.p081m.C3350w7;
import p002b.p011c.p015b.p028b.p090o.p092d.p093e.p094a.C3759g;

public class NativeFaceDetectorImpl extends C3759g {
    /* renamed from: K */
    public final void mo8139K() {
        throw new NoSuchMethodError();
    }

    /* renamed from: m1 */
    public final boolean mo8140m1(int i) {
        throw new NoSuchMethodError();
    }

    /* renamed from: n1 */
    public final FaceParcel[] mo8141n1(C0621a aVar, C3350w7 w7Var) {
        throw new NoSuchMethodError();
    }

    /* renamed from: q3 */
    public final FaceParcel[] mo8142q3(C0621a aVar, C0621a aVar2, C0621a aVar3, int i, int i2, int i3, int i4, int i5, int i6, C3350w7 w7Var) {
        throw new NoSuchMethodError();
    }
}
