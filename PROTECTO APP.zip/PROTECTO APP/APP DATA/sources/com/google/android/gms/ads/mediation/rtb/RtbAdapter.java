package com.google.android.gms.ads.mediation.rtb;

import javax.annotation.ParametersAreNonnullByDefault;
import p002b.p011c.p015b.p028b.p029a.p041y.C0400a;
import p002b.p011c.p015b.p028b.p029a.p041y.p043x.C0427a;
import p002b.p011c.p015b.p028b.p029a.p041y.p043x.C0428b;

@ParametersAreNonnullByDefault
public abstract class RtbAdapter extends C0400a {
    public abstract void collectSignals(C0427a aVar, C0428b bVar);
}
