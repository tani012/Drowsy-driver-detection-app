package com.google.android.gms.measurement.module;

import android.content.Context;
import androidx.annotation.Keep;
import p002b.p011c.p015b.p028b.p068i.p078j.C2729f;
import p002b.p011c.p015b.p028b.p082j.p084b.C3461g5;
import p176d.p178b.p179k.C4851q;

public class Analytics {

    /* renamed from: a */
    public static volatile Analytics f17460a;

    public Analytics(C3461g5 g5Var) {
        C4851q.C4862i.m15170t(g5Var);
    }

    @Keep
    public static Analytics getInstance(Context context) {
        if (f17460a == null) {
            synchronized (Analytics.class) {
                if (f17460a == null) {
                    f17460a = new Analytics(C3461g5.m12271a(context, (C2729f) null, (Long) null));
                }
            }
        }
        return f17460a;
    }
}
