package com.google.android.gms.vision.clearcut;

import android.content.Context;
import android.util.Log;
import androidx.annotation.Keep;
import p002b.p011c.p015b.p028b.p052d.C0436a;
import p002b.p011c.p015b.p028b.p053e.p061r.C0603d;
import p002b.p011c.p015b.p028b.p053e.p061r.C0605f;
import p002b.p011c.p015b.p028b.p068i.p072d.C1837e5;
import p002b.p011c.p015b.p028b.p068i.p072d.C1913o2;
import p002b.p011c.p015b.p028b.p068i.p081m.C3122d4;
import p002b.p011c.p015b.p028b.p068i.p081m.C3173g2;
import p002b.p011c.p015b.p028b.p068i.p081m.C3230l1;
import p002b.p011c.p015b.p028b.p068i.p081m.C3272p3;

@Keep
public class VisionClearcutLogger {
    public final C0436a zzbw;
    public boolean zzbx = true;

    public VisionClearcutLogger(Context context) {
        this.zzbw = new C0436a(context, "VISION", (String) null, false, new C1913o2(context), C0603d.f1665a, new C1837e5(context));
    }

    public final void zzb(int i, C3173g2 g2Var) {
        byte[] a = g2Var.mo7347a();
        if (i < 0 || i > 3) {
            Object[] objArr = {Integer.valueOf(i)};
            if (Log.isLoggable("Vision", 4)) {
                Log.i("Vision", String.format("Illegal event code: %d", objArr));
                return;
            }
            return;
        }
        try {
            if (this.zzbx) {
                C0436a.C0437a b = this.zzbw.mo1291b(a);
                b.f1384g.f11748j = i;
                b.mo1292a();
                return;
            }
            C3173g2.C3174a q = C3173g2.m11586q();
            Class<C3272p3> cls = C3272p3.class;
            try {
                C3272p3 p3Var = C3272p3.f13833c;
                if (p3Var == null) {
                    synchronized (cls) {
                        p3Var = C3272p3.f13833c;
                        if (p3Var == null) {
                            p3Var = C3122d4.m11476a(cls);
                            C3272p3.f13833c = p3Var;
                        }
                    }
                }
                q.mo7142h(a, 0, a.length, p3Var);
                C0605f.m1222w("Would have logged:\n%s", q.toString());
            } catch (Exception e) {
                C0605f.m1229x(e, "Parsing error", new Object[0]);
            }
        } catch (Exception e2) {
            C3230l1.f13781a.mo7243a(e2);
            C0605f.m1229x(e2, "Failed to log", new Object[0]);
        }
    }
}
