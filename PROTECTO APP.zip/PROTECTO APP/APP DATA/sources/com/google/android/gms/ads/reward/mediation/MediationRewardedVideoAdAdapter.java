package com.google.android.gms.ads.reward.mediation;

import android.content.Context;
import android.os.Bundle;
import p002b.p011c.p015b.p028b.p029a.p031b0.p032d.C0296a;
import p002b.p011c.p015b.p028b.p029a.p041y.C0404e;
import p002b.p011c.p015b.p028b.p029a.p041y.C0405f;

public interface MediationRewardedVideoAdAdapter extends C0405f {
    public static final String CUSTOM_EVENT_SERVER_PARAMETER_FIELD = "parameter";

    void initialize(Context context, C0404e eVar, String str, C0296a aVar, Bundle bundle, Bundle bundle2);

    boolean isInitialized();

    void loadAd(C0404e eVar, Bundle bundle, Bundle bundle2);

    /* synthetic */ void onDestroy();

    /* synthetic */ void onPause();

    /* synthetic */ void onResume();

    void showVideo();
}
