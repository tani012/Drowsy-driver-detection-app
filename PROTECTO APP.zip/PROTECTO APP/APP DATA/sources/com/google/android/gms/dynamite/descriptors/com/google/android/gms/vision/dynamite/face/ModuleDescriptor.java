package com.google.android.gms.dynamite.descriptors.com.google.android.gms.vision.dynamite.face;

import com.google.android.gms.common.util.DynamiteApi;

@DynamiteApi
public class ModuleDescriptor {
    public static final String MODULE_ID = "com.google.android.gms.vision.dynamite.face";
    public static final int MODULE_VERSION = 180000;
}
