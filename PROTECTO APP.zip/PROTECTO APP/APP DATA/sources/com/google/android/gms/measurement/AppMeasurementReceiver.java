package com.google.android.gms.measurement;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.PowerManager;
import p002b.p011c.p015b.p028b.p068i.p078j.C2729f;
import p002b.p011c.p015b.p028b.p082j.p084b.C3400b4;
import p002b.p011c.p015b.p028b.p082j.p084b.C3436e4;
import p002b.p011c.p015b.p028b.p082j.p084b.C3461g5;
import p002b.p011c.p015b.p028b.p082j.p084b.C3654x4;
import p002b.p011c.p015b.p028b.p082j.p084b.C3665y4;
import p176d.p240m.p241a.C5774a;

public final class AppMeasurementReceiver extends C5774a implements C3654x4 {

    /* renamed from: c */
    public C3665y4 f17452c;

    public final void onReceive(Context context, Intent intent) {
        String str;
        C3436e4 e4Var;
        if (this.f17452c == null) {
            this.f17452c = new C3665y4(this);
        }
        C3665y4 y4Var = this.f17452c;
        if (y4Var != null) {
            C3400b4 i = C3461g5.m12271a(context, (C2729f) null, (Long) null).mo7499i();
            if (intent == null) {
                e4Var = i.f14152i;
                str = "Receiver called with null intent";
            } else {
                String action = intent.getAction();
                i.f14157n.mo7645b("Local receiver got", action);
                if ("com.google.android.gms.measurement.UPLOAD".equals(action)) {
                    Intent className = new Intent().setClassName(context, "com.google.android.gms.measurement.AppMeasurementService");
                    className.setAction("com.google.android.gms.measurement.UPLOAD");
                    i.f14157n.mo7644a("Starting wakeful intent.");
                    if (((AppMeasurementReceiver) y4Var.f14975a) != null) {
                        synchronized (C5774a.f20287a) {
                            int i2 = C5774a.f20288b;
                            int i3 = C5774a.f20288b + 1;
                            C5774a.f20288b = i3;
                            if (i3 <= 0) {
                                C5774a.f20288b = 1;
                            }
                            className.putExtra("androidx.contentpager.content.wakelockid", i2);
                            ComponentName startService = context.startService(className);
                            if (startService != null) {
                                PowerManager.WakeLock newWakeLock = ((PowerManager) context.getSystemService("power")).newWakeLock(1, "androidx.core:wake:" + startService.flattenToShortString());
                                newWakeLock.setReferenceCounted(false);
                                newWakeLock.acquire(60000);
                                C5774a.f20287a.put(i2, newWakeLock);
                            }
                        }
                        return;
                    }
                    throw null;
                } else if ("com.android.vending.INSTALL_REFERRER".equals(action)) {
                    e4Var = i.f14152i;
                    str = "Install Referrer Broadcasts are deprecated";
                } else {
                    return;
                }
            }
            e4Var.mo7644a(str);
            return;
        }
        throw null;
    }
}
