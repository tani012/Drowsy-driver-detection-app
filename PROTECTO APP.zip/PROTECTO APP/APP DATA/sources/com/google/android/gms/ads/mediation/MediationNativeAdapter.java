package com.google.android.gms.ads.mediation;

import android.content.Context;
import android.os.Bundle;
import p002b.p011c.p015b.p028b.p029a.p041y.C0405f;
import p002b.p011c.p015b.p028b.p029a.p041y.C0412m;
import p002b.p011c.p015b.p028b.p029a.p041y.C0417r;

public interface MediationNativeAdapter extends C0405f {
    /* synthetic */ void onDestroy();

    /* synthetic */ void onPause();

    /* synthetic */ void onResume();

    void requestNativeAd(Context context, C0412m mVar, Bundle bundle, C0417r rVar, Bundle bundle2);
}
