package com.google.android.gms.vision.face;

import android.content.res.AssetManager;
import androidx.annotation.Keep;
import java.nio.ByteBuffer;
import java.util.List;
import p002b.p011c.p015b.p028b.p053e.p061r.C0605f;
import p002b.p011c.p015b.p028b.p068i.p081m.C3095b0;
import p002b.p011c.p015b.p028b.p068i.p081m.C3127e0;
import p002b.p011c.p015b.p028b.p068i.p081m.C3149e4;
import p002b.p011c.p015b.p028b.p068i.p081m.C3197i7;
import p002b.p011c.p015b.p028b.p068i.p081m.C3264o4;
import p002b.p011c.p015b.p028b.p068i.p081m.C3272p3;

public class FaceDetectorV2Jni {

    /* renamed from: a */
    public final C3272p3 f17461a;

    public FaceDetectorV2Jni() {
        C3272p3 p3Var = new C3272p3();
        this.f17461a = p3Var;
        C3149e4.C3156g<C3197i7, List<C3127e0.C3130b>> gVar = C3127e0.f13589a;
        p3Var.f13835a.put(new C3272p3.C3273a(gVar.f13620a, gVar.f13623d.f13615f), gVar);
    }

    @Keep
    private native void closeDetectorJni(long j);

    @Keep
    private native byte[] detectFacesImageByteArrayJni(long j, byte[] bArr, byte[] bArr2);

    @Keep
    private native byte[] detectFacesImageByteArrayMultiPlanesJni(long j, byte[] bArr, byte[] bArr2, byte[] bArr3, int i, int i2, int i3, int i4, int i5, int i6, byte[] bArr4);

    @Keep
    private native byte[] detectFacesImageByteBufferJni(long j, ByteBuffer byteBuffer, byte[] bArr);

    @Keep
    private native byte[] detectFacesImageByteBufferMultiPlanesJni(long j, ByteBuffer byteBuffer, ByteBuffer byteBuffer2, ByteBuffer byteBuffer3, int i, int i2, int i3, int i4, int i5, int i6, byte[] bArr);

    @Keep
    private native long initDetectorJni(byte[] bArr, AssetManager assetManager);

    /* renamed from: a */
    public final long mo9727a(C3127e0.C3137d dVar, AssetManager assetManager) {
        C0605f.m976M("%s initialize.start()", "FaceDetectorV2Jni");
        long initDetectorJni = initDetectorJni(dVar.mo7347a(), assetManager);
        C0605f.m976M("%s initialize.end()", "FaceDetectorV2Jni");
        return initDetectorJni;
    }

    /* renamed from: b */
    public final C3127e0.C3135c mo9728b(long j, ByteBuffer byteBuffer, C3095b0 b0Var) {
        C3127e0.C3135c cVar;
        C0605f.m976M("%s detectFacesImageByteBuffer.start()", "FaceDetectorV2Jni");
        try {
            byte[] detectFacesImageByteBufferJni = detectFacesImageByteBufferJni(j, byteBuffer, b0Var.mo7347a());
            if (detectFacesImageByteBufferJni != null && detectFacesImageByteBufferJni.length > 0) {
                cVar = C3127e0.C3135c.m11488o(detectFacesImageByteBufferJni, this.f17461a);
                C0605f.m976M("%s detectFacesImageByteBuffer.end()", "FaceDetectorV2Jni");
                return cVar;
            }
        } catch (C3264o4 e) {
            C0605f.m1222w("%s detectFacesImageByteBuffer failed to parse result: %s", "FaceDetectorV2Jni", e.getMessage());
        }
        cVar = null;
        C0605f.m976M("%s detectFacesImageByteBuffer.end()", "FaceDetectorV2Jni");
        return cVar;
    }

    /* renamed from: c */
    public final C3127e0.C3135c mo9729c(long j, ByteBuffer byteBuffer, ByteBuffer byteBuffer2, ByteBuffer byteBuffer3, int i, int i2, int i3, int i4, int i5, int i6, C3095b0 b0Var) {
        C3127e0.C3135c cVar;
        C0605f.m976M("%s detectFacesImageByteBufferMultiPlanes.start()", "FaceDetectorV2Jni");
        try {
            byte[] detectFacesImageByteBufferMultiPlanesJni = detectFacesImageByteBufferMultiPlanesJni(j, byteBuffer, byteBuffer2, byteBuffer3, i, i2, i3, i4, i5, i6, b0Var.mo7347a());
            if (detectFacesImageByteBufferMultiPlanesJni == null || detectFacesImageByteBufferMultiPlanesJni.length <= 0) {
                cVar = null;
                C0605f.m976M("%s detectFacesImageByteBuffer.end()", "FaceDetectorV2Jni");
                return cVar;
            }
            try {
                cVar = C3127e0.C3135c.m11488o(detectFacesImageByteBufferMultiPlanesJni, this.f17461a);
            } catch (C3264o4 e) {
                e = e;
                C0605f.m1222w("%s detectFacesImageByteBufferMultiPlanes failed to parse result: %s", "FaceDetectorV2Jni", e.getMessage());
                cVar = null;
                C0605f.m976M("%s detectFacesImageByteBuffer.end()", "FaceDetectorV2Jni");
                return cVar;
            }
            C0605f.m976M("%s detectFacesImageByteBuffer.end()", "FaceDetectorV2Jni");
            return cVar;
        } catch (C3264o4 e2) {
            e = e2;
            C0605f.m1222w("%s detectFacesImageByteBufferMultiPlanes failed to parse result: %s", "FaceDetectorV2Jni", e.getMessage());
            cVar = null;
            C0605f.m976M("%s detectFacesImageByteBuffer.end()", "FaceDetectorV2Jni");
            return cVar;
        }
    }

    /* renamed from: d */
    public final C3127e0.C3135c mo9730d(long j, byte[] bArr, C3095b0 b0Var) {
        C3127e0.C3135c cVar;
        C0605f.m976M("%s detectFacesImageByteArray.start()", "FaceDetectorV2Jni");
        try {
            byte[] detectFacesImageByteArrayJni = detectFacesImageByteArrayJni(j, bArr, b0Var.mo7347a());
            if (detectFacesImageByteArrayJni != null && detectFacesImageByteArrayJni.length > 0) {
                cVar = C3127e0.C3135c.m11488o(detectFacesImageByteArrayJni, this.f17461a);
                C0605f.m976M("%s detectFacesImageByteArray.end()", "FaceDetectorV2Jni");
                return cVar;
            }
        } catch (C3264o4 e) {
            C0605f.m1222w("%s detectFacesImageByteArray failed to parse result: %s", "FaceDetectorV2Jni", e.getMessage());
        }
        cVar = null;
        C0605f.m976M("%s detectFacesImageByteArray.end()", "FaceDetectorV2Jni");
        return cVar;
    }

    /* renamed from: e */
    public final C3127e0.C3135c mo9731e(long j, byte[] bArr, byte[] bArr2, byte[] bArr3, int i, int i2, int i3, int i4, int i5, int i6, C3095b0 b0Var) {
        C3127e0.C3135c cVar;
        C0605f.m976M("%s detectFacesImageByteArrayMultiPlanes.start()", "FaceDetectorV2Jni");
        try {
            byte[] detectFacesImageByteArrayMultiPlanesJni = detectFacesImageByteArrayMultiPlanesJni(j, bArr, bArr2, bArr3, i, i2, i3, i4, i5, i6, b0Var.mo7347a());
            if (detectFacesImageByteArrayMultiPlanesJni == null || detectFacesImageByteArrayMultiPlanesJni.length <= 0) {
                cVar = null;
                C0605f.m976M("%s detectFacesImageByteArrayMultiPlanes.end()", "FaceDetectorV2Jni");
                return cVar;
            }
            try {
                cVar = C3127e0.C3135c.m11488o(detectFacesImageByteArrayMultiPlanesJni, this.f17461a);
            } catch (C3264o4 e) {
                e = e;
                C0605f.m1222w("%s detectFacesImageByteArrayMultiPlanes failed to parse result: %s", "FaceDetectorV2Jni", e.getMessage());
                cVar = null;
                C0605f.m976M("%s detectFacesImageByteArrayMultiPlanes.end()", "FaceDetectorV2Jni");
                return cVar;
            }
            C0605f.m976M("%s detectFacesImageByteArrayMultiPlanes.end()", "FaceDetectorV2Jni");
            return cVar;
        } catch (C3264o4 e2) {
            e = e2;
            C0605f.m1222w("%s detectFacesImageByteArrayMultiPlanes failed to parse result: %s", "FaceDetectorV2Jni", e.getMessage());
            cVar = null;
            C0605f.m976M("%s detectFacesImageByteArrayMultiPlanes.end()", "FaceDetectorV2Jni");
            return cVar;
        }
    }

    /* renamed from: f */
    public final void mo9732f(long j) {
        C0605f.m976M("%s closeDetector.start()", "FaceDetectorV2Jni");
        closeDetectorJni(j);
        C0605f.m976M("%s closeDetector.end()", "FaceDetectorV2Jni");
    }
}
