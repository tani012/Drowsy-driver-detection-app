package com.google.android.gms.vision.face;

import android.content.Context;
import android.util.Log;
import com.google.android.gms.common.util.DynamiteApi;
import com.google.android.gms.vision.clearcut.DynamiteClearcutLogger;
import p002b.p011c.p015b.p028b.p053e.p061r.C0605f;
import p002b.p011c.p015b.p028b.p068i.p081m.C3279q0;
import p002b.p011c.p015b.p028b.p068i.p081m.C3319t7;
import p002b.p011c.p015b.p028b.p090o.p092d.p093e.p094a.C3758f;
import p002b.p011c.p015b.p028b.p090o.p092d.p093e.p094a.C3760h;

@DynamiteApi
public class NativeFaceDetectorV2Creator extends ChimeraNativeBaseFaceDetectorCreator {
    /* renamed from: c2 */
    public final C3760h mo9726c2(Context context, Context context2, DynamiteClearcutLogger dynamiteClearcutLogger, C3758f fVar) {
        boolean z;
        String a = C3279q0.m11790a("libface_detector_v2_jni.so");
        int lastIndexOf = a.lastIndexOf(".so");
        if (lastIndexOf == a.length() - 3) {
            a = a.substring(0, lastIndexOf);
        }
        if (a.indexOf("lib") == 0) {
            a = a.substring(3);
        }
        synchronized (C3319t7.f13937a) {
            String valueOf = String.valueOf(a);
            String concat = valueOf.length() != 0 ? "face".concat(valueOf) : new String("face");
            int intValue = C3319t7.f13938b.containsKey(concat) ? C3319t7.f13938b.get(concat).intValue() : 0;
            if ((intValue & 1) == 0) {
                try {
                    System.loadLibrary(a);
                    C3319t7.f13938b.put(concat, Integer.valueOf(intValue | 1));
                } catch (UnsatisfiedLinkError e) {
                    if ((intValue & 4) == 0) {
                        C0605f.m1229x(e, "System.loadLibrary failed: %s", a);
                        C3319t7.f13938b.put(concat, Integer.valueOf(intValue | 4));
                    }
                    z = false;
                }
            }
        }
        z = true;
        if (!z) {
            Log.d("NativeLibraryLoader", String.format("%s engine not loaded with %s.", new Object[]{"face", a}));
        }
        if (!z) {
            return null;
        }
        return new NativeFaceDetectorV2Impl(context2, dynamiteClearcutLogger, fVar, new FaceDetectorV2Jni());
    }
}
