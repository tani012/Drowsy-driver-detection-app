package com.google.android.gms.dynamite.descriptors.com.google.firebase.perf;

import com.google.android.gms.common.util.DynamiteApi;

@DynamiteApi
public class ModuleDescriptor {
    public static final String MODULE_ID = "com.google.firebase.perf";
    public static final int MODULE_VERSION = 1;
}
