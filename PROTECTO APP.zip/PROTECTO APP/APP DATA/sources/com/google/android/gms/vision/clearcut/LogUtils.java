package com.google.android.gms.vision.clearcut;

import android.content.Context;
import android.content.pm.PackageManager;
import androidx.annotation.Keep;
import p002b.p011c.p015b.p028b.p053e.p061r.C0605f;
import p002b.p011c.p015b.p028b.p053e.p063s.C0613b;
import p002b.p011c.p015b.p028b.p068i.p081m.C3149e4;
import p002b.p011c.p015b.p028b.p068i.p081m.C3298s1;

@Keep
public class LogUtils {
    public static C3298s1 zza(Context context) {
        C3298s1.C3299a aVar = (C3298s1.C3299a) C3298s1.zzmp.mo7139n();
        String packageName = context.getPackageName();
        if (aVar.f13613g) {
            aVar.mo7144j();
            aVar.f13613g = false;
        }
        C3298s1.m11859o((C3298s1) aVar.f13612f, packageName);
        String zzb = zzb(context);
        if (zzb != null) {
            if (aVar.f13613g) {
                aVar.mo7144j();
                aVar.f13613g = false;
            }
            C3298s1.m11860p((C3298s1) aVar.f13612f, zzb);
        }
        return (C3298s1) ((C3149e4) aVar.mo7146l());
    }

    public static String zzb(Context context) {
        try {
            return C0613b.m1259a(context).mo1508b(context.getPackageName(), 0).versionName;
        } catch (PackageManager.NameNotFoundException e) {
            C0605f.m1229x(e, "Unable to find calling package info for %s", context.getPackageName());
            return null;
        }
    }
}
