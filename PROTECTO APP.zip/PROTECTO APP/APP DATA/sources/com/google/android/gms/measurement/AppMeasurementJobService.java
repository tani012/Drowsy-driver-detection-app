package com.google.android.gms.measurement;

import android.annotation.TargetApi;
import android.app.job.JobParameters;
import android.app.job.JobService;
import android.content.Intent;
import p002b.p011c.p015b.p028b.p068i.p078j.C2729f;
import p002b.p011c.p015b.p028b.p082j.p084b.C3400b4;
import p002b.p011c.p015b.p028b.p082j.p084b.C3461g5;
import p002b.p011c.p015b.p028b.p082j.p084b.C3625u8;
import p002b.p011c.p015b.p028b.p082j.p084b.C3647w8;
import p002b.p011c.p015b.p028b.p082j.p084b.C3669y8;

@TargetApi(24)
public final class AppMeasurementJobService extends JobService implements C3669y8 {

    /* renamed from: e */
    public C3625u8<AppMeasurementJobService> f17451e;

    /* renamed from: a */
    public final void mo8036a(Intent intent) {
    }

    @TargetApi(24)
    /* renamed from: b */
    public final void mo8037b(JobParameters jobParameters, boolean z) {
        jobFinished(jobParameters, false);
    }

    /* renamed from: c */
    public final C3625u8<AppMeasurementJobService> mo9708c() {
        if (this.f17451e == null) {
            this.f17451e = new C3625u8<>(this);
        }
        return this.f17451e;
    }

    /* renamed from: i */
    public final boolean mo8038i(int i) {
        throw new UnsupportedOperationException();
    }

    public final void onCreate() {
        super.onCreate();
        C3461g5.m12271a(mo9708c().f14902a, (C2729f) null, (Long) null).mo7499i().f14157n.mo7644a("Local AppMeasurementService is starting up");
    }

    public final void onDestroy() {
        C3461g5.m12271a(mo9708c().f14902a, (C2729f) null, (Long) null).mo7499i().f14157n.mo7644a("Local AppMeasurementService is shutting down");
        super.onDestroy();
    }

    public final void onRebind(Intent intent) {
        mo9708c().mo7963d(intent);
    }

    public final boolean onStartJob(JobParameters jobParameters) {
        C3625u8<AppMeasurementJobService> c = mo9708c();
        C3400b4 i = C3461g5.m12271a(c.f14902a, (C2729f) null, (Long) null).mo7499i();
        String string = jobParameters.getExtras().getString("action");
        i.f14157n.mo7645b("Local AppMeasurementJobService called. action", string);
        if (!"com.google.android.gms.measurement.UPLOAD".equals(string)) {
            return true;
        }
        c.mo7960a(new C3647w8(c, i, jobParameters));
        return true;
    }

    public final boolean onStopJob(JobParameters jobParameters) {
        return false;
    }

    public final boolean onUnbind(Intent intent) {
        mo9708c().mo7961b(intent);
        return true;
    }
}
