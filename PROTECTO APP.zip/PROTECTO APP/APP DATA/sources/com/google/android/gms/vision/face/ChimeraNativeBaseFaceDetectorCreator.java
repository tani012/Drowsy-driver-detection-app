package com.google.android.gms.vision.face;

import android.content.Context;
import android.os.RemoteException;
import android.os.SystemClock;
import com.google.android.gms.common.util.DynamiteApi;
import com.google.android.gms.vision.clearcut.DynamiteClearcutLogger;
import p002b.p011c.p015b.p028b.p064f.C0621a;
import p002b.p011c.p015b.p028b.p064f.C0624b;
import p002b.p011c.p015b.p028b.p068i.p081m.C3296s;
import p002b.p011c.p015b.p028b.p090o.p092d.p093e.p094a.C3758f;
import p002b.p011c.p015b.p028b.p090o.p092d.p093e.p094a.C3760h;
import p002b.p011c.p015b.p028b.p090o.p092d.p093e.p094a.C3764l;

@DynamiteApi
public abstract class ChimeraNativeBaseFaceDetectorCreator extends C3764l {
    /* JADX WARNING: Code restructure failed: missing block: B:19:0x0039, code lost:
        if (r0.f13613g != false) goto L_0x0044;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:22:0x0042, code lost:
        if (r0.f13613g != false) goto L_0x0044;
     */
    /* JADX WARNING: Removed duplicated region for block: B:10:0x0021  */
    /* JADX WARNING: Removed duplicated region for block: B:11:0x0024  */
    /* JADX WARNING: Removed duplicated region for block: B:18:0x0035  */
    /* JADX WARNING: Removed duplicated region for block: B:20:0x003c  */
    /* JADX WARNING: Removed duplicated region for block: B:27:0x0056  */
    /* JADX WARNING: Removed duplicated region for block: B:30:0x006d  */
    /* JADX WARNING: Removed duplicated region for block: B:33:0x0084  */
    /* JADX WARNING: Removed duplicated region for block: B:36:0x00a1  */
    /* JADX WARNING: Removed duplicated region for block: B:39:0x00b3  */
    /* JADX WARNING: Removed duplicated region for block: B:42:0x00c7  */
    /* JADX WARNING: Removed duplicated region for block: B:45:0x00dd  */
    /* JADX WARNING: Removed duplicated region for block: B:51:0x00f5  */
    /* JADX WARNING: Removed duplicated region for block: B:54:0x0109  */
    /* renamed from: A2 */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static void m14875A2(com.google.android.gms.vision.clearcut.DynamiteClearcutLogger r6, android.content.Context r7, p002b.p011c.p015b.p028b.p090o.p092d.p093e.p094a.C3758f r8, java.lang.String r9, long r10) {
        /*
            b.c.b.b.i.m.y1 r0 = p002b.p011c.p015b.p028b.p068i.p081m.C3363y1.zzof
            b.c.b.b.i.m.e4$a r0 = r0.mo7139n()
            b.c.b.b.i.m.y1$b r0 = (p002b.p011c.p015b.p028b.p068i.p081m.C3363y1.C3365b) r0
            int r1 = r8.f15192e
            r2 = 1
            r3 = 2
            if (r1 != r2) goto L_0x0011
            b.c.b.b.i.m.y1$d r1 = p002b.p011c.p015b.p028b.p068i.p081m.C3363y1.C3367d.MODE_ACCURATE
            goto L_0x001a
        L_0x0011:
            if (r1 != 0) goto L_0x0016
            b.c.b.b.i.m.y1$d r1 = p002b.p011c.p015b.p028b.p068i.p081m.C3363y1.C3367d.MODE_FAST
            goto L_0x001a
        L_0x0016:
            if (r1 != r3) goto L_0x001d
            b.c.b.b.i.m.y1$d r1 = p002b.p011c.p015b.p028b.p068i.p081m.C3363y1.C3367d.MODE_SELFIE
        L_0x001a:
            r0.mo7453n(r1)
        L_0x001d:
            int r1 = r8.f15193f
            if (r1 != r2) goto L_0x0024
            b.c.b.b.i.m.y1$c r1 = p002b.p011c.p015b.p028b.p068i.p081m.C3363y1.C3366c.LANDMARK_ALL
            goto L_0x002d
        L_0x0024:
            if (r1 != 0) goto L_0x0029
            b.c.b.b.i.m.y1$c r1 = p002b.p011c.p015b.p028b.p068i.p081m.C3363y1.C3366c.LANDMARK_NONE
            goto L_0x002d
        L_0x0029:
            if (r1 != r3) goto L_0x0030
            b.c.b.b.i.m.y1$c r1 = p002b.p011c.p015b.p028b.p068i.p081m.C3363y1.C3366c.LANDMARK_CONTOUR
        L_0x002d:
            r0.mo7452m(r1)
        L_0x0030:
            int r1 = r8.f15194g
            r4 = 0
            if (r1 != r2) goto L_0x003c
            b.c.b.b.i.m.y1$a r1 = p002b.p011c.p015b.p028b.p068i.p081m.C3363y1.C3364a.CLASSIFICATION_ALL
            boolean r2 = r0.f13613g
            if (r2 == 0) goto L_0x0049
            goto L_0x0044
        L_0x003c:
            if (r1 != 0) goto L_0x0050
            b.c.b.b.i.m.y1$a r1 = p002b.p011c.p015b.p028b.p068i.p081m.C3363y1.C3364a.CLASSIFICATION_NONE
            boolean r2 = r0.f13613g
            if (r2 == 0) goto L_0x0049
        L_0x0044:
            r0.mo7144j()
            r0.f13613g = r4
        L_0x0049:
            MessageType r2 = r0.f13612f
            b.c.b.b.i.m.y1 r2 = (p002b.p011c.p015b.p028b.p068i.p081m.C3363y1) r2
            p002b.p011c.p015b.p028b.p068i.p081m.C3363y1.m12019o(r2, r1)
        L_0x0050:
            boolean r1 = r8.f15195h
            boolean r2 = r0.f13613g
            if (r2 == 0) goto L_0x005b
            r0.mo7144j()
            r0.f13613g = r4
        L_0x005b:
            MessageType r2 = r0.f13612f
            b.c.b.b.i.m.y1 r2 = (p002b.p011c.p015b.p028b.p068i.p081m.C3363y1) r2
            int r5 = r2.zzbf
            r5 = r5 | 8
            r2.zzbf = r5
            r2.zzke = r1
            boolean r1 = r8.f15196i
            boolean r2 = r0.f13613g
            if (r2 == 0) goto L_0x0072
            r0.mo7144j()
            r0.f13613g = r4
        L_0x0072:
            MessageType r2 = r0.f13612f
            b.c.b.b.i.m.y1 r2 = (p002b.p011c.p015b.p028b.p068i.p081m.C3363y1) r2
            int r5 = r2.zzbf
            r5 = r5 | 16
            r2.zzbf = r5
            r2.zzoe = r1
            float r8 = r8.f15197j
            boolean r1 = r0.f13613g
            if (r1 == 0) goto L_0x0089
            r0.mo7144j()
            r0.f13613g = r4
        L_0x0089:
            MessageType r1 = r0.f13612f
            b.c.b.b.i.m.y1 r1 = (p002b.p011c.p015b.p028b.p068i.p081m.C3363y1) r1
            int r2 = r1.zzbf
            r2 = r2 | 32
            r1.zzbf = r2
            r1.zzka = r8
            b.c.b.b.i.m.c2 r8 = p002b.p011c.p015b.p028b.p068i.p081m.C3109c2.zzpt
            b.c.b.b.i.m.e4$a r8 = r8.mo7139n()
            b.c.b.b.i.m.c2$a r8 = (p002b.p011c.p015b.p028b.p068i.p081m.C3109c2.C3110a) r8
            boolean r1 = r8.f13613g
            if (r1 == 0) goto L_0x00a6
            r8.mo7144j()
            r8.f13613g = r4
        L_0x00a6:
            MessageType r1 = r8.f13612f
            b.c.b.b.i.m.c2 r1 = (p002b.p011c.p015b.p028b.p068i.p081m.C3109c2) r1
            java.lang.String r2 = "face"
            p002b.p011c.p015b.p028b.p068i.p081m.C3109c2.m11411q(r1, r2)
            boolean r1 = r8.f13613g
            if (r1 == 0) goto L_0x00b8
            r8.mo7144j()
            r8.f13613g = r4
        L_0x00b8:
            MessageType r1 = r8.f13612f
            b.c.b.b.i.m.c2 r1 = (p002b.p011c.p015b.p028b.p068i.p081m.C3109c2) r1
            int r2 = r1.zzbf
            r2 = r2 | r3
            r1.zzbf = r2
            r1.zzpp = r10
            boolean r10 = r8.f13613g
            if (r10 == 0) goto L_0x00cc
            r8.mo7144j()
            r8.f13613g = r4
        L_0x00cc:
            MessageType r10 = r8.f13612f
            b.c.b.b.i.m.c2 r10 = (p002b.p011c.p015b.p028b.p068i.p081m.C3109c2) r10
            b.c.b.b.i.m.o5 r11 = r0.mo7146l()
            b.c.b.b.i.m.e4 r11 = (p002b.p011c.p015b.p028b.p068i.p081m.C3149e4) r11
            b.c.b.b.i.m.y1 r11 = (p002b.p011c.p015b.p028b.p068i.p081m.C3363y1) r11
            p002b.p011c.p015b.p028b.p068i.p081m.C3109c2.m11410p(r10, r11)
            if (r9 == 0) goto L_0x00ed
            boolean r10 = r8.f13613g
            if (r10 == 0) goto L_0x00e6
            r8.mo7144j()
            r8.f13613g = r4
        L_0x00e6:
            MessageType r10 = r8.f13612f
            b.c.b.b.i.m.c2 r10 = (p002b.p011c.p015b.p028b.p068i.p081m.C3109c2) r10
            p002b.p011c.p015b.p028b.p068i.p081m.C3109c2.m11412r(r10, r9)
        L_0x00ed:
            b.c.b.b.i.m.s1 r7 = com.google.android.gms.vision.clearcut.LogUtils.zza(r7)
            boolean r9 = r8.f13613g
            if (r9 == 0) goto L_0x00fa
            r8.mo7144j()
            r8.f13613g = r4
        L_0x00fa:
            MessageType r9 = r8.f13612f
            b.c.b.b.i.m.c2 r9 = (p002b.p011c.p015b.p028b.p068i.p081m.C3109c2) r9
            p002b.p011c.p015b.p028b.p068i.p081m.C3109c2.m11409o(r9, r7)
            b.c.b.b.i.m.g2$a r7 = p002b.p011c.p015b.p028b.p068i.p081m.C3173g2.m11586q()
            boolean r9 = r7.f13613g
            if (r9 == 0) goto L_0x010e
            r7.mo7144j()
            r7.f13613g = r4
        L_0x010e:
            MessageType r9 = r7.f13612f
            b.c.b.b.i.m.g2 r9 = (p002b.p011c.p015b.p028b.p068i.p081m.C3173g2) r9
            b.c.b.b.i.m.o5 r8 = r8.mo7146l()
            b.c.b.b.i.m.e4 r8 = (p002b.p011c.p015b.p028b.p068i.p081m.C3149e4) r8
            b.c.b.b.i.m.c2 r8 = (p002b.p011c.p015b.p028b.p068i.p081m.C3109c2) r8
            p002b.p011c.p015b.p028b.p068i.p081m.C3173g2.m11585p(r9, r8)
            b.c.b.b.i.m.o5 r7 = r7.mo7146l()
            b.c.b.b.i.m.e4 r7 = (p002b.p011c.p015b.p028b.p068i.p081m.C3149e4) r7
            b.c.b.b.i.m.g2 r7 = (p002b.p011c.p015b.p028b.p068i.p081m.C3173g2) r7
            r6.zza(r3, r7)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.vision.face.ChimeraNativeBaseFaceDetectorCreator.m14875A2(com.google.android.gms.vision.clearcut.DynamiteClearcutLogger, android.content.Context, b.c.b.b.o.d.e.a.f, java.lang.String, long):void");
    }

    /* renamed from: c2 */
    public abstract C3760h mo9726c2(Context context, Context context2, DynamiteClearcutLogger dynamiteClearcutLogger, C3758f fVar);

    public C3760h newFaceDetector(C0621a aVar, C3758f fVar) {
        long elapsedRealtime = SystemClock.elapsedRealtime();
        Context context = (Context) C0624b.m1273A2(aVar);
        synchronized (C3296s.f13903f) {
            if (C3296s.f13904g == null) {
                C3296s.m11850b(context);
            }
        }
        DynamiteClearcutLogger dynamiteClearcutLogger = new DynamiteClearcutLogger(context);
        try {
            C3760h c2 = mo9726c2(context, context, dynamiteClearcutLogger, fVar);
            if (c2 != null) {
                m14875A2(dynamiteClearcutLogger, context, fVar, (String) null, SystemClock.elapsedRealtime() - elapsedRealtime);
            }
            return c2;
        } catch (RemoteException e) {
            String message = e.getMessage();
            throw e;
        } catch (Throwable th) {
            Throwable th2 = th;
            if (0 != 0) {
                m14875A2(dynamiteClearcutLogger, context, fVar, (String) null, SystemClock.elapsedRealtime() - elapsedRealtime);
            }
            throw th2;
        }
    }
}
