package com.google.android.gms.ads;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Context;
import android.content.pm.ProviderInfo;
import android.database.Cursor;
import android.net.Uri;
import p002b.p011c.p015b.p028b.p068i.p069a.qk2;

public class MobileAdsInitProvider extends ContentProvider {

    /* renamed from: e */
    public final qk2 f17343e = new qk2();

    public void attachInfo(Context context, ProviderInfo providerInfo) {
        this.f17343e.attachInfo(context, providerInfo);
    }

    public int delete(Uri uri, String str, String[] strArr) {
        if (this.f17343e != null) {
            return 0;
        }
        throw null;
    }

    public String getType(Uri uri) {
        if (this.f17343e != null) {
            return null;
        }
        throw null;
    }

    public Uri insert(Uri uri, ContentValues contentValues) {
        if (this.f17343e != null) {
            return null;
        }
        throw null;
    }

    public boolean onCreate() {
        if (this.f17343e != null) {
            return false;
        }
        throw null;
    }

    public Cursor query(Uri uri, String[] strArr, String str, String[] strArr2, String str2) {
        if (this.f17343e != null) {
            return null;
        }
        throw null;
    }

    public int update(Uri uri, ContentValues contentValues, String str, String[] strArr) {
        if (this.f17343e != null) {
            return 0;
        }
        throw null;
    }
}
