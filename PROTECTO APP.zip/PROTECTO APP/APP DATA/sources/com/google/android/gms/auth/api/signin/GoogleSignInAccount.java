package com.google.android.gms.auth.api.signin;

import android.net.Uri;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.common.internal.ReflectedParcelable;
import java.util.AbstractSet;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import org.json.JSONArray;
import org.json.JSONObject;
import p002b.p011c.p015b.p028b.p047b.p048a.p049a.C0434b;
import p002b.p011c.p015b.p028b.p053e.p057o.p058t.C0585a;
import p002b.p011c.p015b.p028b.p053e.p061r.C0601b;
import p002b.p011c.p015b.p028b.p053e.p061r.C0603d;
import p176d.p178b.p179k.C4851q;

public class GoogleSignInAccount extends C0585a implements ReflectedParcelable {
    public static final Parcelable.Creator<GoogleSignInAccount> CREATOR = new C0434b();

    /* renamed from: r */
    public static C0601b f17363r = C0603d.f1665a;

    /* renamed from: e */
    public final int f17364e;

    /* renamed from: f */
    public String f17365f;

    /* renamed from: g */
    public String f17366g;

    /* renamed from: h */
    public String f17367h;

    /* renamed from: i */
    public String f17368i;

    /* renamed from: j */
    public Uri f17369j;

    /* renamed from: k */
    public String f17370k;

    /* renamed from: l */
    public long f17371l;

    /* renamed from: m */
    public String f17372m;

    /* renamed from: n */
    public List<Scope> f17373n;

    /* renamed from: o */
    public String f17374o;

    /* renamed from: p */
    public String f17375p;

    /* renamed from: q */
    public Set<Scope> f17376q = new HashSet();

    public GoogleSignInAccount(int i, String str, String str2, String str3, String str4, Uri uri, String str5, long j, String str6, List<Scope> list, String str7, String str8) {
        this.f17364e = i;
        this.f17365f = str;
        this.f17366g = str2;
        this.f17367h = str3;
        this.f17368i = str4;
        this.f17369j = uri;
        this.f17370k = str5;
        this.f17371l = j;
        this.f17372m = str6;
        this.f17373n = list;
        this.f17374o = str7;
        this.f17375p = str8;
    }

    /* renamed from: H */
    public static GoogleSignInAccount m14837H(String str) {
        if (TextUtils.isEmpty(str)) {
            return null;
        }
        JSONObject jSONObject = new JSONObject(str);
        String optString = jSONObject.optString("photoUrl", (String) null);
        Uri parse = !TextUtils.isEmpty(optString) ? Uri.parse(optString) : null;
        long parseLong = Long.parseLong(jSONObject.getString("expirationTime"));
        HashSet hashSet = new HashSet();
        JSONArray jSONArray = jSONObject.getJSONArray("grantedScopes");
        int length = jSONArray.length();
        for (int i = 0; i < length; i++) {
            hashSet.add(new Scope(jSONArray.getString(i)));
        }
        String optString2 = jSONObject.optString("id");
        String optString3 = jSONObject.optString("tokenId", (String) null);
        String optString4 = jSONObject.optString("email", (String) null);
        String optString5 = jSONObject.optString("displayName", (String) null);
        String optString6 = jSONObject.optString("givenName", (String) null);
        String optString7 = jSONObject.optString("familyName", (String) null);
        Long valueOf = Long.valueOf(parseLong);
        String string = jSONObject.getString("obfuscatedIdentifier");
        if (valueOf == null) {
            valueOf = Long.valueOf(System.currentTimeMillis() / 1000);
        }
        long longValue = valueOf.longValue();
        C4851q.C4862i.m15155o(string);
        C4851q.C4862i.m15170t(hashSet);
        GoogleSignInAccount googleSignInAccount = r3;
        GoogleSignInAccount googleSignInAccount2 = new GoogleSignInAccount(3, optString2, optString3, optString4, optString5, parse, (String) null, longValue, string, new ArrayList(hashSet), optString6, optString7);
        GoogleSignInAccount googleSignInAccount3 = googleSignInAccount;
        googleSignInAccount3.f17370k = jSONObject.optString("serverAuthCode", (String) null);
        return googleSignInAccount3;
    }

    /* renamed from: B */
    public Set<Scope> mo9661B() {
        HashSet hashSet = new HashSet(this.f17373n);
        hashSet.addAll(this.f17376q);
        return hashSet;
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof GoogleSignInAccount)) {
            return false;
        }
        GoogleSignInAccount googleSignInAccount = (GoogleSignInAccount) obj;
        if (googleSignInAccount.f17372m.equals(this.f17372m)) {
            if (((AbstractSet) googleSignInAccount.mo9661B()).equals(mo9661B())) {
                return true;
            }
        }
        return false;
    }

    public int hashCode() {
        return ((AbstractSet) mo9661B()).hashCode() + ((this.f17372m.hashCode() + 527) * 31);
    }

    public void writeToParcel(Parcel parcel, int i) {
        int e = C4851q.C4862i.m15125e(parcel);
        C4851q.C4862i.m15136h1(parcel, 1, this.f17364e);
        C4851q.C4862i.m15148l1(parcel, 2, this.f17365f, false);
        C4851q.C4862i.m15148l1(parcel, 3, this.f17366g, false);
        C4851q.C4862i.m15148l1(parcel, 4, this.f17367h, false);
        C4851q.C4862i.m15148l1(parcel, 5, this.f17368i, false);
        C4851q.C4862i.m15145k1(parcel, 6, this.f17369j, i, false);
        C4851q.C4862i.m15148l1(parcel, 7, this.f17370k, false);
        C4851q.C4862i.m15142j1(parcel, 8, this.f17371l);
        C4851q.C4862i.m15148l1(parcel, 9, this.f17372m, false);
        List<Scope> list = this.f17373n;
        if (list != null) {
            int p1 = C4851q.C4862i.m15160p1(parcel, 10);
            int size = list.size();
            parcel.writeInt(size);
            for (int i2 = 0; i2 < size; i2++) {
                Parcelable parcelable = list.get(i2);
                if (parcelable == null) {
                    parcel.writeInt(0);
                } else {
                    C4851q.C4862i.m15175u1(parcel, parcelable, 0);
                }
            }
            C4851q.C4862i.m15181w1(parcel, p1);
        }
        C4851q.C4862i.m15148l1(parcel, 11, this.f17374o, false);
        C4851q.C4862i.m15148l1(parcel, 12, this.f17375p, false);
        C4851q.C4862i.m15181w1(parcel, e);
    }
}
