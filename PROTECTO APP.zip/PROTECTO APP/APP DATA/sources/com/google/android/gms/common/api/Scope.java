package com.google.android.gms.common.api;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.ReflectedParcelable;
import p002b.p011c.p015b.p028b.p053e.p054m.C0532k;
import p002b.p011c.p015b.p028b.p053e.p057o.p058t.C0585a;
import p176d.p178b.p179k.C4851q;

public final class Scope extends C0585a implements ReflectedParcelable {
    public static final Parcelable.Creator<Scope> CREATOR = new C0532k();

    /* renamed from: e */
    public final int f17378e;

    /* renamed from: f */
    public final String f17379f;

    public Scope(int i, String str) {
        C4851q.C4862i.m15158p(str, "scopeUri must not be null or empty");
        this.f17378e = i;
        this.f17379f = str;
    }

    public Scope(String str) {
        C4851q.C4862i.m15158p(str, "scopeUri must not be null or empty");
        this.f17378e = 1;
        this.f17379f = str;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof Scope)) {
            return false;
        }
        return this.f17379f.equals(((Scope) obj).f17379f);
    }

    public final int hashCode() {
        return this.f17379f.hashCode();
    }

    public final String toString() {
        return this.f17379f;
    }

    public final void writeToParcel(Parcel parcel, int i) {
        int e = C4851q.C4862i.m15125e(parcel);
        C4851q.C4862i.m15136h1(parcel, 1, this.f17378e);
        C4851q.C4862i.m15148l1(parcel, 2, this.f17379f, false);
        C4851q.C4862i.m15181w1(parcel, e);
    }
}
