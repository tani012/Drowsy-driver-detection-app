package com.google.android.gms.ads.internal;

import android.app.Activity;
import android.content.Context;
import android.view.View;
import android.widget.FrameLayout;
import com.google.android.gms.ads.internal.overlay.AdOverlayInfoParcel;
import java.util.HashMap;
import p002b.p011c.p015b.p028b.p029a.p039x.C0392k;
import p002b.p011c.p015b.p028b.p029a.p039x.p040a.C0374r;
import p002b.p011c.p015b.p028b.p029a.p039x.p040a.C0375s;
import p002b.p011c.p015b.p028b.p029a.p039x.p040a.C0377u;
import p002b.p011c.p015b.p028b.p029a.p039x.p040a.C0380x;
import p002b.p011c.p015b.p028b.p029a.p039x.p040a.C0382z;
import p002b.p011c.p015b.p028b.p053e.p061r.C0605f;
import p002b.p011c.p015b.p028b.p064f.C0621a;
import p002b.p011c.p015b.p028b.p064f.C0624b;
import p002b.p011c.p015b.p028b.p068i.p069a.C0769cv;
import p002b.p011c.p015b.p028b.p068i.p069a.C0993hu;
import p002b.p011c.p015b.p028b.p068i.p069a.C1014ie;
import p002b.p011c.p015b.p028b.p068i.p069a.C1021ij;
import p002b.p011c.p015b.p028b.p068i.p069a.C1111kn;
import p002b.p011c.p015b.p028b.p068i.p069a.C1225nh;
import p002b.p011c.p015b.p028b.p068i.p069a.C1358qg;
import p002b.p011c.p015b.p028b.p068i.p069a.C1384r2;
import p002b.p011c.p015b.p028b.p068i.p069a.C1525u2;
import p002b.p011c.p015b.p028b.p068i.p069a.C1689xd;
import p002b.p011c.p015b.p028b.p068i.p069a.C1728ya;
import p002b.p011c.p015b.p028b.p068i.p069a.ac1;
import p002b.p011c.p015b.p028b.p068i.p069a.bc1;
import p002b.p011c.p015b.p028b.p068i.p069a.cj2;
import p002b.p011c.p015b.p028b.p068i.p069a.dd1;
import p002b.p011c.p015b.p028b.p068i.p069a.df0;
import p002b.p011c.p015b.p028b.p068i.p069a.ec1;
import p002b.p011c.p015b.p028b.p068i.p069a.ef0;
import p002b.p011c.p015b.p028b.p068i.p069a.fc1;
import p002b.p011c.p015b.p028b.p068i.p069a.g91;
import p002b.p011c.p015b.p028b.p068i.p069a.hz0;
import p002b.p011c.p015b.p028b.p068i.p069a.j91;
import p002b.p011c.p015b.p028b.p068i.p069a.kh2;
import p002b.p011c.p015b.p028b.p068i.p069a.ki2;
import p002b.p011c.p015b.p028b.p068i.p069a.m91;
import p002b.p011c.p015b.p028b.p068i.p069a.ni2;
import p002b.p011c.p015b.p028b.p068i.p069a.p02;
import p002b.p011c.p015b.p028b.p068i.p069a.qb1;
import p002b.p011c.p015b.p028b.p068i.p069a.r02;
import p002b.p011c.p015b.p028b.p068i.p069a.r91;
import p002b.p011c.p015b.p028b.p068i.p069a.s02;
import p002b.p011c.p015b.p028b.p068i.p069a.uy0;
import p002b.p011c.p015b.p028b.p068i.p069a.va1;
import p002b.p011c.p015b.p028b.p068i.p069a.wa1;
import p002b.p011c.p015b.p028b.p068i.p069a.wy0;
import p002b.p011c.p015b.p028b.p068i.p069a.xb1;
import p002b.p011c.p015b.p028b.p068i.p069a.xc1;
import p002b.p011c.p015b.p028b.p068i.p069a.yi2;
import p002b.p011c.p015b.p028b.p068i.p069a.z02;

public class ClientApi extends yi2 {
    /* renamed from: N4 */
    public final C1358qg mo1941N4(C0621a aVar, C1728ya yaVar, int i) {
        Context context = (Context) C0624b.m1273A2(aVar);
        C0769cv cvVar = (C0769cv) C0993hu.m3262b(context, yaVar, i);
        if (context != null) {
            C0605f.m1106f2(context, Context.class);
            s02 a = r02.m6039a(context);
            va1 va1 = new va1(a, cvVar.f2621a0, cvVar.f2623b0);
            z02 a2 = p02.m5419a(new qb1(cvVar.f2621a0));
            z02 a3 = p02.m5419a(xc1.f10609a);
            z02 a4 = p02.m5419a(new xb1(a, cvVar.f2626d, cvVar.f2647y, va1, a2, dd1.f2838a, a3));
            z02 a5 = p02.m5419a(new fc1(a4, a2, a3));
            p02.m5419a(new bc1(r02.m6040b(null), a4, a, a2, a3));
            return (ec1) a5.get();
        }
        throw null;
    }

    /* renamed from: e5 */
    public final cj2 mo1942e5(C0621a aVar, int i) {
        return ((C0769cv) C0993hu.m3263h((Context) C0624b.m1273A2(aVar), i)).f2646x.get();
    }

    /* renamed from: f1 */
    public final C1689xd mo1943f1(C0621a aVar) {
        Activity activity = (Activity) C0624b.m1273A2(aVar);
        AdOverlayInfoParcel B = AdOverlayInfoParcel.m14835B(activity.getIntent());
        if (B == null) {
            return new C0374r(activity);
        }
        int i = B.f17354o;
        return i != 1 ? i != 2 ? i != 3 ? i != 4 ? new C0374r(activity) : new C0377u(activity, B) : new C0382z(activity) : new C0380x(activity) : new C0375s(activity);
    }

    /* renamed from: f6 */
    public final ni2 mo1944f6(C0621a aVar, kh2 kh2, String str, C1728ya yaVar, int i) {
        Context context = (Context) C0624b.m1273A2(aVar);
        return new hz0(C0993hu.m3262b(context, yaVar, i), context, kh2, str);
    }

    /* renamed from: h5 */
    public final C1225nh mo1945h5(C0621a aVar, String str, C1728ya yaVar, int i) {
        Context context = (Context) C0624b.m1273A2(aVar);
        C0769cv cvVar = (C0769cv) C0993hu.m3262b(context, yaVar, i);
        if (context != null) {
            C0605f.m1106f2(context, Context.class);
            s02 a = r02.m6039a(context);
            va1 va1 = new va1(a, cvVar.f2621a0, cvVar.f2623b0);
            z02 a2 = p02.m5419a(new qb1(cvVar.f2621a0));
            z02 a3 = p02.m5419a(xc1.f10609a);
            z02 a4 = p02.m5419a(new xb1(a, cvVar.f2626d, cvVar.f2647y, va1, a2, dd1.f2838a, a3));
            p02.m5419a(new fc1(a4, a2, a3));
            return (ac1) p02.m5419a(new bc1(r02.m6040b(str), a4, a, a2, a3)).get();
        }
        throw null;
    }

    /* renamed from: k6 */
    public final C1021ij mo1946k6(C0621a aVar, C1728ya yaVar, int i) {
        return ((C0769cv) C0993hu.m3262b((Context) C0624b.m1273A2(aVar), yaVar, i)).f2598D.get();
    }

    /* renamed from: l1 */
    public final ni2 mo1947l1(C0621a aVar, kh2 kh2, String str, C1728ya yaVar, int i) {
        Context context = (Context) C0624b.m1273A2(aVar);
        C0769cv cvVar = (C0769cv) C0993hu.m3262b(context, yaVar, i);
        if (str == null) {
            throw null;
        } else if (context != null) {
            C0605f.m1106f2(context, Context.class);
            C0605f.m1106f2(str, String.class);
            s02 a = r02.m6039a(context);
            s02 a2 = r02.m6039a(str);
            wa1 wa1 = new wa1(a, cvVar.f2621a0, cvVar.f2623b0);
            z02 a3 = p02.m5419a(new r91(cvVar.f2621a0));
            return (j91) p02.m5419a(new m91(cvVar.f2647y, a, a2, p02.m5419a(new g91(a, cvVar.f2626d, cvVar.f2647y, wa1, a3, dd1.f2838a)), a3, cvVar.f2634l)).get();
        } else {
            throw null;
        }
    }

    /* renamed from: l3 */
    public final ki2 mo1948l3(C0621a aVar, String str, C1728ya yaVar, int i) {
        Context context = (Context) C0624b.m1273A2(aVar);
        return new uy0(C0993hu.m3262b(context, yaVar, i), context, str);
    }

    /* renamed from: m6 */
    public final cj2 mo1949m6(C0621a aVar) {
        return null;
    }

    /* renamed from: r4 */
    public final C1014ie mo1950r4(C0621a aVar) {
        return null;
    }

    /* renamed from: u7 */
    public final C1384r2 mo1951u7(C0621a aVar, C0621a aVar2) {
        return new df0((FrameLayout) C0624b.m1273A2(aVar), (FrameLayout) C0624b.m1273A2(aVar2), 202006000);
    }

    /* renamed from: v2 */
    public final ni2 mo1952v2(C0621a aVar, kh2 kh2, String str, int i) {
        return new C0392k((Context) C0624b.m1273A2(aVar), kh2, str, new C1111kn(202006000, i, true, false, false));
    }

    /* renamed from: v4 */
    public final ni2 mo1953v4(C0621a aVar, kh2 kh2, String str, C1728ya yaVar, int i) {
        Context context = (Context) C0624b.m1273A2(aVar);
        return new wy0(C0993hu.m3262b(context, yaVar, i), context, kh2, str);
    }

    /* renamed from: x2 */
    public final C1525u2 mo1954x2(C0621a aVar, C0621a aVar2, C0621a aVar3) {
        return new ef0((View) C0624b.m1273A2(aVar), (HashMap) C0624b.m1273A2(aVar2), (HashMap) C0624b.m1273A2(aVar3));
    }
}
