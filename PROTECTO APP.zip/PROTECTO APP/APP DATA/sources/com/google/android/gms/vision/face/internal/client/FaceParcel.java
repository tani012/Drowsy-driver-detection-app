package com.google.android.gms.vision.face.internal.client;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.apps.common.proguard.UsedByNative;
import p002b.p011c.p015b.p028b.p053e.p057o.p058t.C0585a;
import p002b.p011c.p015b.p028b.p090o.p092d.p093e.p094a.C3753a;
import p002b.p011c.p015b.p028b.p090o.p092d.p093e.p094a.C3756d;
import p176d.p178b.p179k.C4851q;

@UsedByNative("wrapper.cc")
public class FaceParcel extends C0585a {
    public static final Parcelable.Creator<FaceParcel> CREATOR = new C3756d();

    /* renamed from: e */
    public final int f17469e;

    /* renamed from: f */
    public final int f17470f;

    /* renamed from: g */
    public final float f17471g;

    /* renamed from: h */
    public final float f17472h;

    /* renamed from: i */
    public final float f17473i;

    /* renamed from: j */
    public final float f17474j;

    /* renamed from: k */
    public final float f17475k;

    /* renamed from: l */
    public final float f17476l;

    /* renamed from: m */
    public final float f17477m;

    /* renamed from: n */
    public final LandmarkParcel[] f17478n;

    /* renamed from: o */
    public final float f17479o;

    /* renamed from: p */
    public final float f17480p;

    /* renamed from: q */
    public final float f17481q;

    /* renamed from: r */
    public final C3753a[] f17482r;

    /* renamed from: s */
    public final float f17483s;

    public FaceParcel(int i, int i2, float f, float f2, float f3, float f4, float f5, float f6, float f7, LandmarkParcel[] landmarkParcelArr, float f8, float f9, float f10, C3753a[] aVarArr, float f11) {
        this.f17469e = i;
        this.f17470f = i2;
        this.f17471g = f;
        this.f17472h = f2;
        this.f17473i = f3;
        this.f17474j = f4;
        this.f17475k = f5;
        this.f17476l = f6;
        this.f17477m = f7;
        this.f17478n = landmarkParcelArr;
        this.f17479o = f8;
        this.f17480p = f9;
        this.f17481q = f10;
        this.f17482r = aVarArr;
        this.f17483s = f11;
    }

    @UsedByNative("wrapper.cc")
    public FaceParcel(int i, int i2, float f, float f2, float f3, float f4, float f5, float f6, LandmarkParcel[] landmarkParcelArr, float f7, float f8, float f9) {
        this(i, i2, f, f2, f3, f4, f5, f6, 0.0f, landmarkParcelArr, f7, f8, f9, new C3753a[0], -1.0f);
    }

    public void writeToParcel(Parcel parcel, int i) {
        int e = C4851q.C4862i.m15125e(parcel);
        C4851q.C4862i.m15136h1(parcel, 1, this.f17469e);
        C4851q.C4862i.m15136h1(parcel, 2, this.f17470f);
        C4851q.C4862i.m15130f1(parcel, 3, this.f17471g);
        C4851q.C4862i.m15130f1(parcel, 4, this.f17472h);
        C4851q.C4862i.m15130f1(parcel, 5, this.f17473i);
        C4851q.C4862i.m15130f1(parcel, 6, this.f17474j);
        C4851q.C4862i.m15130f1(parcel, 7, this.f17475k);
        C4851q.C4862i.m15130f1(parcel, 8, this.f17476l);
        C4851q.C4862i.m15157o1(parcel, 9, this.f17478n, i, false);
        C4851q.C4862i.m15130f1(parcel, 10, this.f17479o);
        C4851q.C4862i.m15130f1(parcel, 11, this.f17480p);
        C4851q.C4862i.m15130f1(parcel, 12, this.f17481q);
        C4851q.C4862i.m15157o1(parcel, 13, this.f17482r, i, false);
        C4851q.C4862i.m15130f1(parcel, 14, this.f17477m);
        C4851q.C4862i.m15130f1(parcel, 15, this.f17483s);
        C4851q.C4862i.m15181w1(parcel, e);
    }
}
