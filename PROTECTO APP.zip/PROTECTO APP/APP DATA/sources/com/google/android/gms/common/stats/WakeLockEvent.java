package com.google.android.gms.common.stats;

import android.os.Parcel;
import android.os.Parcelable;
import java.util.List;
import p002b.p011c.p015b.p028b.p053e.p060q.C0599d;
import p176d.p178b.p179k.C4851q;

public final class WakeLockEvent extends StatsEvent {
    public static final Parcelable.Creator<WakeLockEvent> CREATOR = new C0599d();

    /* renamed from: e */
    public final int f17409e;

    /* renamed from: f */
    public final long f17410f;

    /* renamed from: g */
    public int f17411g;

    /* renamed from: h */
    public final String f17412h;

    /* renamed from: i */
    public final String f17413i;

    /* renamed from: j */
    public final String f17414j;

    /* renamed from: k */
    public final int f17415k;

    /* renamed from: l */
    public final List<String> f17416l;

    /* renamed from: m */
    public final String f17417m;

    /* renamed from: n */
    public final long f17418n;

    /* renamed from: o */
    public int f17419o;

    /* renamed from: p */
    public final String f17420p;

    /* renamed from: q */
    public final float f17421q;

    /* renamed from: r */
    public final long f17422r;

    /* renamed from: s */
    public final boolean f17423s;

    /* renamed from: t */
    public long f17424t = -1;

    public WakeLockEvent(int i, long j, int i2, String str, int i3, List<String> list, String str2, long j2, int i4, String str3, String str4, float f, long j3, String str5, boolean z) {
        this.f17409e = i;
        this.f17410f = j;
        this.f17411g = i2;
        this.f17412h = str;
        this.f17413i = str3;
        this.f17414j = str5;
        this.f17415k = i3;
        this.f17416l = list;
        this.f17417m = str2;
        this.f17418n = j2;
        this.f17419o = i4;
        this.f17420p = str4;
        this.f17421q = f;
        this.f17422r = j3;
        this.f17423s = z;
    }

    public final void writeToParcel(Parcel parcel, int i) {
        int e = C4851q.C4862i.m15125e(parcel);
        C4851q.C4862i.m15136h1(parcel, 1, this.f17409e);
        C4851q.C4862i.m15142j1(parcel, 2, this.f17410f);
        C4851q.C4862i.m15148l1(parcel, 4, this.f17412h, false);
        C4851q.C4862i.m15136h1(parcel, 5, this.f17415k);
        C4851q.C4862i.m15154n1(parcel, 6, this.f17416l, false);
        C4851q.C4862i.m15142j1(parcel, 8, this.f17418n);
        C4851q.C4862i.m15148l1(parcel, 10, this.f17413i, false);
        C4851q.C4862i.m15136h1(parcel, 11, this.f17411g);
        C4851q.C4862i.m15148l1(parcel, 12, this.f17417m, false);
        C4851q.C4862i.m15148l1(parcel, 13, this.f17420p, false);
        C4851q.C4862i.m15136h1(parcel, 14, this.f17419o);
        C4851q.C4862i.m15130f1(parcel, 15, this.f17421q);
        C4851q.C4862i.m15142j1(parcel, 16, this.f17422r);
        C4851q.C4862i.m15148l1(parcel, 17, this.f17414j, false);
        C4851q.C4862i.m15118b1(parcel, 18, this.f17423s);
        C4851q.C4862i.m15181w1(parcel, e);
    }
}
