package com.google.android.gms.measurement;

import android.os.Bundle;
import androidx.annotation.Keep;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import p002b.p011c.p015b.p028b.p053e.p061r.C0605f;
import p002b.p011c.p015b.p028b.p082j.p084b.C3461g5;
import p002b.p011c.p015b.p028b.p082j.p084b.C3487i7;
import p002b.p011c.p015b.p028b.p082j.p084b.C3510k6;
import p002b.p011c.p015b.p028b.p082j.p084b.C3536m7;
import p002b.p011c.p015b.p028b.p082j.p084b.C3558o7;
import p176d.p178b.p179k.C4851q;

@Deprecated
public class AppMeasurement {

    /* renamed from: d */
    public static volatile AppMeasurement f17447d;

    /* renamed from: a */
    public final C3461g5 f17448a;

    /* renamed from: b */
    public final C3487i7 f17449b;

    /* renamed from: c */
    public final boolean f17450c;

    public static class ConditionalUserProperty {
        @Keep
        public boolean mActive;
        @Keep
        public String mAppId;
        @Keep
        public long mCreationTimestamp;
        @Keep
        public String mExpiredEventName;
        @Keep
        public Bundle mExpiredEventParams;
        @Keep
        public String mName;
        @Keep
        public String mOrigin;
        @Keep
        public long mTimeToLive;
        @Keep
        public String mTimedOutEventName;
        @Keep
        public Bundle mTimedOutEventParams;
        @Keep
        public String mTriggerEventName;
        @Keep
        public long mTriggerTimeout;
        @Keep
        public String mTriggeredEventName;
        @Keep
        public Bundle mTriggeredEventParams;
        @Keep
        public long mTriggeredTimestamp;
        @Keep
        public Object mValue;

        public ConditionalUserProperty() {
        }

        public ConditionalUserProperty(Bundle bundle) {
            Class cls = Long.class;
            Class cls2 = String.class;
            C4851q.C4862i.m15170t(bundle);
            this.mAppId = (String) C0605f.m1105f1(bundle, "app_id", cls2, null);
            this.mOrigin = (String) C0605f.m1105f1(bundle, "origin", cls2, null);
            this.mName = (String) C0605f.m1105f1(bundle, "name", cls2, null);
            this.mValue = C0605f.m1105f1(bundle, "value", Object.class, null);
            this.mTriggerEventName = (String) C0605f.m1105f1(bundle, "trigger_event_name", cls2, null);
            this.mTriggerTimeout = ((Long) C0605f.m1105f1(bundle, "trigger_timeout", cls, 0L)).longValue();
            this.mTimedOutEventName = (String) C0605f.m1105f1(bundle, "timed_out_event_name", cls2, null);
            this.mTimedOutEventParams = (Bundle) C0605f.m1105f1(bundle, "timed_out_event_params", Bundle.class, null);
            this.mTriggeredEventName = (String) C0605f.m1105f1(bundle, "triggered_event_name", cls2, null);
            this.mTriggeredEventParams = (Bundle) C0605f.m1105f1(bundle, "triggered_event_params", Bundle.class, null);
            this.mTimeToLive = ((Long) C0605f.m1105f1(bundle, "time_to_live", cls, 0L)).longValue();
            this.mExpiredEventName = (String) C0605f.m1105f1(bundle, "expired_event_name", cls2, null);
            this.mExpiredEventParams = (Bundle) C0605f.m1105f1(bundle, "expired_event_params", Bundle.class, null);
            this.mActive = ((Boolean) C0605f.m1105f1(bundle, "active", Boolean.class, Boolean.FALSE)).booleanValue();
            this.mCreationTimestamp = ((Long) C0605f.m1105f1(bundle, "creation_timestamp", cls, 0L)).longValue();
            this.mTriggeredTimestamp = ((Long) C0605f.m1105f1(bundle, "triggered_timestamp", cls, 0L)).longValue();
        }

        /* renamed from: a */
        public final Bundle mo9707a() {
            Bundle bundle = new Bundle();
            String str = this.mAppId;
            if (str != null) {
                bundle.putString("app_id", str);
            }
            String str2 = this.mOrigin;
            if (str2 != null) {
                bundle.putString("origin", str2);
            }
            String str3 = this.mName;
            if (str3 != null) {
                bundle.putString("name", str3);
            }
            Object obj = this.mValue;
            if (obj != null) {
                C0605f.m978M1(bundle, obj);
            }
            String str4 = this.mTriggerEventName;
            if (str4 != null) {
                bundle.putString("trigger_event_name", str4);
            }
            bundle.putLong("trigger_timeout", this.mTriggerTimeout);
            String str5 = this.mTimedOutEventName;
            if (str5 != null) {
                bundle.putString("timed_out_event_name", str5);
            }
            Bundle bundle2 = this.mTimedOutEventParams;
            if (bundle2 != null) {
                bundle.putBundle("timed_out_event_params", bundle2);
            }
            String str6 = this.mTriggeredEventName;
            if (str6 != null) {
                bundle.putString("triggered_event_name", str6);
            }
            Bundle bundle3 = this.mTriggeredEventParams;
            if (bundle3 != null) {
                bundle.putBundle("triggered_event_params", bundle3);
            }
            bundle.putLong("time_to_live", this.mTimeToLive);
            String str7 = this.mExpiredEventName;
            if (str7 != null) {
                bundle.putString("expired_event_name", str7);
            }
            Bundle bundle4 = this.mExpiredEventParams;
            if (bundle4 != null) {
                bundle.putBundle("expired_event_params", bundle4);
            }
            bundle.putLong("creation_timestamp", this.mCreationTimestamp);
            bundle.putBoolean("active", this.mActive);
            bundle.putLong("triggered_timestamp", this.mTriggeredTimestamp);
            return bundle;
        }
    }

    public AppMeasurement(C3461g5 g5Var) {
        C4851q.C4862i.m15170t(g5Var);
        this.f17448a = g5Var;
        this.f17449b = null;
        this.f17450c = false;
    }

    public AppMeasurement(C3487i7 i7Var) {
        C4851q.C4862i.m15170t(i7Var);
        this.f17449b = i7Var;
        this.f17448a = null;
        this.f17450c = true;
    }

    /* JADX WARNING: No exception handlers in catch block: Catch:{  } */
    @java.lang.Deprecated
    @androidx.annotation.Keep
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static com.google.android.gms.measurement.AppMeasurement getInstance(android.content.Context r13) {
        /*
            com.google.android.gms.measurement.AppMeasurement r0 = f17447d
            if (r0 != 0) goto L_0x005c
            java.lang.Class<com.google.android.gms.measurement.AppMeasurement> r0 = com.google.android.gms.measurement.AppMeasurement.class
            monitor-enter(r0)
            com.google.android.gms.measurement.AppMeasurement r1 = f17447d     // Catch:{ all -> 0x0059 }
            if (r1 != 0) goto L_0x0057
            r1 = 0
            java.lang.String r2 = "com.google.firebase.analytics.FirebaseAnalytics"
            java.lang.Class r2 = java.lang.Class.forName(r2)     // Catch:{ ClassNotFoundException -> 0x0032 }
            java.lang.String r3 = "getScionFrontendApiImplementation"
            r4 = 2
            java.lang.Class[] r5 = new java.lang.Class[r4]     // Catch:{  }
            java.lang.Class<android.content.Context> r6 = android.content.Context.class
            r7 = 0
            r5[r7] = r6     // Catch:{  }
            java.lang.Class<android.os.Bundle> r6 = android.os.Bundle.class
            r8 = 1
            r5[r8] = r6     // Catch:{  }
            java.lang.reflect.Method r2 = r2.getDeclaredMethod(r3, r5)     // Catch:{  }
            java.lang.Object[] r3 = new java.lang.Object[r4]     // Catch:{  }
            r3[r7] = r13     // Catch:{  }
            r3[r8] = r1     // Catch:{  }
            java.lang.Object r2 = r2.invoke(r1, r3)     // Catch:{  }
            b.c.b.b.j.b.i7 r2 = (p002b.p011c.p015b.p028b.p082j.p084b.C3487i7) r2     // Catch:{  }
            goto L_0x0033
        L_0x0032:
            r2 = r1
        L_0x0033:
            if (r2 == 0) goto L_0x003d
            com.google.android.gms.measurement.AppMeasurement r13 = new com.google.android.gms.measurement.AppMeasurement     // Catch:{ all -> 0x0059 }
            r13.<init>((p002b.p011c.p015b.p028b.p082j.p084b.C3487i7) r2)     // Catch:{ all -> 0x0059 }
            f17447d = r13     // Catch:{ all -> 0x0059 }
            goto L_0x0057
        L_0x003d:
            b.c.b.b.i.j.f r12 = new b.c.b.b.i.j.f     // Catch:{ all -> 0x0059 }
            r3 = 0
            r5 = 0
            r7 = 1
            r8 = 0
            r9 = 0
            r10 = 0
            r11 = 0
            r2 = r12
            r2.<init>(r3, r5, r7, r8, r9, r10, r11)     // Catch:{ all -> 0x0059 }
            b.c.b.b.j.b.g5 r13 = p002b.p011c.p015b.p028b.p082j.p084b.C3461g5.m12271a(r13, r12, r1)     // Catch:{ all -> 0x0059 }
            com.google.android.gms.measurement.AppMeasurement r1 = new com.google.android.gms.measurement.AppMeasurement     // Catch:{ all -> 0x0059 }
            r1.<init>((p002b.p011c.p015b.p028b.p082j.p084b.C3461g5) r13)     // Catch:{ all -> 0x0059 }
            f17447d = r1     // Catch:{ all -> 0x0059 }
        L_0x0057:
            monitor-exit(r0)     // Catch:{ all -> 0x0059 }
            goto L_0x005c
        L_0x0059:
            r13 = move-exception
            monitor-exit(r0)     // Catch:{ all -> 0x0059 }
            throw r13
        L_0x005c:
            com.google.android.gms.measurement.AppMeasurement r13 = f17447d
            return r13
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.measurement.AppMeasurement.getInstance(android.content.Context):com.google.android.gms.measurement.AppMeasurement");
    }

    @Keep
    public void beginAdUnitExposure(String str) {
        if (this.f17450c) {
            this.f17449b.mo7745i(str);
        } else {
            this.f17448a.mo7692x().mo7468v(str, this.f17448a.f14341n.mo1503b());
        }
    }

    @Keep
    public void clearConditionalUserProperty(String str, String str2, Bundle bundle) {
        if (this.f17450c) {
            this.f17449b.mo7747k(str, str2, bundle);
            return;
        }
        C3510k6 p = this.f17448a.mo7684p();
        p.mo7492a();
        p.mo7779Q((String) null, str, str2, bundle);
    }

    @Keep
    public void clearConditionalUserPropertyAs(String str, String str2, String str3, Bundle bundle) {
        if (!this.f17450c) {
            C3510k6 p = this.f17448a.mo7684p();
            if (p != null) {
                C4851q.C4862i.m15155o(str);
                p.mo7508l();
                throw null;
            }
            throw null;
        }
        throw new IllegalStateException("Unexpected call on client side");
    }

    @Keep
    public void endAdUnitExposure(String str) {
        if (this.f17450c) {
            this.f17449b.mo7743g(str);
        } else {
            this.f17448a.mo7692x().mo7471y(str, this.f17448a.f14341n.mo1503b());
        }
    }

    @Keep
    public long generateEventId() {
        return this.f17450c ? this.f17449b.mo7741e() : this.f17448a.mo7685q().mo8017w0();
    }

    @Keep
    public String getAppInstanceId() {
        if (this.f17450c) {
            return this.f17449b.mo7739c();
        }
        C3510k6 p = this.f17448a.mo7684p();
        p.mo7492a();
        return p.f14485g.get();
    }

    @Keep
    public List<ConditionalUserProperty> getConditionalUserProperties(String str, String str2) {
        List<Bundle> list;
        if (this.f17450c) {
            list = this.f17449b.mo7742f(str, str2);
        } else {
            C3510k6 p = this.f17448a.mo7684p();
            p.mo7492a();
            list = p.mo7776M((String) null, str, str2);
        }
        ArrayList arrayList = new ArrayList(list == null ? 0 : list.size());
        for (Bundle conditionalUserProperty : list) {
            arrayList.add(new ConditionalUserProperty(conditionalUserProperty));
        }
        return arrayList;
    }

    @Keep
    public List<ConditionalUserProperty> getConditionalUserPropertiesAs(String str, String str2, String str3) {
        if (!this.f17450c) {
            C3510k6 p = this.f17448a.mo7684p();
            if (p != null) {
                C4851q.C4862i.m15155o(str);
                p.mo7508l();
                throw null;
            }
            throw null;
        }
        throw new IllegalStateException("Unexpected call on client side");
    }

    @Keep
    public String getCurrentScreenClass() {
        if (this.f17450c) {
            return this.f17449b.mo7738b();
        }
        C3558o7 t = this.f17448a.mo7684p().f14129a.mo7688t();
        t.mo7492a();
        C3536m7 m7Var = t.f14646c;
        if (m7Var != null) {
            return m7Var.f14564b;
        }
        return null;
    }

    @Keep
    public String getCurrentScreenName() {
        if (this.f17450c) {
            return this.f17449b.mo7737a();
        }
        C3558o7 t = this.f17448a.mo7684p().f14129a.mo7688t();
        t.mo7492a();
        C3536m7 m7Var = t.f14646c;
        if (m7Var != null) {
            return m7Var.f14563a;
        }
        return null;
    }

    @Keep
    public String getGmpAppId() {
        return this.f17450c ? this.f17449b.mo7740d() : this.f17448a.mo7684p().mo7774I();
    }

    @Keep
    public int getMaxUserProperties(String str) {
        if (this.f17450c) {
            return this.f17449b.mo7746j(str);
        }
        this.f17448a.mo7684p();
        C4851q.C4862i.m15155o(str);
        return 25;
    }

    @Keep
    public Map<String, Object> getUserProperties(String str, String str2, boolean z) {
        if (this.f17450c) {
            return this.f17449b.mo7744h(str, str2, z);
        }
        C3510k6 p = this.f17448a.mo7684p();
        p.mo7492a();
        return p.mo7777O((String) null, str, str2, z);
    }

    @Keep
    public Map<String, Object> getUserPropertiesAs(String str, String str2, String str3, boolean z) {
        if (!this.f17450c) {
            C3510k6 p = this.f17448a.mo7684p();
            if (p != null) {
                C4851q.C4862i.m15155o(str);
                p.mo7508l();
                throw null;
            }
            throw null;
        }
        throw new IllegalStateException("Unexpected call on client side");
    }

    @Keep
    public void logEventInternal(String str, String str2, Bundle bundle) {
        if (this.f17450c) {
            this.f17449b.mo7735L0(str, str2, bundle);
        } else {
            this.f17448a.mo7684p().mo7767B(str, str2, bundle);
        }
    }

    @Keep
    public void setConditionalUserProperty(ConditionalUserProperty conditionalUserProperty) {
        C4851q.C4862i.m15170t(conditionalUserProperty);
        if (this.f17450c) {
            this.f17449b.mo7736N(conditionalUserProperty.mo9707a());
            return;
        }
        C3510k6 p = this.f17448a.mo7684p();
        p.mo7780x(conditionalUserProperty.mo9707a(), p.f14129a.f14341n.mo1502a());
    }

    @Keep
    public void setConditionalUserPropertyAs(ConditionalUserProperty conditionalUserProperty) {
        C4851q.C4862i.m15170t(conditionalUserProperty);
        if (!this.f17450c) {
            C3510k6 p = this.f17448a.mo7684p();
            Bundle a = conditionalUserProperty.mo9707a();
            if (p != null) {
                C4851q.C4862i.m15170t(a);
                C4851q.C4862i.m15155o(a.getString("app_id"));
                p.mo7508l();
                throw null;
            }
            throw null;
        }
        throw new IllegalStateException("Unexpected call on client side");
    }
}
