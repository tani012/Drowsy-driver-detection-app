package com.google.android.gms.vision.internal;

import androidx.annotation.Keep;
import p002b.p011c.p015b.p028b.p066h.C0637a;

@Keep
public class Flags {
    public static final C0637a<Boolean> zzdl = new C0637a.C0638a(0, "vision:product_barcode_value_logging_enabled", Boolean.TRUE);
}
