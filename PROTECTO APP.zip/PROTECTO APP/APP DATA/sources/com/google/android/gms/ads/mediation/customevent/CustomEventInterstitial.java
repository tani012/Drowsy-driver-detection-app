package com.google.android.gms.ads.mediation.customevent;

import android.content.Context;
import android.os.Bundle;
import p002b.p011c.p015b.p028b.p029a.p041y.C0404e;
import p002b.p011c.p015b.p028b.p029a.p041y.p042w.C0422a;
import p002b.p011c.p015b.p028b.p029a.p041y.p042w.C0425d;

public interface CustomEventInterstitial extends C0422a {
    /* synthetic */ void onDestroy();

    /* synthetic */ void onPause();

    /* synthetic */ void onResume();

    void requestInterstitialAd(Context context, C0425d dVar, String str, C0404e eVar, Bundle bundle);

    void showInterstitial();
}
