package com.google.android.gms.vision.face.internal.client;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.apps.common.proguard.UsedByNative;
import p002b.p011c.p015b.p028b.p053e.p057o.p058t.C0585a;
import p002b.p011c.p015b.p028b.p090o.p092d.p093e.p094a.C3765m;
import p176d.p178b.p179k.C4851q;

@UsedByNative("wrapper.cc")
public final class LandmarkParcel extends C0585a {
    public static final Parcelable.Creator<LandmarkParcel> CREATOR = new C3765m();

    /* renamed from: e */
    public final int f17484e;

    /* renamed from: f */
    public final float f17485f;

    /* renamed from: g */
    public final float f17486g;

    /* renamed from: h */
    public final int f17487h;

    @UsedByNative("wrapper.cc")
    public LandmarkParcel(int i, float f, float f2, int i2) {
        this.f17484e = i;
        this.f17485f = f;
        this.f17486g = f2;
        this.f17487h = i2;
    }

    public final void writeToParcel(Parcel parcel, int i) {
        int e = C4851q.C4862i.m15125e(parcel);
        C4851q.C4862i.m15136h1(parcel, 1, this.f17484e);
        C4851q.C4862i.m15130f1(parcel, 2, this.f17485f);
        C4851q.C4862i.m15130f1(parcel, 3, this.f17486g);
        C4851q.C4862i.m15136h1(parcel, 4, this.f17487h);
        C4851q.C4862i.m15181w1(parcel, e);
    }
}
