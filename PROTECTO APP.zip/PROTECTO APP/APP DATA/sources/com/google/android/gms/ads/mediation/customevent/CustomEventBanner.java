package com.google.android.gms.ads.mediation.customevent;

import android.content.Context;
import android.os.Bundle;
import p002b.p011c.p015b.p028b.p029a.C0305f;
import p002b.p011c.p015b.p028b.p029a.p041y.C0404e;
import p002b.p011c.p015b.p028b.p029a.p041y.p042w.C0422a;
import p002b.p011c.p015b.p028b.p029a.p041y.p042w.C0423b;

public interface CustomEventBanner extends C0422a {
    /* synthetic */ void onDestroy();

    /* synthetic */ void onPause();

    /* synthetic */ void onResume();

    void requestBannerAd(Context context, C0423b bVar, String str, C0305f fVar, C0404e eVar, Bundle bundle);
}
