package com.google.android.gms.vision.face;

import android.graphics.PointF;
import android.os.SystemClock;
import com.google.android.gms.vision.clearcut.DynamiteClearcutLogger;
import com.google.android.gms.vision.face.internal.client.FaceParcel;
import com.google.android.gms.vision.face.internal.client.LandmarkParcel;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;
import p002b.p011c.p015b.p028b.p053e.p057o.C0566i;
import p002b.p011c.p015b.p028b.p064f.C0621a;
import p002b.p011c.p015b.p028b.p064f.C0624b;
import p002b.p011c.p015b.p028b.p068i.p081m.C3087a2;
import p002b.p011c.p015b.p028b.p068i.p081m.C3095b0;
import p002b.p011c.p015b.p028b.p068i.p081m.C3098b2;
import p002b.p011c.p015b.p028b.p068i.p081m.C3107c0;
import p002b.p011c.p015b.p028b.p068i.p081m.C3127e0;
import p002b.p011c.p015b.p028b.p068i.p081m.C3146e2;
import p002b.p011c.p015b.p028b.p068i.p081m.C3149e4;
import p002b.p011c.p015b.p028b.p068i.p081m.C3163f2;
import p002b.p011c.p015b.p028b.p068i.p081m.C3171g0;
import p002b.p011c.p015b.p028b.p068i.p081m.C3173g2;
import p002b.p011c.p015b.p028b.p068i.p081m.C3179g7;
import p002b.p011c.p015b.p028b.p068i.p081m.C3197i7;
import p002b.p011c.p015b.p028b.p068i.p081m.C3211j0;
import p002b.p011c.p015b.p028b.p068i.p081m.C3234l4;
import p002b.p011c.p015b.p028b.p068i.p081m.C3257n7;
import p002b.p011c.p015b.p028b.p068i.p081m.C3290r2;
import p002b.p011c.p015b.p028b.p068i.p081m.C3332v1;
import p002b.p011c.p015b.p028b.p068i.p081m.C3350w7;
import p002b.p011c.p015b.p028b.p068i.p081m.C3351x;
import p002b.p011c.p015b.p028b.p068i.p081m.C3353x1;
import p002b.p011c.p015b.p028b.p068i.p081m.C3375z1;
import p002b.p011c.p015b.p028b.p090o.p092d.p093e.p094a.C3753a;
import p002b.p011c.p015b.p028b.p090o.p092d.p093e.p094a.C3759g;

public final class NativeFaceDetectorV2Impl extends C3759g {

    /* renamed from: i */
    public static final C0566i f17462i = new C0566i("NativeFaceDetectorV2Imp", "");

    /* renamed from: e */
    public final long f17463e;

    /* renamed from: f */
    public final DynamiteClearcutLogger f17464f;

    /* renamed from: g */
    public final C3127e0.C3137d f17465g;

    /* renamed from: h */
    public final FaceDetectorV2Jni f17466h;

    /* renamed from: com.google.android.gms.vision.face.NativeFaceDetectorV2Impl$1 */
    public static /* synthetic */ class C48081 {

        /* renamed from: a */
        public static final /* synthetic */ int[] f17467a;

        /* renamed from: b */
        public static final /* synthetic */ int[] f17468b;

        /* JADX WARNING: Can't wrap try/catch for region: R(55:0|(2:1|2)|3|(2:5|6)|7|(2:9|10)|11|(2:13|14)|15|(2:17|18)|19|(2:21|22)|23|(2:25|26)|27|(2:29|30)|31|(2:33|34)|35|(2:37|38)|39|41|42|43|45|46|47|48|49|50|(2:51|52)|53|55|56|57|58|59|60|61|62|63|64|65|66|67|68|69|70|71|72|73|74|75|76|(3:77|78|80)) */
        /* JADX WARNING: Can't wrap try/catch for region: R(56:0|(2:1|2)|3|(2:5|6)|7|(2:9|10)|11|(2:13|14)|15|(2:17|18)|19|(2:21|22)|23|(2:25|26)|27|(2:29|30)|31|(2:33|34)|35|37|38|39|41|42|43|45|46|47|48|49|50|(2:51|52)|53|55|56|57|58|59|60|61|62|63|64|65|66|67|68|69|70|71|72|73|74|75|76|(3:77|78|80)) */
        /* JADX WARNING: Can't wrap try/catch for region: R(57:0|(2:1|2)|3|(2:5|6)|7|(2:9|10)|11|(2:13|14)|15|(2:17|18)|19|(2:21|22)|23|(2:25|26)|27|(2:29|30)|31|33|34|35|37|38|39|41|42|43|45|46|47|48|49|50|(2:51|52)|53|55|56|57|58|59|60|61|62|63|64|65|66|67|68|69|70|71|72|73|74|75|76|(3:77|78|80)) */
        /* JADX WARNING: Can't wrap try/catch for region: R(58:0|(2:1|2)|3|(2:5|6)|7|(2:9|10)|11|(2:13|14)|15|(2:17|18)|19|(2:21|22)|23|(2:25|26)|27|29|30|31|33|34|35|37|38|39|41|42|43|45|46|47|48|49|50|(2:51|52)|53|55|56|57|58|59|60|61|62|63|64|65|66|67|68|69|70|71|72|73|74|75|76|(3:77|78|80)) */
        /* JADX WARNING: Can't wrap try/catch for region: R(65:0|(2:1|2)|3|(2:5|6)|7|(2:9|10)|11|13|14|15|17|18|19|21|22|23|25|26|27|29|30|31|33|34|35|37|38|39|41|42|43|45|46|47|48|49|50|51|52|53|55|56|57|58|59|60|61|62|63|64|65|66|67|68|69|70|71|72|73|74|75|76|77|78|80) */
        /* JADX WARNING: Can't wrap try/catch for region: R(66:0|(2:1|2)|3|(2:5|6)|7|9|10|11|13|14|15|17|18|19|21|22|23|25|26|27|29|30|31|33|34|35|37|38|39|41|42|43|45|46|47|48|49|50|51|52|53|55|56|57|58|59|60|61|62|63|64|65|66|67|68|69|70|71|72|73|74|75|76|77|78|80) */
        /* JADX WARNING: Can't wrap try/catch for region: R(67:0|(2:1|2)|3|5|6|7|9|10|11|13|14|15|17|18|19|21|22|23|25|26|27|29|30|31|33|34|35|37|38|39|41|42|43|45|46|47|48|49|50|51|52|53|55|56|57|58|59|60|61|62|63|64|65|66|67|68|69|70|71|72|73|74|75|76|77|78|80) */
        /* JADX WARNING: Can't wrap try/catch for region: R(68:0|1|2|3|5|6|7|9|10|11|13|14|15|17|18|19|21|22|23|25|26|27|29|30|31|33|34|35|37|38|39|41|42|43|45|46|47|48|49|50|51|52|53|55|56|57|58|59|60|61|62|63|64|65|66|67|68|69|70|71|72|73|74|75|76|77|78|80) */
        /* JADX WARNING: Failed to process nested try/catch */
        /* JADX WARNING: Missing exception handler attribute for start block: B:47:0x0048 */
        /* JADX WARNING: Missing exception handler attribute for start block: B:49:0x004e */
        /* JADX WARNING: Missing exception handler attribute for start block: B:51:0x0054 */
        /* JADX WARNING: Missing exception handler attribute for start block: B:57:0x0066 */
        /* JADX WARNING: Missing exception handler attribute for start block: B:59:0x006a */
        /* JADX WARNING: Missing exception handler attribute for start block: B:61:0x006e */
        /* JADX WARNING: Missing exception handler attribute for start block: B:63:0x0072 */
        /* JADX WARNING: Missing exception handler attribute for start block: B:65:0x0076 */
        /* JADX WARNING: Missing exception handler attribute for start block: B:67:0x007a */
        /* JADX WARNING: Missing exception handler attribute for start block: B:69:0x0080 */
        /* JADX WARNING: Missing exception handler attribute for start block: B:71:0x0086 */
        /* JADX WARNING: Missing exception handler attribute for start block: B:73:0x008c */
        /* JADX WARNING: Missing exception handler attribute for start block: B:75:0x0092 */
        /* JADX WARNING: Missing exception handler attribute for start block: B:77:0x0098 */
        static {
            /*
                b.c.b.b.i.m.e0$b$c[] r0 = p002b.p011c.p015b.p028b.p068i.p081m.C3127e0.C3130b.C3134c.values()
                int r0 = r0.length
                int[] r0 = new int[r0]
                f17468b = r0
                r1 = 1
                r0[r1] = r1     // Catch:{ NoSuchFieldError -> 0x000c }
            L_0x000c:
                r0 = 2
                int[] r2 = f17468b     // Catch:{ NoSuchFieldError -> 0x0011 }
                r2[r0] = r0     // Catch:{ NoSuchFieldError -> 0x0011 }
            L_0x0011:
                r2 = 3
                int[] r3 = f17468b     // Catch:{ NoSuchFieldError -> 0x0016 }
                r3[r2] = r2     // Catch:{ NoSuchFieldError -> 0x0016 }
            L_0x0016:
                r3 = 4
                int[] r4 = f17468b     // Catch:{ NoSuchFieldError -> 0x001b }
                r4[r3] = r3     // Catch:{ NoSuchFieldError -> 0x001b }
            L_0x001b:
                r4 = 5
                int[] r5 = f17468b     // Catch:{ NoSuchFieldError -> 0x0020 }
                r5[r4] = r4     // Catch:{ NoSuchFieldError -> 0x0020 }
            L_0x0020:
                r5 = 6
                int[] r6 = f17468b     // Catch:{ NoSuchFieldError -> 0x0025 }
                r6[r5] = r5     // Catch:{ NoSuchFieldError -> 0x0025 }
            L_0x0025:
                r6 = 7
                int[] r7 = f17468b     // Catch:{ NoSuchFieldError -> 0x002a }
                r7[r6] = r6     // Catch:{ NoSuchFieldError -> 0x002a }
            L_0x002a:
                r7 = 8
                int[] r8 = f17468b     // Catch:{ NoSuchFieldError -> 0x0030 }
                r8[r7] = r7     // Catch:{ NoSuchFieldError -> 0x0030 }
            L_0x0030:
                r8 = 9
                int[] r9 = f17468b     // Catch:{ NoSuchFieldError -> 0x0036 }
                r9[r8] = r8     // Catch:{ NoSuchFieldError -> 0x0036 }
            L_0x0036:
                r9 = 10
                int[] r10 = f17468b     // Catch:{ NoSuchFieldError -> 0x003c }
                r10[r9] = r9     // Catch:{ NoSuchFieldError -> 0x003c }
            L_0x003c:
                r10 = 11
                int[] r11 = f17468b     // Catch:{ NoSuchFieldError -> 0x0042 }
                r11[r10] = r10     // Catch:{ NoSuchFieldError -> 0x0042 }
            L_0x0042:
                r11 = 12
                int[] r12 = f17468b     // Catch:{ NoSuchFieldError -> 0x0048 }
                r12[r11] = r11     // Catch:{ NoSuchFieldError -> 0x0048 }
            L_0x0048:
                int[] r12 = f17468b     // Catch:{ NoSuchFieldError -> 0x004e }
                r13 = 13
                r12[r13] = r13     // Catch:{ NoSuchFieldError -> 0x004e }
            L_0x004e:
                int[] r12 = f17468b     // Catch:{ NoSuchFieldError -> 0x0054 }
                r13 = 14
                r12[r13] = r13     // Catch:{ NoSuchFieldError -> 0x0054 }
            L_0x0054:
                int[] r12 = f17468b     // Catch:{ NoSuchFieldError -> 0x005a }
                r13 = 15
                r12[r13] = r13     // Catch:{ NoSuchFieldError -> 0x005a }
            L_0x005a:
                b.c.b.b.i.m.i7$e$a[] r12 = p002b.p011c.p015b.p028b.p068i.p081m.C3197i7.C3206e.C3207a.values()
                int r12 = r12.length
                int[] r12 = new int[r12]
                f17467a = r12
                r13 = 0
                r12[r13] = r1     // Catch:{ NoSuchFieldError -> 0x0066 }
            L_0x0066:
                int[] r12 = f17467a     // Catch:{ NoSuchFieldError -> 0x006a }
                r12[r1] = r0     // Catch:{ NoSuchFieldError -> 0x006a }
            L_0x006a:
                int[] r0 = f17467a     // Catch:{ NoSuchFieldError -> 0x006e }
                r0[r6] = r2     // Catch:{ NoSuchFieldError -> 0x006e }
            L_0x006e:
                int[] r0 = f17467a     // Catch:{ NoSuchFieldError -> 0x0072 }
                r0[r8] = r3     // Catch:{ NoSuchFieldError -> 0x0072 }
            L_0x0072:
                int[] r0 = f17467a     // Catch:{ NoSuchFieldError -> 0x0076 }
                r0[r9] = r4     // Catch:{ NoSuchFieldError -> 0x0076 }
            L_0x0076:
                int[] r0 = f17467a     // Catch:{ NoSuchFieldError -> 0x007a }
                r0[r10] = r5     // Catch:{ NoSuchFieldError -> 0x007a }
            L_0x007a:
                int[] r0 = f17467a     // Catch:{ NoSuchFieldError -> 0x0080 }
                r1 = 26
                r0[r1] = r6     // Catch:{ NoSuchFieldError -> 0x0080 }
            L_0x0080:
                int[] r0 = f17467a     // Catch:{ NoSuchFieldError -> 0x0086 }
                r1 = 27
                r0[r1] = r7     // Catch:{ NoSuchFieldError -> 0x0086 }
            L_0x0086:
                int[] r0 = f17467a     // Catch:{ NoSuchFieldError -> 0x008c }
                r1 = 34
                r0[r1] = r8     // Catch:{ NoSuchFieldError -> 0x008c }
            L_0x008c:
                int[] r0 = f17467a     // Catch:{ NoSuchFieldError -> 0x0092 }
                r1 = 35
                r0[r1] = r9     // Catch:{ NoSuchFieldError -> 0x0092 }
            L_0x0092:
                int[] r0 = f17467a     // Catch:{ NoSuchFieldError -> 0x0098 }
                r1 = 36
                r0[r1] = r10     // Catch:{ NoSuchFieldError -> 0x0098 }
            L_0x0098:
                int[] r0 = f17467a     // Catch:{ NoSuchFieldError -> 0x009e }
                r1 = 37
                r0[r1] = r11     // Catch:{ NoSuchFieldError -> 0x009e }
            L_0x009e:
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.vision.face.NativeFaceDetectorV2Impl.C48081.<clinit>():void");
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:71:0x01ac, code lost:
        if (r1.f13613g != false) goto L_0x01b5;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:73:0x01b3, code lost:
        if (r1.f13613g != false) goto L_0x01b5;
     */
    /* JADX WARNING: Removed duplicated region for block: B:61:0x0191  */
    /* JADX WARNING: Removed duplicated region for block: B:65:0x019c  */
    /* JADX WARNING: Removed duplicated region for block: B:69:0x01a5  */
    /* JADX WARNING: Removed duplicated region for block: B:72:0x01af  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public NativeFaceDetectorV2Impl(android.content.Context r7, com.google.android.gms.vision.clearcut.DynamiteClearcutLogger r8, p002b.p011c.p015b.p028b.p090o.p092d.p093e.p094a.C3758f r9, com.google.android.gms.vision.face.FaceDetectorV2Jni r10) {
        /*
            r6 = this;
            r6.<init>()
            b.c.b.b.i.m.e0$g r0 = p002b.p011c.p015b.p028b.p068i.p081m.C3127e0.C3143g.zzli
            b.c.b.b.i.m.e4$a r0 = r0.mo7139n()
            b.c.b.b.i.m.e0$g$a r0 = (p002b.p011c.p015b.p028b.p068i.p081m.C3127e0.C3143g.C3144a) r0
            boolean r1 = r0.f13613g
            r2 = 0
            if (r1 == 0) goto L_0x0015
            r0.mo7144j()
            r0.f13613g = r2
        L_0x0015:
            MessageType r1 = r0.f13612f
            b.c.b.b.i.m.e0$g r1 = (p002b.p011c.p015b.p028b.p068i.p081m.C3127e0.C3143g) r1
            java.lang.String r3 = "models"
            p002b.p011c.p015b.p028b.p068i.p081m.C3127e0.C3143g.m11508o(r1, r3)
            b.c.b.b.i.m.o5 r0 = r0.mo7146l()
            b.c.b.b.i.m.e4 r0 = (p002b.p011c.p015b.p028b.p068i.p081m.C3149e4) r0
            b.c.b.b.i.m.e0$g r0 = (p002b.p011c.p015b.p028b.p068i.p081m.C3127e0.C3143g) r0
            b.c.b.b.i.m.e0$d r1 = p002b.p011c.p015b.p028b.p068i.p081m.C3127e0.C3137d.zzkm
            b.c.b.b.i.m.e4$a r1 = r1.mo7139n()
            b.c.b.b.i.m.e0$d$a r1 = (p002b.p011c.p015b.p028b.p068i.p081m.C3127e0.C3137d.C3138a) r1
            b.c.b.b.i.m.e0$e r3 = p002b.p011c.p015b.p028b.p068i.p081m.C3127e0.C3139e.zzkq
            b.c.b.b.i.m.e4$a r3 = r3.mo7139n()
            b.c.b.b.i.m.e0$e$a r3 = (p002b.p011c.p015b.p028b.p068i.p081m.C3127e0.C3139e.C3140a) r3
            boolean r4 = r3.f13613g
            if (r4 == 0) goto L_0x003f
            r3.mo7144j()
            r3.f13613g = r2
        L_0x003f:
            MessageType r4 = r3.f13612f
            b.c.b.b.i.m.e0$e r4 = (p002b.p011c.p015b.p028b.p068i.p081m.C3127e0.C3139e) r4
            p002b.p011c.p015b.p028b.p068i.p081m.C3127e0.C3139e.m11499o(r4, r0)
            boolean r4 = r3.f13613g
            if (r4 == 0) goto L_0x004f
            r3.mo7144j()
            r3.f13613g = r2
        L_0x004f:
            MessageType r4 = r3.f13612f
            b.c.b.b.i.m.e0$e r4 = (p002b.p011c.p015b.p028b.p068i.p081m.C3127e0.C3139e) r4
            p002b.p011c.p015b.p028b.p068i.p081m.C3127e0.C3139e.m11500p(r4, r0)
            boolean r4 = r3.f13613g
            if (r4 == 0) goto L_0x005f
            r3.mo7144j()
            r3.f13613g = r2
        L_0x005f:
            MessageType r4 = r3.f13612f
            b.c.b.b.i.m.e0$e r4 = (p002b.p011c.p015b.p028b.p068i.p081m.C3127e0.C3139e) r4
            p002b.p011c.p015b.p028b.p068i.p081m.C3127e0.C3139e.m11501q(r4, r0)
            boolean r4 = r1.f13613g
            if (r4 == 0) goto L_0x006f
            r1.mo7144j()
            r1.f13613g = r2
        L_0x006f:
            MessageType r4 = r1.f13612f
            b.c.b.b.i.m.e0$d r4 = (p002b.p011c.p015b.p028b.p068i.p081m.C3127e0.C3137d) r4
            b.c.b.b.i.m.o5 r3 = r3.mo7146l()
            b.c.b.b.i.m.e4 r3 = (p002b.p011c.p015b.p028b.p068i.p081m.C3149e4) r3
            b.c.b.b.i.m.e0$e r3 = (p002b.p011c.p015b.p028b.p068i.p081m.C3127e0.C3139e) r3
            p002b.p011c.p015b.p028b.p068i.p081m.C3127e0.C3137d.m11491p(r4, r3)
            b.c.b.b.i.m.e0$a r3 = p002b.p011c.p015b.p028b.p068i.p081m.C3127e0.C3128a.zziu
            b.c.b.b.i.m.e4$a r3 = r3.mo7139n()
            b.c.b.b.i.m.e0$a$a r3 = (p002b.p011c.p015b.p028b.p068i.p081m.C3127e0.C3128a.C3129a) r3
            boolean r4 = r3.f13613g
            if (r4 == 0) goto L_0x008f
            r3.mo7144j()
            r3.f13613g = r2
        L_0x008f:
            MessageType r4 = r3.f13612f
            b.c.b.b.i.m.e0$a r4 = (p002b.p011c.p015b.p028b.p068i.p081m.C3127e0.C3128a) r4
            p002b.p011c.p015b.p028b.p068i.p081m.C3127e0.C3128a.m11481o(r4, r0)
            boolean r4 = r3.f13613g
            if (r4 == 0) goto L_0x009f
            r3.mo7144j()
            r3.f13613g = r2
        L_0x009f:
            MessageType r4 = r3.f13612f
            b.c.b.b.i.m.e0$a r4 = (p002b.p011c.p015b.p028b.p068i.p081m.C3127e0.C3128a) r4
            p002b.p011c.p015b.p028b.p068i.p081m.C3127e0.C3128a.m11482p(r4, r0)
            boolean r4 = r1.f13613g
            if (r4 == 0) goto L_0x00af
            r1.mo7144j()
            r1.f13613g = r2
        L_0x00af:
            MessageType r4 = r1.f13612f
            b.c.b.b.i.m.e0$d r4 = (p002b.p011c.p015b.p028b.p068i.p081m.C3127e0.C3137d) r4
            b.c.b.b.i.m.o5 r3 = r3.mo7146l()
            b.c.b.b.i.m.e4 r3 = (p002b.p011c.p015b.p028b.p068i.p081m.C3149e4) r3
            b.c.b.b.i.m.e0$a r3 = (p002b.p011c.p015b.p028b.p068i.p081m.C3127e0.C3128a) r3
            p002b.p011c.p015b.p028b.p068i.p081m.C3127e0.C3137d.m11490o(r4, r3)
            b.c.b.b.i.m.e0$f r3 = p002b.p011c.p015b.p028b.p068i.p081m.C3127e0.C3141f.zzla
            b.c.b.b.i.m.e4$a r3 = r3.mo7139n()
            b.c.b.b.i.m.e0$f$a r3 = (p002b.p011c.p015b.p028b.p068i.p081m.C3127e0.C3141f.C3142a) r3
            boolean r4 = r3.f13613g
            if (r4 == 0) goto L_0x00cf
            r3.mo7144j()
            r3.f13613g = r2
        L_0x00cf:
            MessageType r4 = r3.f13612f
            b.c.b.b.i.m.e0$f r4 = (p002b.p011c.p015b.p028b.p068i.p081m.C3127e0.C3141f) r4
            p002b.p011c.p015b.p028b.p068i.p081m.C3127e0.C3141f.m11503o(r4, r0)
            boolean r4 = r3.f13613g
            if (r4 == 0) goto L_0x00df
            r3.mo7144j()
            r3.f13613g = r2
        L_0x00df:
            MessageType r4 = r3.f13612f
            b.c.b.b.i.m.e0$f r4 = (p002b.p011c.p015b.p028b.p068i.p081m.C3127e0.C3141f) r4
            p002b.p011c.p015b.p028b.p068i.p081m.C3127e0.C3141f.m11504p(r4, r0)
            boolean r4 = r3.f13613g
            if (r4 == 0) goto L_0x00ef
            r3.mo7144j()
            r3.f13613g = r2
        L_0x00ef:
            MessageType r4 = r3.f13612f
            b.c.b.b.i.m.e0$f r4 = (p002b.p011c.p015b.p028b.p068i.p081m.C3127e0.C3141f) r4
            p002b.p011c.p015b.p028b.p068i.p081m.C3127e0.C3141f.m11505q(r4, r0)
            boolean r4 = r3.f13613g
            if (r4 == 0) goto L_0x00ff
            r3.mo7144j()
            r3.f13613g = r2
        L_0x00ff:
            MessageType r4 = r3.f13612f
            b.c.b.b.i.m.e0$f r4 = (p002b.p011c.p015b.p028b.p068i.p081m.C3127e0.C3141f) r4
            p002b.p011c.p015b.p028b.p068i.p081m.C3127e0.C3141f.m11506r(r4, r0)
            boolean r0 = r1.f13613g
            if (r0 == 0) goto L_0x010f
            r1.mo7144j()
            r1.f13613g = r2
        L_0x010f:
            MessageType r0 = r1.f13612f
            b.c.b.b.i.m.e0$d r0 = (p002b.p011c.p015b.p028b.p068i.p081m.C3127e0.C3137d) r0
            b.c.b.b.i.m.o5 r3 = r3.mo7146l()
            b.c.b.b.i.m.e4 r3 = (p002b.p011c.p015b.p028b.p068i.p081m.C3149e4) r3
            b.c.b.b.i.m.e0$f r3 = (p002b.p011c.p015b.p028b.p068i.p081m.C3127e0.C3141f) r3
            p002b.p011c.p015b.p028b.p068i.p081m.C3127e0.C3137d.m11492q(r0, r3)
            boolean r0 = r9.f15195h
            boolean r3 = r1.f13613g
            if (r3 == 0) goto L_0x0129
            r1.mo7144j()
            r1.f13613g = r2
        L_0x0129:
            MessageType r3 = r1.f13612f
            b.c.b.b.i.m.e0$d r3 = (p002b.p011c.p015b.p028b.p068i.p081m.C3127e0.C3137d) r3
            int r4 = r3.zzbf
            r4 = r4 | 16
            r3.zzbf = r4
            r3.zzke = r0
            boolean r0 = r9.f15196i
            boolean r3 = r1.f13613g
            if (r3 == 0) goto L_0x0140
            r1.mo7144j()
            r1.f13613g = r2
        L_0x0140:
            MessageType r3 = r1.f13612f
            b.c.b.b.i.m.e0$d r3 = (p002b.p011c.p015b.p028b.p068i.p081m.C3127e0.C3137d) r3
            int r4 = r3.zzbf
            r4 = r4 | 32
            r3.zzbf = r4
            r3.zzkf = r0
            float r0 = r9.f15197j
            boolean r3 = r1.f13613g
            if (r3 == 0) goto L_0x0157
            r1.mo7144j()
            r1.f13613g = r2
        L_0x0157:
            MessageType r3 = r1.f13612f
            b.c.b.b.i.m.e0$d r3 = (p002b.p011c.p015b.p028b.p068i.p081m.C3127e0.C3137d) r3
            int r4 = r3.zzbf
            r5 = 1
            r4 = r4 | r5
            r3.zzbf = r4
            r3.zzka = r0
            boolean r0 = r1.f13613g
            if (r0 == 0) goto L_0x016c
            r1.mo7144j()
            r1.f13613g = r2
        L_0x016c:
            MessageType r0 = r1.f13612f
            b.c.b.b.i.m.e0$d r0 = (p002b.p011c.p015b.p028b.p068i.p081m.C3127e0.C3137d) r0
            int r3 = r0.zzbf
            r3 = r3 | 256(0x100, float:3.59E-43)
            r0.zzbf = r3
            r0.zzki = r5
            int r0 = r9.f15192e
            r3 = 2
            if (r0 == 0) goto L_0x0188
            if (r0 == r5) goto L_0x0185
            if (r0 == r3) goto L_0x0182
            goto L_0x018d
        L_0x0182:
            b.c.b.b.i.m.l0 r0 = p002b.p011c.p015b.p028b.p068i.p081m.C3229l0.SELFIE
            goto L_0x018a
        L_0x0185:
            b.c.b.b.i.m.l0 r0 = p002b.p011c.p015b.p028b.p068i.p081m.C3229l0.ACCURATE
            goto L_0x018a
        L_0x0188:
            b.c.b.b.i.m.l0 r0 = p002b.p011c.p015b.p028b.p068i.p081m.C3229l0.FAST
        L_0x018a:
            r1.mo7124n(r0)
        L_0x018d:
            int r0 = r9.f15193f
            if (r0 == 0) goto L_0x019c
            if (r0 == r5) goto L_0x0199
            if (r0 == r3) goto L_0x0196
            goto L_0x01a1
        L_0x0196:
            b.c.b.b.i.m.j0 r0 = p002b.p011c.p015b.p028b.p068i.p081m.C3211j0.CONTOUR_LANDMARKS
            goto L_0x019e
        L_0x0199:
            b.c.b.b.i.m.j0 r0 = p002b.p011c.p015b.p028b.p068i.p081m.C3211j0.ALL_LANDMARKS
            goto L_0x019e
        L_0x019c:
            b.c.b.b.i.m.j0 r0 = p002b.p011c.p015b.p028b.p068i.p081m.C3211j0.NO_LANDMARK
        L_0x019e:
            r1.mo7123m(r0)
        L_0x01a1:
            int r9 = r9.f15194g
            if (r9 == 0) goto L_0x01af
            if (r9 == r5) goto L_0x01a8
            goto L_0x01c1
        L_0x01a8:
            b.c.b.b.i.m.g0 r9 = p002b.p011c.p015b.p028b.p068i.p081m.C3171g0.ALL_CLASSIFICATIONS
            boolean r0 = r1.f13613g
            if (r0 == 0) goto L_0x01ba
            goto L_0x01b5
        L_0x01af:
            b.c.b.b.i.m.g0 r9 = p002b.p011c.p015b.p028b.p068i.p081m.C3171g0.NO_CLASSIFICATION
            boolean r0 = r1.f13613g
            if (r0 == 0) goto L_0x01ba
        L_0x01b5:
            r1.mo7144j()
            r1.f13613g = r2
        L_0x01ba:
            MessageType r0 = r1.f13612f
            b.c.b.b.i.m.e0$d r0 = (p002b.p011c.p015b.p028b.p068i.p081m.C3127e0.C3137d) r0
            p002b.p011c.p015b.p028b.p068i.p081m.C3127e0.C3137d.m11493r(r0, r9)
        L_0x01c1:
            b.c.b.b.i.m.o5 r9 = r1.mo7146l()
            b.c.b.b.i.m.e4 r9 = (p002b.p011c.p015b.p028b.p068i.p081m.C3149e4) r9
            b.c.b.b.i.m.e0$d r9 = (p002b.p011c.p015b.p028b.p068i.p081m.C3127e0.C3137d) r9
            r6.f17465g = r9
            android.content.res.AssetManager r7 = r7.getAssets()
            long r0 = r10.mo9727a(r9, r7)
            r6.f17463e = r0
            r6.f17464f = r8
            r6.f17466h = r10
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.vision.face.NativeFaceDetectorV2Impl.<init>(android.content.Context, com.google.android.gms.vision.clearcut.DynamiteClearcutLogger, b.c.b.b.o.d.e.a.f, com.google.android.gms.vision.face.FaceDetectorV2Jni):void");
    }

    /* renamed from: A2 */
    public static FaceParcel[] m14888A2(C3127e0.C3135c cVar, C3171g0 g0Var, C3211j0 j0Var) {
        C3257n7 n7Var;
        float f;
        float f2;
        float f3;
        LandmarkParcel[] landmarkParcelArr;
        FaceParcel[] faceParcelArr;
        C3753a[] aVarArr;
        int i;
        C3234l4<C3197i7.C3206e> l4Var;
        int i2;
        C3211j0 j0Var2 = j0Var;
        C3257n7 n7Var2 = cVar.zzjx;
        if (n7Var2 == null) {
            n7Var2 = C3257n7.zzagr;
        }
        FaceParcel[] faceParcelArr2 = new FaceParcel[n7Var2.zzagq.size()];
        int i3 = 0;
        while (i3 < n7Var2.zzagq.size()) {
            C3197i7 i7Var = n7Var2.zzagq.get(i3);
            C3197i7.C3201b bVar = i7Var.zzacx;
            if (bVar == null) {
                bVar = C3197i7.C3201b.zzaeq;
            }
            float f4 = bVar.zzaem;
            float f5 = bVar.zzaeo - f4;
            float f6 = (f5 / 2.0f) + f4;
            float f7 = bVar.zzaen;
            float f8 = bVar.zzaep - f7;
            float f9 = (f8 / 2.0f) + f7;
            if (g0Var == C3171g0.ALL_CLASSIFICATIONS) {
                float f10 = -1.0f;
                float f11 = -1.0f;
                float f12 = -1.0f;
                for (C3197i7.C3198a next : i7Var.zzade) {
                    C3257n7 n7Var3 = n7Var2;
                    if (next.zznn.equals("joy")) {
                        f12 = next.zzacz;
                    } else if (next.zznn.equals("left_eye_closed")) {
                        f10 = 1.0f - next.zzacz;
                    } else if (next.zznn.equals("right_eye_closed")) {
                        f11 = 1.0f - next.zzacz;
                    }
                    n7Var2 = n7Var3;
                }
                n7Var = n7Var2;
                f3 = f10;
                f2 = f11;
                f = f12;
            } else {
                n7Var = n7Var2;
                f3 = -1.0f;
                f2 = -1.0f;
                f = -1.0f;
            }
            float f13 = (i7Var.zzbf & 2) != 0 ? i7Var.zzacz : -1.0f;
            if (j0Var2 == C3211j0.ALL_LANDMARKS) {
                C3234l4<C3197i7.C3206e> l4Var2 = i7Var.zzacy;
                ArrayList arrayList = new ArrayList();
                int i4 = 0;
                while (i4 < l4Var2.size()) {
                    C3197i7.C3206e eVar = l4Var2.get(i4);
                    C3197i7.C3206e.C3207a h = C3197i7.C3206e.C3207a.m11624h(eVar.zziz);
                    if (h == null) {
                        h = C3197i7.C3206e.C3207a.LANDMARK_UNKNOWN;
                    }
                    switch (C48081.f17467a[h.ordinal()]) {
                        case 1:
                            l4Var = l4Var2;
                            i2 = 4;
                            break;
                        case 2:
                            l4Var = l4Var2;
                            i2 = 10;
                            break;
                        case 3:
                            l4Var = l4Var2;
                            i2 = 6;
                            break;
                        case 4:
                            l4Var = l4Var2;
                            i2 = 0;
                            break;
                        case 5:
                            l4Var = l4Var2;
                            i2 = 5;
                            break;
                        case 6:
                            l4Var = l4Var2;
                            i2 = 11;
                            break;
                        case 7:
                            l4Var = l4Var2;
                            i2 = 3;
                            break;
                        case 8:
                            l4Var = l4Var2;
                            i2 = 9;
                            break;
                        case 9:
                            l4Var = l4Var2;
                            i2 = 1;
                            break;
                        case 10:
                            l4Var = l4Var2;
                            i2 = 7;
                            break;
                        case 11:
                            l4Var = l4Var2;
                            i2 = 2;
                            break;
                        case 12:
                            l4Var = l4Var2;
                            i2 = 8;
                            break;
                        default:
                            C0566i iVar = f17462i;
                            String valueOf = String.valueOf(h);
                            l4Var = l4Var2;
                            StringBuilder sb = new StringBuilder(valueOf.length() + 23);
                            sb.append("Unknown landmark type: ");
                            sb.append(valueOf);
                            iVar.mo1475b("NativeFaceDetectorV2Imp", sb.toString());
                            i2 = -1;
                            break;
                    }
                    if (i2 >= 0) {
                        arrayList.add(new LandmarkParcel(-1, eVar.zzjc, eVar.zzjd, i2));
                    }
                    i4++;
                    C3171g0 g0Var2 = g0Var;
                    l4Var2 = l4Var;
                }
                landmarkParcelArr = (LandmarkParcel[]) arrayList.toArray(new LandmarkParcel[0]);
            } else {
                landmarkParcelArr = new LandmarkParcel[0];
            }
            if (j0Var2 == C3211j0.CONTOUR_LANDMARKS) {
                C3149e4.C3156g<C3197i7, List<C3127e0.C3130b>> gVar = C3127e0.f13589a;
                if (gVar.f13620a == ((C3149e4) i7Var.mo7134e())) {
                    Type d = i7Var.zzwq.mo7401d(gVar.f13623d);
                    if (d == null) {
                        d = gVar.f13621b;
                    } else {
                        C3149e4.C3153d dVar = gVar.f13623d;
                        if (!dVar.f13617h) {
                            d = gVar.mo7157a(d);
                        } else if (dVar.f13616g.f13586e == C3179g7.ENUM) {
                            Type arrayList2 = new ArrayList();
                            for (Object a : (List) d) {
                                arrayList2.add(gVar.mo7157a(a));
                            }
                            d = arrayList2;
                        }
                    }
                    List list = (List) d;
                    C3753a[] aVarArr2 = new C3753a[list.size()];
                    int i5 = 0;
                    while (i5 < list.size()) {
                        C3127e0.C3130b bVar2 = (C3127e0.C3130b) list.get(i5);
                        PointF[] pointFArr = new PointF[bVar2.zzja.size()];
                        int i6 = 0;
                        while (i6 < bVar2.zzja.size()) {
                            C3127e0.C3130b.C3132b bVar3 = bVar2.zzja.get(i6);
                            pointFArr[i6] = new PointF(bVar3.zzjc, bVar3.zzjd);
                            i6++;
                            list = list;
                            faceParcelArr2 = faceParcelArr2;
                        }
                        FaceParcel[] faceParcelArr3 = faceParcelArr2;
                        List list2 = list;
                        C3127e0.C3130b.C3134c h2 = C3127e0.C3130b.C3134c.m11486h(bVar2.zziz);
                        if (h2 == null) {
                            h2 = C3127e0.C3130b.C3134c.CONTOUR_UNKNOWN;
                        }
                        switch (C48081.f17468b[h2.ordinal()]) {
                            case 1:
                                i = 1;
                                break;
                            case 2:
                                i = 2;
                                break;
                            case 3:
                                i = 3;
                                break;
                            case 4:
                                i = 4;
                                break;
                            case 5:
                                i = 5;
                                break;
                            case 6:
                                i = 6;
                                break;
                            case 7:
                                i = 7;
                                break;
                            case 8:
                                i = 8;
                                break;
                            case 9:
                                i = 9;
                                break;
                            case 10:
                                i = 10;
                                break;
                            case 11:
                                i = 11;
                                break;
                            case 12:
                                i = 12;
                                break;
                            case 13:
                                i = 13;
                                break;
                            case 14:
                                i = 14;
                                break;
                            case 15:
                                i = 15;
                                break;
                            default:
                                C0566i iVar2 = f17462i;
                                int i7 = h2.f13607e;
                                StringBuilder sb2 = new StringBuilder(33);
                                sb2.append("Unknown contour type: ");
                                sb2.append(i7);
                                iVar2.mo1476c("NativeFaceDetectorV2Imp", sb2.toString());
                                i = -1;
                                break;
                        }
                        aVarArr2[i5] = new C3753a(pointFArr, i);
                        i5++;
                        C3211j0 j0Var3 = j0Var;
                        list = list2;
                        faceParcelArr2 = faceParcelArr3;
                    }
                    faceParcelArr = faceParcelArr2;
                    aVarArr = aVarArr2;
                } else {
                    throw new IllegalArgumentException("This extension is for a different message type.  Please make sure that you are not suppressing any generics type warnings.");
                }
            } else {
                faceParcelArr = faceParcelArr2;
                aVarArr = new C3753a[0];
            }
            faceParcelArr[i3] = new FaceParcel(3, (int) i7Var.zzadg, f6, f9, f5, f8, i7Var.zzadb, -i7Var.zzada, i7Var.zzadc, landmarkParcelArr, f3, f2, f, aVarArr, f13);
            i3++;
            j0Var2 = j0Var;
            n7Var2 = n7Var;
            faceParcelArr2 = faceParcelArr;
        }
        return faceParcelArr2;
    }

    /* renamed from: I2 */
    public static C3107c0 m14889I2(int i) {
        if (i == 0) {
            return C3107c0.ROTATION_0;
        }
        if (i == 1) {
            return C3107c0.ROTATION_270;
        }
        if (i == 2) {
            return C3107c0.ROTATION_180;
        }
        if (i == 3) {
            return C3107c0.ROTATION_90;
        }
        throw new IllegalArgumentException("Unsupported rotation degree.");
    }

    /* renamed from: c2 */
    public static void m14890c2(DynamiteClearcutLogger dynamiteClearcutLogger, C3350w7 w7Var, FaceParcel[] faceParcelArr, long j) {
        C3350w7 w7Var2 = w7Var;
        FaceParcel[] faceParcelArr2 = faceParcelArr;
        if (w7Var2.f13990g <= 2 || faceParcelArr2.length != 0) {
            ArrayList arrayList = new ArrayList();
            for (FaceParcel faceParcel : faceParcelArr2) {
                C3146e2.C3147a o = C3146e2.m11512o();
                o.mo7129n((int) (faceParcel.f17471g - (faceParcel.f17473i / 2.0f)));
                o.mo7128m((int) (faceParcel.f17472h - (faceParcel.f17474j / 2.0f)));
                C3146e2 e2Var = (C3146e2) ((C3149e4) o.mo7146l());
                C3146e2.C3147a o2 = C3146e2.m11512o();
                o2.mo7129n((int) ((faceParcel.f17473i / 2.0f) + faceParcel.f17471g));
                o2.mo7128m((int) (faceParcel.f17472h - (faceParcel.f17474j / 2.0f)));
                C3146e2 e2Var2 = (C3146e2) ((C3149e4) o2.mo7146l());
                C3146e2.C3147a o3 = C3146e2.m11512o();
                o3.mo7129n((int) ((faceParcel.f17473i / 2.0f) + faceParcel.f17471g));
                o3.mo7128m((int) ((faceParcel.f17474j / 2.0f) + faceParcel.f17472h));
                C3146e2 e2Var3 = (C3146e2) ((C3149e4) o3.mo7146l());
                C3146e2.C3147a o4 = C3146e2.m11512o();
                o4.mo7129n((int) (faceParcel.f17471g - (faceParcel.f17473i / 2.0f)));
                o4.mo7128m((int) ((faceParcel.f17474j / 2.0f) + faceParcel.f17472h));
                C3146e2 e2Var4 = (C3146e2) ((C3149e4) o4.mo7146l());
                C3375z1.C3376a aVar = (C3375z1.C3376a) C3375z1.zzpa.mo7139n();
                float f = faceParcel.f17475k;
                if (aVar.f13613g) {
                    aVar.mo7144j();
                    aVar.f13613g = false;
                }
                C3375z1 z1Var = (C3375z1) aVar.f13612f;
                z1Var.zzbf |= 8;
                z1Var.zzox = f;
                float f2 = faceParcel.f17476l;
                if (aVar.f13613g) {
                    aVar.mo7144j();
                    aVar.f13613g = false;
                }
                C3375z1 z1Var2 = (C3375z1) aVar.f13612f;
                z1Var2.zzbf |= 16;
                z1Var2.zzoy = f2;
                float f3 = faceParcel.f17477m;
                if (aVar.f13613g) {
                    aVar.mo7144j();
                    aVar.f13613g = false;
                }
                C3375z1 z1Var3 = (C3375z1) aVar.f13612f;
                z1Var3.zzbf |= 32;
                z1Var3.zzoz = f3;
                float f4 = faceParcel.f17479o;
                if (aVar.f13613g) {
                    aVar.mo7144j();
                    aVar.f13613g = false;
                }
                C3375z1 z1Var4 = (C3375z1) aVar.f13612f;
                z1Var4.zzbf |= 1;
                z1Var4.zzou = f4;
                float f5 = faceParcel.f17480p;
                if (aVar.f13613g) {
                    aVar.mo7144j();
                    aVar.f13613g = false;
                }
                C3375z1 z1Var5 = (C3375z1) aVar.f13612f;
                z1Var5.zzbf |= 2;
                z1Var5.zzov = f5;
                float f6 = faceParcel.f17481q;
                if (aVar.f13613g) {
                    aVar.mo7144j();
                    aVar.f13613g = false;
                }
                C3375z1 z1Var6 = (C3375z1) aVar.f13612f;
                z1Var6.zzbf |= 4;
                z1Var6.zzow = f6;
                C3375z1 z1Var7 = (C3375z1) ((C3149e4) aVar.mo7146l());
                C3163f2.C3164a aVar2 = (C3163f2.C3164a) C3163f2.zzqc.mo7139n();
                C3332v1.C3333a aVar3 = (C3332v1.C3333a) C3332v1.zzmy.mo7139n();
                aVar3.mo7416m(e2Var);
                aVar3.mo7416m(e2Var2);
                aVar3.mo7416m(e2Var3);
                aVar3.mo7416m(e2Var4);
                if (aVar2.f13613g) {
                    aVar2.mo7144j();
                    aVar2.f13613g = false;
                }
                C3163f2.m11555o((C3163f2) aVar2.f13612f, (C3332v1) ((C3149e4) aVar3.mo7146l()));
                int i = faceParcel.f17470f;
                if (aVar2.f13613g) {
                    aVar2.mo7144j();
                    aVar2.f13613g = false;
                }
                C3163f2 f2Var = (C3163f2) aVar2.f13612f;
                f2Var.zzbf |= 2;
                f2Var.zzpz = i;
                if (aVar2.f13613g) {
                    aVar2.mo7144j();
                    aVar2.f13613g = false;
                }
                C3163f2.m11556p((C3163f2) aVar2.f13612f, z1Var7);
                arrayList.add((C3163f2) ((C3149e4) aVar2.mo7146l()));
            }
            int length = faceParcelArr2.length;
            C3087a2.C3088a aVar4 = (C3087a2.C3088a) C3087a2.zzpe.mo7139n();
            C3353x1.C3354a aVar5 = (C3353x1.C3354a) C3353x1.zznv.mo7139n();
            if (aVar5.f13613g) {
                aVar5.mo7144j();
                aVar5.f13613g = false;
            }
            C3353x1.m12009o((C3353x1) aVar5.f13612f, "face");
            if (aVar5.f13613g) {
                aVar5.mo7144j();
                aVar5.f13613g = false;
            }
            C3353x1 x1Var = (C3353x1) aVar5.f13612f;
            x1Var.zzbf |= 16;
            x1Var.zzns = j;
            long j2 = (long) length;
            if (aVar5.f13613g) {
                aVar5.mo7144j();
                aVar5.f13613g = false;
            }
            C3353x1 x1Var2 = (C3353x1) aVar5.f13612f;
            x1Var2.zzbf |= 32;
            x1Var2.zznt = j2;
            if (aVar5.f13613g) {
                aVar5.mo7144j();
                aVar5.f13613g = false;
            }
            C3353x1 x1Var3 = (C3353x1) aVar5.f13612f;
            if (!x1Var3.zznu.mo7246w0()) {
                x1Var3.zznu = C3149e4.m11517i(x1Var3.zznu);
            }
            C3290r2.m11844h(arrayList, x1Var3.zznu);
            ArrayList arrayList2 = new ArrayList();
            arrayList2.add((C3353x1) ((C3149e4) aVar5.mo7146l()));
            if (aVar4.f13613g) {
                aVar4.mo7144j();
                aVar4.f13613g = false;
            }
            C3087a2 a2Var = (C3087a2) aVar4.f13612f;
            if (!a2Var.zzpd.mo7246w0()) {
                a2Var.zzpd = C3149e4.m11517i(a2Var.zzpd);
            }
            C3290r2.m11844h(arrayList2, a2Var.zzpd);
            C3098b2.C3099a aVar6 = (C3098b2.C3099a) C3098b2.zzpj.mo7139n();
            long j3 = (long) w7Var2.f13989f;
            if (aVar6.f13613g) {
                aVar6.mo7144j();
                aVar6.f13613g = false;
            }
            C3098b2 b2Var = (C3098b2) aVar6.f13612f;
            b2Var.zzbf |= 4;
            b2Var.zzpg = j3;
            long j4 = (long) w7Var2.f13988e;
            if (aVar6.f13613g) {
                aVar6.mo7144j();
                aVar6.f13613g = false;
            }
            C3098b2 b2Var2 = (C3098b2) aVar6.f13612f;
            b2Var2.zzbf = 2 | b2Var2.zzbf;
            b2Var2.zzpf = j4;
            long j5 = (long) w7Var2.f13990g;
            if (aVar6.f13613g) {
                aVar6.mo7144j();
                aVar6.f13613g = false;
            }
            C3098b2 b2Var3 = (C3098b2) aVar6.f13612f;
            b2Var3.zzbf |= 8;
            b2Var3.zzph = j5;
            long j6 = w7Var2.f13991h;
            if (aVar6.f13613g) {
                aVar6.mo7144j();
                aVar6.f13613g = false;
            }
            C3098b2 b2Var4 = (C3098b2) aVar6.f13612f;
            b2Var4.zzbf |= 16;
            b2Var4.zzpi = j6;
            C3098b2 b2Var5 = (C3098b2) ((C3149e4) aVar6.mo7146l());
            if (aVar4.f13613g) {
                aVar4.mo7144j();
                aVar4.f13613g = false;
            }
            C3087a2.m11352o((C3087a2) aVar4.f13612f, b2Var5);
            C3087a2 a2Var2 = (C3087a2) ((C3149e4) aVar4.mo7146l());
            C3173g2.C3174a q = C3173g2.m11586q();
            if (q.f13613g) {
                q.mo7144j();
                q.f13613g = false;
            }
            C3173g2.m11584o((C3173g2) q.f13612f, a2Var2);
            dynamiteClearcutLogger.zza(3, (C3173g2) ((C3149e4) q.mo7146l()));
        }
    }

    /* renamed from: K */
    public final void mo8139K() {
        this.f17466h.mo9732f(this.f17463e);
    }

    /* renamed from: m1 */
    public final boolean mo8140m1(int i) {
        return true;
    }

    /* renamed from: n1 */
    public final FaceParcel[] mo8141n1(C0621a aVar, C3350w7 w7Var) {
        C3127e0.C3135c cVar;
        long elapsedRealtime = SystemClock.elapsedRealtime();
        try {
            ByteBuffer byteBuffer = (ByteBuffer) C0624b.m1273A2(aVar);
            C3095b0.C3096a aVar2 = (C3095b0.C3096a) C3095b0.zzhm.mo7139n();
            aVar2.mo7060n(w7Var.f13988e);
            aVar2.mo7061o(w7Var.f13989f);
            C3107c0 I2 = m14889I2(w7Var.f13992i);
            if (aVar2.f13613g) {
                aVar2.mo7144j();
                aVar2.f13613g = false;
            }
            C3095b0.m11370p((C3095b0) aVar2.f13612f, I2);
            C3351x xVar = C3351x.NV21;
            if (aVar2.f13613g) {
                aVar2.mo7144j();
                aVar2.f13613g = false;
            }
            C3095b0.m11369o((C3095b0) aVar2.f13612f, xVar);
            if (w7Var.f13991h > 0) {
                aVar2.mo7059m(w7Var.f13991h * 1000);
            }
            C3095b0 b0Var = (C3095b0) ((C3149e4) aVar2.mo7146l());
            if (byteBuffer.isDirect()) {
                cVar = this.f17466h.mo9728b(this.f17463e, byteBuffer, b0Var);
            } else if (!byteBuffer.hasArray() || byteBuffer.arrayOffset() != 0) {
                byte[] bArr = new byte[byteBuffer.remaining()];
                byteBuffer.get(bArr);
                cVar = this.f17466h.mo9730d(this.f17463e, bArr, b0Var);
            } else {
                cVar = this.f17466h.mo9730d(this.f17463e, byteBuffer.array(), b0Var);
            }
            C3171g0 h = C3171g0.m11579h(this.f17465g.zzkc);
            if (h == null) {
                h = C3171g0.NO_CLASSIFICATION;
            }
            C3211j0 h2 = C3211j0.m11631h(this.f17465g.zzkb);
            if (h2 == null) {
                h2 = C3211j0.NO_LANDMARK;
            }
            FaceParcel[] A2 = m14888A2(cVar, h, h2);
            m14890c2(this.f17464f, w7Var, A2, SystemClock.elapsedRealtime() - elapsedRealtime);
            return A2;
        } catch (Exception e) {
            f17462i.mo1477d("NativeFaceDetectorV2Imp", "Native face detection v2 failed", e);
            return new FaceParcel[0];
        }
    }

    /* renamed from: q3 */
    public final FaceParcel[] mo8142q3(C0621a aVar, C0621a aVar2, C0621a aVar3, int i, int i2, int i3, int i4, int i5, int i6, C3350w7 w7Var) {
        C3127e0.C3135c cVar;
        C3350w7 w7Var2 = w7Var;
        long elapsedRealtime = SystemClock.elapsedRealtime();
        try {
            ByteBuffer byteBuffer = (ByteBuffer) C0624b.m1273A2(aVar);
            ByteBuffer byteBuffer2 = (ByteBuffer) C0624b.m1273A2(aVar2);
            ByteBuffer byteBuffer3 = (ByteBuffer) C0624b.m1273A2(aVar3);
            C3095b0.C3096a aVar4 = (C3095b0.C3096a) C3095b0.zzhm.mo7139n();
            aVar4.mo7060n(w7Var2.f13988e);
            aVar4.mo7061o(w7Var2.f13989f);
            C3107c0 I2 = m14889I2(w7Var2.f13992i);
            if (aVar4.f13613g) {
                aVar4.mo7144j();
                aVar4.f13613g = false;
            }
            C3095b0.m11370p((C3095b0) aVar4.f13612f, I2);
            if (w7Var2.f13991h > 0) {
                aVar4.mo7059m(w7Var2.f13991h * 1000);
            }
            C3095b0 b0Var = (C3095b0) ((C3149e4) aVar4.mo7146l());
            if (byteBuffer.isDirect()) {
                cVar = this.f17466h.mo9729c(this.f17463e, byteBuffer, byteBuffer2, byteBuffer3, i, i2, i3, i4, i5, i6, b0Var);
            } else if (!byteBuffer.hasArray() || byteBuffer.arrayOffset() != 0) {
                byte[] bArr = new byte[byteBuffer.remaining()];
                byteBuffer.get(bArr);
                byteBuffer.get(bArr);
                byteBuffer.get(bArr);
                cVar = this.f17466h.mo9731e(this.f17463e, bArr, new byte[byteBuffer2.remaining()], new byte[byteBuffer3.remaining()], i, i2, i3, i4, i5, i6, b0Var);
            } else {
                byte[] bArr2 = null;
                byte[] array = (byteBuffer2 == null || !byteBuffer2.hasArray() || byteBuffer2.arrayOffset() != 0) ? null : byteBuffer2.array();
                if (byteBuffer3 != null && byteBuffer3.hasArray() && byteBuffer3.arrayOffset() == 0) {
                    bArr2 = byteBuffer3.array();
                }
                cVar = this.f17466h.mo9731e(this.f17463e, byteBuffer.array(), array, bArr2, i, i2, i3, i4, i5, i6, b0Var);
            }
            C3171g0 h = C3171g0.m11579h(this.f17465g.zzkc);
            if (h == null) {
                h = C3171g0.NO_CLASSIFICATION;
            }
            C3211j0 h2 = C3211j0.m11631h(this.f17465g.zzkb);
            if (h2 == null) {
                h2 = C3211j0.NO_LANDMARK;
            }
            FaceParcel[] A2 = m14888A2(cVar, h, h2);
            m14890c2(this.f17464f, w7Var2, A2, SystemClock.elapsedRealtime() - elapsedRealtime);
            return A2;
        } catch (Exception e) {
            f17462i.mo1477d("NativeFaceDetectorV2Imp", "Native face detection v2 failed", e);
            return new FaceParcel[0];
        }
    }
}
