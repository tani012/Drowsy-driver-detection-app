package com.google.android.gms.ads.mediation;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import p002b.p011c.p015b.p028b.p029a.C0305f;
import p002b.p011c.p015b.p028b.p029a.p041y.C0404e;
import p002b.p011c.p015b.p028b.p029a.p041y.C0405f;
import p002b.p011c.p015b.p028b.p029a.p041y.C0407h;

public interface MediationBannerAdapter extends C0405f {
    View getBannerView();

    /* synthetic */ void onDestroy();

    /* synthetic */ void onPause();

    /* synthetic */ void onResume();

    void requestBannerAd(Context context, C0407h hVar, Bundle bundle, C0305f fVar, C0404e eVar, Bundle bundle2);
}
