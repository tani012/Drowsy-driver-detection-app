package com.google.android.gms.ads.internal.overlay;

import android.content.Intent;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.ReflectedParcelable;
import p002b.p011c.p015b.p028b.p029a.p039x.C0391j;
import p002b.p011c.p015b.p028b.p029a.p039x.p040a.C0360d;
import p002b.p011c.p015b.p028b.p029a.p039x.p040a.C0369m;
import p002b.p011c.p015b.p028b.p029a.p039x.p040a.C0371o;
import p002b.p011c.p015b.p028b.p029a.p039x.p040a.C0376t;
import p002b.p011c.p015b.p028b.p053e.p057o.p058t.C0585a;
import p002b.p011c.p015b.p028b.p064f.C0621a;
import p002b.p011c.p015b.p028b.p064f.C0624b;
import p002b.p011c.p015b.p028b.p068i.p069a.C0657a5;
import p002b.p011c.p015b.p028b.p068i.p069a.C0740c5;
import p002b.p011c.p015b.p028b.p068i.p069a.C1111kn;
import p002b.p011c.p015b.p028b.p068i.p069a.C1555ur;
import p002b.p011c.p015b.p028b.p068i.p069a.ug2;
import p176d.p178b.p179k.C4851q;

public final class AdOverlayInfoParcel extends C0585a implements ReflectedParcelable {
    public static final Parcelable.Creator<AdOverlayInfoParcel> CREATOR = new C0369m();

    /* renamed from: e */
    public final C0360d f17344e;

    /* renamed from: f */
    public final ug2 f17345f;

    /* renamed from: g */
    public final C0371o f17346g;

    /* renamed from: h */
    public final C1555ur f17347h;

    /* renamed from: i */
    public final C0740c5 f17348i;

    /* renamed from: j */
    public final String f17349j;

    /* renamed from: k */
    public final boolean f17350k;

    /* renamed from: l */
    public final String f17351l;

    /* renamed from: m */
    public final C0376t f17352m;

    /* renamed from: n */
    public final int f17353n;

    /* renamed from: o */
    public final int f17354o;

    /* renamed from: p */
    public final String f17355p;

    /* renamed from: q */
    public final C1111kn f17356q;

    /* renamed from: r */
    public final String f17357r;

    /* renamed from: s */
    public final C0391j f17358s;

    /* renamed from: t */
    public final C0657a5 f17359t;

    public AdOverlayInfoParcel(C0360d dVar, IBinder iBinder, IBinder iBinder2, IBinder iBinder3, IBinder iBinder4, String str, boolean z, String str2, IBinder iBinder5, int i, int i2, String str3, C1111kn knVar, String str4, C0391j jVar, IBinder iBinder6) {
        this.f17344e = dVar;
        this.f17345f = (ug2) C0624b.m1273A2(C0621a.C0622a.m1272c2(iBinder));
        this.f17346g = (C0371o) C0624b.m1273A2(C0621a.C0622a.m1272c2(iBinder2));
        this.f17347h = (C1555ur) C0624b.m1273A2(C0621a.C0622a.m1272c2(iBinder3));
        this.f17359t = (C0657a5) C0624b.m1273A2(C0621a.C0622a.m1272c2(iBinder6));
        this.f17348i = (C0740c5) C0624b.m1273A2(C0621a.C0622a.m1272c2(iBinder4));
        this.f17349j = str;
        this.f17350k = z;
        this.f17351l = str2;
        this.f17352m = (C0376t) C0624b.m1273A2(C0621a.C0622a.m1272c2(iBinder5));
        this.f17353n = i;
        this.f17354o = i2;
        this.f17355p = str3;
        this.f17356q = knVar;
        this.f17357r = str4;
        this.f17358s = jVar;
    }

    public AdOverlayInfoParcel(C0360d dVar, ug2 ug2, C0371o oVar, C0376t tVar, C1111kn knVar) {
        this.f17344e = dVar;
        this.f17345f = ug2;
        this.f17346g = oVar;
        this.f17347h = null;
        this.f17359t = null;
        this.f17348i = null;
        this.f17349j = null;
        this.f17350k = false;
        this.f17351l = null;
        this.f17352m = tVar;
        this.f17353n = -1;
        this.f17354o = 4;
        this.f17355p = null;
        this.f17356q = knVar;
        this.f17357r = null;
        this.f17358s = null;
    }

    public AdOverlayInfoParcel(C0371o oVar, C1555ur urVar, int i, C1111kn knVar, String str, C0391j jVar, String str2, String str3) {
        this.f17344e = null;
        this.f17345f = null;
        this.f17346g = oVar;
        this.f17347h = urVar;
        this.f17359t = null;
        this.f17348i = null;
        this.f17349j = str2;
        this.f17350k = false;
        this.f17351l = str3;
        this.f17352m = null;
        this.f17353n = i;
        this.f17354o = 1;
        this.f17355p = null;
        this.f17356q = knVar;
        this.f17357r = str;
        this.f17358s = jVar;
    }

    public AdOverlayInfoParcel(ug2 ug2, C0371o oVar, C0376t tVar, C1555ur urVar, boolean z, int i, C1111kn knVar) {
        this.f17344e = null;
        this.f17345f = ug2;
        this.f17346g = oVar;
        this.f17347h = urVar;
        this.f17359t = null;
        this.f17348i = null;
        this.f17349j = null;
        this.f17350k = z;
        this.f17351l = null;
        this.f17352m = tVar;
        this.f17353n = i;
        this.f17354o = 2;
        this.f17355p = null;
        this.f17356q = knVar;
        this.f17357r = null;
        this.f17358s = null;
    }

    public AdOverlayInfoParcel(ug2 ug2, C0371o oVar, C0657a5 a5Var, C0740c5 c5Var, C0376t tVar, C1555ur urVar, boolean z, int i, String str, C1111kn knVar) {
        this.f17344e = null;
        this.f17345f = ug2;
        this.f17346g = oVar;
        this.f17347h = urVar;
        this.f17359t = a5Var;
        this.f17348i = c5Var;
        this.f17349j = null;
        this.f17350k = z;
        this.f17351l = null;
        this.f17352m = tVar;
        this.f17353n = i;
        this.f17354o = 3;
        this.f17355p = str;
        this.f17356q = knVar;
        this.f17357r = null;
        this.f17358s = null;
    }

    public AdOverlayInfoParcel(ug2 ug2, C0371o oVar, C0657a5 a5Var, C0740c5 c5Var, C0376t tVar, C1555ur urVar, boolean z, int i, String str, String str2, C1111kn knVar) {
        this.f17344e = null;
        this.f17345f = ug2;
        this.f17346g = oVar;
        this.f17347h = urVar;
        this.f17359t = a5Var;
        this.f17348i = c5Var;
        this.f17349j = str2;
        this.f17350k = z;
        this.f17351l = str;
        this.f17352m = tVar;
        this.f17353n = i;
        this.f17354o = 3;
        this.f17355p = null;
        this.f17356q = knVar;
        this.f17357r = null;
        this.f17358s = null;
    }

    /* renamed from: B */
    public static AdOverlayInfoParcel m14835B(Intent intent) {
        try {
            Bundle bundleExtra = intent.getBundleExtra("com.google.android.gms.ads.inernal.overlay.AdOverlayInfo");
            bundleExtra.setClassLoader(AdOverlayInfoParcel.class.getClassLoader());
            return (AdOverlayInfoParcel) bundleExtra.getParcelable("com.google.android.gms.ads.inernal.overlay.AdOverlayInfo");
        } catch (Exception unused) {
            return null;
        }
    }

    public final void writeToParcel(Parcel parcel, int i) {
        int e = C4851q.C4862i.m15125e(parcel);
        C4851q.C4862i.m15145k1(parcel, 2, this.f17344e, i, false);
        C4851q.C4862i.m15133g1(parcel, 3, new C0624b(this.f17345f), false);
        C4851q.C4862i.m15133g1(parcel, 4, new C0624b(this.f17346g), false);
        C4851q.C4862i.m15133g1(parcel, 5, new C0624b(this.f17347h), false);
        C4851q.C4862i.m15133g1(parcel, 6, new C0624b(this.f17348i), false);
        C4851q.C4862i.m15148l1(parcel, 7, this.f17349j, false);
        C4851q.C4862i.m15118b1(parcel, 8, this.f17350k);
        C4851q.C4862i.m15148l1(parcel, 9, this.f17351l, false);
        C4851q.C4862i.m15133g1(parcel, 10, new C0624b(this.f17352m), false);
        C4851q.C4862i.m15136h1(parcel, 11, this.f17353n);
        C4851q.C4862i.m15136h1(parcel, 12, this.f17354o);
        C4851q.C4862i.m15148l1(parcel, 13, this.f17355p, false);
        C4851q.C4862i.m15145k1(parcel, 14, this.f17356q, i, false);
        C4851q.C4862i.m15148l1(parcel, 16, this.f17357r, false);
        C4851q.C4862i.m15145k1(parcel, 17, this.f17358s, i, false);
        C4851q.C4862i.m15133g1(parcel, 18, new C0624b(this.f17359t), false);
        C4851q.C4862i.m15181w1(parcel, e);
    }
}
