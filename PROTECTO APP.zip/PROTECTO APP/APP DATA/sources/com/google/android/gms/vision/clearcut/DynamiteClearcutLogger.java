package com.google.android.gms.vision.clearcut;

import android.content.Context;
import androidx.annotation.Keep;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import p002b.p011c.p015b.p028b.p053e.p061r.C0605f;
import p002b.p011c.p015b.p028b.p068i.p081m.C3173g2;
import p002b.p011c.p015b.p028b.p090o.p091c.C3746a;
import p002b.p011c.p015b.p028b.p090o.p091c.C3747b;

@Keep
public class DynamiteClearcutLogger {
    public static final ThreadPoolExecutor zzbo = new ThreadPoolExecutor(1, 2, 2, TimeUnit.SECONDS, new LinkedBlockingQueue(10), new ThreadPoolExecutor.DiscardPolicy());
    public C3747b zzbp = new C3747b();
    public VisionClearcutLogger zzbq;

    public DynamiteClearcutLogger(Context context) {
        this.zzbq = new VisionClearcutLogger(context);
    }

    public final void zza(int i, C3173g2 g2Var) {
        boolean z;
        if (i == 3) {
            C3747b bVar = this.zzbp;
            synchronized (bVar.f15161b) {
                long currentTimeMillis = System.currentTimeMillis();
                if (bVar.f15162c + bVar.f15160a > currentTimeMillis) {
                    z = false;
                } else {
                    bVar.f15162c = currentTimeMillis;
                    z = true;
                }
            }
            if (!z) {
                C0605f.m976M("Skipping image analysis log due to rate limiting", new Object[0]);
                return;
            }
        }
        zzbo.execute(new C3746a(this, i, g2Var));
    }
}
