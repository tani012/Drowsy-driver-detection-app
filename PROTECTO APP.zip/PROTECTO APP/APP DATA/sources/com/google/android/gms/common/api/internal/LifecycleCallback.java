package com.google.android.gms.common.api.internal;

import androidx.annotation.Keep;
import p002b.p011c.p015b.p028b.p053e.p054m.p055j.C0504f;
import p002b.p011c.p015b.p028b.p053e.p054m.p055j.C0506g;

public class LifecycleCallback {
    @Keep
    public static C0506g getChimeraLifecycleFragmentImpl(C0504f fVar) {
        throw new IllegalStateException("Method not available in SDK.");
    }
}
