package com.google.android.gms.vision.face;

public final class NativeFaceDetectorV2ImplFactory {
}
