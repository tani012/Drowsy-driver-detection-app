package com.google.android.gms.ads.mediation.customevent;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import com.google.android.gms.ads.mediation.MediationBannerAdapter;
import com.google.android.gms.ads.mediation.MediationInterstitialAdapter;
import com.google.android.gms.ads.mediation.MediationNativeAdapter;
import com.google.android.gms.ads.reward.mediation.MediationRewardedVideoAdAdapter;
import com.google.android.gms.common.annotation.KeepName;
import p002b.p011c.p015b.p028b.p029a.C0305f;
import p002b.p011c.p015b.p028b.p029a.p041y.C0404e;
import p002b.p011c.p015b.p028b.p029a.p041y.C0407h;
import p002b.p011c.p015b.p028b.p029a.p041y.C0410k;
import p002b.p011c.p015b.p028b.p029a.p041y.C0412m;
import p002b.p011c.p015b.p028b.p029a.p041y.C0417r;
import p002b.p011c.p015b.p028b.p029a.p041y.p042w.C0423b;
import p002b.p011c.p015b.p028b.p029a.p041y.p042w.C0425d;
import p002b.p011c.p015b.p028b.p029a.p041y.p042w.C0426e;
import p002b.p011c.p015b.p028b.p053e.p061r.C0605f;
import p002b.p011c.p015b.p028b.p068i.p069a.C1579vb;

@KeepName
public final class CustomEventAdapter implements MediationBannerAdapter, MediationInterstitialAdapter, MediationNativeAdapter {

    /* renamed from: a */
    public CustomEventBanner f17360a;

    /* renamed from: b */
    public CustomEventInterstitial f17361b;

    /* renamed from: c */
    public CustomEventNative f17362c;

    /* renamed from: com.google.android.gms.ads.mediation.customevent.CustomEventAdapter$a */
    public class C4795a implements C0425d {
        public C4795a(CustomEventAdapter customEventAdapter, CustomEventAdapter customEventAdapter2, C0410k kVar) {
        }
    }

    /* renamed from: com.google.android.gms.ads.mediation.customevent.CustomEventAdapter$b */
    public static final class C4796b implements C0423b {
        public C4796b(CustomEventAdapter customEventAdapter, C0407h hVar) {
        }
    }

    /* renamed from: com.google.android.gms.ads.mediation.customevent.CustomEventAdapter$c */
    public static class C4797c implements C0426e {
        public C4797c(CustomEventAdapter customEventAdapter, C0412m mVar) {
        }
    }

    /* renamed from: a */
    public static <T> T m14836a(String str) {
        try {
            return Class.forName(str).newInstance();
        } catch (Throwable th) {
            String message = th.getMessage();
            StringBuilder sb = new StringBuilder(String.valueOf(message).length() + String.valueOf(str).length() + 46);
            sb.append("Could not instantiate custom event adapter: ");
            sb.append(str);
            sb.append(". ");
            sb.append(message);
            C0605f.m1109f5(sb.toString());
            return null;
        }
    }

    public final View getBannerView() {
        return null;
    }

    public final void onDestroy() {
        CustomEventBanner customEventBanner = this.f17360a;
        if (customEventBanner != null) {
            customEventBanner.onDestroy();
        }
        CustomEventInterstitial customEventInterstitial = this.f17361b;
        if (customEventInterstitial != null) {
            customEventInterstitial.onDestroy();
        }
        CustomEventNative customEventNative = this.f17362c;
        if (customEventNative != null) {
            customEventNative.onDestroy();
        }
    }

    public final void onPause() {
        CustomEventBanner customEventBanner = this.f17360a;
        if (customEventBanner != null) {
            customEventBanner.onPause();
        }
        CustomEventInterstitial customEventInterstitial = this.f17361b;
        if (customEventInterstitial != null) {
            customEventInterstitial.onPause();
        }
        CustomEventNative customEventNative = this.f17362c;
        if (customEventNative != null) {
            customEventNative.onPause();
        }
    }

    public final void onResume() {
        CustomEventBanner customEventBanner = this.f17360a;
        if (customEventBanner != null) {
            customEventBanner.onResume();
        }
        CustomEventInterstitial customEventInterstitial = this.f17361b;
        if (customEventInterstitial != null) {
            customEventInterstitial.onResume();
        }
        CustomEventNative customEventNative = this.f17362c;
        if (customEventNative != null) {
            customEventNative.onResume();
        }
    }

    public final void requestBannerAd(Context context, C0407h hVar, Bundle bundle, C0305f fVar, C0404e eVar, Bundle bundle2) {
        CustomEventBanner customEventBanner = (CustomEventBanner) m14836a(bundle.getString("class_name"));
        this.f17360a = customEventBanner;
        if (customEventBanner == null) {
            ((C1579vb) hVar).mo4634b(this, 0);
            return;
        }
        this.f17360a.requestBannerAd(context, new C4796b(this, hVar), bundle.getString(MediationRewardedVideoAdAdapter.CUSTOM_EVENT_SERVER_PARAMETER_FIELD), fVar, eVar, bundle2 == null ? null : bundle2.getBundle(bundle.getString("class_name")));
    }

    public final void requestInterstitialAd(Context context, C0410k kVar, Bundle bundle, C0404e eVar, Bundle bundle2) {
        CustomEventInterstitial customEventInterstitial = (CustomEventInterstitial) m14836a(bundle.getString("class_name"));
        this.f17361b = customEventInterstitial;
        if (customEventInterstitial == null) {
            ((C1579vb) kVar).mo4635c(this, 0);
            return;
        }
        this.f17361b.requestInterstitialAd(context, new C4795a(this, this, kVar), bundle.getString(MediationRewardedVideoAdAdapter.CUSTOM_EVENT_SERVER_PARAMETER_FIELD), eVar, bundle2 == null ? null : bundle2.getBundle(bundle.getString("class_name")));
    }

    public final void requestNativeAd(Context context, C0412m mVar, Bundle bundle, C0417r rVar, Bundle bundle2) {
        CustomEventNative customEventNative = (CustomEventNative) m14836a(bundle.getString("class_name"));
        this.f17362c = customEventNative;
        if (customEventNative == null) {
            ((C1579vb) mVar).mo4636d(this, 0);
            return;
        }
        this.f17362c.requestNativeAd(context, new C4797c(this, mVar), bundle.getString(MediationRewardedVideoAdAdapter.CUSTOM_EVENT_SERVER_PARAMETER_FIELD), rVar, bundle2 == null ? null : bundle2.getBundle(bundle.getString("class_name")));
    }

    public final void showInterstitial() {
        this.f17361b.showInterstitial();
    }
}
