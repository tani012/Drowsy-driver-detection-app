package com.google.android.gms.common.api.internal;

import android.os.Looper;
import android.os.Message;
import android.util.Log;
import android.util.Pair;
import com.google.android.gms.common.annotation.KeepName;
import com.google.android.gms.common.api.Status;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.atomic.AtomicReference;
import p002b.p008b.p009a.p010a.C0131a;
import p002b.p011c.p015b.p028b.p053e.p054m.C0481d;
import p002b.p011c.p015b.p028b.p053e.p054m.C0484e;
import p002b.p011c.p015b.p028b.p053e.p054m.C0486f;
import p002b.p011c.p015b.p028b.p053e.p054m.C0487g;
import p002b.p011c.p015b.p028b.p053e.p054m.C0488h;
import p002b.p011c.p015b.p028b.p053e.p054m.p055j.C0503e0;
import p002b.p011c.p015b.p028b.p053e.p054m.p055j.C0517l0;
import p002b.p011c.p015b.p028b.p068i.p071c.C1802c;
import p176d.p178b.p179k.C4851q;

@KeepName
public abstract class BasePendingResult<R extends C0487g> extends C0484e<R> {

    /* renamed from: l */
    public static final ThreadLocal<Boolean> f17387l = new C0517l0();

    /* renamed from: a */
    public final Object f17388a;

    /* renamed from: b */
    public final C4798a<R> f17389b;

    /* renamed from: c */
    public final CountDownLatch f17390c;

    /* renamed from: d */
    public final ArrayList<C0484e.C0485a> f17391d;

    /* renamed from: e */
    public C0488h<? super R> f17392e;

    /* renamed from: f */
    public final AtomicReference<C0503e0> f17393f;

    /* renamed from: g */
    public R f17394g;

    /* renamed from: h */
    public Status f17395h;

    /* renamed from: i */
    public volatile boolean f17396i;

    /* renamed from: j */
    public boolean f17397j;

    /* renamed from: k */
    public boolean f17398k;
    @KeepName
    public C4799b mResultGuardian;

    /* renamed from: com.google.android.gms.common.api.internal.BasePendingResult$a */
    public static class C4798a<R extends C0487g> extends C1802c {
        public C4798a(Looper looper) {
            super(looper);
        }

        public void handleMessage(Message message) {
            int i = message.what;
            if (i == 1) {
                Pair pair = (Pair) message.obj;
                C0488h hVar = (C0488h) pair.first;
                C0487g gVar = (C0487g) pair.second;
                try {
                    hVar.mo1357a(gVar);
                } catch (RuntimeException e) {
                    BasePendingResult.m14841e(gVar);
                    throw e;
                }
            } else if (i != 2) {
                Log.wtf("BasePendingResult", C0131a.m386t(45, "Don't know how to handle message: ", i), new Exception());
            } else {
                ((BasePendingResult) message.obj).mo9680f(Status.f17381j);
            }
        }
    }

    /* renamed from: com.google.android.gms.common.api.internal.BasePendingResult$b */
    public final class C4799b {
        public C4799b(C0517l0 l0Var) {
        }

        public final void finalize() {
            BasePendingResult.m14841e(BasePendingResult.this.f17394g);
            super.finalize();
        }
    }

    @Deprecated
    public BasePendingResult() {
        this.f17388a = new Object();
        this.f17390c = new CountDownLatch(1);
        this.f17391d = new ArrayList<>();
        this.f17393f = new AtomicReference<>();
        this.f17398k = false;
        this.f17389b = new C4798a<>(Looper.getMainLooper());
        new WeakReference((Object) null);
    }

    public BasePendingResult(C0481d dVar) {
        this.f17388a = new Object();
        this.f17390c = new CountDownLatch(1);
        this.f17391d = new ArrayList<>();
        this.f17393f = new AtomicReference<>();
        this.f17398k = false;
        this.f17389b = new C4798a<>(dVar != null ? dVar.mo1350a() : Looper.getMainLooper());
        new WeakReference(dVar);
    }

    /* renamed from: e */
    public static void m14841e(C0487g gVar) {
        if (gVar instanceof C0486f) {
            try {
                ((C0486f) gVar).mo1355a();
            } catch (RuntimeException e) {
                String valueOf = String.valueOf(gVar);
                StringBuilder sb = new StringBuilder(valueOf.length() + 18);
                sb.append("Unable to release ");
                sb.append(valueOf);
                Log.w("BasePendingResult", sb.toString(), e);
            }
        }
    }

    /* renamed from: a */
    public abstract R mo1409a(Status status);

    /* renamed from: b */
    public final boolean mo9677b() {
        return this.f17390c.getCount() == 0;
    }

    /* renamed from: c */
    public final void mo9678c(R r) {
        synchronized (this.f17388a) {
            if (!this.f17397j) {
                mo9677b();
                boolean z = true;
                C4851q.C4862i.m15185y(!mo9677b(), "Results have already been set");
                if (this.f17396i) {
                    z = false;
                }
                C4851q.C4862i.m15185y(z, "Result has already been consumed");
                mo9679d(r);
                return;
            }
            m14841e(r);
        }
    }

    /* renamed from: d */
    public final void mo9679d(R r) {
        R r2;
        this.f17394g = r;
        this.f17390c.countDown();
        this.f17395h = this.f17394g.mo1356p();
        int i = 0;
        if (this.f17392e != null) {
            this.f17389b.removeMessages(2);
            C4798a<R> aVar = this.f17389b;
            C0488h<? super R> hVar = this.f17392e;
            synchronized (this.f17388a) {
                C4851q.C4862i.m15185y(!this.f17396i, "Result has already been consumed.");
                C4851q.C4862i.m15185y(mo9677b(), "Result is not ready.");
                r2 = this.f17394g;
                this.f17394g = null;
                this.f17392e = null;
                this.f17396i = true;
            }
            C0503e0 andSet = this.f17393f.getAndSet((Object) null);
            if (andSet != null) {
                andSet.mo1401a(this);
            }
            if (aVar != null) {
                aVar.sendMessage(aVar.obtainMessage(1, new Pair(hVar, r2)));
            } else {
                throw null;
            }
        } else if (this.f17394g instanceof C0486f) {
            this.mResultGuardian = new C4799b((C0517l0) null);
        }
        ArrayList<C0484e.C0485a> arrayList = this.f17391d;
        int size = arrayList.size();
        while (i < size) {
            C0484e.C0485a aVar2 = arrayList.get(i);
            i++;
            aVar2.mo1354a(this.f17395h);
        }
        this.f17391d.clear();
    }

    /* renamed from: f */
    public final void mo9680f(Status status) {
        synchronized (this.f17388a) {
            if (!mo9677b()) {
                mo9678c(mo1409a(status));
                this.f17397j = true;
            }
        }
    }
}
