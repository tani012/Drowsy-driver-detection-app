package com.google.android.gms.dynamite;

import android.content.Context;
import android.database.Cursor;
import android.os.IBinder;
import android.os.IInterface;
import android.os.RemoteException;
import android.util.Log;
import com.google.android.gms.common.util.DynamiteApi;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import javax.annotation.concurrent.GuardedBy;
import p002b.p011c.p015b.p028b.p053e.p061r.C0602c;
import p002b.p011c.p015b.p028b.p064f.C0621a;
import p002b.p011c.p015b.p028b.p064f.C0624b;
import p002b.p011c.p015b.p028b.p065g.C0627a;
import p002b.p011c.p015b.p028b.p065g.C0628b;
import p002b.p011c.p015b.p028b.p065g.C0629c;
import p002b.p011c.p015b.p028b.p065g.C0630d;
import p002b.p011c.p015b.p028b.p065g.C0631e;
import p002b.p011c.p015b.p028b.p065g.C0633g;
import p002b.p011c.p015b.p028b.p065g.C0634h;
import p002b.p011c.p015b.p028b.p065g.C0635i;
import p002b.p011c.p015b.p028b.p065g.C0636j;
import p176d.p178b.p179k.C4851q;

public final class DynamiteModule {
    @GuardedBy("DynamiteModule.class")

    /* renamed from: b */
    public static Boolean f17425b = null;
    @GuardedBy("DynamiteModule.class")

    /* renamed from: c */
    public static C0634h f17426c = null;
    @GuardedBy("DynamiteModule.class")

    /* renamed from: d */
    public static C0636j f17427d = null;
    @GuardedBy("DynamiteModule.class")

    /* renamed from: e */
    public static String f17428e = null;
    @GuardedBy("DynamiteModule.class")

    /* renamed from: f */
    public static int f17429f = -1;

    /* renamed from: g */
    public static final ThreadLocal<C4804c> f17430g = new ThreadLocal<>();

    /* renamed from: h */
    public static final C4801b.C4803b f17431h = new C0628b();

    /* renamed from: i */
    public static final C4801b f17432i = new C0627a();

    /* renamed from: j */
    public static final C4801b f17433j = new C0629c();

    /* renamed from: k */
    public static final C4801b f17434k = new C0630d();

    /* renamed from: l */
    public static final C4801b f17435l = new C0631e();

    /* renamed from: a */
    public final Context f17436a;

    @DynamiteApi
    public static class DynamiteLoaderClassLoader {
        @GuardedBy("DynamiteLoaderClassLoader.class")
        public static ClassLoader sClassLoader;
    }

    /* renamed from: com.google.android.gms.dynamite.DynamiteModule$a */
    public static class C4800a extends Exception {
        public C4800a(String str, C0628b bVar) {
            super(str);
        }

        public C4800a(String str, Throwable th, C0628b bVar) {
            super(str, th);
        }
    }

    /* renamed from: com.google.android.gms.dynamite.DynamiteModule$b */
    public interface C4801b {

        /* renamed from: com.google.android.gms.dynamite.DynamiteModule$b$a */
        public static class C4802a {

            /* renamed from: a */
            public int f17437a = 0;

            /* renamed from: b */
            public int f17438b = 0;

            /* renamed from: c */
            public int f17439c = 0;
        }

        /* renamed from: com.google.android.gms.dynamite.DynamiteModule$b$b */
        public interface C4803b {
            /* renamed from: a */
            int mo1521a(Context context, String str);

            /* renamed from: b */
            int mo1522b(Context context, String str, boolean z);
        }

        /* renamed from: a */
        C4802a mo1520a(Context context, String str, C4803b bVar);
    }

    /* renamed from: com.google.android.gms.dynamite.DynamiteModule$c */
    public static class C4804c {

        /* renamed from: a */
        public Cursor f17440a;

        public C4804c() {
        }

        public C4804c(C0628b bVar) {
        }
    }

    /* renamed from: com.google.android.gms.dynamite.DynamiteModule$d */
    public static class C4805d implements C4801b.C4803b {

        /* renamed from: a */
        public final int f17441a;

        public C4805d(int i) {
            this.f17441a = i;
        }

        /* renamed from: a */
        public final int mo1521a(Context context, String str) {
            return this.f17441a;
        }

        /* renamed from: b */
        public final int mo1522b(Context context, String str, boolean z) {
            return 0;
        }
    }

    public DynamiteModule(Context context) {
        C4851q.C4862i.m15170t(context);
        this.f17436a = context;
    }

    /* renamed from: a */
    public static int m14847a(Context context, String str) {
        try {
            ClassLoader classLoader = context.getApplicationContext().getClassLoader();
            StringBuilder sb = new StringBuilder(String.valueOf(str).length() + 61);
            sb.append("com.google.android.gms.dynamite.descriptors.");
            sb.append(str);
            sb.append(".ModuleDescriptor");
            Class<?> loadClass = classLoader.loadClass(sb.toString());
            Field declaredField = loadClass.getDeclaredField("MODULE_ID");
            Field declaredField2 = loadClass.getDeclaredField("MODULE_VERSION");
            if (declaredField.get((Object) null).equals(str)) {
                return declaredField2.getInt((Object) null);
            }
            String valueOf = String.valueOf(declaredField.get((Object) null));
            StringBuilder sb2 = new StringBuilder(valueOf.length() + 51 + String.valueOf(str).length());
            sb2.append("Module descriptor id '");
            sb2.append(valueOf);
            sb2.append("' didn't match expected id '");
            sb2.append(str);
            sb2.append("'");
            Log.e("DynamiteModule", sb2.toString());
            return 0;
        } catch (ClassNotFoundException unused) {
            StringBuilder sb3 = new StringBuilder(String.valueOf(str).length() + 45);
            sb3.append("Local module descriptor class for ");
            sb3.append(str);
            sb3.append(" not found.");
            Log.w("DynamiteModule", sb3.toString());
            return 0;
        } catch (Exception e) {
            String valueOf2 = String.valueOf(e.getMessage());
            Log.e("DynamiteModule", valueOf2.length() != 0 ? "Failed to load module descriptor class: ".concat(valueOf2) : new String("Failed to load module descriptor class: "));
            return 0;
        }
    }

    /* renamed from: b */
    public static int m14848b(Context context, String str) {
        return m14850e(context, str, false);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:16:0x007c, code lost:
        if (r11 != null) goto L_0x007e;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:26:0x0093, code lost:
        if (r11 != null) goto L_0x007e;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:40:0x00ce, code lost:
        if (r11 != null) goto L_0x007e;
     */
    /* renamed from: d */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static com.google.android.gms.dynamite.DynamiteModule m14849d(android.content.Context r10, com.google.android.gms.dynamite.DynamiteModule.C4801b r11, java.lang.String r12) {
        /*
            java.lang.String r0 = ":"
            java.lang.String r1 = "DynamiteModule"
            java.lang.ThreadLocal<com.google.android.gms.dynamite.DynamiteModule$c> r2 = f17430g
            java.lang.Object r2 = r2.get()
            com.google.android.gms.dynamite.DynamiteModule$c r2 = (com.google.android.gms.dynamite.DynamiteModule.C4804c) r2
            com.google.android.gms.dynamite.DynamiteModule$c r3 = new com.google.android.gms.dynamite.DynamiteModule$c
            r4 = 0
            r3.<init>(r4)
            java.lang.ThreadLocal<com.google.android.gms.dynamite.DynamiteModule$c> r5 = f17430g
            r5.set(r3)
            com.google.android.gms.dynamite.DynamiteModule$b$b r5 = f17431h     // Catch:{ all -> 0x011e }
            com.google.android.gms.dynamite.DynamiteModule$b$a r5 = r11.mo1520a(r10, r12, r5)     // Catch:{ all -> 0x011e }
            int r6 = r5.f17437a     // Catch:{ all -> 0x011e }
            int r7 = r5.f17438b     // Catch:{ all -> 0x011e }
            java.lang.String r8 = java.lang.String.valueOf(r12)     // Catch:{ all -> 0x011e }
            int r8 = r8.length()     // Catch:{ all -> 0x011e }
            int r8 = r8 + 68
            java.lang.String r9 = java.lang.String.valueOf(r12)     // Catch:{ all -> 0x011e }
            int r9 = r9.length()     // Catch:{ all -> 0x011e }
            int r8 = r8 + r9
            java.lang.StringBuilder r9 = new java.lang.StringBuilder     // Catch:{ all -> 0x011e }
            r9.<init>(r8)     // Catch:{ all -> 0x011e }
            java.lang.String r8 = "Considering local module "
            r9.append(r8)     // Catch:{ all -> 0x011e }
            r9.append(r12)     // Catch:{ all -> 0x011e }
            r9.append(r0)     // Catch:{ all -> 0x011e }
            r9.append(r6)     // Catch:{ all -> 0x011e }
            java.lang.String r6 = " and remote module "
            r9.append(r6)     // Catch:{ all -> 0x011e }
            r9.append(r12)     // Catch:{ all -> 0x011e }
            r9.append(r0)     // Catch:{ all -> 0x011e }
            r9.append(r7)     // Catch:{ all -> 0x011e }
            java.lang.String r0 = r9.toString()     // Catch:{ all -> 0x011e }
            android.util.Log.i(r1, r0)     // Catch:{ all -> 0x011e }
            int r0 = r5.f17439c     // Catch:{ all -> 0x011e }
            if (r0 == 0) goto L_0x00f4
            int r0 = r5.f17439c     // Catch:{ all -> 0x011e }
            r6 = -1
            if (r0 != r6) goto L_0x0069
            int r0 = r5.f17437a     // Catch:{ all -> 0x011e }
            if (r0 == 0) goto L_0x00f4
        L_0x0069:
            int r0 = r5.f17439c     // Catch:{ all -> 0x011e }
            r7 = 1
            if (r0 != r7) goto L_0x0072
            int r0 = r5.f17438b     // Catch:{ all -> 0x011e }
            if (r0 == 0) goto L_0x00f4
        L_0x0072:
            int r0 = r5.f17439c     // Catch:{ all -> 0x011e }
            if (r0 != r6) goto L_0x0087
            com.google.android.gms.dynamite.DynamiteModule r10 = m14856k(r10, r12)     // Catch:{ all -> 0x011e }
            android.database.Cursor r11 = r3.f17440a
            if (r11 == 0) goto L_0x0081
        L_0x007e:
            r11.close()
        L_0x0081:
            java.lang.ThreadLocal<com.google.android.gms.dynamite.DynamiteModule$c> r11 = f17430g
            r11.set(r2)
            return r10
        L_0x0087:
            int r0 = r5.f17439c     // Catch:{ all -> 0x011e }
            if (r0 != r7) goto L_0x00d9
            int r0 = r5.f17438b     // Catch:{ a -> 0x0096 }
            com.google.android.gms.dynamite.DynamiteModule r10 = m14851f(r10, r12, r0)     // Catch:{ a -> 0x0096 }
            android.database.Cursor r11 = r3.f17440a
            if (r11 == 0) goto L_0x0081
            goto L_0x007e
        L_0x0096:
            r0 = move-exception
            java.lang.String r7 = "Failed to load remote module: "
            java.lang.String r8 = r0.getMessage()     // Catch:{ all -> 0x011e }
            java.lang.String r8 = java.lang.String.valueOf(r8)     // Catch:{ all -> 0x011e }
            int r9 = r8.length()     // Catch:{ all -> 0x011e }
            if (r9 == 0) goto L_0x00ac
            java.lang.String r7 = r7.concat(r8)     // Catch:{ all -> 0x011e }
            goto L_0x00b2
        L_0x00ac:
            java.lang.String r8 = new java.lang.String     // Catch:{ all -> 0x011e }
            r8.<init>(r7)     // Catch:{ all -> 0x011e }
            r7 = r8
        L_0x00b2:
            android.util.Log.w(r1, r7)     // Catch:{ all -> 0x011e }
            int r1 = r5.f17437a     // Catch:{ all -> 0x011e }
            if (r1 == 0) goto L_0x00d1
            com.google.android.gms.dynamite.DynamiteModule$d r1 = new com.google.android.gms.dynamite.DynamiteModule$d     // Catch:{ all -> 0x011e }
            int r5 = r5.f17437a     // Catch:{ all -> 0x011e }
            r1.<init>(r5)     // Catch:{ all -> 0x011e }
            com.google.android.gms.dynamite.DynamiteModule$b$a r11 = r11.mo1520a(r10, r12, r1)     // Catch:{ all -> 0x011e }
            int r11 = r11.f17439c     // Catch:{ all -> 0x011e }
            if (r11 != r6) goto L_0x00d1
            com.google.android.gms.dynamite.DynamiteModule r10 = m14856k(r10, r12)     // Catch:{ all -> 0x011e }
            android.database.Cursor r11 = r3.f17440a
            if (r11 == 0) goto L_0x0081
            goto L_0x007e
        L_0x00d1:
            com.google.android.gms.dynamite.DynamiteModule$a r10 = new com.google.android.gms.dynamite.DynamiteModule$a     // Catch:{ all -> 0x011e }
            java.lang.String r11 = "Remote load failed. No local fallback found."
            r10.<init>(r11, r0, r4)     // Catch:{ all -> 0x011e }
            throw r10     // Catch:{ all -> 0x011e }
        L_0x00d9:
            com.google.android.gms.dynamite.DynamiteModule$a r10 = new com.google.android.gms.dynamite.DynamiteModule$a     // Catch:{ all -> 0x011e }
            int r11 = r5.f17439c     // Catch:{ all -> 0x011e }
            r12 = 47
            java.lang.StringBuilder r0 = new java.lang.StringBuilder     // Catch:{ all -> 0x011e }
            r0.<init>(r12)     // Catch:{ all -> 0x011e }
            java.lang.String r12 = "VersionPolicy returned invalid code:"
            r0.append(r12)     // Catch:{ all -> 0x011e }
            r0.append(r11)     // Catch:{ all -> 0x011e }
            java.lang.String r11 = r0.toString()     // Catch:{ all -> 0x011e }
            r10.<init>(r11, r4)     // Catch:{ all -> 0x011e }
            throw r10     // Catch:{ all -> 0x011e }
        L_0x00f4:
            com.google.android.gms.dynamite.DynamiteModule$a r10 = new com.google.android.gms.dynamite.DynamiteModule$a     // Catch:{ all -> 0x011e }
            int r11 = r5.f17437a     // Catch:{ all -> 0x011e }
            int r12 = r5.f17438b     // Catch:{ all -> 0x011e }
            r0 = 91
            java.lang.StringBuilder r1 = new java.lang.StringBuilder     // Catch:{ all -> 0x011e }
            r1.<init>(r0)     // Catch:{ all -> 0x011e }
            java.lang.String r0 = "No acceptable module found. Local version is "
            r1.append(r0)     // Catch:{ all -> 0x011e }
            r1.append(r11)     // Catch:{ all -> 0x011e }
            java.lang.String r11 = " and remote version is "
            r1.append(r11)     // Catch:{ all -> 0x011e }
            r1.append(r12)     // Catch:{ all -> 0x011e }
            java.lang.String r11 = "."
            r1.append(r11)     // Catch:{ all -> 0x011e }
            java.lang.String r11 = r1.toString()     // Catch:{ all -> 0x011e }
            r10.<init>(r11, r4)     // Catch:{ all -> 0x011e }
            throw r10     // Catch:{ all -> 0x011e }
        L_0x011e:
            r10 = move-exception
            android.database.Cursor r11 = r3.f17440a
            if (r11 == 0) goto L_0x0126
            r11.close()
        L_0x0126:
            java.lang.ThreadLocal<com.google.android.gms.dynamite.DynamiteModule$c> r11 = f17430g
            r11.set(r2)
            throw r10
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.dynamite.DynamiteModule.m14849d(android.content.Context, com.google.android.gms.dynamite.DynamiteModule$b, java.lang.String):com.google.android.gms.dynamite.DynamiteModule");
    }

    /*  JADX ERROR: IndexOutOfBoundsException in pass: RegionMakerVisitor
        java.lang.IndexOutOfBoundsException: Index 0 out of bounds for length 0
        	at java.base/jdk.internal.util.Preconditions.outOfBounds(Preconditions.java:64)
        	at java.base/jdk.internal.util.Preconditions.outOfBoundsCheckIndex(Preconditions.java:70)
        	at java.base/jdk.internal.util.Preconditions.checkIndex(Preconditions.java:248)
        	at java.base/java.util.Objects.checkIndex(Objects.java:372)
        	at java.base/java.util.ArrayList.get(ArrayList.java:458)
        	at jadx.core.dex.nodes.InsnNode.getArg(InsnNode.java:101)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:611)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.processMonitorEnter(RegionMaker.java:561)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverse(RegionMaker.java:133)
        	at jadx.core.dex.visitors.regions.RegionMaker.makeRegion(RegionMaker.java:86)
        	at jadx.core.dex.visitors.regions.RegionMaker.processIf(RegionMaker.java:693)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverse(RegionMaker.java:123)
        	at jadx.core.dex.visitors.regions.RegionMaker.makeRegion(RegionMaker.java:86)
        	at jadx.core.dex.visitors.regions.RegionMaker.processMonitorEnter(RegionMaker.java:598)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverse(RegionMaker.java:133)
        	at jadx.core.dex.visitors.regions.RegionMaker.makeRegion(RegionMaker.java:86)
        	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:49)
        */
    /* JADX WARNING: Unknown top exception splitter block from list: {B:23:0x0054=Splitter:B:23:0x0054, B:18:0x0039=Splitter:B:18:0x0039, B:39:0x008f=Splitter:B:39:0x008f} */
    /* renamed from: e */
    public static int m14850e(android.content.Context r8, java.lang.String r9, boolean r10) {
        /*
            java.lang.Class<com.google.android.gms.dynamite.DynamiteModule> r0 = com.google.android.gms.dynamite.DynamiteModule.class
            monitor-enter(r0)     // Catch:{ all -> 0x00fe }
            java.lang.Boolean r1 = f17425b     // Catch:{ all -> 0x00fb }
            if (r1 != 0) goto L_0x00c8
            android.content.Context r1 = r8.getApplicationContext()     // Catch:{ ClassNotFoundException -> 0x00a3, IllegalAccessException -> 0x00a1, NoSuchFieldException -> 0x009f }
            java.lang.ClassLoader r1 = r1.getClassLoader()     // Catch:{ ClassNotFoundException -> 0x00a3, IllegalAccessException -> 0x00a1, NoSuchFieldException -> 0x009f }
            java.lang.Class<com.google.android.gms.dynamite.DynamiteModule$DynamiteLoaderClassLoader> r2 = com.google.android.gms.dynamite.DynamiteModule.DynamiteLoaderClassLoader.class
            java.lang.String r2 = r2.getName()     // Catch:{ ClassNotFoundException -> 0x00a3, IllegalAccessException -> 0x00a1, NoSuchFieldException -> 0x009f }
            java.lang.Class r1 = r1.loadClass(r2)     // Catch:{ ClassNotFoundException -> 0x00a3, IllegalAccessException -> 0x00a1, NoSuchFieldException -> 0x009f }
            java.lang.String r2 = "sClassLoader"
            java.lang.reflect.Field r1 = r1.getDeclaredField(r2)     // Catch:{ ClassNotFoundException -> 0x00a3, IllegalAccessException -> 0x00a1, NoSuchFieldException -> 0x009f }
            java.lang.Class r2 = r1.getDeclaringClass()     // Catch:{ ClassNotFoundException -> 0x00a3, IllegalAccessException -> 0x00a1, NoSuchFieldException -> 0x009f }
            monitor-enter(r2)     // Catch:{ ClassNotFoundException -> 0x00a3, IllegalAccessException -> 0x00a1, NoSuchFieldException -> 0x009f }
            r3 = 0
            java.lang.Object r4 = r1.get(r3)     // Catch:{ all -> 0x009c }
            java.lang.ClassLoader r4 = (java.lang.ClassLoader) r4     // Catch:{ all -> 0x009c }
            if (r4 == 0) goto L_0x003c
            java.lang.ClassLoader r1 = java.lang.ClassLoader.getSystemClassLoader()     // Catch:{ all -> 0x009c }
            if (r4 != r1) goto L_0x0036
        L_0x0033:
            java.lang.Boolean r1 = java.lang.Boolean.FALSE     // Catch:{ all -> 0x009c }
            goto L_0x009a
        L_0x0036:
            m14852g(r4)     // Catch:{ a -> 0x0039 }
        L_0x0039:
            java.lang.Boolean r1 = java.lang.Boolean.TRUE     // Catch:{ all -> 0x009c }
            goto L_0x009a
        L_0x003c:
            java.lang.String r4 = "com.google.android.gms"
            android.content.Context r5 = r8.getApplicationContext()     // Catch:{ all -> 0x009c }
            java.lang.String r5 = r5.getPackageName()     // Catch:{ all -> 0x009c }
            boolean r4 = r4.equals(r5)     // Catch:{ all -> 0x009c }
            if (r4 == 0) goto L_0x0054
            java.lang.ClassLoader r4 = java.lang.ClassLoader.getSystemClassLoader()     // Catch:{ all -> 0x009c }
            r1.set(r3, r4)     // Catch:{ all -> 0x009c }
            goto L_0x0033
        L_0x0054:
            int r4 = m14855j(r8, r9, r10)     // Catch:{ a -> 0x0092 }
            java.lang.String r5 = f17428e     // Catch:{ a -> 0x0092 }
            if (r5 == 0) goto L_0x008f
            java.lang.String r5 = f17428e     // Catch:{ a -> 0x0092 }
            boolean r5 = r5.isEmpty()     // Catch:{ a -> 0x0092 }
            if (r5 == 0) goto L_0x0065
            goto L_0x008f
        L_0x0065:
            int r5 = android.os.Build.VERSION.SDK_INT     // Catch:{ a -> 0x0092 }
            r6 = 29
            if (r5 < r6) goto L_0x0077
            dalvik.system.DelegateLastClassLoader r5 = new dalvik.system.DelegateLastClassLoader     // Catch:{ a -> 0x0092 }
            java.lang.String r6 = f17428e     // Catch:{ a -> 0x0092 }
            java.lang.ClassLoader r7 = java.lang.ClassLoader.getSystemClassLoader()     // Catch:{ a -> 0x0092 }
            r5.<init>(r6, r7)     // Catch:{ a -> 0x0092 }
            goto L_0x0082
        L_0x0077:
            b.c.b.b.g.f r5 = new b.c.b.b.g.f     // Catch:{ a -> 0x0092 }
            java.lang.String r6 = f17428e     // Catch:{ a -> 0x0092 }
            java.lang.ClassLoader r7 = java.lang.ClassLoader.getSystemClassLoader()     // Catch:{ a -> 0x0092 }
            r5.<init>(r6, r7)     // Catch:{ a -> 0x0092 }
        L_0x0082:
            m14852g(r5)     // Catch:{ a -> 0x0092 }
            r1.set(r3, r5)     // Catch:{ a -> 0x0092 }
            java.lang.Boolean r5 = java.lang.Boolean.TRUE     // Catch:{ a -> 0x0092 }
            f17425b = r5     // Catch:{ a -> 0x0092 }
            monitor-exit(r2)     // Catch:{ all -> 0x009c }
            monitor-exit(r0)     // Catch:{ all -> 0x00fb }
            return r4
        L_0x008f:
            monitor-exit(r2)     // Catch:{ all -> 0x009c }
            monitor-exit(r0)     // Catch:{ all -> 0x00fb }
            return r4
        L_0x0092:
            java.lang.ClassLoader r4 = java.lang.ClassLoader.getSystemClassLoader()     // Catch:{ all -> 0x009c }
            r1.set(r3, r4)     // Catch:{ all -> 0x009c }
            goto L_0x0033
        L_0x009a:
            monitor-exit(r2)     // Catch:{ all -> 0x009c }
            goto L_0x00c6
        L_0x009c:
            r1 = move-exception
            monitor-exit(r2)     // Catch:{ all -> 0x009c }
            throw r1     // Catch:{ ClassNotFoundException -> 0x00a3, IllegalAccessException -> 0x00a1, NoSuchFieldException -> 0x009f }
        L_0x009f:
            r1 = move-exception
            goto L_0x00a4
        L_0x00a1:
            r1 = move-exception
            goto L_0x00a4
        L_0x00a3:
            r1 = move-exception
        L_0x00a4:
            java.lang.String r2 = "DynamiteModule"
            java.lang.String r1 = java.lang.String.valueOf(r1)     // Catch:{ all -> 0x00fb }
            int r3 = r1.length()     // Catch:{ all -> 0x00fb }
            int r3 = r3 + 30
            java.lang.StringBuilder r4 = new java.lang.StringBuilder     // Catch:{ all -> 0x00fb }
            r4.<init>(r3)     // Catch:{ all -> 0x00fb }
            java.lang.String r3 = "Failed to load module via V2: "
            r4.append(r3)     // Catch:{ all -> 0x00fb }
            r4.append(r1)     // Catch:{ all -> 0x00fb }
            java.lang.String r1 = r4.toString()     // Catch:{ all -> 0x00fb }
            android.util.Log.w(r2, r1)     // Catch:{ all -> 0x00fb }
            java.lang.Boolean r1 = java.lang.Boolean.FALSE     // Catch:{ all -> 0x00fb }
        L_0x00c6:
            f17425b = r1     // Catch:{ all -> 0x00fb }
        L_0x00c8:
            monitor-exit(r0)     // Catch:{ all -> 0x00fb }
            boolean r0 = r1.booleanValue()     // Catch:{ all -> 0x00fe }
            if (r0 == 0) goto L_0x00f6
            int r8 = m14855j(r8, r9, r10)     // Catch:{ a -> 0x00d4 }
            return r8
        L_0x00d4:
            r9 = move-exception
            java.lang.String r10 = "DynamiteModule"
            java.lang.String r0 = "Failed to retrieve remote module version: "
            java.lang.String r9 = r9.getMessage()     // Catch:{ all -> 0x00fe }
            java.lang.String r9 = java.lang.String.valueOf(r9)     // Catch:{ all -> 0x00fe }
            int r1 = r9.length()     // Catch:{ all -> 0x00fe }
            if (r1 == 0) goto L_0x00ec
            java.lang.String r9 = r0.concat(r9)     // Catch:{ all -> 0x00fe }
            goto L_0x00f1
        L_0x00ec:
            java.lang.String r9 = new java.lang.String     // Catch:{ all -> 0x00fe }
            r9.<init>(r0)     // Catch:{ all -> 0x00fe }
        L_0x00f1:
            android.util.Log.w(r10, r9)     // Catch:{ all -> 0x00fe }
            r8 = 0
            return r8
        L_0x00f6:
            int r8 = m14853h(r8, r9, r10)     // Catch:{ all -> 0x00fe }
            return r8
        L_0x00fb:
            r9 = move-exception
            monitor-exit(r0)     // Catch:{ all -> 0x00fb }
            throw r9     // Catch:{ all -> 0x00fe }
        L_0x00fe:
            r9 = move-exception
            p002b.p011c.p015b.p028b.p053e.p061r.C0602c.m885a(r8, r9)
            throw r9
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.dynamite.DynamiteModule.m14850e(android.content.Context, java.lang.String, boolean):int");
    }

    /* renamed from: f */
    public static DynamiteModule m14851f(Context context, String str, int i) {
        Boolean bool;
        C0621a aVar;
        try {
            synchronized (DynamiteModule.class) {
                bool = f17425b;
            }
            if (bool == null) {
                throw new C4800a("Failed to determine which loading route to use.", (C0628b) null);
            } else if (bool.booleanValue()) {
                return m14854i(context, str, i);
            } else {
                StringBuilder sb = new StringBuilder(String.valueOf(str).length() + 51);
                sb.append("Selected remote version of ");
                sb.append(str);
                sb.append(", version >= ");
                sb.append(i);
                Log.i("DynamiteModule", sb.toString());
                C0634h l = m14857l(context);
                if (l != null) {
                    if (l.mo1528x4() >= 2) {
                        aVar = l.mo1527p3(new C0624b(context), str, i);
                    } else {
                        Log.w("DynamiteModule", "Dynamite loader version < 2, falling back to createModuleContext");
                        aVar = l.mo1526l5(new C0624b(context), str, i);
                    }
                    if (C0624b.m1273A2(aVar) != null) {
                        return new DynamiteModule((Context) C0624b.m1273A2(aVar));
                    }
                    throw new C4800a("Failed to load remote module.", (C0628b) null);
                }
                throw new C4800a("Failed to create IDynamiteLoader.", (C0628b) null);
            }
        } catch (RemoteException e) {
            throw new C4800a("Failed to load remote module.", e, (C0628b) null);
        } catch (C4800a e2) {
            throw e2;
        } catch (Throwable th) {
            C0602c.m885a(context, th);
            throw new C4800a("Failed to load remote module.", th, (C0628b) null);
        }
    }

    @GuardedBy("DynamiteModule.class")
    /* renamed from: g */
    public static void m14852g(ClassLoader classLoader) {
        C0636j jVar;
        try {
            IBinder iBinder = (IBinder) classLoader.loadClass("com.google.android.gms.dynamiteloader.DynamiteLoaderV2").getConstructor(new Class[0]).newInstance(new Object[0]);
            if (iBinder == null) {
                jVar = null;
            } else {
                IInterface queryLocalInterface = iBinder.queryLocalInterface("com.google.android.gms.dynamite.IDynamiteLoaderV2");
                jVar = queryLocalInterface instanceof C0636j ? (C0636j) queryLocalInterface : new C0635i(iBinder);
            }
            f17427d = jVar;
        } catch (ClassNotFoundException | IllegalAccessException | InstantiationException | NoSuchMethodException | InvocationTargetException e) {
            throw new C4800a("Failed to instantiate dynamite loader", e, (C0628b) null);
        }
    }

    /* renamed from: h */
    public static int m14853h(Context context, String str, boolean z) {
        C0634h l = m14857l(context);
        if (l == null) {
            return 0;
        }
        try {
            if (l.mo1528x4() >= 2) {
                return l.mo1525V0(new C0624b(context), str, z);
            }
            Log.w("DynamiteModule", "IDynamite loader version < 2, falling back to getModuleVersion2");
            return l.mo1524M2(new C0624b(context), str, z);
        } catch (RemoteException e) {
            String valueOf = String.valueOf(e.getMessage());
            Log.w("DynamiteModule", valueOf.length() != 0 ? "Failed to retrieve remote module version: ".concat(valueOf) : new String("Failed to retrieve remote module version: "));
            return 0;
        }
    }

    /* renamed from: i */
    public static DynamiteModule m14854i(Context context, String str, int i) {
        C0636j jVar;
        Boolean valueOf;
        C0621a aVar;
        Class<DynamiteModule> cls = DynamiteModule.class;
        StringBuilder sb = new StringBuilder(String.valueOf(str).length() + 51);
        sb.append("Selected remote version of ");
        sb.append(str);
        sb.append(", version >= ");
        sb.append(i);
        Log.i("DynamiteModule", sb.toString());
        synchronized (cls) {
            jVar = f17427d;
        }
        if (jVar != null) {
            C4804c cVar = f17430g.get();
            if (cVar == null || cVar.f17440a == null) {
                throw new C4800a("No result cursor", (C0628b) null);
            }
            Context applicationContext = context.getApplicationContext();
            Cursor cursor = cVar.f17440a;
            new C0624b(null);
            synchronized (cls) {
                valueOf = Boolean.valueOf(f17429f >= 2);
            }
            if (valueOf.booleanValue()) {
                Log.v("DynamiteModule", "Dynamite loader version >= 2, using loadModule2NoCrashUtils");
                aVar = jVar.mo1529H2(new C0624b(applicationContext), str, i, new C0624b(cursor));
            } else {
                Log.w("DynamiteModule", "Dynamite loader version < 2, falling back to loadModule2");
                aVar = jVar.mo1530z2(new C0624b(applicationContext), str, i, new C0624b(cursor));
            }
            Context context2 = (Context) C0624b.m1273A2(aVar);
            if (context2 != null) {
                return new DynamiteModule(context2);
            }
            throw new C4800a("Failed to get module context", (C0628b) null);
        }
        throw new C4800a("DynamiteLoaderV2 was not cached.", (C0628b) null);
    }

    /* JADX WARNING: Removed duplicated region for block: B:34:0x007f  */
    /* JADX WARNING: Removed duplicated region for block: B:56:0x00b0  */
    /* renamed from: j */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static int m14855j(android.content.Context r8, java.lang.String r9, boolean r10) {
        /*
            r0 = 0
            android.content.ContentResolver r1 = r8.getContentResolver()     // Catch:{ Exception -> 0x009d, all -> 0x009b }
            if (r10 == 0) goto L_0x000a
            java.lang.String r8 = "api_force_staging"
            goto L_0x000c
        L_0x000a:
            java.lang.String r8 = "api"
        L_0x000c:
            int r10 = r8.length()     // Catch:{ Exception -> 0x009d, all -> 0x009b }
            int r10 = r10 + 42
            java.lang.String r2 = java.lang.String.valueOf(r9)     // Catch:{ Exception -> 0x009d, all -> 0x009b }
            int r2 = r2.length()     // Catch:{ Exception -> 0x009d, all -> 0x009b }
            int r10 = r10 + r2
            java.lang.StringBuilder r2 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x009d, all -> 0x009b }
            r2.<init>(r10)     // Catch:{ Exception -> 0x009d, all -> 0x009b }
            java.lang.String r10 = "content://com.google.android.gms.chimera/"
            r2.append(r10)     // Catch:{ Exception -> 0x009d, all -> 0x009b }
            r2.append(r8)     // Catch:{ Exception -> 0x009d, all -> 0x009b }
            java.lang.String r8 = "/"
            r2.append(r8)     // Catch:{ Exception -> 0x009d, all -> 0x009b }
            r2.append(r9)     // Catch:{ Exception -> 0x009d, all -> 0x009b }
            java.lang.String r8 = r2.toString()     // Catch:{ Exception -> 0x009d, all -> 0x009b }
            android.net.Uri r2 = android.net.Uri.parse(r8)     // Catch:{ Exception -> 0x009d, all -> 0x009b }
            r3 = 0
            r4 = 0
            r5 = 0
            r6 = 0
            android.database.Cursor r8 = r1.query(r2, r3, r4, r5, r6)     // Catch:{ Exception -> 0x009d, all -> 0x009b }
            if (r8 == 0) goto L_0x0083
            boolean r9 = r8.moveToFirst()     // Catch:{ Exception -> 0x0096, all -> 0x0092 }
            if (r9 == 0) goto L_0x0083
            r9 = 0
            int r9 = r8.getInt(r9)     // Catch:{ Exception -> 0x0096, all -> 0x0092 }
            if (r9 <= 0) goto L_0x007c
            java.lang.Class<com.google.android.gms.dynamite.DynamiteModule> r10 = com.google.android.gms.dynamite.DynamiteModule.class
            monitor-enter(r10)     // Catch:{ Exception -> 0x0096, all -> 0x0092 }
            r1 = 2
            java.lang.String r1 = r8.getString(r1)     // Catch:{ all -> 0x0079 }
            f17428e = r1     // Catch:{ all -> 0x0079 }
            java.lang.String r1 = "loaderVersion"
            int r1 = r8.getColumnIndex(r1)     // Catch:{ all -> 0x0079 }
            if (r1 < 0) goto L_0x0067
            int r1 = r8.getInt(r1)     // Catch:{ all -> 0x0079 }
            f17429f = r1     // Catch:{ all -> 0x0079 }
        L_0x0067:
            monitor-exit(r10)     // Catch:{ all -> 0x0079 }
            java.lang.ThreadLocal<com.google.android.gms.dynamite.DynamiteModule$c> r10 = f17430g     // Catch:{ Exception -> 0x0096, all -> 0x0092 }
            java.lang.Object r10 = r10.get()     // Catch:{ Exception -> 0x0096, all -> 0x0092 }
            com.google.android.gms.dynamite.DynamiteModule$c r10 = (com.google.android.gms.dynamite.DynamiteModule.C4804c) r10     // Catch:{ Exception -> 0x0096, all -> 0x0092 }
            if (r10 == 0) goto L_0x007c
            android.database.Cursor r1 = r10.f17440a     // Catch:{ Exception -> 0x0096, all -> 0x0092 }
            if (r1 != 0) goto L_0x007c
            r10.f17440a = r8     // Catch:{ Exception -> 0x0096, all -> 0x0092 }
            goto L_0x007d
        L_0x0079:
            r9 = move-exception
            monitor-exit(r10)     // Catch:{ all -> 0x0079 }
            throw r9     // Catch:{ Exception -> 0x0096, all -> 0x0092 }
        L_0x007c:
            r0 = r8
        L_0x007d:
            if (r0 == 0) goto L_0x0082
            r0.close()
        L_0x0082:
            return r9
        L_0x0083:
            java.lang.String r9 = "DynamiteModule"
            java.lang.String r10 = "Failed to retrieve remote module version."
            android.util.Log.w(r9, r10)     // Catch:{ Exception -> 0x0096, all -> 0x0092 }
            com.google.android.gms.dynamite.DynamiteModule$a r9 = new com.google.android.gms.dynamite.DynamiteModule$a     // Catch:{ Exception -> 0x0096, all -> 0x0092 }
            java.lang.String r10 = "Failed to connect to dynamite module ContentResolver."
            r9.<init>(r10, r0)     // Catch:{ Exception -> 0x0096, all -> 0x0092 }
            throw r9     // Catch:{ Exception -> 0x0096, all -> 0x0092 }
        L_0x0092:
            r9 = move-exception
            r0 = r8
            r8 = r9
            goto L_0x00ae
        L_0x0096:
            r9 = move-exception
            r7 = r9
            r9 = r8
            r8 = r7
            goto L_0x009f
        L_0x009b:
            r8 = move-exception
            goto L_0x00ae
        L_0x009d:
            r8 = move-exception
            r9 = r0
        L_0x009f:
            boolean r10 = r8 instanceof com.google.android.gms.dynamite.DynamiteModule.C4800a     // Catch:{ all -> 0x00ac }
            if (r10 == 0) goto L_0x00a4
            throw r8     // Catch:{ all -> 0x00ac }
        L_0x00a4:
            com.google.android.gms.dynamite.DynamiteModule$a r10 = new com.google.android.gms.dynamite.DynamiteModule$a     // Catch:{ all -> 0x00ac }
            java.lang.String r1 = "V2 version check failed"
            r10.<init>(r1, r8, r0)     // Catch:{ all -> 0x00ac }
            throw r10     // Catch:{ all -> 0x00ac }
        L_0x00ac:
            r8 = move-exception
            r0 = r9
        L_0x00ae:
            if (r0 == 0) goto L_0x00b3
            r0.close()
        L_0x00b3:
            throw r8
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.dynamite.DynamiteModule.m14855j(android.content.Context, java.lang.String, boolean):int");
    }

    /* renamed from: k */
    public static DynamiteModule m14856k(Context context, String str) {
        String valueOf = String.valueOf(str);
        Log.i("DynamiteModule", valueOf.length() != 0 ? "Selected local version of ".concat(valueOf) : new String("Selected local version of "));
        return new DynamiteModule(context.getApplicationContext());
    }

    /* renamed from: l */
    public static C0634h m14857l(Context context) {
        C0634h hVar;
        synchronized (DynamiteModule.class) {
            if (f17426c != null) {
                C0634h hVar2 = f17426c;
                return hVar2;
            }
            try {
                IBinder iBinder = (IBinder) context.createPackageContext("com.google.android.gms", 3).getClassLoader().loadClass("com.google.android.gms.chimera.container.DynamiteLoaderImpl").newInstance();
                if (iBinder == null) {
                    hVar = null;
                } else {
                    IInterface queryLocalInterface = iBinder.queryLocalInterface("com.google.android.gms.dynamite.IDynamiteLoader");
                    hVar = queryLocalInterface instanceof C0634h ? (C0634h) queryLocalInterface : new C0633g(iBinder);
                }
                if (hVar != null) {
                    f17426c = hVar;
                    return hVar;
                }
            } catch (Exception e) {
                String valueOf = String.valueOf(e.getMessage());
                Log.e("DynamiteModule", valueOf.length() != 0 ? "Failed to load IDynamiteLoader from GmsCore: ".concat(valueOf) : new String("Failed to load IDynamiteLoader from GmsCore: "));
            }
        }
        return null;
    }

    /* renamed from: c */
    public final IBinder mo9688c(String str) {
        try {
            return (IBinder) this.f17436a.getClassLoader().loadClass(str).newInstance();
        } catch (ClassNotFoundException | IllegalAccessException | InstantiationException e) {
            String valueOf = String.valueOf(str);
            throw new C4800a(valueOf.length() != 0 ? "Failed to instantiate module class: ".concat(valueOf) : new String("Failed to instantiate module class: "), e, (C0628b) null);
        }
    }
}
