package com.google.android.gms.internal.ads;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.IBinder;
import android.text.TextUtils;
import com.google.android.gms.ads.internal.overlay.AdOverlayInfoParcel;
import com.google.android.gms.ads.mediation.MediationInterstitialAdapter;
import p002b.p011c.p015b.p028b.p029a.p039x.C0398q;
import p002b.p011c.p015b.p028b.p029a.p039x.p040a.C0360d;
import p002b.p011c.p015b.p028b.p029a.p039x.p040a.C0376t;
import p002b.p011c.p015b.p028b.p029a.p041y.C0404e;
import p002b.p011c.p015b.p028b.p029a.p041y.C0410k;
import p002b.p011c.p015b.p028b.p053e.p061r.C0605f;
import p002b.p011c.p015b.p028b.p068i.p069a.C0675ak;
import p002b.p011c.p015b.p028b.p068i.p069a.C0922gd;
import p002b.p011c.p015b.p028b.p068i.p069a.C1013id;
import p002b.p011c.p015b.p028b.p068i.p069a.C1111kn;
import p002b.p011c.p015b.p028b.p068i.p069a.C1363qk;
import p002b.p011c.p015b.p028b.p068i.p069a.C1426s;
import p002b.p011c.p015b.p028b.p068i.p069a.C1579vb;
import p002b.p011c.p015b.p028b.p068i.p069a.ug2;
import p002b.p011c.p015b.p028b.p068i.p069a.zh2;
import p176d.p193d.p194b.C5026a;

public final class zzapq implements MediationInterstitialAdapter {

    /* renamed from: a */
    public Activity f17444a;

    /* renamed from: b */
    public C0410k f17445b;

    /* renamed from: c */
    public Uri f17446c;

    public final void onDestroy() {
        C0605f.m1030T4("Destroying AdMobCustomTabsAdapter adapter.");
    }

    public final void onPause() {
        C0605f.m1030T4("Pausing AdMobCustomTabsAdapter adapter.");
    }

    public final void onResume() {
        C0605f.m1030T4("Resuming AdMobCustomTabsAdapter adapter.");
    }

    public final void requestInterstitialAd(Context context, C0410k kVar, Bundle bundle, C0404e eVar, Bundle bundle2) {
        this.f17445b = kVar;
        if (kVar == null) {
            C0605f.m1109f5("Listener not set for mediation. Returning.");
        } else if (!(context instanceof Activity)) {
            C0605f.m1109f5("AdMobCustomTabs can only work with Activity context. Bailing out.");
            ((C1579vb) this.f17445b).mo4635c(this, 0);
        } else {
            if (!(C0605f.m954I5(context))) {
                C0605f.m1109f5("Default browser does not support custom tabs. Bailing out.");
                ((C1579vb) this.f17445b).mo4635c(this, 0);
                return;
            }
            String string = bundle.getString("tab_url");
            if (TextUtils.isEmpty(string)) {
                C0605f.m1109f5("The tab_url retrieved from mediation metadata is empty. Bailing out.");
                ((C1579vb) this.f17445b).mo4635c(this, 0);
                return;
            }
            this.f17444a = (Activity) context;
            this.f17446c = Uri.parse(string);
            ((C1579vb) this.f17445b).mo4637e(this);
        }
    }

    public final void showInterstitial() {
        Intent intent = new Intent("android.intent.action.VIEW");
        Bundle bundle = new Bundle();
        bundle.putBinder("android.support.customtabs.extra.SESSION", (IBinder) null);
        intent.putExtras(bundle);
        intent.putExtra("android.support.customtabs.extra.EXTRA_ENABLE_INSTANT_APPS", true);
        C5026a aVar = new C5026a(intent, (Bundle) null);
        aVar.f18325a.setData(this.f17446c);
        C1363qk.f7745h.post(new C1013id(this, new AdOverlayInfoParcel(new C0360d(aVar.f18325a), (ug2) null, new C0922gd(this), (C0376t) null, new C1111kn(0, 0, false))));
        C0398q qVar = C0398q.f1281B;
        C0675ak akVar = qVar.f1289g.f10343j;
        if (akVar != null) {
            long a = qVar.f1292j.mo1502a();
            synchronized (akVar.f1902a) {
                if (akVar.f1903b == 3) {
                    if (akVar.f1904c + ((Long) zh2.f11224j.f11230f.mo3857a(C1426s.f8338T2)).longValue() <= a) {
                        akVar.f1903b = 1;
                    }
                }
            }
            long a2 = C0398q.f1281B.f1292j.mo1502a();
            synchronized (akVar.f1902a) {
                if (akVar.f1903b == 2) {
                    akVar.f1903b = 3;
                    if (akVar.f1903b == 3) {
                        akVar.f1904c = a2;
                    }
                }
            }
            return;
        }
        throw null;
    }
}
