package com.google.android.gms.common.stats;

import android.text.TextUtils;
import com.google.android.gms.common.internal.ReflectedParcelable;
import java.util.List;
import p002b.p011c.p015b.p028b.p053e.p057o.p058t.C0585a;

public abstract class StatsEvent extends C0585a implements ReflectedParcelable {
    public String toString() {
        WakeLockEvent wakeLockEvent = (WakeLockEvent) this;
        long j = wakeLockEvent.f17410f;
        int i = wakeLockEvent.f17411g;
        long j2 = wakeLockEvent.f17424t;
        String str = wakeLockEvent.f17412h;
        int i2 = wakeLockEvent.f17415k;
        List<String> list = wakeLockEvent.f17416l;
        String str2 = "";
        String join = list == null ? str2 : TextUtils.join(",", list);
        int i3 = wakeLockEvent.f17419o;
        String str3 = wakeLockEvent.f17413i;
        if (str3 == null) {
            str3 = str2;
        }
        String str4 = wakeLockEvent.f17420p;
        if (str4 == null) {
            str4 = str2;
        }
        float f = wakeLockEvent.f17421q;
        String str5 = wakeLockEvent.f17414j;
        if (str5 != null) {
            str2 = str5;
        }
        boolean z = wakeLockEvent.f17423s;
        StringBuilder sb = new StringBuilder(str2.length() + str4.length() + str3.length() + String.valueOf(join).length() + String.valueOf(str).length() + 51);
        sb.append("\t");
        sb.append(str);
        sb.append("\t");
        sb.append(i2);
        sb.append("\t");
        sb.append(join);
        sb.append("\t");
        sb.append(i3);
        sb.append("\t");
        sb.append(str3);
        sb.append("\t");
        sb.append(str4);
        sb.append("\t");
        sb.append(f);
        sb.append("\t");
        sb.append(str2);
        sb.append("\t");
        sb.append(z);
        String sb2 = sb.toString();
        StringBuilder sb3 = new StringBuilder(String.valueOf(sb2).length() + 53);
        sb3.append(j);
        sb3.append("\t");
        sb3.append(i);
        sb3.append("\t");
        sb3.append(j2);
        sb3.append(sb2);
        return sb3.toString();
    }
}
