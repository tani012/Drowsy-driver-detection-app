package com.google.android.gms.ads.mediation.customevent;

import android.content.Context;
import android.os.Bundle;
import p002b.p011c.p015b.p028b.p029a.p041y.C0417r;
import p002b.p011c.p015b.p028b.p029a.p041y.p042w.C0422a;
import p002b.p011c.p015b.p028b.p029a.p041y.p042w.C0426e;

public interface CustomEventNative extends C0422a {
    /* synthetic */ void onDestroy();

    /* synthetic */ void onPause();

    /* synthetic */ void onResume();

    void requestNativeAd(Context context, C0426e eVar, String str, C0417r rVar, Bundle bundle);
}
