package com.google.android.gms.flags.impl;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.util.Log;
import com.google.android.gms.common.util.DynamiteApi;
import p002b.p011c.p015b.p028b.p053e.p061r.C0605f;
import p002b.p011c.p015b.p028b.p064f.C0621a;
import p002b.p011c.p015b.p028b.p064f.C0624b;
import p002b.p011c.p015b.p028b.p066h.C0649g;
import p002b.p011c.p015b.p028b.p066h.p067d.C0641a;
import p002b.p011c.p015b.p028b.p066h.p067d.C0642b;
import p002b.p011c.p015b.p028b.p066h.p067d.C0643c;
import p002b.p011c.p015b.p028b.p066h.p067d.C0644d;
import p002b.p011c.p015b.p028b.p066h.p067d.C0645e;

@DynamiteApi
public class FlagProviderImpl extends C0649g {

    /* renamed from: e */
    public boolean f17442e = false;

    /* renamed from: f */
    public SharedPreferences f17443f;

    public boolean getBooleanFlagValue(String str, boolean z, int i) {
        if (!this.f17442e) {
            return z;
        }
        SharedPreferences sharedPreferences = this.f17443f;
        Boolean valueOf = Boolean.valueOf(z);
        try {
            valueOf = (Boolean) C0605f.m937G2(new C0641a(sharedPreferences, str, valueOf));
        } catch (Exception e) {
            String valueOf2 = String.valueOf(e.getMessage());
            Log.w("FlagDataUtils", valueOf2.length() != 0 ? "Flag value not available, returning default: ".concat(valueOf2) : new String("Flag value not available, returning default: "));
        }
        return valueOf.booleanValue();
    }

    public int getIntFlagValue(String str, int i, int i2) {
        if (!this.f17442e) {
            return i;
        }
        SharedPreferences sharedPreferences = this.f17443f;
        Integer valueOf = Integer.valueOf(i);
        try {
            valueOf = (Integer) C0605f.m937G2(new C0642b(sharedPreferences, str, valueOf));
        } catch (Exception e) {
            String valueOf2 = String.valueOf(e.getMessage());
            Log.w("FlagDataUtils", valueOf2.length() != 0 ? "Flag value not available, returning default: ".concat(valueOf2) : new String("Flag value not available, returning default: "));
        }
        return valueOf.intValue();
    }

    public long getLongFlagValue(String str, long j, int i) {
        if (!this.f17442e) {
            return j;
        }
        SharedPreferences sharedPreferences = this.f17443f;
        Long valueOf = Long.valueOf(j);
        try {
            valueOf = (Long) C0605f.m937G2(new C0643c(sharedPreferences, str, valueOf));
        } catch (Exception e) {
            String valueOf2 = String.valueOf(e.getMessage());
            Log.w("FlagDataUtils", valueOf2.length() != 0 ? "Flag value not available, returning default: ".concat(valueOf2) : new String("Flag value not available, returning default: "));
        }
        return valueOf.longValue();
    }

    public String getStringFlagValue(String str, String str2, int i) {
        if (!this.f17442e) {
            return str2;
        }
        try {
            return (String) C0605f.m937G2(new C0644d(this.f17443f, str, str2));
        } catch (Exception e) {
            String valueOf = String.valueOf(e.getMessage());
            Log.w("FlagDataUtils", valueOf.length() != 0 ? "Flag value not available, returning default: ".concat(valueOf) : new String("Flag value not available, returning default: "));
            return str2;
        }
    }

    public void init(C0621a aVar) {
        Context context = (Context) C0624b.m1273A2(aVar);
        if (!this.f17442e) {
            try {
                this.f17443f = C0645e.m1297a(context.createPackageContext("com.google.android.gms", 0));
                this.f17442e = true;
            } catch (PackageManager.NameNotFoundException unused) {
            } catch (Exception e) {
                String valueOf = String.valueOf(e.getMessage());
                Log.w("FlagProviderImpl", valueOf.length() != 0 ? "Could not retrieve sdk flags, continuing with defaults: ".concat(valueOf) : new String("Could not retrieve sdk flags, continuing with defaults: "));
            }
        }
    }
}
