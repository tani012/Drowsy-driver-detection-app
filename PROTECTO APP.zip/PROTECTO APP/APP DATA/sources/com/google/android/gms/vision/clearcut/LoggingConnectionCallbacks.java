package com.google.android.gms.vision.clearcut;

import android.os.Bundle;
import androidx.annotation.Keep;
import p002b.p011c.p015b.p028b.p053e.C0449b;
import p002b.p011c.p015b.p028b.p053e.p054m.C0481d;

@Keep
public class LoggingConnectionCallbacks implements C0481d.C0482a, C0481d.C0483b {
    public void onConnected(Bundle bundle) {
        throw new NoSuchMethodError();
    }

    public void onConnectionFailed(C0449b bVar) {
        throw new NoSuchMethodError();
    }

    public void onConnectionSuspended(int i) {
        throw new NoSuchMethodError();
    }
}
