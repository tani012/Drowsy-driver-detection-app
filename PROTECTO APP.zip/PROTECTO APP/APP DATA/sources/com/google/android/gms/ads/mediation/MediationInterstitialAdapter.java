package com.google.android.gms.ads.mediation;

import android.content.Context;
import android.os.Bundle;
import p002b.p011c.p015b.p028b.p029a.p041y.C0404e;
import p002b.p011c.p015b.p028b.p029a.p041y.C0405f;
import p002b.p011c.p015b.p028b.p029a.p041y.C0410k;

public interface MediationInterstitialAdapter extends C0405f {
    /* synthetic */ void onDestroy();

    /* synthetic */ void onPause();

    /* synthetic */ void onResume();

    void requestInterstitialAd(Context context, C0410k kVar, Bundle bundle, C0404e eVar, Bundle bundle2);

    void showInterstitial();
}
