package com.google.android.gms.common.api;

import android.app.PendingIntent;
import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.ReflectedParcelable;
import java.util.Arrays;
import p002b.p008b.p009a.p010a.C0131a;
import p002b.p011c.p015b.p028b.p053e.p054m.C0487g;
import p002b.p011c.p015b.p028b.p053e.p054m.C0533l;
import p002b.p011c.p015b.p028b.p053e.p057o.C0581p;
import p002b.p011c.p015b.p028b.p053e.p057o.p058t.C0585a;
import p176d.p178b.p179k.C4851q;

public final class Status extends C0585a implements C0487g, ReflectedParcelable {
    public static final Parcelable.Creator<Status> CREATOR = new C0533l();

    /* renamed from: i */
    public static final Status f17380i = new Status(0);

    /* renamed from: j */
    public static final Status f17381j = new Status(15);

    /* renamed from: k */
    public static final Status f17382k = new Status(16);

    /* renamed from: e */
    public final int f17383e;

    /* renamed from: f */
    public final int f17384f;

    /* renamed from: g */
    public final String f17385g;

    /* renamed from: h */
    public final PendingIntent f17386h;

    static {
        new Status(14);
        new Status(8);
        new Status(17);
        new Status(18);
    }

    public Status(int i) {
        this(1, i, (String) null, (PendingIntent) null);
    }

    public Status(int i, int i2, String str, PendingIntent pendingIntent) {
        this.f17383e = i;
        this.f17384f = i2;
        this.f17385g = str;
        this.f17386h = pendingIntent;
    }

    public Status(int i, String str) {
        this(1, i, str, (PendingIntent) null);
    }

    public final boolean equals(Object obj) {
        if (!(obj instanceof Status)) {
            return false;
        }
        Status status = (Status) obj;
        return this.f17383e == status.f17383e && this.f17384f == status.f17384f && C4851q.C4862i.m15103V(this.f17385g, status.f17385g) && C4851q.C4862i.m15103V(this.f17386h, status.f17386h);
    }

    public final int hashCode() {
        return Arrays.hashCode(new Object[]{Integer.valueOf(this.f17383e), Integer.valueOf(this.f17384f), this.f17385g, this.f17386h});
    }

    /* renamed from: p */
    public final Status mo1356p() {
        return this;
    }

    public final String toString() {
        C0581p X0 = C4851q.C4862i.m15108X0(this);
        String str = this.f17385g;
        if (str == null) {
            int i = this.f17384f;
            switch (i) {
                case -1:
                    str = "SUCCESS_CACHE";
                    break;
                case 0:
                    str = "SUCCESS";
                    break;
                case 2:
                    str = "SERVICE_VERSION_UPDATE_REQUIRED";
                    break;
                case 3:
                    str = "SERVICE_DISABLED";
                    break;
                case 4:
                    str = "SIGN_IN_REQUIRED";
                    break;
                case 5:
                    str = "INVALID_ACCOUNT";
                    break;
                case 6:
                    str = "RESOLUTION_REQUIRED";
                    break;
                case 7:
                    str = "NETWORK_ERROR";
                    break;
                case 8:
                    str = "INTERNAL_ERROR";
                    break;
                case 10:
                    str = "DEVELOPER_ERROR";
                    break;
                case 13:
                    str = "ERROR";
                    break;
                case 14:
                    str = "INTERRUPTED";
                    break;
                case 15:
                    str = "TIMEOUT";
                    break;
                case 16:
                    str = "CANCELED";
                    break;
                case 17:
                    str = "API_NOT_CONNECTED";
                    break;
                case 18:
                    str = "DEAD_CLIENT";
                    break;
                default:
                    str = C0131a.m386t(32, "unknown status code: ", i);
                    break;
            }
        }
        X0.mo1485a("statusCode", str);
        X0.mo1485a("resolution", this.f17386h);
        return X0.toString();
    }

    public final void writeToParcel(Parcel parcel, int i) {
        int e = C4851q.C4862i.m15125e(parcel);
        C4851q.C4862i.m15136h1(parcel, 1, this.f17384f);
        C4851q.C4862i.m15148l1(parcel, 2, this.f17385g, false);
        C4851q.C4862i.m15145k1(parcel, 3, this.f17386h, i, false);
        C4851q.C4862i.m15136h1(parcel, 1000, this.f17383e);
        C4851q.C4862i.m15181w1(parcel, e);
    }
}
