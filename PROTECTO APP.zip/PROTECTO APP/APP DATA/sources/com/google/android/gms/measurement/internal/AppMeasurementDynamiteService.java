package com.google.android.gms.measurement.internal;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.os.RemoteException;
import com.google.android.gms.common.util.DynamiteApi;
import java.util.Map;
import java.util.concurrent.atomic.AtomicReference;
import p002b.p011c.p015b.p028b.p064f.C0621a;
import p002b.p011c.p015b.p028b.p064f.C0624b;
import p002b.p011c.p015b.p028b.p068i.p078j.C2660ae;
import p002b.p011c.p015b.p028b.p068i.p078j.C2678c;
import p002b.p011c.p015b.p028b.p068i.p078j.C2694ce;
import p002b.p011c.p015b.p028b.p068i.p078j.C2695d;
import p002b.p011c.p015b.p028b.p068i.p078j.C2729f;
import p002b.p011c.p015b.p028b.p082j.p084b.C3391a7;
import p002b.p011c.p015b.p028b.p082j.p084b.C3392a8;
import p002b.p011c.p015b.p028b.p082j.p084b.C3403b7;
import p002b.p011c.p015b.p028b.p082j.p084b.C3405b9;
import p002b.p011c.p015b.p028b.p082j.p084b.C3414c6;
import p002b.p011c.p015b.p028b.p082j.p084b.C3415c7;
import p002b.p011c.p015b.p028b.p082j.p084b.C3427d7;
import p002b.p011c.p015b.p028b.p082j.p084b.C3436e4;
import p002b.p011c.p015b.p028b.p082j.p084b.C3437e5;
import p002b.p011c.p015b.p028b.p082j.p084b.C3450f6;
import p002b.p011c.p015b.p028b.p082j.p084b.C3461g5;
import p002b.p011c.p015b.p028b.p082j.p084b.C3463g7;
import p002b.p011c.p015b.p028b.p082j.p084b.C3486i6;
import p002b.p011c.p015b.p028b.p082j.p084b.C3498j6;
import p002b.p011c.p015b.p028b.p082j.p084b.C3510k6;
import p002b.p011c.p015b.p028b.p082j.p084b.C3522l6;
import p002b.p011c.p015b.p028b.p082j.p084b.C3528m;
import p002b.p011c.p015b.p028b.p082j.p084b.C3536m7;
import p002b.p011c.p015b.p028b.p082j.p084b.C3539n;
import p002b.p011c.p015b.p028b.p082j.p084b.C3557o6;
import p002b.p011c.p015b.p028b.p082j.p084b.C3558o7;
import p002b.p011c.p015b.p028b.p082j.p084b.C3579q6;
import p002b.p011c.p015b.p028b.p082j.p084b.C3590r6;
import p002b.p011c.p015b.p028b.p082j.p084b.C3634v6;
import p002b.p011c.p015b.p028b.p082j.p084b.C3645w6;
import p002b.p011c.p015b.p028b.p082j.p084b.C3648w9;
import p002b.p011c.p015b.p028b.p082j.p084b.C3659x9;
import p002b.p011c.p015b.p028b.p082j.p084b.C3667y6;
import p002b.p011c.p015b.p028b.p082j.p084b.C3676z4;
import p002b.p011c.p015b.p028b.p082j.p084b.C3678z6;
import p176d.p178b.p179k.C4851q;
import p176d.p212f.C5507a;

@DynamiteApi
public class AppMeasurementDynamiteService extends C2660ae {

    /* renamed from: e */
    public C3461g5 f17454e = null;

    /* renamed from: f */
    public Map<Integer, C3486i6> f17455f = new C5507a();

    /* renamed from: com.google.android.gms.measurement.internal.AppMeasurementDynamiteService$a */
    public class C4806a implements C3486i6 {

        /* renamed from: a */
        public C2678c f17456a;

        public C4806a(C2678c cVar) {
            this.f17456a = cVar;
        }

        /* renamed from: a */
        public final void mo7734a(String str, String str2, Bundle bundle, long j) {
            try {
                this.f17456a.mo6318W1(str, str2, bundle, j);
            } catch (RemoteException e) {
                AppMeasurementDynamiteService.this.f17454e.mo7499i().f14152i.mo7645b("Event listener threw exception", e);
            }
        }
    }

    /* renamed from: com.google.android.gms.measurement.internal.AppMeasurementDynamiteService$b */
    public class C4807b implements C3450f6 {

        /* renamed from: a */
        public C2678c f17458a;

        public C4807b(C2678c cVar) {
            this.f17458a = cVar;
        }
    }

    public void beginAdUnitExposure(String str, long j) {
        mo9723c2();
        this.f17454e.mo7692x().mo7468v(str, j);
    }

    /* renamed from: c2 */
    public final void mo9723c2() {
        if (this.f17454e == null) {
            throw new IllegalStateException("Attempting to perform action before initialize.");
        }
    }

    public void clearConditionalUserProperty(String str, String str2, Bundle bundle) {
        mo9723c2();
        C3510k6 p = this.f17454e.mo7684p();
        p.mo7492a();
        p.mo7779Q((String) null, str, str2, bundle);
    }

    public void endAdUnitExposure(String str, long j) {
        mo9723c2();
        this.f17454e.mo7692x().mo7471y(str, j);
    }

    public void generateEventId(C2694ce ceVar) {
        mo9723c2();
        this.f17454e.mo7685q().mo7990I(ceVar, this.f17454e.mo7685q().mo8017w0());
    }

    public void getAppInstanceId(C2694ce ceVar) {
        mo9723c2();
        C3676z4 L = this.f17454e.mo7490L();
        C3414c6 c6Var = new C3414c6(this, ceVar);
        L.mo8055m();
        C4851q.C4862i.m15170t(c6Var);
        L.mo8051t(new C3437e5(L, c6Var, "Task exception on worker thread"));
    }

    public void getCachedAppInstanceId(C2694ce ceVar) {
        mo9723c2();
        C3510k6 p = this.f17454e.mo7684p();
        p.mo7492a();
        this.f17454e.mo7685q().mo7992M(ceVar, p.f14485g.get());
    }

    public void getConditionalUserProperties(String str, String str2, C2694ce ceVar) {
        mo9723c2();
        C3676z4 L = this.f17454e.mo7490L();
        C3659x9 x9Var = new C3659x9(this, ceVar, str, str2);
        L.mo8055m();
        C4851q.C4862i.m15170t(x9Var);
        L.mo8051t(new C3437e5(L, x9Var, "Task exception on worker thread"));
    }

    public void getCurrentScreenClass(C2694ce ceVar) {
        mo9723c2();
        C3558o7 t = this.f17454e.mo7684p().f14129a.mo7688t();
        t.mo7492a();
        C3536m7 m7Var = t.f14646c;
        this.f17454e.mo7685q().mo7992M(ceVar, m7Var != null ? m7Var.f14564b : null);
    }

    public void getCurrentScreenName(C2694ce ceVar) {
        mo9723c2();
        C3558o7 t = this.f17454e.mo7684p().f14129a.mo7688t();
        t.mo7492a();
        C3536m7 m7Var = t.f14646c;
        this.f17454e.mo7685q().mo7992M(ceVar, m7Var != null ? m7Var.f14563a : null);
    }

    public void getGmpAppId(C2694ce ceVar) {
        mo9723c2();
        this.f17454e.mo7685q().mo7992M(ceVar, this.f17454e.mo7684p().mo7774I());
    }

    public void getMaxUserProperties(String str, C2694ce ceVar) {
        mo9723c2();
        this.f17454e.mo7684p();
        C4851q.C4862i.m15155o(str);
        this.f17454e.mo7685q().mo7989H(ceVar, 25);
    }

    public void getTestFlag(C2694ce ceVar, int i) {
        mo9723c2();
        if (i == 0) {
            C3648w9 q = this.f17454e.mo7685q();
            C3510k6 p = this.f17454e.mo7684p();
            if (p != null) {
                AtomicReference atomicReference = new AtomicReference();
                q.mo7992M(ceVar, (String) p.mo7490L().mo8049r(atomicReference, 15000, "String test flag value", new C3634v6(p, atomicReference)));
                return;
            }
            throw null;
        } else if (i == 1) {
            C3648w9 q2 = this.f17454e.mo7685q();
            C3510k6 p2 = this.f17454e.mo7684p();
            if (p2 != null) {
                AtomicReference atomicReference2 = new AtomicReference();
                q2.mo7990I(ceVar, ((Long) p2.mo7490L().mo8049r(atomicReference2, 15000, "long test flag value", new C3645w6(p2, atomicReference2))).longValue());
                return;
            }
            throw null;
        } else if (i == 2) {
            C3648w9 q3 = this.f17454e.mo7685q();
            C3510k6 p3 = this.f17454e.mo7684p();
            if (p3 != null) {
                AtomicReference atomicReference3 = new AtomicReference();
                double doubleValue = ((Double) p3.mo7490L().mo8049r(atomicReference3, 15000, "double test flag value", new C3667y6(p3, atomicReference3))).doubleValue();
                Bundle bundle = new Bundle();
                bundle.putDouble("r", doubleValue);
                try {
                    ceVar.mo6355N(bundle);
                } catch (RemoteException e) {
                    q3.f14129a.mo7499i().f14152i.mo7645b("Error returning double value to wrapper", e);
                }
            } else {
                throw null;
            }
        } else if (i == 3) {
            C3648w9 q4 = this.f17454e.mo7685q();
            C3510k6 p4 = this.f17454e.mo7684p();
            if (p4 != null) {
                AtomicReference atomicReference4 = new AtomicReference();
                q4.mo7989H(ceVar, ((Integer) p4.mo7490L().mo8049r(atomicReference4, 15000, "int test flag value", new C3678z6(p4, atomicReference4))).intValue());
                return;
            }
            throw null;
        } else if (i == 4) {
            C3648w9 q5 = this.f17454e.mo7685q();
            C3510k6 p5 = this.f17454e.mo7684p();
            if (p5 != null) {
                AtomicReference atomicReference5 = new AtomicReference();
                q5.mo7994P(ceVar, ((Boolean) p5.mo7490L().mo8049r(atomicReference5, 15000, "boolean test flag value", new C3522l6(p5, atomicReference5))).booleanValue());
                return;
            }
            throw null;
        }
    }

    public void getUserProperties(String str, String str2, boolean z, C2694ce ceVar) {
        mo9723c2();
        C3676z4 L = this.f17454e.mo7490L();
        C3415c7 c7Var = new C3415c7(this, ceVar, str, str2, z);
        L.mo8055m();
        C4851q.C4862i.m15170t(c7Var);
        L.mo8051t(new C3437e5(L, c7Var, "Task exception on worker thread"));
    }

    public void initForTests(Map map) {
        mo9723c2();
    }

    public void initialize(C0621a aVar, C2729f fVar, long j) {
        Context context = (Context) C0624b.m1273A2(aVar);
        C3461g5 g5Var = this.f17454e;
        if (g5Var == null) {
            this.f17454e = C3461g5.m12271a(context, fVar, Long.valueOf(j));
        } else {
            g5Var.mo7499i().f14152i.mo7644a("Attempting to initialize multiple times");
        }
    }

    public void isDataCollectionEnabled(C2694ce ceVar) {
        mo9723c2();
        C3676z4 L = this.f17454e.mo7490L();
        C3405b9 b9Var = new C3405b9(this, ceVar);
        L.mo8055m();
        C4851q.C4862i.m15170t(b9Var);
        L.mo8051t(new C3437e5(L, b9Var, "Task exception on worker thread"));
    }

    public void logEvent(String str, String str2, Bundle bundle, boolean z, boolean z2, long j) {
        mo9723c2();
        this.f17454e.mo7684p().mo7768C(str, str2, bundle, z, z2, j);
    }

    public void logEventAndBundle(String str, String str2, Bundle bundle, C2694ce ceVar, long j) {
        Bundle bundle2;
        mo9723c2();
        C4851q.C4862i.m15155o(str2);
        if (bundle == null) {
            bundle2 = new Bundle();
        }
        bundle2.putString("_o", "app");
        C3539n nVar = new C3539n(str2, new C3528m(bundle), "app", j);
        C3676z4 L = this.f17454e.mo7490L();
        C3392a8 a8Var = new C3392a8(this, ceVar, nVar, str);
        L.mo8055m();
        C4851q.C4862i.m15170t(a8Var);
        L.mo8051t(new C3437e5(L, a8Var, "Task exception on worker thread"));
    }

    public void logHealthData(int i, String str, C0621a aVar, C0621a aVar2, C0621a aVar3) {
        mo9723c2();
        Object obj = null;
        Object A2 = aVar == null ? null : C0624b.m1273A2(aVar);
        Object A22 = aVar2 == null ? null : C0624b.m1273A2(aVar2);
        if (aVar3 != null) {
            obj = C0624b.m1273A2(aVar3);
        }
        this.f17454e.mo7499i().mo7523v(i, true, false, str, A2, A22, obj);
    }

    public void onActivityCreated(C0621a aVar, Bundle bundle, long j) {
        mo9723c2();
        C3463g7 g7Var = this.f17454e.mo7684p().f14481c;
        if (g7Var != null) {
            this.f17454e.mo7684p().mo7772G();
            g7Var.onActivityCreated((Activity) C0624b.m1273A2(aVar), bundle);
        }
    }

    public void onActivityDestroyed(C0621a aVar, long j) {
        mo9723c2();
        C3463g7 g7Var = this.f17454e.mo7684p().f14481c;
        if (g7Var != null) {
            this.f17454e.mo7684p().mo7772G();
            g7Var.onActivityDestroyed((Activity) C0624b.m1273A2(aVar));
        }
    }

    public void onActivityPaused(C0621a aVar, long j) {
        mo9723c2();
        C3463g7 g7Var = this.f17454e.mo7684p().f14481c;
        if (g7Var != null) {
            this.f17454e.mo7684p().mo7772G();
            g7Var.onActivityPaused((Activity) C0624b.m1273A2(aVar));
        }
    }

    public void onActivityResumed(C0621a aVar, long j) {
        mo9723c2();
        C3463g7 g7Var = this.f17454e.mo7684p().f14481c;
        if (g7Var != null) {
            this.f17454e.mo7684p().mo7772G();
            g7Var.onActivityResumed((Activity) C0624b.m1273A2(aVar));
        }
    }

    public void onActivitySaveInstanceState(C0621a aVar, C2694ce ceVar, long j) {
        mo9723c2();
        C3463g7 g7Var = this.f17454e.mo7684p().f14481c;
        Bundle bundle = new Bundle();
        if (g7Var != null) {
            this.f17454e.mo7684p().mo7772G();
            g7Var.onActivitySaveInstanceState((Activity) C0624b.m1273A2(aVar), bundle);
        }
        try {
            ceVar.mo6355N(bundle);
        } catch (RemoteException e) {
            this.f17454e.mo7499i().f14152i.mo7645b("Error returning bundle value to wrapper", e);
        }
    }

    public void onActivityStarted(C0621a aVar, long j) {
        mo9723c2();
        if (this.f17454e.mo7684p().f14481c != null) {
            this.f17454e.mo7684p().mo7772G();
            Activity activity = (Activity) C0624b.m1273A2(aVar);
        }
    }

    public void onActivityStopped(C0621a aVar, long j) {
        mo9723c2();
        if (this.f17454e.mo7684p().f14481c != null) {
            this.f17454e.mo7684p().mo7772G();
            Activity activity = (Activity) C0624b.m1273A2(aVar);
        }
    }

    public void performAction(Bundle bundle, C2694ce ceVar, long j) {
        mo9723c2();
        ceVar.mo6355N((Bundle) null);
    }

    public void registerOnMeasurementEventListener(C2678c cVar) {
        mo9723c2();
        Object obj = this.f17455f.get(Integer.valueOf(cVar.mo6319a()));
        if (obj == null) {
            obj = new C4806a(cVar);
            this.f17455f.put(Integer.valueOf(cVar.mo6319a()), obj);
        }
        C3510k6 p = this.f17454e.mo7684p();
        p.mo7492a();
        p.mo7586u();
        C4851q.C4862i.m15170t(obj);
        if (!p.f14483e.add(obj)) {
            p.mo7499i().f14152i.mo7644a("OnEventListener already registered");
        }
    }

    public void resetAnalyticsData(long j) {
        mo9723c2();
        C3510k6 p = this.f17454e.mo7684p();
        p.f14485g.set((Object) null);
        C3676z4 L = p.mo7490L();
        C3590r6 r6Var = new C3590r6(p, j);
        L.mo8055m();
        C4851q.C4862i.m15170t(r6Var);
        L.mo8051t(new C3437e5(L, r6Var, "Task exception on worker thread"));
    }

    public void setConditionalUserProperty(Bundle bundle, long j) {
        mo9723c2();
        if (bundle == null) {
            this.f17454e.mo7499i().f14149f.mo7644a("Conditional user property must not be null");
        } else {
            this.f17454e.mo7684p().mo7780x(bundle, j);
        }
    }

    public void setCurrentScreen(C0621a aVar, String str, String str2, long j) {
        C3436e4 e4Var;
        Integer valueOf;
        String str3;
        C3436e4 e4Var2;
        String str4;
        mo9723c2();
        C3558o7 t = this.f17454e.mo7688t();
        Activity activity = (Activity) C0624b.m1273A2(aVar);
        if (!t.f14129a.f14334g.mo7801z().booleanValue()) {
            e4Var2 = t.mo7499i().f14154k;
            str4 = "setCurrentScreen cannot be called while screen reporting is disabled.";
        } else if (t.f14646c == null) {
            e4Var2 = t.mo7499i().f14154k;
            str4 = "setCurrentScreen cannot be called while no activity active";
        } else if (t.f14649f.get(activity) == null) {
            e4Var2 = t.mo7499i().f14154k;
            str4 = "setCurrentScreen must be called with an activity in the activity lifecycle";
        } else {
            if (str2 == null) {
                str2 = C3558o7.m12508y(activity.getClass().getCanonicalName());
            }
            boolean s0 = C3648w9.m12762s0(t.f14646c.f14564b, str2);
            boolean s02 = C3648w9.m12762s0(t.f14646c.f14563a, str);
            if (!s0 || !s02) {
                if (str != null && (str.length() <= 0 || str.length() > 100)) {
                    e4Var = t.mo7499i().f14154k;
                    valueOf = Integer.valueOf(str.length());
                    str3 = "Invalid screen name length in setCurrentScreen. Length";
                } else if (str2 == null || (str2.length() > 0 && str2.length() <= 100)) {
                    t.mo7499i().f14157n.mo7646c("Setting current screen to name, class", str == null ? "null" : str, str2);
                    C3536m7 m7Var = new C3536m7(str, str2, t.mo7497g().mo8017w0());
                    t.f14649f.put(activity, m7Var);
                    t.mo7883A(activity, m7Var, true);
                    return;
                } else {
                    e4Var = t.mo7499i().f14154k;
                    valueOf = Integer.valueOf(str2.length());
                    str3 = "Invalid class name length in setCurrentScreen. Length";
                }
                e4Var.mo7645b(str3, valueOf);
                return;
            }
            e4Var2 = t.mo7499i().f14154k;
            str4 = "setCurrentScreen cannot be called with the same class and name";
        }
        e4Var2.mo7644a(str4);
    }

    public void setDataCollectionEnabled(boolean z) {
        mo9723c2();
        C3510k6 p = this.f17454e.mo7684p();
        p.mo7586u();
        p.mo7492a();
        C3676z4 L = p.mo7490L();
        C3391a7 a7Var = new C3391a7(p, z);
        L.mo8055m();
        C4851q.C4862i.m15170t(a7Var);
        L.mo8051t(new C3437e5(L, a7Var, "Task exception on worker thread"));
    }

    public void setDefaultEventParameters(Bundle bundle) {
        mo9723c2();
        C3510k6 p = this.f17454e.mo7684p();
        Bundle bundle2 = bundle == null ? null : new Bundle(bundle);
        C3676z4 L = p.mo7490L();
        C3498j6 j6Var = new C3498j6(p, bundle2);
        L.mo8055m();
        C4851q.C4862i.m15170t(j6Var);
        L.mo8051t(new C3437e5(L, j6Var, "Task exception on worker thread"));
    }

    public void setEventInterceptor(C2678c cVar) {
        mo9723c2();
        C3510k6 p = this.f17454e.mo7684p();
        C4807b bVar = new C4807b(cVar);
        p.mo7492a();
        p.mo7586u();
        C3676z4 L = p.mo7490L();
        C3579q6 q6Var = new C3579q6(p, bVar);
        L.mo8055m();
        C4851q.C4862i.m15170t(q6Var);
        L.mo8051t(new C3437e5(L, q6Var, "Task exception on worker thread"));
    }

    public void setInstanceIdProvider(C2695d dVar) {
        mo9723c2();
    }

    public void setMeasurementEnabled(boolean z, long j) {
        mo9723c2();
        C3510k6 p = this.f17454e.mo7684p();
        p.mo7586u();
        p.mo7492a();
        C3676z4 L = p.mo7490L();
        C3403b7 b7Var = new C3403b7(p, z);
        L.mo8055m();
        C4851q.C4862i.m15170t(b7Var);
        L.mo8051t(new C3437e5(L, b7Var, "Task exception on worker thread"));
    }

    public void setMinimumSessionDuration(long j) {
        mo9723c2();
        C3510k6 p = this.f17454e.mo7684p();
        p.mo7492a();
        C3676z4 L = p.mo7490L();
        C3427d7 d7Var = new C3427d7(p, j);
        L.mo8055m();
        C4851q.C4862i.m15170t(d7Var);
        L.mo8051t(new C3437e5(L, d7Var, "Task exception on worker thread"));
    }

    public void setSessionTimeoutDuration(long j) {
        mo9723c2();
        C3510k6 p = this.f17454e.mo7684p();
        p.mo7492a();
        C3676z4 L = p.mo7490L();
        C3557o6 o6Var = new C3557o6(p, j);
        L.mo8055m();
        C4851q.C4862i.m15170t(o6Var);
        L.mo8051t(new C3437e5(L, o6Var, "Task exception on worker thread"));
    }

    public void setUserId(String str, long j) {
        mo9723c2();
        this.f17454e.mo7684p().mo7771F((String) null, "_id", str, true, j);
    }

    public void setUserProperty(String str, String str2, C0621a aVar, boolean z, long j) {
        mo9723c2();
        this.f17454e.mo7684p().mo7771F(str, str2, C0624b.m1273A2(aVar), z, j);
    }

    public void unregisterOnMeasurementEventListener(C2678c cVar) {
        mo9723c2();
        Object remove = this.f17455f.remove(Integer.valueOf(cVar.mo6319a()));
        if (remove == null) {
            remove = new C4806a(cVar);
        }
        C3510k6 p = this.f17454e.mo7684p();
        p.mo7492a();
        p.mo7586u();
        C4851q.C4862i.m15170t(remove);
        if (!p.f14483e.remove(remove)) {
            p.mo7499i().f14152i.mo7644a("OnEventListener had not been registered");
        }
    }
}
