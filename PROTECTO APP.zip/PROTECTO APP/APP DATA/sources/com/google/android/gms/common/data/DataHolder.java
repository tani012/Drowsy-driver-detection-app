package com.google.android.gms.common.data;

import android.database.CursorWindow;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.Log;
import com.google.android.gms.common.annotation.KeepName;
import java.io.Closeable;
import java.util.ArrayList;
import java.util.HashMap;
import p002b.p011c.p015b.p028b.p053e.p056n.C0534a;
import p002b.p011c.p015b.p028b.p053e.p057o.p058t.C0585a;
import p176d.p178b.p179k.C4851q;

@KeepName
public final class DataHolder extends C0585a implements Closeable {
    public static final Parcelable.Creator<DataHolder> CREATOR = new C0534a();

    /* renamed from: e */
    public final int f17400e;

    /* renamed from: f */
    public final String[] f17401f;

    /* renamed from: g */
    public Bundle f17402g;

    /* renamed from: h */
    public final CursorWindow[] f17403h;

    /* renamed from: i */
    public final int f17404i;

    /* renamed from: j */
    public final Bundle f17405j;

    /* renamed from: k */
    public int[] f17406k;

    /* renamed from: l */
    public boolean f17407l = false;

    /* renamed from: m */
    public boolean f17408m = true;

    static {
        C4851q.C4862i.m15170t(new String[0]);
        new ArrayList();
        new HashMap();
    }

    public DataHolder(int i, String[] strArr, CursorWindow[] cursorWindowArr, int i2, Bundle bundle) {
        this.f17400e = i;
        this.f17401f = strArr;
        this.f17403h = cursorWindowArr;
        this.f17404i = i2;
        this.f17405j = bundle;
    }

    public final void close() {
        synchronized (this) {
            if (!this.f17407l) {
                this.f17407l = true;
                for (CursorWindow close : this.f17403h) {
                    close.close();
                }
            }
        }
    }

    public final void finalize() {
        boolean z;
        try {
            if (this.f17408m && this.f17403h.length > 0) {
                synchronized (this) {
                    z = this.f17407l;
                }
                if (!z) {
                    close();
                    String obj = toString();
                    StringBuilder sb = new StringBuilder(String.valueOf(obj).length() + 178);
                    sb.append("Internal data leak within a DataBuffer object detected!  Be sure to explicitly call release() on all DataBuffer extending objects when you are done with them. (internal object: ");
                    sb.append(obj);
                    sb.append(")");
                    Log.e("DataBuffer", sb.toString());
                }
            }
            super.finalize();
        } catch (Throwable th) {
            super.finalize();
            throw th;
        }
    }

    public final void writeToParcel(Parcel parcel, int i) {
        int e = C4851q.C4862i.m15125e(parcel);
        C4851q.C4862i.m15151m1(parcel, 1, this.f17401f, false);
        C4851q.C4862i.m15157o1(parcel, 2, this.f17403h, i, false);
        C4851q.C4862i.m15136h1(parcel, 3, this.f17404i);
        C4851q.C4862i.m15121c1(parcel, 4, this.f17405j, false);
        C4851q.C4862i.m15136h1(parcel, 1000, this.f17400e);
        C4851q.C4862i.m15181w1(parcel, e);
        if ((i & 1) != 0) {
            close();
        }
    }
}
