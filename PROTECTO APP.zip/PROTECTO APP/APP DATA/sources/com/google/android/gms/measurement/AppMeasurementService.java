package com.google.android.gms.measurement;

import android.app.Service;
import android.app.job.JobParameters;
import android.content.Intent;
import android.os.IBinder;
import p002b.p011c.p015b.p028b.p068i.p078j.C2729f;
import p002b.p011c.p015b.p028b.p082j.p084b.C3400b4;
import p002b.p011c.p015b.p028b.p082j.p084b.C3461g5;
import p002b.p011c.p015b.p028b.p082j.p084b.C3473h5;
import p002b.p011c.p015b.p028b.p082j.p084b.C3525l9;
import p002b.p011c.p015b.p028b.p082j.p084b.C3614t8;
import p002b.p011c.p015b.p028b.p082j.p084b.C3625u8;
import p002b.p011c.p015b.p028b.p082j.p084b.C3669y8;
import p176d.p240m.p241a.C5774a;

public final class AppMeasurementService extends Service implements C3669y8 {

    /* renamed from: e */
    public C3625u8<AppMeasurementService> f17453e;

    /* renamed from: a */
    public final void mo8036a(Intent intent) {
        C5774a.m17096a(intent);
    }

    /* renamed from: b */
    public final void mo8037b(JobParameters jobParameters, boolean z) {
        throw new UnsupportedOperationException();
    }

    /* renamed from: c */
    public final C3625u8<AppMeasurementService> mo9716c() {
        if (this.f17453e == null) {
            this.f17453e = new C3625u8<>(this);
        }
        return this.f17453e;
    }

    /* renamed from: i */
    public final boolean mo8038i(int i) {
        return stopSelfResult(i);
    }

    public final IBinder onBind(Intent intent) {
        C3625u8<AppMeasurementService> c = mo9716c();
        if (c == null) {
            throw null;
        } else if (intent == null) {
            c.mo7962c().f14149f.mo7644a("onBind called with null intent");
            return null;
        } else {
            String action = intent.getAction();
            if ("com.google.android.gms.measurement.START".equals(action)) {
                return new C3473h5(C3525l9.m12428a(c.f14902a));
            }
            c.mo7962c().f14152i.mo7645b("onBind received unknown action", action);
            return null;
        }
    }

    public final void onCreate() {
        super.onCreate();
        C3461g5.m12271a(mo9716c().f14902a, (C2729f) null, (Long) null).mo7499i().f14157n.mo7644a("Local AppMeasurementService is starting up");
    }

    public final void onDestroy() {
        C3461g5.m12271a(mo9716c().f14902a, (C2729f) null, (Long) null).mo7499i().f14157n.mo7644a("Local AppMeasurementService is shutting down");
        super.onDestroy();
    }

    public final void onRebind(Intent intent) {
        mo9716c().mo7963d(intent);
    }

    public final int onStartCommand(Intent intent, int i, int i2) {
        C3625u8<AppMeasurementService> c = mo9716c();
        C3400b4 i3 = C3461g5.m12271a(c.f14902a, (C2729f) null, (Long) null).mo7499i();
        if (intent == null) {
            i3.f14152i.mo7644a("AppMeasurementService started with null intent");
            return 2;
        }
        String action = intent.getAction();
        i3.f14157n.mo7646c("Local AppMeasurementService called. startId, action", Integer.valueOf(i2), action);
        if (!"com.google.android.gms.measurement.UPLOAD".equals(action)) {
            return 2;
        }
        c.mo7960a(new C3614t8(c, i2, i3, intent));
        return 2;
    }

    public final boolean onUnbind(Intent intent) {
        mo9716c().mo7961b(intent);
        return true;
    }
}
