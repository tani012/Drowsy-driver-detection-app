package com.google.android.datatransport.cct;

import androidx.annotation.Keep;
import p002b.p011c.p015b.p016a.p017e.C0182e;
import p002b.p011c.p015b.p016a.p019f.p020n.C0209c;
import p002b.p011c.p015b.p016a.p019f.p020n.C0210d;
import p002b.p011c.p015b.p016a.p019f.p020n.C0215h;
import p002b.p011c.p015b.p016a.p019f.p020n.C0221m;

@Keep
public class CctBackendFactory implements C0210d {
    public C0221m create(C0215h hVar) {
        C0209c cVar = (C0209c) hVar;
        return new C0182e(cVar.f954a, cVar.f955b, cVar.f956c);
    }
}
