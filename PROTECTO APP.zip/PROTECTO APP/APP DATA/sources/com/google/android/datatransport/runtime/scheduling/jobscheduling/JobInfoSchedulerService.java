package com.google.android.datatransport.runtime.scheduling.jobscheduling;

import android.app.job.JobParameters;
import android.app.job.JobService;
import android.util.Base64;
import p002b.p011c.p015b.p016a.p019f.C0188b;
import p002b.p011c.p015b.p016a.p019f.C0199h;
import p002b.p011c.p015b.p016a.p019f.C0203k;
import p002b.p011c.p015b.p016a.p019f.p022p.p023h.C0236e;
import p002b.p011c.p015b.p016a.p019f.p022p.p023h.C0241g;
import p002b.p011c.p015b.p016a.p019f.p022p.p023h.C0246l;
import p002b.p011c.p015b.p016a.p019f.p027s.C0289a;

public class JobInfoSchedulerService extends JobService {
    public boolean onStartJob(JobParameters jobParameters) {
        String string = jobParameters.getExtras().getString("backendName");
        String string2 = jobParameters.getExtras().getString("extras");
        int i = jobParameters.getExtras().getInt("priority");
        int i2 = jobParameters.getExtras().getInt("attemptNumber");
        C0203k.m432b(getApplicationContext());
        C0199h.C0200a a = C0199h.m427a();
        a.mo932b(string);
        a.mo933c(C0289a.m523b(i));
        if (string2 != null) {
            ((C0188b.C0190b) a).f916b = Base64.decode(string2, 0);
        }
        C0246l lVar = C0203k.m431a().f944d;
        lVar.f1035e.execute(new C0241g(lVar, a.mo931a(), i2, new C0236e(this, jobParameters)));
        return true;
    }

    public boolean onStopJob(JobParameters jobParameters) {
        return true;
    }
}
