package com.google.android.datatransport.runtime.scheduling.jobscheduling;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Base64;
import p002b.p011c.p015b.p016a.p019f.C0188b;
import p002b.p011c.p015b.p016a.p019f.C0199h;
import p002b.p011c.p015b.p016a.p019f.C0203k;
import p002b.p011c.p015b.p016a.p019f.p022p.p023h.C0230a;
import p002b.p011c.p015b.p016a.p019f.p022p.p023h.C0241g;
import p002b.p011c.p015b.p016a.p019f.p022p.p023h.C0246l;
import p002b.p011c.p015b.p016a.p019f.p027s.C0289a;

public class AlarmManagerSchedulerBroadcastReceiver extends BroadcastReceiver {
    /* renamed from: a */
    public static /* synthetic */ void m14818a() {
    }

    public void onReceive(Context context, Intent intent) {
        String queryParameter = intent.getData().getQueryParameter("backendName");
        String queryParameter2 = intent.getData().getQueryParameter("extras");
        int intValue = Integer.valueOf(intent.getData().getQueryParameter("priority")).intValue();
        int i = intent.getExtras().getInt("attemptNumber");
        C0203k.m432b(context);
        C0199h.C0200a a = C0199h.m427a();
        a.mo932b(queryParameter);
        a.mo933c(C0289a.m523b(intValue));
        if (queryParameter2 != null) {
            ((C0188b.C0190b) a).f916b = Base64.decode(queryParameter2, 0);
        }
        C0246l lVar = C0203k.m431a().f944d;
        lVar.f1035e.execute(new C0241g(lVar, a.mo931a(), i, C0230a.f998e));
    }
}
