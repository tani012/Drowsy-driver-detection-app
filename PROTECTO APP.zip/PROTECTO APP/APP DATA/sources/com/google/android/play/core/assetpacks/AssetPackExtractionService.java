package com.google.android.play.core.assetpacks;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.IBinder;
import p002b.p011c.p015b.p028b.p053e.p061r.C0605f;
import p002b.p011c.p015b.p095c.p096a.p098b.C3789a0;
import p002b.p011c.p015b.p095c.p096a.p098b.C3846m0;
import p002b.p011c.p015b.p095c.p096a.p098b.C3871s1;
import p002b.p011c.p015b.p095c.p096a.p098b.C3872s2;
import p002b.p011c.p015b.p095c.p096a.p098b.C3892x2;
import p002b.p011c.p015b.p095c.p096a.p098b.C3893y;
import p002b.p011c.p015b.p095c.p096a.p103e.C3909a;

public class AssetPackExtractionService extends Service {

    /* renamed from: e */
    public final C3909a f17488e = new C3909a("AssetPackExtractionService");

    /* renamed from: f */
    public Context f17489f;

    /* renamed from: g */
    public C3872s2 f17490g;

    /* renamed from: h */
    public C3789a0 f17491h;

    /* renamed from: i */
    public C3893y f17492i;

    /* renamed from: j */
    public NotificationManager f17493j;

    /* renamed from: a */
    public final synchronized void mo9735a() {
        this.f17488e.mo8271a(4, "Stopping service.", new Object[0]);
        this.f17490g.mo8248a(false);
        stopForeground(true);
        stopSelf();
    }

    /* renamed from: b */
    public final synchronized void mo9736b(Bundle bundle) {
        String string = bundle.getString("notification_title");
        String string2 = bundle.getString("notification_subtext");
        long j = bundle.getLong("notification_timeout");
        PendingIntent pendingIntent = (PendingIntent) bundle.getParcelable("notification_on_click_intent");
        Notification.Builder timeoutAfter = new Notification.Builder(this.f17489f, "playcore-assetpacks-service-notification-channel").setTimeoutAfter(j);
        if (pendingIntent != null) {
            timeoutAfter.setContentIntent(pendingIntent);
        }
        timeoutAfter.setSmallIcon(17301633).setOngoing(false).setContentTitle(string).setSubText(string2);
        timeoutAfter.setColor(bundle.getInt("notification_color")).setVisibility(-1);
        Notification build = timeoutAfter.build();
        this.f17488e.mo8271a(4, "Starting foreground service.", new Object[0]);
        this.f17490g.mo8248a(true);
        this.f17493j.createNotificationChannel(new NotificationChannel("playcore-assetpacks-service-notification-channel", bundle.getString("notification_channel_name"), 2));
        startForeground(-1883842196, build);
    }

    public final IBinder onBind(Intent intent) {
        return this.f17492i;
    }

    public final void onCreate() {
        C3846m0 m0Var;
        super.onCreate();
        this.f17488e.mo8271a(3, "onCreate", new Object[0]);
        Context applicationContext = getApplicationContext();
        synchronized (C3871s1.class) {
            if (C3871s1.f15521a == null) {
                Context applicationContext2 = applicationContext.getApplicationContext();
                if (applicationContext2 != null) {
                    applicationContext = applicationContext2;
                }
                C3892x2 x2Var = new C3892x2(applicationContext);
                C0605f.m1110g(x2Var, C3892x2.class);
                C3871s1.f15521a = new C3846m0(x2Var);
            }
            m0Var = C3871s1.f15521a;
        }
        Context context = m0Var.f15405a.f15588a;
        C0605f.m1152m(context);
        this.f17489f = context;
        this.f17490g = m0Var.f15429y.mo8148a();
        this.f17491h = m0Var.f15408d.mo8148a();
        this.f17492i = new C3893y(this.f17489f, this, this.f17491h);
        this.f17493j = (NotificationManager) this.f17489f.getSystemService("notification");
    }
}
