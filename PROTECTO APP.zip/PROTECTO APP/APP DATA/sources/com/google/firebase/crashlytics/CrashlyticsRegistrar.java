package com.google.firebase.crashlytics;

import java.util.Arrays;
import java.util.List;
import p002b.p011c.p110d.C3976c;
import p002b.p011c.p110d.p113g.p114a.C3989a;
import p002b.p011c.p110d.p116h.C4007d;
import p002b.p011c.p110d.p116h.C4014i;
import p002b.p011c.p110d.p116h.C4022q;
import p002b.p011c.p110d.p117i.C4032b;
import p002b.p011c.p110d.p117i.C4034d;
import p002b.p011c.p110d.p117i.p118e.C4035a;
import p002b.p011c.p110d.p117i.p118e.p121k.C4102r0;
import p002b.p011c.p110d.p142m.p143b.C4340a;

public class CrashlyticsRegistrar implements C4014i {
    public List<C4007d<?>> getComponents() {
        C4007d.C4009b<C4034d> a = C4007d.m13290a(C4034d.class);
        a.mo8356a(C4022q.m13308c(C3976c.class));
        a.mo8356a(new C4022q(C4340a.class, 1, 1));
        a.mo8356a(C4022q.m13307b(C3989a.class));
        a.mo8356a(C4022q.m13307b(C4035a.class));
        a.mo8358c(new C4032b(this));
        a.mo8359d(2);
        return Arrays.asList(new C4007d[]{a.mo8357b(), C4102r0.m13482p("fire-cls", "17.1.1")});
    }
}
