package com.google.firebase.abt.component;

import android.content.Context;
import androidx.annotation.Keep;
import java.util.Arrays;
import java.util.List;
import p002b.p011c.p110d.p111f.p112d.C3987a;
import p002b.p011c.p110d.p111f.p112d.C3988b;
import p002b.p011c.p110d.p113g.p114a.C3989a;
import p002b.p011c.p110d.p116h.C4007d;
import p002b.p011c.p110d.p116h.C4010e;
import p002b.p011c.p110d.p116h.C4014i;
import p002b.p011c.p110d.p116h.C4022q;
import p002b.p011c.p110d.p117i.p118e.p121k.C4102r0;

@Keep
public class AbtRegistrar implements C4014i {
    public static /* synthetic */ C3987a lambda$getComponents$0(C4010e eVar) {
        return new C3987a((Context) eVar.mo8352a(Context.class), (C3989a) eVar.mo8352a(C3989a.class));
    }

    public List<C4007d<?>> getComponents() {
        C4007d.C4009b<C3987a> a = C4007d.m13290a(C3987a.class);
        a.mo8356a(C4022q.m13308c(Context.class));
        a.mo8356a(C4022q.m13307b(C3989a.class));
        a.mo8358c(C3988b.f15719a);
        return Arrays.asList(new C4007d[]{a.mo8357b(), C4102r0.m13482p("fire-abt", "19.1.0")});
    }
}
