package com.google.firebase.analytics.connector.internal;

import android.annotation.SuppressLint;
import android.content.Context;
import androidx.annotation.Keep;
import java.util.Arrays;
import java.util.List;
import p002b.p011c.p110d.C3976c;
import p002b.p011c.p110d.p113g.p114a.C3989a;
import p002b.p011c.p110d.p113g.p114a.p115c.C3996b;
import p002b.p011c.p110d.p116h.C4007d;
import p002b.p011c.p110d.p116h.C4014i;
import p002b.p011c.p110d.p116h.C4022q;
import p002b.p011c.p110d.p117i.p118e.p121k.C4102r0;
import p002b.p011c.p110d.p140k.C4331d;

@Keep
public class AnalyticsConnectorRegistrar implements C4014i {
    @SuppressLint({"MissingPermission"})
    @Keep
    public List<C4007d<?>> getComponents() {
        C4007d.C4009b<C3989a> a = C4007d.m13290a(C3989a.class);
        a.mo8356a(C4022q.m13308c(C3976c.class));
        a.mo8356a(C4022q.m13308c(Context.class));
        a.mo8356a(C4022q.m13308c(C4331d.class));
        a.mo8358c(C3996b.f15744a);
        a.mo8359d(2);
        return Arrays.asList(new C4007d[]{a.mo8357b(), C4102r0.m13482p("fire-analytics", "17.4.4")});
    }
}
