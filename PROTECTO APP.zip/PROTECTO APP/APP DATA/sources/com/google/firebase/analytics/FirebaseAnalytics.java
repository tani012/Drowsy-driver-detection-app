package com.google.firebase.analytics;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import androidx.annotation.Keep;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import p002b.p011c.p015b.p028b.p053e.p061r.C0605f;
import p002b.p011c.p015b.p028b.p068i.p078j.C2764h;
import p002b.p011c.p015b.p028b.p068i.p078j.C2865n;
import p002b.p011c.p015b.p028b.p082j.p084b.C3487i7;
import p002b.p011c.p110d.p113g.C4003b;
import p002b.p011c.p110d.p145o.C4402f;
import p176d.p178b.p179k.C4851q;

public final class FirebaseAnalytics {

    /* renamed from: b */
    public static volatile FirebaseAnalytics f17495b;

    /* renamed from: a */
    public final C2764h f17496a;

    public FirebaseAnalytics(C2764h hVar) {
        C4851q.C4862i.m15170t(hVar);
        this.f17496a = hVar;
    }

    @Keep
    public static FirebaseAnalytics getInstance(Context context) {
        if (f17495b == null) {
            synchronized (FirebaseAnalytics.class) {
                if (f17495b == null) {
                    f17495b = new FirebaseAnalytics(C2764h.m10574b(context, (String) null, (String) null, (String) null, (Bundle) null));
                }
            }
        }
        return f17495b;
    }

    @Keep
    public static C3487i7 getScionFrontendApiImplementation(Context context, Bundle bundle) {
        C2764h b = C2764h.m10574b(context, (String) null, (String) null, (String) null, bundle);
        if (b == null) {
            return null;
        }
        return new C4003b(b);
    }

    @Keep
    public final String getFirebaseInstanceId() {
        try {
            return (String) C0605f.m1138k(C4402f.m13850f().mo8747s(), 30000, TimeUnit.MILLISECONDS);
        } catch (ExecutionException e) {
            throw new IllegalStateException(e.getCause());
        } catch (TimeoutException unused) {
            throw new IllegalThreadStateException("Firebase Installations getId Task has timed out.");
        } catch (InterruptedException e2) {
            throw new IllegalStateException(e2);
        }
    }

    @Keep
    public final void setCurrentScreen(Activity activity, String str, String str2) {
        C2764h hVar = this.f17496a;
        if (hVar != null) {
            hVar.f12944c.execute(new C2865n(hVar, activity, str, str2));
            return;
        }
        throw null;
    }
}
