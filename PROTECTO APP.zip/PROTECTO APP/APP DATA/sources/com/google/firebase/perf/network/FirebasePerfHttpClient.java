package com.google.firebase.perf.network;

import androidx.annotation.Keep;
import java.io.IOException;
import java.util.concurrent.TimeUnit;
import org.apache.http.HttpHost;
import org.apache.http.HttpRequest;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.protocol.HttpContext;
import p002b.p011c.p015b.p028b.p068i.p074f.C2101k0;
import p002b.p011c.p015b.p028b.p068i.p074f.C2237z0;
import p002b.p011c.p110d.p117i.p118e.p121k.C4102r0;
import p002b.p011c.p110d.p159r.p160b.C4464e;
import p002b.p011c.p110d.p159r.p162d.C4492e;

public class FirebasePerfHttpClient {
    @Keep
    public static <T> T execute(HttpClient httpClient, HttpHost httpHost, HttpRequest httpRequest, ResponseHandler<? extends T> responseHandler) {
        C2237z0 z0Var = new C2237z0();
        C2101k0 k0Var = new C2101k0(C4464e.m13928c());
        try {
            String valueOf = String.valueOf(httpHost.toURI());
            String valueOf2 = String.valueOf(httpRequest.getRequestLine().getUri());
            k0Var.mo5684d(valueOf2.length() != 0 ? valueOf.concat(valueOf2) : new String(valueOf));
            k0Var.mo5685e(httpRequest.getRequestLine().getMethod());
            Long F0 = C4102r0.m13429F0(httpRequest);
            if (F0 != null) {
                k0Var.mo5687g(F0.longValue());
            }
            z0Var.mo5838b();
            k0Var.mo5688h(z0Var.f12203e);
            return httpClient.execute(httpHost, httpRequest, new C4492e(responseHandler, z0Var, k0Var));
        } catch (IOException e) {
            k0Var.mo5690j(z0Var.mo5837a());
            C4102r0.m13433H0(k0Var);
            throw e;
        }
    }

    @Keep
    public static <T> T execute(HttpClient httpClient, HttpHost httpHost, HttpRequest httpRequest, ResponseHandler<? extends T> responseHandler, HttpContext httpContext) {
        C2237z0 z0Var = new C2237z0();
        C2101k0 k0Var = new C2101k0(C4464e.m13928c());
        try {
            String valueOf = String.valueOf(httpHost.toURI());
            String valueOf2 = String.valueOf(httpRequest.getRequestLine().getUri());
            k0Var.mo5684d(valueOf2.length() != 0 ? valueOf.concat(valueOf2) : new String(valueOf));
            k0Var.mo5685e(httpRequest.getRequestLine().getMethod());
            Long F0 = C4102r0.m13429F0(httpRequest);
            if (F0 != null) {
                k0Var.mo5687g(F0.longValue());
            }
            z0Var.mo5838b();
            k0Var.mo5688h(z0Var.f12203e);
            return httpClient.execute(httpHost, httpRequest, new C4492e(responseHandler, z0Var, k0Var), httpContext);
        } catch (IOException e) {
            k0Var.mo5690j(z0Var.mo5837a());
            C4102r0.m13433H0(k0Var);
            throw e;
        }
    }

    @Keep
    public static <T> T execute(HttpClient httpClient, HttpUriRequest httpUriRequest, ResponseHandler<T> responseHandler) {
        C2237z0 z0Var = new C2237z0();
        C2101k0 k0Var = new C2101k0(C4464e.m13928c());
        try {
            k0Var.mo5684d(httpUriRequest.getURI().toString());
            k0Var.mo5685e(httpUriRequest.getMethod());
            Long F0 = C4102r0.m13429F0(httpUriRequest);
            if (F0 != null) {
                k0Var.mo5687g(F0.longValue());
            }
            z0Var.mo5838b();
            k0Var.mo5688h(z0Var.f12203e);
            return httpClient.execute(httpUriRequest, new C4492e(responseHandler, z0Var, k0Var));
        } catch (IOException e) {
            k0Var.mo5690j(z0Var.mo5837a());
            C4102r0.m13433H0(k0Var);
            throw e;
        }
    }

    @Keep
    public static <T> T execute(HttpClient httpClient, HttpUriRequest httpUriRequest, ResponseHandler<T> responseHandler, HttpContext httpContext) {
        C2237z0 z0Var = new C2237z0();
        C2101k0 k0Var = new C2101k0(C4464e.m13928c());
        try {
            k0Var.mo5684d(httpUriRequest.getURI().toString());
            k0Var.mo5685e(httpUriRequest.getMethod());
            Long F0 = C4102r0.m13429F0(httpUriRequest);
            if (F0 != null) {
                k0Var.mo5687g(F0.longValue());
            }
            z0Var.mo5838b();
            k0Var.mo5688h(z0Var.f12203e);
            return httpClient.execute(httpUriRequest, new C4492e(responseHandler, z0Var, k0Var), httpContext);
        } catch (IOException e) {
            k0Var.mo5690j(z0Var.mo5837a());
            C4102r0.m13433H0(k0Var);
            throw e;
        }
    }

    @Keep
    public static HttpResponse execute(HttpClient httpClient, HttpHost httpHost, HttpRequest httpRequest) {
        TimeUnit.MILLISECONDS.toMicros(System.currentTimeMillis());
        long nanoTime = System.nanoTime();
        C2101k0 k0Var = new C2101k0(C4464e.m13928c());
        try {
            String valueOf = String.valueOf(httpHost.toURI());
            String valueOf2 = String.valueOf(httpRequest.getRequestLine().getUri());
            k0Var.mo5684d(valueOf2.length() != 0 ? valueOf.concat(valueOf2) : new String(valueOf));
            k0Var.mo5685e(httpRequest.getRequestLine().getMethod());
            Long F0 = C4102r0.m13429F0(httpRequest);
            if (F0 != null) {
                k0Var.mo5687g(F0.longValue());
            }
            long micros = TimeUnit.MILLISECONDS.toMicros(System.currentTimeMillis());
            long nanoTime2 = System.nanoTime();
            k0Var.mo5688h(micros);
            HttpResponse execute = httpClient.execute(httpHost, httpRequest);
            k0Var.mo5690j(TimeUnit.NANOSECONDS.toMicros(System.nanoTime() - nanoTime2));
            k0Var.mo5683c(execute.getStatusLine().getStatusCode());
            Long F02 = C4102r0.m13429F0(execute);
            if (F02 != null) {
                k0Var.mo5691k(F02.longValue());
            }
            String G0 = C4102r0.m13431G0(execute);
            if (G0 != null) {
                k0Var.mo5686f(G0);
            }
            k0Var.mo5682b();
            return execute;
        } catch (IOException e) {
            k0Var.mo5690j(TimeUnit.NANOSECONDS.toMicros(System.nanoTime() - nanoTime));
            C4102r0.m13433H0(k0Var);
            throw e;
        }
    }

    @Keep
    public static HttpResponse execute(HttpClient httpClient, HttpHost httpHost, HttpRequest httpRequest, HttpContext httpContext) {
        TimeUnit.MILLISECONDS.toMicros(System.currentTimeMillis());
        long nanoTime = System.nanoTime();
        C2101k0 k0Var = new C2101k0(C4464e.m13928c());
        try {
            String valueOf = String.valueOf(httpHost.toURI());
            String valueOf2 = String.valueOf(httpRequest.getRequestLine().getUri());
            k0Var.mo5684d(valueOf2.length() != 0 ? valueOf.concat(valueOf2) : new String(valueOf));
            k0Var.mo5685e(httpRequest.getRequestLine().getMethod());
            Long F0 = C4102r0.m13429F0(httpRequest);
            if (F0 != null) {
                k0Var.mo5687g(F0.longValue());
            }
            long micros = TimeUnit.MILLISECONDS.toMicros(System.currentTimeMillis());
            long nanoTime2 = System.nanoTime();
            k0Var.mo5688h(micros);
            HttpResponse execute = httpClient.execute(httpHost, httpRequest, httpContext);
            k0Var.mo5690j(TimeUnit.NANOSECONDS.toMicros(System.nanoTime() - nanoTime2));
            k0Var.mo5683c(execute.getStatusLine().getStatusCode());
            Long F02 = C4102r0.m13429F0(execute);
            if (F02 != null) {
                k0Var.mo5691k(F02.longValue());
            }
            String G0 = C4102r0.m13431G0(execute);
            if (G0 != null) {
                k0Var.mo5686f(G0);
            }
            k0Var.mo5682b();
            return execute;
        } catch (IOException e) {
            k0Var.mo5690j(TimeUnit.NANOSECONDS.toMicros(System.nanoTime() - nanoTime));
            C4102r0.m13433H0(k0Var);
            throw e;
        }
    }

    @Keep
    public static HttpResponse execute(HttpClient httpClient, HttpUriRequest httpUriRequest) {
        TimeUnit.MILLISECONDS.toMicros(System.currentTimeMillis());
        long nanoTime = System.nanoTime();
        C2101k0 k0Var = new C2101k0(C4464e.m13928c());
        try {
            k0Var.mo5684d(httpUriRequest.getURI().toString());
            k0Var.mo5685e(httpUriRequest.getMethod());
            Long F0 = C4102r0.m13429F0(httpUriRequest);
            if (F0 != null) {
                k0Var.mo5687g(F0.longValue());
            }
            long micros = TimeUnit.MILLISECONDS.toMicros(System.currentTimeMillis());
            long nanoTime2 = System.nanoTime();
            k0Var.mo5688h(micros);
            HttpResponse execute = httpClient.execute(httpUriRequest);
            k0Var.mo5690j(TimeUnit.NANOSECONDS.toMicros(System.nanoTime() - nanoTime2));
            k0Var.mo5683c(execute.getStatusLine().getStatusCode());
            Long F02 = C4102r0.m13429F0(execute);
            if (F02 != null) {
                k0Var.mo5691k(F02.longValue());
            }
            String G0 = C4102r0.m13431G0(execute);
            if (G0 != null) {
                k0Var.mo5686f(G0);
            }
            k0Var.mo5682b();
            return execute;
        } catch (IOException e) {
            k0Var.mo5690j(TimeUnit.NANOSECONDS.toMicros(System.nanoTime() - nanoTime));
            C4102r0.m13433H0(k0Var);
            throw e;
        }
    }

    @Keep
    public static HttpResponse execute(HttpClient httpClient, HttpUriRequest httpUriRequest, HttpContext httpContext) {
        TimeUnit.MILLISECONDS.toMicros(System.currentTimeMillis());
        long nanoTime = System.nanoTime();
        C2101k0 k0Var = new C2101k0(C4464e.m13928c());
        try {
            k0Var.mo5684d(httpUriRequest.getURI().toString());
            k0Var.mo5685e(httpUriRequest.getMethod());
            Long F0 = C4102r0.m13429F0(httpUriRequest);
            if (F0 != null) {
                k0Var.mo5687g(F0.longValue());
            }
            long micros = TimeUnit.MILLISECONDS.toMicros(System.currentTimeMillis());
            long nanoTime2 = System.nanoTime();
            k0Var.mo5688h(micros);
            HttpResponse execute = httpClient.execute(httpUriRequest, httpContext);
            k0Var.mo5690j(TimeUnit.NANOSECONDS.toMicros(System.nanoTime() - nanoTime2));
            k0Var.mo5683c(execute.getStatusLine().getStatusCode());
            Long F02 = C4102r0.m13429F0(execute);
            if (F02 != null) {
                k0Var.mo5691k(F02.longValue());
            }
            String G0 = C4102r0.m13431G0(execute);
            if (G0 != null) {
                k0Var.mo5686f(G0);
            }
            k0Var.mo5682b();
            return execute;
        } catch (IOException e) {
            k0Var.mo5690j(TimeUnit.NANOSECONDS.toMicros(System.nanoTime() - nanoTime));
            C4102r0.m13433H0(k0Var);
            throw e;
        }
    }
}
