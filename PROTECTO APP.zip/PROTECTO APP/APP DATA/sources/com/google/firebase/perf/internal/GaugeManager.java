package com.google.firebase.perf.internal;

import android.content.Context;
import android.util.Log;
import androidx.annotation.Keep;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import p002b.p011c.p015b.p028b.p053e.p061r.C0605f;
import p002b.p011c.p015b.p028b.p068i.p074f.C2015c0;
import p002b.p011c.p015b.p028b.p068i.p074f.C2037e1;
import p002b.p011c.p015b.p028b.p068i.p074f.C2049f0;
import p002b.p011c.p015b.p028b.p068i.p074f.C2060g0;
import p002b.p011c.p015b.p028b.p068i.p074f.C2069h0;
import p002b.p011c.p015b.p028b.p068i.p074f.C2070h1;
import p002b.p011c.p015b.p028b.p068i.p074f.C2082i0;
import p002b.p011c.p015b.p028b.p068i.p074f.C2091j;
import p002b.p011c.p015b.p028b.p068i.p074f.C2102k1;
import p002b.p011c.p015b.p028b.p068i.p074f.C2111l0;
import p002b.p011c.p015b.p028b.p068i.p074f.C2128n1;
import p002b.p011c.p015b.p028b.p068i.p074f.C2137o1;
import p002b.p011c.p015b.p028b.p068i.p074f.C2153q0;
import p002b.p011c.p015b.p028b.p068i.p074f.C2156q3;
import p002b.p011c.p015b.p028b.p068i.p074f.C2174s;
import p002b.p011c.p015b.p028b.p068i.p074f.C2184t0;
import p002b.p011c.p015b.p028b.p068i.p074f.C2200v;
import p002b.p011c.p015b.p028b.p068i.p074f.C2212w;
import p002b.p011c.p015b.p028b.p068i.p074f.C2220x;
import p002b.p011c.p015b.p028b.p068i.p074f.C2237z0;
import p002b.p011c.p110d.p159r.p160b.C4464e;
import p002b.p011c.p110d.p159r.p160b.C4468i;
import p002b.p011c.p110d.p159r.p160b.C4472m;
import p002b.p011c.p110d.p159r.p160b.C4473n;
import p002b.p011c.p110d.p159r.p160b.C4474o;
import p002b.p011c.p110d.p159r.p160b.C4476q;
import p002b.p011c.p110d.p159r.p160b.C4478s;

@Keep
public class GaugeManager {
    public static GaugeManager zzdy = new GaugeManager();
    public final C2091j zzag;
    public C2111l0 zzai;
    public C4464e zzcr;
    public final ScheduledExecutorService zzdz;
    public final C2049f0 zzea;
    public final C2060g0 zzeb;
    public C4476q zzec;
    public C2070h1 zzed;
    public String zzee;
    public ScheduledFuture zzef;
    public final ConcurrentLinkedQueue<C4811a> zzeg;

    /* renamed from: com.google.firebase.perf.internal.GaugeManager$a */
    public class C4811a {

        /* renamed from: a */
        public final C2137o1 f17516a;

        /* renamed from: b */
        public final C2070h1 f17517b;

        public C4811a(C2137o1 o1Var, C2070h1 h1Var) {
            this.f17516a = o1Var;
            this.f17517b = h1Var;
        }
    }

    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public GaugeManager() {
        /*
            r7 = this;
            java.util.concurrent.ScheduledExecutorService r1 = java.util.concurrent.Executors.newSingleThreadScheduledExecutor()
            b.c.b.b.i.f.j r3 = p002b.p011c.p015b.p028b.p068i.p074f.C2091j.m9275q()
            b.c.b.b.i.f.f0 r0 = p002b.p011c.p015b.p028b.p068i.p074f.C2049f0.f11877h
            if (r0 != 0) goto L_0x0013
            b.c.b.b.i.f.f0 r0 = new b.c.b.b.i.f.f0
            r0.<init>()
            p002b.p011c.p015b.p028b.p068i.p074f.C2049f0.f11877h = r0
        L_0x0013:
            b.c.b.b.i.f.f0 r5 = p002b.p011c.p015b.p028b.p068i.p074f.C2049f0.f11877h
            b.c.b.b.i.f.g0 r6 = p002b.p011c.p015b.p028b.p068i.p074f.C2060g0.f11895g
            r2 = 0
            r4 = 0
            r0 = r7
            r0.<init>(r1, r2, r3, r4, r5, r6)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.firebase.perf.internal.GaugeManager.<init>():void");
    }

    public GaugeManager(ScheduledExecutorService scheduledExecutorService, C4464e eVar, C2091j jVar, C4476q qVar, C2049f0 f0Var, C2060g0 g0Var) {
        this.zzed = C2070h1.APPLICATION_PROCESS_STATE_UNKNOWN;
        this.zzee = null;
        this.zzef = null;
        this.zzeg = new ConcurrentLinkedQueue<>();
        this.zzdz = scheduledExecutorService;
        this.zzcr = null;
        this.zzag = jVar;
        this.zzec = null;
        this.zzea = f0Var;
        this.zzeb = g0Var;
        this.zzai = C2111l0.m9323a();
    }

    private final void zzc(C2137o1 o1Var, C2070h1 h1Var) {
        C4464e eVar = this.zzcr;
        if (eVar == null) {
            eVar = C4464e.m13928c();
        }
        this.zzcr = eVar;
        if (eVar != null) {
            ExecutorService executorService = eVar.f16697a;
            C4468i iVar = new C4468i(eVar, o1Var, h1Var);
            while (true) {
                executorService.execute(iVar);
                SessionManager.zzco().zzcq();
                if (!this.zzeg.isEmpty()) {
                    C4811a poll = this.zzeg.poll();
                    C4464e eVar2 = this.zzcr;
                    C2137o1 o1Var2 = poll.f17516a;
                    C2070h1 h1Var2 = poll.f17517b;
                    executorService = eVar2.f16697a;
                    iVar = new C4468i(eVar2, o1Var2, h1Var2);
                } else {
                    return;
                }
            }
        } else {
            this.zzeg.add(new C4811a(o1Var, h1Var));
        }
    }

    public static synchronized GaugeManager zzca() {
        GaugeManager gaugeManager;
        synchronized (GaugeManager.class) {
            gaugeManager = zzdy;
        }
        return gaugeManager;
    }

    public final void zza(C4478s sVar, C2070h1 h1Var) {
        long j;
        boolean z;
        long j2;
        long j3;
        boolean z2;
        C2220x xVar;
        Long l;
        C2212w wVar;
        Long l2;
        C2174s sVar2;
        Long l3;
        C2200v vVar;
        Long l4;
        C4478s sVar3 = sVar;
        C2070h1 h1Var2 = h1Var;
        if (this.zzee != null) {
            zzcb();
        }
        C2237z0 z0Var = sVar3.f16742g;
        int i = C4474o.f16734a[h1Var.ordinal()];
        if (i == 1) {
            C2091j jVar = this.zzag;
            if (jVar.f11946d.f11969a) {
                Log.d("FirebasePerformance", "Retrieving Session CPU Capture Frequency on background (milliseonds) configuration value.");
            }
            synchronized (C2174s.class) {
                if (C2174s.f12127a == null) {
                    C2174s.f12127a = new C2174s();
                }
                sVar2 = C2174s.f12127a;
            }
            C2153q0<Long> f = jVar.mo5667f(sVar2);
            if (!f.mo5755b() || !C2091j.m9273k(f.mo5754a().longValue())) {
                f = jVar.mo5670j(sVar2);
                if (!f.mo5755b() || !C2091j.m9273k(f.mo5754a().longValue())) {
                    f = jVar.mo5672n(sVar2);
                    if (!f.mo5755b() || !C2091j.m9273k(f.mo5754a().longValue())) {
                        l3 = 0L;
                        j = l3.longValue();
                    }
                } else {
                    C2015c0 c0Var = jVar.f11945c;
                    if (sVar2 != null) {
                        c0Var.mo5497b("com.google.firebase.perf.SessionsCpuCaptureFrequencyBackgroundMs", f.mo5754a().longValue());
                    } else {
                        throw null;
                    }
                }
            }
            l3 = f.mo5754a();
            j = l3.longValue();
        } else if (i != 2) {
            j = -1;
        } else {
            C2091j jVar2 = this.zzag;
            if (jVar2.f11946d.f11969a) {
                Log.d("FirebasePerformance", "Retrieving Session CPU Capture Frequency on foreground (milliseonds) configuration value.");
            }
            synchronized (C2200v.class) {
                if (C2200v.f12162a == null) {
                    C2200v.f12162a = new C2200v();
                }
                vVar = C2200v.f12162a;
            }
            C2153q0<Long> f2 = jVar2.mo5667f(vVar);
            if (!f2.mo5755b() || !C2091j.m9273k(f2.mo5754a().longValue())) {
                f2 = jVar2.mo5670j(vVar);
                if (!f2.mo5755b() || !C2091j.m9273k(f2.mo5754a().longValue())) {
                    f2 = jVar2.mo5672n(vVar);
                    if (!f2.mo5755b() || !C2091j.m9273k(f2.mo5754a().longValue())) {
                        l4 = 100L;
                        j = l4.longValue();
                    }
                } else {
                    C2015c0 c0Var2 = jVar2.f11945c;
                    if (vVar != null) {
                        c0Var2.mo5497b("com.google.firebase.perf.SessionsCpuCaptureFrequencyForegroundMs", f2.mo5754a().longValue());
                    } else {
                        throw null;
                    }
                }
            }
            l4 = f2.mo5754a();
            j = l4.longValue();
        }
        if (C2049f0.m9137c(j)) {
            j = -1;
        }
        if (j == -1) {
            if (this.zzai.f11969a) {
                Log.d("FirebasePerformance", "Invalid Cpu Metrics collection frequency. Did not collect Cpu Metrics.");
            }
            z = false;
        } else {
            C2049f0 f0Var = this.zzea;
            long j4 = f0Var.f11881d;
            if (!(j4 == -1 || j4 == 0)) {
                if (!(j <= 0)) {
                    ScheduledFuture scheduledFuture = f0Var.f11878a;
                    if (scheduledFuture != null) {
                        if (f0Var.f11880c != j) {
                            scheduledFuture.cancel(false);
                            f0Var.f11878a = null;
                            f0Var.f11880c = -1;
                        }
                    }
                    f0Var.mo5583a(j, z0Var);
                }
            }
            z = true;
        }
        if (!z) {
            j = -1;
        }
        int i2 = C4474o.f16734a[h1Var.ordinal()];
        if (i2 == 1) {
            C2091j jVar3 = this.zzag;
            if (jVar3.f11946d.f11969a) {
                Log.d("FirebasePerformance", "Retrieving Session Memory Capture Frequency on background (milliseonds) configuration value.");
            }
            synchronized (C2220x.class) {
                if (C2220x.f12194a == null) {
                    C2220x.f12194a = new C2220x();
                }
                xVar = C2220x.f12194a;
            }
            C2153q0<Long> f3 = jVar3.mo5667f(xVar);
            if (!f3.mo5755b() || !C2091j.m9273k(f3.mo5754a().longValue())) {
                f3 = jVar3.mo5670j(xVar);
                if (!f3.mo5755b() || !C2091j.m9273k(f3.mo5754a().longValue())) {
                    f3 = jVar3.mo5672n(xVar);
                    if (!f3.mo5755b() || !C2091j.m9273k(f3.mo5754a().longValue())) {
                        l = 0L;
                        j2 = l.longValue();
                    }
                } else {
                    C2015c0 c0Var3 = jVar3.f11945c;
                    if (xVar != null) {
                        c0Var3.mo5497b("com.google.firebase.perf.SessionsMemoryCaptureFrequencyBackgroundMs", f3.mo5754a().longValue());
                    } else {
                        throw null;
                    }
                }
            }
            l = f3.mo5754a();
            j2 = l.longValue();
        } else if (i2 != 2) {
            j2 = -1;
        } else {
            C2091j jVar4 = this.zzag;
            if (jVar4.f11946d.f11969a) {
                Log.d("FirebasePerformance", "Retrieving Session Memory Capture Frequency on foreground (milliseonds) configuration value.");
            }
            synchronized (C2212w.class) {
                if (C2212w.f12189a == null) {
                    C2212w.f12189a = new C2212w();
                }
                wVar = C2212w.f12189a;
            }
            C2153q0<Long> f4 = jVar4.mo5667f(wVar);
            if (!f4.mo5755b() || !C2091j.m9273k(f4.mo5754a().longValue())) {
                C2153q0<Long> j5 = jVar4.mo5670j(wVar);
                if (!j5.mo5755b() || !C2091j.m9273k(j5.mo5754a().longValue())) {
                    f4 = jVar4.mo5672n(wVar);
                    if (!f4.mo5755b() || !C2091j.m9273k(f4.mo5754a().longValue())) {
                        l2 = 100L;
                        j2 = l2.longValue();
                    }
                } else {
                    C2015c0 c0Var4 = jVar4.f11945c;
                    if (wVar != null) {
                        c0Var4.mo5497b("com.google.firebase.perf.SessionsMemoryCaptureFrequencyForegroundMs", j5.mo5754a().longValue());
                        f4 = j5;
                    } else {
                        throw null;
                    }
                }
            }
            l2 = f4.mo5754a();
            j2 = l2.longValue();
        }
        if (C2060g0.m9169c(j2)) {
            j2 = -1;
        }
        if (j2 == -1) {
            if (this.zzai.f11969a) {
                Log.d("FirebasePerformance", "Invalid Memory Metrics collection frequency. Did not collect Memory Metrics.");
            }
            j3 = -1;
            z2 = false;
        } else {
            C2060g0 g0Var = this.zzeb;
            if (g0Var != null) {
                if (j2 <= 0) {
                    j3 = -1;
                } else {
                    ScheduledFuture scheduledFuture2 = g0Var.f11899d;
                    if (scheduledFuture2 == null) {
                        j3 = -1;
                    } else if (g0Var.f11900e != j2) {
                        scheduledFuture2.cancel(false);
                        g0Var.f11899d = null;
                        j3 = -1;
                        g0Var.f11900e = -1;
                    } else {
                        j3 = -1;
                    }
                    g0Var.mo5619a(j2, z0Var);
                }
                z2 = true;
            } else {
                throw null;
            }
        }
        if (z2) {
            if (j == j3) {
                j = j2;
            } else {
                j = Math.min(j, j2);
            }
        }
        if (j != j3) {
            String str = sVar3.f16740e;
            this.zzee = str;
            this.zzed = h1Var2;
            try {
                long j6 = j * 20;
                this.zzef = this.zzdz.scheduleAtFixedRate(new C4473n(this, str, h1Var2), j6, j6, TimeUnit.MILLISECONDS);
            } catch (RejectedExecutionException e) {
                C2111l0 l0Var = this.zzai;
                String valueOf = String.valueOf(e.getMessage());
                l0Var.mo5705d(valueOf.length() != 0 ? "Unable to start collecting Gauges: ".concat(valueOf) : new String("Unable to start collecting Gauges: "));
            }
        } else if (this.zzai.f11969a) {
            Log.w("FirebasePerformance", "Invalid gauge collection frequency. Unable to start collecting Gauges.");
        }
    }

    public final boolean zzb(String str, C2070h1 h1Var) {
        if (this.zzec == null) {
            return false;
        }
        C2137o1.C2138a aVar = (C2137o1.C2138a) C2137o1.zzke.mo5759l();
        if (aVar.f12103g) {
            aVar.mo5763i();
            aVar.f12103g = false;
        }
        C2137o1.m9356p((C2137o1) aVar.f12102f, str);
        C2128n1.C2129a aVar2 = (C2128n1.C2129a) C2128n1.zzjy.mo5759l();
        String str2 = this.zzec.f16738d;
        if (aVar2.f12103g) {
            aVar2.mo5763i();
            aVar2.f12103g = false;
        }
        C2128n1.m9346m((C2128n1) aVar2.f12102f, str2);
        int h0 = C0605f.m1118h0(C2184t0.f12153j.mo5786h(this.zzec.f16737c.totalMem));
        if (aVar2.f12103g) {
            aVar2.mo5763i();
            aVar2.f12103g = false;
        }
        C2128n1 n1Var = (C2128n1) aVar2.f12102f;
        n1Var.zzij |= 8;
        n1Var.zzjv = h0;
        int h02 = C0605f.m1118h0(C2184t0.f12153j.mo5786h(this.zzec.f16735a.maxMemory()));
        if (aVar2.f12103g) {
            aVar2.mo5763i();
            aVar2.f12103g = false;
        }
        C2128n1 n1Var2 = (C2128n1) aVar2.f12102f;
        n1Var2.zzij |= 16;
        n1Var2.zzjw = h02;
        int h03 = C0605f.m1118h0(C2184t0.f12151h.mo5786h((long) this.zzec.f16736b.getMemoryClass()));
        if (aVar2.f12103g) {
            aVar2.mo5763i();
            aVar2.f12103g = false;
        }
        C2128n1 n1Var3 = (C2128n1) aVar2.f12102f;
        n1Var3.zzij |= 32;
        n1Var3.zzjx = h03;
        C2128n1 n1Var4 = (C2128n1) ((C2156q3) aVar2.mo5765k());
        if (aVar.f12103g) {
            aVar.mo5763i();
            aVar.f12103g = false;
        }
        C2137o1.m9355o((C2137o1) aVar.f12102f, n1Var4);
        zzc((C2137o1) ((C2156q3) aVar.mo5765k()), h1Var);
        return true;
    }

    public final void zzc(Context context) {
        this.zzec = new C4476q(context);
    }

    public final void zzcb() {
        String str = this.zzee;
        if (str != null) {
            C2070h1 h1Var = this.zzed;
            C2049f0 f0Var = this.zzea;
            ScheduledFuture scheduledFuture = f0Var.f11878a;
            if (scheduledFuture != null) {
                scheduledFuture.cancel(false);
                f0Var.f11878a = null;
                f0Var.f11880c = -1;
            }
            C2060g0 g0Var = this.zzeb;
            ScheduledFuture scheduledFuture2 = g0Var.f11899d;
            if (scheduledFuture2 != null) {
                scheduledFuture2.cancel(false);
                g0Var.f11899d = null;
                g0Var.f11900e = -1;
            }
            ScheduledFuture scheduledFuture3 = this.zzef;
            if (scheduledFuture3 != null) {
                scheduledFuture3.cancel(false);
            }
            this.zzdz.schedule(new C4472m(this, str, h1Var), 20, TimeUnit.MILLISECONDS);
            this.zzee = null;
            this.zzed = C2070h1.APPLICATION_PROCESS_STATE_UNKNOWN;
        }
    }

    public final void zzj(C2237z0 z0Var) {
        C2049f0 f0Var = this.zzea;
        C2060g0 g0Var = this.zzeb;
        synchronized (f0Var) {
            try {
                f0Var.f11879b.schedule(new C2069h0(f0Var, z0Var), 0, TimeUnit.MILLISECONDS);
            } catch (RejectedExecutionException e) {
                String valueOf = String.valueOf(e.getMessage());
                if (valueOf.length() != 0) {
                    "Unable to collect Cpu Metric: ".concat(valueOf);
                } else {
                    new String("Unable to collect Cpu Metric: ");
                }
                throw null;
            }
        }
        synchronized (g0Var) {
            try {
                g0Var.f11896a.schedule(new C2082i0(g0Var, z0Var), 0, TimeUnit.MILLISECONDS);
            } catch (RejectedExecutionException e2) {
                C2111l0 l0Var = g0Var.f11901f;
                String valueOf2 = String.valueOf(e2.getMessage());
                l0Var.mo5705d(valueOf2.length() != 0 ? "Unable to collect Memory Metric: ".concat(valueOf2) : new String("Unable to collect Memory Metric: "));
            }
        }
    }

    /* access modifiers changed from: private */
    /* renamed from: zza */
    public final void zzd(String str, C2070h1 h1Var) {
        C2137o1.C2138a aVar = (C2137o1.C2138a) C2137o1.zzke.mo5759l();
        while (!this.zzea.f11883f.isEmpty()) {
            C2102k1 poll = this.zzea.f11883f.poll();
            if (aVar.f12103g) {
                aVar.mo5763i();
                aVar.f12103g = false;
            }
            C2137o1.m9354n((C2137o1) aVar.f12102f, poll);
        }
        while (!this.zzeb.f11897b.isEmpty()) {
            C2037e1 poll2 = this.zzeb.f11897b.poll();
            if (aVar.f12103g) {
                aVar.mo5763i();
                aVar.f12103g = false;
            }
            C2137o1.m9353m((C2137o1) aVar.f12102f, poll2);
        }
        if (aVar.f12103g) {
            aVar.mo5763i();
            aVar.f12103g = false;
        }
        C2137o1.m9356p((C2137o1) aVar.f12102f, str);
        zzc((C2137o1) ((C2156q3) aVar.mo5765k()), h1Var);
    }
}
