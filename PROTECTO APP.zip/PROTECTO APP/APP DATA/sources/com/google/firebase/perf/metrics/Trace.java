package com.google.firebase.perf.metrics;

import android.os.Parcel;
import android.os.Parcelable;
import android.util.Log;
import androidx.annotation.Keep;
import com.google.firebase.perf.internal.GaugeManager;
import com.google.firebase.perf.internal.SessionManager;
import java.lang.ref.WeakReference;
import java.util.AbstractMap;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import p002b.p011c.p015b.p028b.p068i.p074f.C2091j;
import p002b.p011c.p015b.p028b.p068i.p074f.C2111l0;
import p002b.p011c.p015b.p028b.p068i.p074f.C2127n0;
import p002b.p011c.p015b.p028b.p068i.p074f.C2136o0;
import p002b.p011c.p015b.p028b.p068i.p074f.C2237z0;
import p002b.p011c.p110d.p159r.p160b.C4459a;
import p002b.p011c.p110d.p159r.p160b.C4461b;
import p002b.p011c.p110d.p159r.p160b.C4464e;
import p002b.p011c.p110d.p159r.p160b.C4475p;
import p002b.p011c.p110d.p159r.p160b.C4478s;
import p002b.p011c.p110d.p159r.p160b.C4482w;
import p002b.p011c.p110d.p159r.p161c.C4485b;
import p002b.p011c.p110d.p159r.p161c.C4486c;
import p002b.p011c.p110d.p159r.p161c.C4487d;

public class Trace extends C4461b implements Parcelable, C4482w {
    @Keep
    public static final Parcelable.Creator<Trace> CREATOR = new C4486c();

    /* renamed from: e */
    public final Trace f17529e;

    /* renamed from: f */
    public final GaugeManager f17530f;

    /* renamed from: g */
    public final String f17531g;

    /* renamed from: h */
    public C2111l0 f17532h;

    /* renamed from: i */
    public final List<C4478s> f17533i;

    /* renamed from: j */
    public final List<Trace> f17534j;

    /* renamed from: k */
    public final Map<String, C4485b> f17535k;

    /* renamed from: l */
    public final C4464e f17536l;

    /* renamed from: m */
    public final Map<String, String> f17537m;

    /* renamed from: n */
    public C2237z0 f17538n;

    /* renamed from: o */
    public C2237z0 f17539o;

    /* renamed from: p */
    public final WeakReference<C4482w> f17540p;

    static {
        new ConcurrentHashMap();
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public Trace(Parcel parcel, boolean z, C4486c cVar) {
        super(z ? null : C4459a.m13921f());
        this.f17540p = new WeakReference<>(this);
        this.f17529e = (Trace) parcel.readParcelable(Trace.class.getClassLoader());
        this.f17531g = parcel.readString();
        ArrayList arrayList = new ArrayList();
        this.f17534j = arrayList;
        parcel.readList(arrayList, Trace.class.getClassLoader());
        this.f17535k = new ConcurrentHashMap();
        this.f17537m = new ConcurrentHashMap();
        parcel.readMap(this.f17535k, C4485b.class.getClassLoader());
        this.f17538n = (C2237z0) parcel.readParcelable(C2237z0.class.getClassLoader());
        this.f17539o = (C2237z0) parcel.readParcelable(C2237z0.class.getClassLoader());
        ArrayList arrayList2 = new ArrayList();
        this.f17533i = arrayList2;
        parcel.readList(arrayList2, C4478s.class.getClassLoader());
        if (z) {
            this.f17536l = null;
            this.f17530f = null;
            return;
        }
        this.f17536l = C4464e.m13928c();
        this.f17530f = GaugeManager.zzca();
    }

    /* renamed from: a */
    public final void mo5681a(C4478s sVar) {
        if (sVar == null) {
            if (this.f17532h.f11969a) {
                Log.i("FirebasePerformance", "Unable to add new SessionId to the Trace. Continuing without it.");
            }
        } else if (mo9791b() && !mo9792c()) {
            this.f17533i.add(sVar);
        }
    }

    /* renamed from: b */
    public final boolean mo9791b() {
        return this.f17538n != null;
    }

    /* renamed from: c */
    public final boolean mo9792c() {
        return this.f17539o != null;
    }

    @Keep
    public int describeContents() {
        return 0;
    }

    public void finalize() {
        try {
            if (mo9791b() && !mo9792c()) {
                this.f17532h.mo5705d(String.format(Locale.ENGLISH, "Trace '%s' is started but not stopped when it is destructed!", new Object[]{this.f17531g}));
                zzc(1);
            }
        } finally {
            super.finalize();
        }
    }

    @Keep
    public String getAttribute(String str) {
        return this.f17537m.get(str);
    }

    @Keep
    public Map<String, String> getAttributes() {
        return new HashMap(this.f17537m);
    }

    @Keep
    public long getLongMetric(String str) {
        C4485b bVar = str != null ? this.f17535k.get(str.trim()) : null;
        if (bVar == null) {
            return 0;
        }
        return bVar.mo8838a();
    }

    @Keep
    public void incrementMetric(String str, long j) {
        String c = C4475p.m13939c(str);
        if (c != null) {
            this.f17532h.mo5706e(String.format(Locale.ENGLISH, "Cannot increment metric '%s'. Metric name is invalid.(%s)", new Object[]{str, c}));
        } else if (!mo9791b()) {
            this.f17532h.mo5705d(String.format(Locale.ENGLISH, "Cannot increment metric '%s' for trace '%s' because it's not started", new Object[]{str, this.f17531g}));
        } else if (mo9792c()) {
            this.f17532h.mo5705d(String.format(Locale.ENGLISH, "Cannot increment metric '%s' for trace '%s' because it's been stopped", new Object[]{str, this.f17531g}));
        } else {
            String trim = str.trim();
            C4485b bVar = this.f17535k.get(trim);
            if (bVar == null) {
                bVar = new C4485b(trim);
                this.f17535k.put(trim, bVar);
            }
            bVar.f16762f.addAndGet(j);
            this.f17532h.mo5703b(String.format(Locale.ENGLISH, "Incrementing metric '%s' to %d on trace '%s'", new Object[]{str, Long.valueOf(bVar.mo8838a()), this.f17531g}));
        }
    }

    @Keep
    public void putAttribute(String str, String str2) {
        boolean z = false;
        try {
            str = str.trim();
            str2 = str2.trim();
            if (!mo9792c()) {
                if (!this.f17537m.containsKey(str)) {
                    if (this.f17537m.size() >= 5) {
                        throw new IllegalArgumentException(String.format(Locale.ENGLISH, "Exceeds max limit of number of attributes - %d", new Object[]{5}));
                    }
                }
                String a = C4475p.m13938a(new AbstractMap.SimpleEntry(str, str2));
                if (a == null) {
                    this.f17532h.mo5703b(String.format(Locale.ENGLISH, "Setting attribute '%s' to '%s' on trace '%s'", new Object[]{str, str2, this.f17531g}));
                    z = true;
                    if (z) {
                        this.f17537m.put(str, str2);
                        return;
                    }
                    return;
                }
                throw new IllegalArgumentException(a);
            }
            throw new IllegalArgumentException(String.format(Locale.ENGLISH, "Trace '%s' has been stopped", new Object[]{this.f17531g}));
        } catch (Exception e) {
            this.f17532h.mo5706e(String.format(Locale.ENGLISH, "Can not set attribute '%s' with value '%s' (%s)", new Object[]{str, str2, e.getMessage()}));
        }
    }

    @Keep
    public void putMetric(String str, long j) {
        String c = C4475p.m13939c(str);
        if (c != null) {
            this.f17532h.mo5706e(String.format(Locale.ENGLISH, "Cannot set value for metric '%s'. Metric name is invalid.(%s)", new Object[]{str, c}));
        } else if (!mo9791b()) {
            this.f17532h.mo5705d(String.format(Locale.ENGLISH, "Cannot set value for metric '%s' for trace '%s' because it's not started", new Object[]{str, this.f17531g}));
        } else if (mo9792c()) {
            this.f17532h.mo5705d(String.format(Locale.ENGLISH, "Cannot set value for metric '%s' for trace '%s' because it's been stopped", new Object[]{str, this.f17531g}));
        } else {
            String trim = str.trim();
            C4485b bVar = this.f17535k.get(trim);
            if (bVar == null) {
                bVar = new C4485b(trim);
                this.f17535k.put(trim, bVar);
            }
            bVar.f16762f.set(j);
            this.f17532h.mo5703b(String.format(Locale.ENGLISH, "Setting metric '%s' to '%s' on trace '%s'", new Object[]{str, Long.valueOf(j), this.f17531g}));
        }
    }

    @Keep
    public void removeAttribute(String str) {
        if (!mo9792c()) {
            this.f17537m.remove(str);
        } else if (this.f17532h.f11969a) {
            Log.e("FirebasePerformance", "Can't remove a attribute from a Trace that's stopped.");
        }
    }

    @Keep
    public void start() {
        String str;
        if (C2091j.m9275q().mo5675r()) {
            String str2 = this.f17531g;
            if (str2 == null) {
                str = "Trace name must not be null";
            } else if (str2.length() > 100) {
                str = String.format(Locale.US, "Trace name must not exceed %d characters", new Object[]{100});
            } else {
                if (str2.startsWith("_")) {
                    C2136o0[] values = C2136o0.values();
                    int length = values.length;
                    int i = 0;
                    while (true) {
                        if (i < length) {
                            if (values[i].f12052e.equals(str2)) {
                                break;
                            }
                            i++;
                        } else if (!str2.startsWith("_st_")) {
                            str = "Trace name must not start with '_'";
                        }
                    }
                }
                str = null;
            }
            if (str != null) {
                this.f17532h.mo5706e(String.format(Locale.ENGLISH, "Cannot start trace '%s'. Trace name is invalid.(%s)", new Object[]{this.f17531g, str}));
            } else if (this.f17538n != null) {
                this.f17532h.mo5706e(String.format(Locale.ENGLISH, "Trace '%s' has already started, should not start again!", new Object[]{this.f17531g}));
            } else {
                this.f17538n = new C2237z0();
                zzbr();
                C4478s zzcp = SessionManager.zzco().zzcp();
                SessionManager.zzco().zzc(this.f17540p);
                mo5681a(zzcp);
                if (zzcp.f16741f) {
                    this.f17530f.zzj(zzcp.f16742g);
                }
            }
        } else if (this.f17532h.f11969a) {
            Log.i("FirebasePerformance", "Trace feature is disabled.");
        }
    }

    @Keep
    public void stop() {
        String str;
        C2111l0 l0Var;
        if (!mo9791b()) {
            l0Var = this.f17532h;
            str = String.format(Locale.ENGLISH, "Trace '%s' has not been started so unable to stop!", new Object[]{this.f17531g});
        } else if (mo9792c()) {
            l0Var = this.f17532h;
            str = String.format(Locale.ENGLISH, "Trace '%s' has already stopped, should not stop again!", new Object[]{this.f17531g});
        } else {
            SessionManager.zzco().zzd(this.f17540p);
            zzbs();
            C2237z0 z0Var = new C2237z0();
            this.f17539o = z0Var;
            if (this.f17529e == null) {
                if (!this.f17534j.isEmpty()) {
                    Trace trace = this.f17534j.get(this.f17534j.size() - 1);
                    if (trace.f17539o == null) {
                        trace.f17539o = z0Var;
                    }
                }
                if (!this.f17531g.isEmpty()) {
                    C4464e eVar = this.f17536l;
                    if (eVar != null) {
                        eVar.mo8818b(new C4487d(this).mo8843a(), zzbj());
                        if (SessionManager.zzco().zzcp().f16741f) {
                            this.f17530f.zzj(SessionManager.zzco().zzcp().f16742g);
                            return;
                        }
                        return;
                    }
                    return;
                } else if (this.f17532h.f11969a) {
                    Log.e("FirebasePerformance", "Trace name is empty, no log is sent to server");
                    return;
                } else {
                    return;
                }
            } else {
                return;
            }
        }
        l0Var.mo5706e(str);
    }

    @Keep
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeParcelable(this.f17529e, 0);
        parcel.writeString(this.f17531g);
        parcel.writeList(this.f17534j);
        parcel.writeMap(this.f17535k);
        parcel.writeParcelable(this.f17538n, 0);
        parcel.writeParcelable(this.f17539o, 0);
        parcel.writeList(this.f17533i);
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public Trace(String str, C4464e eVar, C2127n0 n0Var, C4459a aVar) {
        super(aVar);
        GaugeManager zzca = GaugeManager.zzca();
        this.f17540p = new WeakReference<>(this);
        this.f17529e = null;
        this.f17531g = str.trim();
        this.f17534j = new ArrayList();
        this.f17535k = new ConcurrentHashMap();
        this.f17537m = new ConcurrentHashMap();
        this.f17536l = eVar;
        this.f17533i = new ArrayList();
        this.f17530f = zzca;
        this.f17532h = C2111l0.m9323a();
    }
}
