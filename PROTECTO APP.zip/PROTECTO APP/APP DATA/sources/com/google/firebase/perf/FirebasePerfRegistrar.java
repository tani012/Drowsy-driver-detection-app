package com.google.firebase.perf;

import androidx.annotation.Keep;
import java.util.Arrays;
import java.util.List;
import p002b.p011c.p110d.C3976c;
import p002b.p011c.p110d.p116h.C4007d;
import p002b.p011c.p110d.p116h.C4014i;
import p002b.p011c.p110d.p116h.C4022q;
import p002b.p011c.p110d.p117i.p118e.p121k.C4102r0;
import p002b.p011c.p110d.p159r.C4458a;
import p002b.p011c.p110d.p159r.C4495e;
import p002b.p011c.p110d.p164t.C4514m;

@Keep
public class FirebasePerfRegistrar implements C4014i {
    @Keep
    public List<C4007d<?>> getComponents() {
        C4007d.C4009b<C4458a> a = C4007d.m13290a(C4458a.class);
        a.mo8356a(C4022q.m13308c(C3976c.class));
        a.mo8356a(C4022q.m13308c(C4514m.class));
        a.mo8358c(C4495e.f16790a);
        a.mo8359d(2);
        return Arrays.asList(new C4007d[]{a.mo8357b(), C4102r0.m13482p("fire-perf", "19.0.8")});
    }
}
