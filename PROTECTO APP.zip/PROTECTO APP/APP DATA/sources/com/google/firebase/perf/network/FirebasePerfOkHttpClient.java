package com.google.firebase.perf.network;

import androidx.annotation.Keep;
import java.io.IOException;
import java.util.concurrent.TimeUnit;
import p002b.p011c.p015b.p028b.p068i.p074f.C2101k0;
import p002b.p011c.p015b.p028b.p068i.p074f.C2237z0;
import p002b.p011c.p110d.p117i.p118e.p121k.C4102r0;
import p002b.p011c.p110d.p159r.p160b.C4464e;
import p002b.p011c.p110d.p159r.p162d.C4494g;
import p274i.C5944c0;
import p274i.C5947d0;
import p274i.C5949e;
import p274i.C5951f;
import p274i.C5952f0;
import p274i.C6059m;
import p274i.C6069s;
import p274i.C6073u;
import p274i.C6081y;
import p274i.C6084z;
import p274i.p275i0.p281i.C6047f;

public class FirebasePerfOkHttpClient {
    /* renamed from: a */
    public static void m14922a(C5947d0 d0Var, C2101k0 k0Var, long j, long j2) {
        C6084z zVar = d0Var.f20480e;
        if (zVar != null) {
            k0Var.mo5684d(zVar.f21031a.mo12563r().toString());
            k0Var.mo5685e(zVar.f21032b);
            C5944c0 c0Var = zVar.f21034d;
            if (c0Var != null) {
                long a = c0Var.mo12318a();
                if (a != -1) {
                    k0Var.mo5687g(a);
                }
            }
            C5952f0 f0Var = d0Var.f20486k;
            if (f0Var != null) {
                long a2 = f0Var.mo12330a();
                if (a2 != -1) {
                    k0Var.mo5691k(a2);
                }
                C6073u b = f0Var.mo12331b();
                if (b != null) {
                    k0Var.mo5686f(b.f20938a);
                }
            }
            k0Var.mo5683c(d0Var.f20482g);
            k0Var.mo5688h(j);
            k0Var.mo5690j(j2);
            k0Var.mo5682b();
        }
    }

    @Keep
    public static void enqueue(C5949e eVar, C5951f fVar) {
        C2237z0 z0Var = new C2237z0();
        C5951f fVar2 = fVar;
        C4494g gVar = new C4494g(fVar2, C4464e.m13928c(), z0Var, z0Var.f12203e);
        C6081y yVar = (C6081y) eVar;
        synchronized (yVar) {
            if (!yVar.f21027k) {
                yVar.f21027k = true;
            } else {
                throw new IllegalStateException("Already Executed");
            }
        }
        yVar.f21022f.f20651c = C6047f.f20873a.mo12497j("response.body().close()");
        if (yVar.f21024h != null) {
            C6059m mVar = yVar.f21021e.f20963e;
            C6081y.C6083b bVar = new C6081y.C6083b(gVar);
            synchronized (mVar) {
                mVar.f20907d.add(bVar);
            }
            mVar.mo12539b();
            return;
        }
        throw null;
    }

    @Keep
    public static C5947d0 execute(C5949e eVar) {
        C2101k0 k0Var = new C2101k0(C4464e.m13928c());
        long micros = TimeUnit.MILLISECONDS.toMicros(System.currentTimeMillis());
        long nanoTime = System.nanoTime();
        C6081y yVar = (C6081y) eVar;
        try {
            C5947d0 b = yVar.mo12576b();
            m14922a(b, k0Var, micros, TimeUnit.NANOSECONDS.toMicros(System.nanoTime() - nanoTime));
            return b;
        } catch (IOException e) {
            C6084z zVar = yVar.f21025i;
            if (zVar != null) {
                C6069s sVar = zVar.f21031a;
                if (sVar != null) {
                    k0Var.mo5684d(sVar.mo12563r().toString());
                }
                String str = zVar.f21032b;
                if (str != null) {
                    k0Var.mo5685e(str);
                }
            }
            k0Var.mo5688h(micros);
            k0Var.mo5690j(TimeUnit.NANOSECONDS.toMicros(System.nanoTime() - nanoTime));
            C4102r0.m13433H0(k0Var);
            throw e;
        }
    }
}
