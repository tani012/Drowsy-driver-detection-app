package com.google.firebase.perf.provider;

import android.app.Application;
import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Context;
import android.content.pm.ProviderInfo;
import android.database.Cursor;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import androidx.annotation.Keep;
import com.google.firebase.perf.internal.SessionManager;
import com.google.firebase.perf.metrics.AppStartTrace;
import p002b.p011c.p015b.p028b.p068i.p074f.C2019c4;
import p002b.p011c.p015b.p028b.p068i.p074f.C2070h1;
import p002b.p011c.p015b.p028b.p068i.p074f.C2091j;
import p002b.p011c.p015b.p028b.p068i.p074f.C2127n0;
import p002b.p011c.p015b.p028b.p068i.p074f.C2237z0;
import p002b.p011c.p110d.p159r.p160b.C4459a;
import p176d.p178b.p179k.C4851q;

@Keep
public class FirebasePerfProvider extends ContentProvider {
    public static final C2237z0 zzhh = new C2237z0();
    public final Handler mHandler = new C2019c4(Looper.getMainLooper());

    public static C2237z0 zzdb() {
        return zzhh;
    }

    public void attachInfo(Context context, ProviderInfo providerInfo) {
        AppStartTrace appStartTrace;
        C4851q.C4862i.m15173u(providerInfo, "FirebasePerfProvider ProviderInfo cannot be null.");
        if (!"com.google.firebase.firebaseperfprovider".equals(providerInfo.authority)) {
            super.attachInfo(context, providerInfo);
            C2091j q = C2091j.m9275q();
            Context context2 = getContext();
            if (q != null) {
                q.mo5669i(context2.getApplicationContext());
                if (q.mo5675r()) {
                    C4459a f = C4459a.m13921f();
                    Context context3 = getContext();
                    synchronized (f) {
                        if (!f.f16677e) {
                            Context applicationContext = context3.getApplicationContext();
                            if (applicationContext instanceof Application) {
                                ((Application) applicationContext).registerActivityLifecycleCallbacks(f);
                                f.f16677e = true;
                            }
                        }
                    }
                    if (AppStartTrace.f17519n != null) {
                        appStartTrace = AppStartTrace.f17519n;
                    } else {
                        C2127n0 n0Var = new C2127n0();
                        if (AppStartTrace.f17519n == null) {
                            synchronized (AppStartTrace.class) {
                                if (AppStartTrace.f17519n == null) {
                                    AppStartTrace.f17519n = new AppStartTrace(n0Var);
                                }
                            }
                        }
                        appStartTrace = AppStartTrace.f17519n;
                    }
                    Context context4 = getContext();
                    synchronized (appStartTrace) {
                        if (!appStartTrace.f17520e) {
                            Context applicationContext2 = context4.getApplicationContext();
                            if (applicationContext2 instanceof Application) {
                                ((Application) applicationContext2).registerActivityLifecycleCallbacks(appStartTrace);
                                appStartTrace.f17520e = true;
                                appStartTrace.f17522g = applicationContext2;
                            }
                        }
                    }
                    this.mHandler.post(new AppStartTrace.C4812a(appStartTrace));
                }
                SessionManager.zzco().zzc(C2070h1.FOREGROUND);
                return;
            }
            throw null;
        }
        throw new IllegalStateException("Incorrect provider authority in manifest. Most likely due to a missing applicationId variable in application's build.gradle.");
    }

    public int delete(Uri uri, String str, String[] strArr) {
        return 0;
    }

    public String getType(Uri uri) {
        return null;
    }

    public Uri insert(Uri uri, ContentValues contentValues) {
        return null;
    }

    public boolean onCreate() {
        return false;
    }

    public Cursor query(Uri uri, String[] strArr, String str, String[] strArr2, String str2) {
        return null;
    }

    public int update(Uri uri, ContentValues contentValues, String str, String[] strArr) {
        return 0;
    }
}
