package com.google.firebase.perf.internal;

import android.util.Log;
import androidx.annotation.Keep;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executor;
import java.util.concurrent.TimeUnit;
import p002b.p011c.p015b.p028b.p068i.p074f.C2111l0;
import p002b.p011c.p015b.p028b.p068i.p074f.C2153q0;
import p002b.p011c.p015b.p028b.p089n.C3719h;
import p002b.p011c.p110d.p159r.p160b.C4481v;
import p002b.p011c.p110d.p159r.p160b.C4483x;
import p002b.p011c.p110d.p164t.C4503b;
import p002b.p011c.p110d.p164t.C4505d;
import p002b.p011c.p110d.p164t.C4506e;
import p002b.p011c.p110d.p164t.C4511j;
import p002b.p011c.p110d.p164t.p165o.C4526g;
import p002b.p011c.p110d.p164t.p165o.C4530k;
import p002b.p011c.p110d.p164t.p165o.C4533m;

@Keep
public class RemoteConfigManager {
    public static final RemoteConfigManager zzfg = new RemoteConfigManager();
    public static final long zzfh = TimeUnit.HOURS.toMillis(12);
    public final Executor executor;
    public C2111l0 zzai;
    public long zzfi;
    public C4506e zzfj;
    public final ConcurrentHashMap<String, C4511j> zzfk;

    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public RemoteConfigManager() {
        /*
            r9 = this;
            java.util.concurrent.ThreadFactory r7 = java.util.concurrent.Executors.defaultThreadFactory()
            java.util.concurrent.ThreadPoolExecutor r8 = new java.util.concurrent.ThreadPoolExecutor
            java.util.concurrent.TimeUnit r5 = java.util.concurrent.TimeUnit.SECONDS
            java.util.concurrent.LinkedBlockingQueue r6 = new java.util.concurrent.LinkedBlockingQueue
            r6.<init>()
            r1 = 1
            r2 = 1
            r3 = 60
            r0 = r8
            r0.<init>(r1, r2, r3, r5, r6, r7)
            r0 = 1
            r8.allowCoreThreadTimeOut(r0)
            java.util.concurrent.ExecutorService r0 = java.util.concurrent.Executors.unconfigurableExecutorService(r8)
            r1 = 0
            r9.<init>(r0, r1)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.firebase.perf.internal.RemoteConfigManager.<init>():void");
    }

    public RemoteConfigManager(Executor executor2, C4506e eVar) {
        this.zzfi = 0;
        this.executor = executor2;
        this.zzfj = null;
        this.zzfk = new ConcurrentHashMap<>();
        this.zzai = C2111l0.m9323a();
    }

    private final void zzb(Map<String, C4511j> map) {
        this.zzfk.putAll(map);
        for (String next : this.zzfk.keySet()) {
            if (!map.containsKey(next)) {
                this.zzfk.remove(next);
            }
        }
    }

    public static RemoteConfigManager zzck() {
        return zzfg;
    }

    private final boolean zzcm() {
        return this.zzfj != null;
    }

    private final C4511j zzl(String str) {
        if (zzcm()) {
            if (this.zzfk.isEmpty()) {
                zzb(this.zzfj.mo8999a());
            }
            if (System.currentTimeMillis() - this.zzfi > zzfh) {
                this.zzfi = System.currentTimeMillis();
                C4506e eVar = this.zzfj;
                C4530k kVar = eVar.f16809f;
                long j = kVar.f16866h.f16877a.getLong("minimum_fetch_interval_in_seconds", C4530k.f16857j);
                if (kVar.f16866h.f16877a.getBoolean("is_developer_mode_enabled", false)) {
                    j = 0;
                }
                C3719h<TContinuationResult> m = kVar.f16864f.mo9013b().mo8096g(kVar.f16861c, new C4526g(kVar, j)).mo8101l(C4505d.f16803a).mo8102m(eVar.f16805b, new C4503b(eVar));
                m.mo8093d(this.executor, new C4481v(this));
                m.mo8092c(this.executor, new C4483x(this));
            }
        }
        if (!zzcm() || !this.zzfk.containsKey(str)) {
            return null;
        }
        C4511j jVar = this.zzfk.get(str);
        if (jVar.mo9004e() != 2) {
            return null;
        }
        this.zzai.mo5703b(String.format("Fetched value: '%s' for key: '%s' from Firebase Remote Config.", new Object[]{jVar.mo9001b(), str}));
        return jVar;
    }

    /* JADX WARNING: Removed duplicated region for block: B:29:0x0066  */
    /* JADX WARNING: Removed duplicated region for block: B:36:? A[RETURN, SYNTHETIC] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final <T> T zza(java.lang.String r8, T r9) {
        /*
            r7 = this;
            b.c.d.t.j r0 = r7.zzl(r8)
            if (r0 == 0) goto L_0x007c
            r1 = 1
            r2 = 0
            boolean r3 = r9 instanceof java.lang.Boolean     // Catch:{ IllegalArgumentException -> 0x005c }
            if (r3 == 0) goto L_0x0015
            boolean r3 = r0.mo9003d()     // Catch:{ IllegalArgumentException -> 0x005c }
            java.lang.Boolean r9 = java.lang.Boolean.valueOf(r3)     // Catch:{ IllegalArgumentException -> 0x005c }
            goto L_0x007c
        L_0x0015:
            boolean r3 = r9 instanceof java.lang.Float     // Catch:{ IllegalArgumentException -> 0x005c }
            if (r3 == 0) goto L_0x002a
            double r3 = r0.mo9000a()     // Catch:{ IllegalArgumentException -> 0x005c }
            java.lang.Double r3 = java.lang.Double.valueOf(r3)     // Catch:{ IllegalArgumentException -> 0x005c }
            float r3 = r3.floatValue()     // Catch:{ IllegalArgumentException -> 0x005c }
            java.lang.Float r9 = java.lang.Float.valueOf(r3)     // Catch:{ IllegalArgumentException -> 0x005c }
            goto L_0x007c
        L_0x002a:
            boolean r3 = r9 instanceof java.lang.Long     // Catch:{ IllegalArgumentException -> 0x005c }
            if (r3 != 0) goto L_0x0053
            boolean r3 = r9 instanceof java.lang.Integer     // Catch:{ IllegalArgumentException -> 0x005c }
            if (r3 == 0) goto L_0x0033
            goto L_0x0053
        L_0x0033:
            boolean r3 = r9 instanceof java.lang.String     // Catch:{ IllegalArgumentException -> 0x005c }
            if (r3 == 0) goto L_0x003c
            java.lang.String r9 = r0.mo9001b()     // Catch:{ IllegalArgumentException -> 0x005c }
            goto L_0x007c
        L_0x003c:
            java.lang.String r3 = r0.mo9001b()     // Catch:{ IllegalArgumentException -> 0x005c }
            b.c.b.b.i.f.l0 r4 = r7.zzai     // Catch:{ IllegalArgumentException -> 0x0051 }
            java.lang.String r5 = "No matching type found for the defaultValue: '%s', using String."
            java.lang.Object[] r6 = new java.lang.Object[r1]     // Catch:{ IllegalArgumentException -> 0x0051 }
            r6[r2] = r9     // Catch:{ IllegalArgumentException -> 0x0051 }
            java.lang.String r9 = java.lang.String.format(r5, r6)     // Catch:{ IllegalArgumentException -> 0x0051 }
            r4.mo5703b(r9)     // Catch:{ IllegalArgumentException -> 0x0051 }
            r9 = r3
            goto L_0x007c
        L_0x0051:
            r9 = r3
            goto L_0x005c
        L_0x0053:
            long r3 = r0.mo9002c()     // Catch:{ IllegalArgumentException -> 0x005c }
            java.lang.Long r9 = java.lang.Long.valueOf(r3)     // Catch:{ IllegalArgumentException -> 0x005c }
            goto L_0x007c
        L_0x005c:
            java.lang.String r3 = r0.mo9001b()
            boolean r3 = r3.isEmpty()
            if (r3 != 0) goto L_0x007c
            b.c.b.b.i.f.l0 r3 = r7.zzai
            r4 = 2
            java.lang.Object[] r4 = new java.lang.Object[r4]
            java.lang.String r0 = r0.mo9001b()
            r4[r2] = r0
            r4[r1] = r8
            java.lang.String r8 = "Could not parse value: '%s' for key: '%s'."
            java.lang.String r8 = java.lang.String.format(r8, r4)
            r3.mo5703b(r8)
        L_0x007c:
            return r9
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.firebase.perf.internal.RemoteConfigManager.zza(java.lang.String, java.lang.Object):java.lang.Object");
    }

    public final void zza(C4506e eVar) {
        this.zzfj = eVar;
    }

    public final /* synthetic */ void zza(Exception exc) {
        this.zzfi = 0;
    }

    public final C2153q0<Boolean> zzb(String str) {
        if (str == null) {
            if (this.zzai.f11969a) {
                Log.d("FirebasePerformance", "The key to get Remote Config boolean value is null.");
            }
            return C2153q0.f12099b;
        }
        C4511j zzl = zzl(str);
        if (zzl != null) {
            try {
                return new C2153q0<>(Boolean.valueOf(zzl.mo9003d()));
            } catch (IllegalArgumentException unused) {
                if (!zzl.mo9001b().isEmpty()) {
                    this.zzai.mo5703b(String.format("Could not parse value: '%s' for key: '%s'.", new Object[]{zzl.mo9001b(), str}));
                }
            }
        }
        return C2153q0.f12099b;
    }

    public final C2153q0<String> zzc(String str) {
        if (str == null) {
            if (this.zzai.f11969a) {
                Log.d("FirebasePerformance", "The key to get Remote Config String value is null.");
            }
            return C2153q0.f12099b;
        }
        C4511j zzl = zzl(str);
        if (zzl != null) {
            return new C2153q0<>(zzl.mo9001b());
        }
        return C2153q0.f12099b;
    }

    public final /* synthetic */ void zzc(Boolean bool) {
        zzb(this.zzfj.mo8999a());
    }

    public final boolean zzcl() {
        int i;
        C4506e eVar = this.zzfj;
        if (eVar != null) {
            C4533m mVar = eVar.f16811h;
            synchronized (mVar.f16878b) {
                mVar.f16877a.getLong("last_fetch_time_in_millis", -1);
                i = mVar.f16877a.getInt("last_fetch_status", 0);
                long j = C4530k.f16857j;
                mVar.f16877a.getBoolean("is_developer_mode_enabled", false);
                long j2 = mVar.f16877a.getLong("fetch_timeout_in_seconds", 60);
                if (j2 >= 0) {
                    long j3 = mVar.f16877a.getLong("minimum_fetch_interval_in_seconds", C4530k.f16857j);
                    if (j3 < 0) {
                        throw new IllegalArgumentException("Minimum interval between fetches has to be a non-negative number. " + j3 + " is an invalid argument");
                    }
                } else {
                    throw new IllegalArgumentException(String.format("Fetch connection timeout has to be a non-negative number. %d is an invalid argument", new Object[]{Long.valueOf(j2)}));
                }
            }
            if (i != 1) {
                return false;
            }
        }
        return true;
    }

    public final C2153q0<Float> zzd(String str) {
        if (str == null) {
            if (this.zzai.f11969a) {
                Log.d("FirebasePerformance", "The key to get Remote Config float value is null.");
            }
            return C2153q0.f12099b;
        }
        C4511j zzl = zzl(str);
        if (zzl != null) {
            try {
                return new C2153q0<>(Float.valueOf(Double.valueOf(zzl.mo9000a()).floatValue()));
            } catch (IllegalArgumentException unused) {
                if (!zzl.mo9001b().isEmpty()) {
                    this.zzai.mo5703b(String.format("Could not parse value: '%s' for key: '%s'.", new Object[]{zzl.mo9001b(), str}));
                }
            }
        }
        return C2153q0.f12099b;
    }

    public final C2153q0<Long> zze(String str) {
        if (str == null) {
            if (this.zzai.f11969a) {
                Log.d("FirebasePerformance", "The key to get Remote Config long value is null.");
            }
            return C2153q0.f12099b;
        }
        C4511j zzl = zzl(str);
        if (zzl != null) {
            try {
                return new C2153q0<>(Long.valueOf(zzl.mo9002c()));
            } catch (IllegalArgumentException unused) {
                if (!zzl.mo9001b().isEmpty()) {
                    this.zzai.mo5703b(String.format("Could not parse value: '%s' for key: '%s'.", new Object[]{zzl.mo9001b(), str}));
                }
            }
        }
        return C2153q0.f12099b;
    }
}
