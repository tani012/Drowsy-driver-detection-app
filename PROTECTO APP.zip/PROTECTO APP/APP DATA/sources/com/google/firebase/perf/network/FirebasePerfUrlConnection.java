package com.google.firebase.perf.network;

import androidx.annotation.Keep;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import javax.net.ssl.HttpsURLConnection;
import p002b.p011c.p015b.p028b.p068i.p074f.C2101k0;
import p002b.p011c.p015b.p028b.p068i.p074f.C2237z0;
import p002b.p011c.p110d.p117i.p118e.p121k.C4102r0;
import p002b.p011c.p110d.p159r.p160b.C4464e;
import p002b.p011c.p110d.p159r.p162d.C4490c;
import p002b.p011c.p110d.p159r.p162d.C4491d;

public class FirebasePerfUrlConnection {
    @Keep
    public static Object getContent(URL url) {
        C4464e c = C4464e.m13928c();
        C2237z0 z0Var = new C2237z0();
        z0Var.mo5838b();
        long j = z0Var.f12203e;
        C2101k0 k0Var = new C2101k0(c);
        try {
            URLConnection openConnection = url.openConnection();
            if (openConnection instanceof HttpsURLConnection) {
                return new C4490c((HttpsURLConnection) openConnection, z0Var, k0Var).getContent();
            }
            return openConnection instanceof HttpURLConnection ? new C4491d((HttpURLConnection) openConnection, z0Var, k0Var).getContent() : openConnection.getContent();
        } catch (IOException e) {
            k0Var.mo5688h(j);
            k0Var.mo5690j(z0Var.mo5837a());
            k0Var.mo5684d(url.toString());
            C4102r0.m13433H0(k0Var);
            throw e;
        }
    }

    @Keep
    public static Object instrument(Object obj) {
        if (obj instanceof HttpsURLConnection) {
            return new C4490c((HttpsURLConnection) obj, new C2237z0(), new C2101k0(C4464e.m13928c()));
        }
        return obj instanceof HttpURLConnection ? new C4491d((HttpURLConnection) obj, new C2237z0(), new C2101k0(C4464e.m13928c())) : obj;
    }

    @Keep
    public static InputStream openStream(URL url) {
        C4464e c = C4464e.m13928c();
        C2237z0 z0Var = new C2237z0();
        z0Var.mo5838b();
        long j = z0Var.f12203e;
        C2101k0 k0Var = new C2101k0(c);
        try {
            URLConnection openConnection = url.openConnection();
            if (openConnection instanceof HttpsURLConnection) {
                return new C4490c((HttpsURLConnection) openConnection, z0Var, k0Var).getInputStream();
            }
            return openConnection instanceof HttpURLConnection ? new C4491d((HttpURLConnection) openConnection, z0Var, k0Var).getInputStream() : openConnection.getInputStream();
        } catch (IOException e) {
            k0Var.mo5688h(j);
            k0Var.mo5690j(z0Var.mo5837a());
            k0Var.mo5684d(url.toString());
            C4102r0.m13433H0(k0Var);
            throw e;
        }
    }

    @Keep
    public static Object getContent(URL url, Class[] clsArr) {
        C4464e c = C4464e.m13928c();
        C2237z0 z0Var = new C2237z0();
        z0Var.mo5838b();
        long j = z0Var.f12203e;
        C2101k0 k0Var = new C2101k0(c);
        try {
            URLConnection openConnection = url.openConnection();
            if (openConnection instanceof HttpsURLConnection) {
                return new C4490c((HttpsURLConnection) openConnection, z0Var, k0Var).f16774a.mo8982c(clsArr);
            }
            if (openConnection instanceof HttpURLConnection) {
                return new C4491d((HttpURLConnection) openConnection, z0Var, k0Var).f16776a.mo8982c(clsArr);
            }
            return openConnection.getContent(clsArr);
        } catch (IOException e) {
            k0Var.mo5688h(j);
            k0Var.mo5690j(z0Var.mo5837a());
            k0Var.mo5684d(url.toString());
            C4102r0.m13433H0(k0Var);
            throw e;
        }
    }
}
