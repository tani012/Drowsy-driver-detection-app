package com.google.firebase.perf.internal;

import android.annotation.SuppressLint;
import androidx.annotation.Keep;
import java.lang.ref.WeakReference;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import p002b.p011c.p015b.p028b.p068i.p074f.C2070h1;
import p002b.p011c.p110d.p159r.p160b.C4459a;
import p002b.p011c.p110d.p159r.p160b.C4461b;
import p002b.p011c.p110d.p159r.p160b.C4478s;
import p002b.p011c.p110d.p159r.p160b.C4482w;

@Keep
public class SessionManager extends C4461b {
    @SuppressLint({"StaticFieldLeak"})
    public static final SessionManager zzfn = new SessionManager();
    public final GaugeManager zzcq;
    public final C4459a zzdo;
    public final Set<WeakReference<C4482w>> zzfo;
    public C4478s zzfp;

    public SessionManager() {
        this(GaugeManager.zzca(), C4478s.m13942b(), C4459a.m13921f());
    }

    public SessionManager(GaugeManager gaugeManager, C4478s sVar, C4459a aVar) {
        this.zzfo = new HashSet();
        this.zzcq = gaugeManager;
        this.zzfp = sVar;
        this.zzdo = aVar;
        zzbr();
    }

    public static SessionManager zzco() {
        return zzfn;
    }

    private final void zzd(C2070h1 h1Var) {
        C4478s sVar = this.zzfp;
        if (sVar.f16741f) {
            this.zzcq.zza(sVar, h1Var);
        } else {
            this.zzcq.zzcb();
        }
    }

    public final void zzb(C2070h1 h1Var) {
        super.zzb(h1Var);
        if (!this.zzdo.f16682j) {
            if (h1Var == C2070h1.FOREGROUND) {
                zzc(h1Var);
            } else if (!zzcq()) {
                zzd(h1Var);
            }
        }
    }

    public final void zzc(C2070h1 h1Var) {
        synchronized (this.zzfo) {
            this.zzfp = C4478s.m13942b();
            Iterator<WeakReference<C4482w>> it = this.zzfo.iterator();
            while (it.hasNext()) {
                C4482w wVar = (C4482w) it.next().get();
                if (wVar != null) {
                    wVar.mo5681a(this.zzfp);
                } else {
                    it.remove();
                }
            }
        }
        C4478s sVar = this.zzfp;
        if (sVar.f16741f) {
            this.zzcq.zzb(sVar.f16740e, h1Var);
        }
        zzd(h1Var);
    }

    public final void zzc(WeakReference<C4482w> weakReference) {
        synchronized (this.zzfo) {
            this.zzfo.add(weakReference);
        }
    }

    public final C4478s zzcp() {
        return this.zzfp;
    }

    /* JADX WARNING: Removed duplicated region for block: B:33:0x00ae  */
    /* JADX WARNING: Removed duplicated region for block: B:34:0x00b0  */
    /* JADX WARNING: Removed duplicated region for block: B:36:0x00b3  */
    /* JADX WARNING: Removed duplicated region for block: B:38:0x00bb A[RETURN] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final boolean zzcq() {
        /*
            r8 = this;
            b.c.d.r.b.s r0 = r8.zzfp
            r1 = 0
            if (r0 == 0) goto L_0x00bf
            java.util.concurrent.TimeUnit r2 = java.util.concurrent.TimeUnit.MICROSECONDS
            b.c.b.b.i.f.z0 r0 = r0.f16742g
            long r3 = r0.mo5837a()
            long r2 = r2.toMinutes(r3)
            b.c.b.b.i.f.j r0 = p002b.p011c.p015b.p028b.p068i.p074f.C2091j.m9275q()
            b.c.b.b.i.f.l0 r4 = r0.f11946d
            java.lang.String r5 = "Retrieving Max Duration (in minutes) of single Session configuration value."
            boolean r4 = r4.f11969a
            if (r4 == 0) goto L_0x0022
            java.lang.String r4 = "FirebasePerformance"
            android.util.Log.d(r4, r5)
        L_0x0022:
            java.lang.Class<b.c.b.b.i.f.u> r4 = p002b.p011c.p015b.p028b.p068i.p074f.C2191u.class
            monitor-enter(r4)
            b.c.b.b.i.f.u r5 = p002b.p011c.p015b.p028b.p068i.p074f.C2191u.f12159a     // Catch:{ all -> 0x00bc }
            if (r5 != 0) goto L_0x0030
            b.c.b.b.i.f.u r5 = new b.c.b.b.i.f.u     // Catch:{ all -> 0x00bc }
            r5.<init>()     // Catch:{ all -> 0x00bc }
            p002b.p011c.p015b.p028b.p068i.p074f.C2191u.f12159a = r5     // Catch:{ all -> 0x00bc }
        L_0x0030:
            b.c.b.b.i.f.u r5 = p002b.p011c.p015b.p028b.p068i.p074f.C2191u.f12159a     // Catch:{ all -> 0x00bc }
            monitor-exit(r4)
            b.c.b.b.i.f.q0 r4 = r0.mo5667f(r5)
            boolean r6 = r4.mo5755b()
            if (r6 == 0) goto L_0x004e
            java.lang.Object r6 = r4.mo5754a()
            java.lang.Long r6 = (java.lang.Long) r6
            long r6 = r6.longValue()
            boolean r6 = p002b.p011c.p015b.p028b.p068i.p074f.C2091j.m9274m(r6)
            if (r6 == 0) goto L_0x004e
            goto L_0x0097
        L_0x004e:
            b.c.b.b.i.f.q0 r4 = r0.mo5670j(r5)
            boolean r6 = r4.mo5755b()
            if (r6 == 0) goto L_0x007d
            java.lang.Object r6 = r4.mo5754a()
            java.lang.Long r6 = (java.lang.Long) r6
            long r6 = r6.longValue()
            boolean r6 = p002b.p011c.p015b.p028b.p068i.p074f.C2091j.m9274m(r6)
            if (r6 == 0) goto L_0x007d
            b.c.b.b.i.f.c0 r0 = r0.f11945c
            if (r5 == 0) goto L_0x007c
            java.lang.String r1 = "com.google.firebase.perf.SessionsMaxDurationMinutes"
            java.lang.Object r5 = r4.mo5754a()
            java.lang.Long r5 = (java.lang.Long) r5
            long r5 = r5.longValue()
            r0.mo5497b(r1, r5)
            goto L_0x0097
        L_0x007c:
            throw r1
        L_0x007d:
            b.c.b.b.i.f.q0 r4 = r0.mo5672n(r5)
            boolean r0 = r4.mo5755b()
            if (r0 == 0) goto L_0x009e
            java.lang.Object r0 = r4.mo5754a()
            java.lang.Long r0 = (java.lang.Long) r0
            long r0 = r0.longValue()
            boolean r0 = p002b.p011c.p015b.p028b.p068i.p074f.C2091j.m9274m(r0)
            if (r0 == 0) goto L_0x009e
        L_0x0097:
            java.lang.Object r0 = r4.mo5754a()
            java.lang.Long r0 = (java.lang.Long) r0
            goto L_0x00a4
        L_0x009e:
            r0 = 240(0xf0, double:1.186E-321)
            java.lang.Long r0 = java.lang.Long.valueOf(r0)
        L_0x00a4:
            long r0 = r0.longValue()
            int r0 = (r2 > r0 ? 1 : (r2 == r0 ? 0 : -1))
            r1 = 1
            r2 = 0
            if (r0 <= 0) goto L_0x00b0
            r0 = r1
            goto L_0x00b1
        L_0x00b0:
            r0 = r2
        L_0x00b1:
            if (r0 == 0) goto L_0x00bb
            b.c.d.r.b.a r0 = r8.zzdo
            b.c.b.b.i.f.h1 r0 = r0.f16688p
            r8.zzc((p002b.p011c.p015b.p028b.p068i.p074f.C2070h1) r0)
            return r1
        L_0x00bb:
            return r2
        L_0x00bc:
            r0 = move-exception
            monitor-exit(r4)
            throw r0
        L_0x00bf:
            throw r1
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.firebase.perf.internal.SessionManager.zzcq():boolean");
    }

    public final void zzd(WeakReference<C4482w> weakReference) {
        synchronized (this.zzfo) {
            this.zzfo.remove(weakReference);
        }
    }
}
