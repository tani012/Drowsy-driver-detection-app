package com.google.firebase.perf.metrics;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.os.Bundle;
import androidx.annotation.Keep;
import java.util.concurrent.TimeUnit;
import p002b.p011c.p015b.p028b.p068i.p074f.C2127n0;
import p002b.p011c.p015b.p028b.p068i.p074f.C2237z0;
import p002b.p011c.p110d.p159r.p160b.C4464e;

public class AppStartTrace implements Application.ActivityLifecycleCallbacks {

    /* renamed from: m */
    public static final long f17518m = TimeUnit.MINUTES.toMicros(1);

    /* renamed from: n */
    public static volatile AppStartTrace f17519n;

    /* renamed from: e */
    public boolean f17520e = false;

    /* renamed from: f */
    public C4464e f17521f = null;

    /* renamed from: g */
    public Context f17522g;

    /* renamed from: h */
    public boolean f17523h = false;

    /* renamed from: i */
    public C2237z0 f17524i = null;

    /* renamed from: j */
    public C2237z0 f17525j = null;

    /* renamed from: k */
    public C2237z0 f17526k = null;

    /* renamed from: l */
    public boolean f17527l = false;

    /* renamed from: com.google.firebase.perf.metrics.AppStartTrace$a */
    public static class C4812a implements Runnable {

        /* renamed from: e */
        public final AppStartTrace f17528e;

        public C4812a(AppStartTrace appStartTrace) {
            this.f17528e = appStartTrace;
        }

        public final void run() {
            AppStartTrace appStartTrace = this.f17528e;
            if (appStartTrace.f17524i == null) {
                appStartTrace.f17527l = true;
            }
        }
    }

    public AppStartTrace(C2127n0 n0Var) {
    }

    @Keep
    public static void setLauncherActivityOnCreateTime(String str) {
    }

    @Keep
    public static void setLauncherActivityOnResumeTime(String str) {
    }

    @Keep
    public static void setLauncherActivityOnStartTime(String str) {
    }

    /* JADX WARNING: Code restructure failed: missing block: B:11:0x002a, code lost:
        return;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:13:0x002c, code lost:
        return;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public synchronized void onActivityCreated(android.app.Activity r3, android.os.Bundle r4) {
        /*
            r2 = this;
            monitor-enter(r2)
            boolean r4 = r2.f17527l     // Catch:{ all -> 0x002d }
            if (r4 != 0) goto L_0x002b
            b.c.b.b.i.f.z0 r4 = r2.f17524i     // Catch:{ all -> 0x002d }
            if (r4 == 0) goto L_0x000a
            goto L_0x002b
        L_0x000a:
            java.lang.ref.WeakReference r4 = new java.lang.ref.WeakReference     // Catch:{ all -> 0x002d }
            r4.<init>(r3)     // Catch:{ all -> 0x002d }
            b.c.b.b.i.f.z0 r3 = new b.c.b.b.i.f.z0     // Catch:{ all -> 0x002d }
            r3.<init>()     // Catch:{ all -> 0x002d }
            r2.f17524i = r3     // Catch:{ all -> 0x002d }
            b.c.b.b.i.f.z0 r3 = com.google.firebase.perf.provider.FirebasePerfProvider.zzdb()     // Catch:{ all -> 0x002d }
            b.c.b.b.i.f.z0 r4 = r2.f17524i     // Catch:{ all -> 0x002d }
            long r3 = r3.mo5839c(r4)     // Catch:{ all -> 0x002d }
            long r0 = f17518m     // Catch:{ all -> 0x002d }
            int r3 = (r3 > r0 ? 1 : (r3 == r0 ? 0 : -1))
            if (r3 <= 0) goto L_0x0029
            r3 = 1
            r2.f17523h = r3     // Catch:{ all -> 0x002d }
        L_0x0029:
            monitor-exit(r2)
            return
        L_0x002b:
            monitor-exit(r2)
            return
        L_0x002d:
            r3 = move-exception
            monitor-exit(r2)
            throw r3
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.firebase.perf.metrics.AppStartTrace.onActivityCreated(android.app.Activity, android.os.Bundle):void");
    }

    public void onActivityDestroyed(Activity activity) {
    }

    public void onActivityPaused(Activity activity) {
    }

    /*  JADX ERROR: IndexOutOfBoundsException in pass: RegionMakerVisitor
        java.lang.IndexOutOfBoundsException: Index 0 out of bounds for length 0
        	at java.base/jdk.internal.util.Preconditions.outOfBounds(Preconditions.java:64)
        	at java.base/jdk.internal.util.Preconditions.outOfBoundsCheckIndex(Preconditions.java:70)
        	at java.base/jdk.internal.util.Preconditions.checkIndex(Preconditions.java:248)
        	at java.base/java.util.Objects.checkIndex(Objects.java:372)
        	at java.base/java.util.ArrayList.get(ArrayList.java:458)
        	at jadx.core.dex.nodes.InsnNode.getArg(InsnNode.java:101)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:611)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.processMonitorEnter(RegionMaker.java:561)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverse(RegionMaker.java:133)
        	at jadx.core.dex.visitors.regions.RegionMaker.makeRegion(RegionMaker.java:86)
        	at jadx.core.dex.visitors.regions.RegionMaker.processIf(RegionMaker.java:693)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverse(RegionMaker.java:123)
        	at jadx.core.dex.visitors.regions.RegionMaker.makeRegion(RegionMaker.java:86)
        	at jadx.core.dex.visitors.regions.RegionMaker.processIf(RegionMaker.java:698)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverse(RegionMaker.java:123)
        	at jadx.core.dex.visitors.regions.RegionMaker.makeRegion(RegionMaker.java:86)
        	at jadx.core.dex.visitors.regions.RegionMaker.processIf(RegionMaker.java:693)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverse(RegionMaker.java:123)
        	at jadx.core.dex.visitors.regions.RegionMaker.makeRegion(RegionMaker.java:86)
        	at jadx.core.dex.visitors.regions.RegionMaker.processMonitorEnter(RegionMaker.java:598)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverse(RegionMaker.java:133)
        	at jadx.core.dex.visitors.regions.RegionMaker.makeRegion(RegionMaker.java:86)
        	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:49)
        */
    public synchronized void onActivityResumed(android.app.Activity r7) {
        /*
            r6 = this;
            monitor-enter(r6)
            boolean r0 = r6.f17527l     // Catch:{ all -> 0x0161 }
            if (r0 != 0) goto L_0x015f
            b.c.b.b.i.f.z0 r0 = r6.f17526k     // Catch:{ all -> 0x0161 }
            if (r0 != 0) goto L_0x015f
            boolean r0 = r6.f17523h     // Catch:{ all -> 0x0161 }
            if (r0 == 0) goto L_0x000f
            goto L_0x015f
        L_0x000f:
            java.lang.ref.WeakReference r0 = new java.lang.ref.WeakReference     // Catch:{ all -> 0x0161 }
            r0.<init>(r7)     // Catch:{ all -> 0x0161 }
            b.c.b.b.i.f.z0 r0 = new b.c.b.b.i.f.z0     // Catch:{ all -> 0x0161 }
            r0.<init>()     // Catch:{ all -> 0x0161 }
            r6.f17526k = r0     // Catch:{ all -> 0x0161 }
            b.c.b.b.i.f.z0 r0 = com.google.firebase.perf.provider.FirebasePerfProvider.zzdb()     // Catch:{ all -> 0x0161 }
            b.c.b.b.i.f.l0 r1 = p002b.p011c.p015b.p028b.p068i.p074f.C2111l0.m9323a()     // Catch:{ all -> 0x0161 }
            java.lang.Class r7 = r7.getClass()     // Catch:{ all -> 0x0161 }
            java.lang.String r7 = r7.getName()     // Catch:{ all -> 0x0161 }
            b.c.b.b.i.f.z0 r2 = r6.f17526k     // Catch:{ all -> 0x0161 }
            long r2 = r0.mo5839c(r2)     // Catch:{ all -> 0x0161 }
            int r4 = r7.length()     // Catch:{ all -> 0x0161 }
            int r4 = r4 + 47
            java.lang.StringBuilder r5 = new java.lang.StringBuilder     // Catch:{ all -> 0x0161 }
            r5.<init>(r4)     // Catch:{ all -> 0x0161 }
            java.lang.String r4 = "onResume(): "
            r5.append(r4)     // Catch:{ all -> 0x0161 }
            r5.append(r7)     // Catch:{ all -> 0x0161 }
            java.lang.String r7 = ": "
            r5.append(r7)     // Catch:{ all -> 0x0161 }
            r5.append(r2)     // Catch:{ all -> 0x0161 }
            java.lang.String r7 = " microseconds"
            r5.append(r7)     // Catch:{ all -> 0x0161 }
            java.lang.String r7 = r5.toString()     // Catch:{ all -> 0x0161 }
            r1.mo5703b(r7)     // Catch:{ all -> 0x0161 }
            b.c.b.b.i.f.e2$a r7 = p002b.p011c.p015b.p028b.p068i.p074f.C2039e2.m9124q()     // Catch:{ all -> 0x0161 }
            b.c.b.b.i.f.o0 r1 = p002b.p011c.p015b.p028b.p068i.p074f.C2136o0.APP_START_TRACE_NAME     // Catch:{ all -> 0x0161 }
            java.lang.String r1 = r1.f12052e     // Catch:{ all -> 0x0161 }
            r7.mo5572l(r1)     // Catch:{ all -> 0x0161 }
            long r1 = r0.f12203e     // Catch:{ all -> 0x0161 }
            r7.mo5573m(r1)     // Catch:{ all -> 0x0161 }
            b.c.b.b.i.f.z0 r1 = r6.f17526k     // Catch:{ all -> 0x0161 }
            long r1 = r0.mo5839c(r1)     // Catch:{ all -> 0x0161 }
            r7.mo5574n(r1)     // Catch:{ all -> 0x0161 }
            java.util.ArrayList r1 = new java.util.ArrayList     // Catch:{ all -> 0x0161 }
            r2 = 3
            r1.<init>(r2)     // Catch:{ all -> 0x0161 }
            b.c.b.b.i.f.e2$a r2 = p002b.p011c.p015b.p028b.p068i.p074f.C2039e2.m9124q()     // Catch:{ all -> 0x0161 }
            b.c.b.b.i.f.o0 r3 = p002b.p011c.p015b.p028b.p068i.p074f.C2136o0.ON_CREATE_TRACE_NAME     // Catch:{ all -> 0x0161 }
            java.lang.String r3 = r3.f12052e     // Catch:{ all -> 0x0161 }
            r2.mo5572l(r3)     // Catch:{ all -> 0x0161 }
            long r3 = r0.f12203e     // Catch:{ all -> 0x0161 }
            r2.mo5573m(r3)     // Catch:{ all -> 0x0161 }
            b.c.b.b.i.f.z0 r3 = r6.f17524i     // Catch:{ all -> 0x0161 }
            long r3 = r0.mo5839c(r3)     // Catch:{ all -> 0x0161 }
            r2.mo5574n(r3)     // Catch:{ all -> 0x0161 }
            b.c.b.b.i.f.a5 r0 = r2.mo5765k()     // Catch:{ all -> 0x0161 }
            b.c.b.b.i.f.q3 r0 = (p002b.p011c.p015b.p028b.p068i.p074f.C2156q3) r0     // Catch:{ all -> 0x0161 }
            b.c.b.b.i.f.e2 r0 = (p002b.p011c.p015b.p028b.p068i.p074f.C2039e2) r0     // Catch:{ all -> 0x0161 }
            r1.add(r0)     // Catch:{ all -> 0x0161 }
            b.c.b.b.i.f.e2$a r0 = p002b.p011c.p015b.p028b.p068i.p074f.C2039e2.m9124q()     // Catch:{ all -> 0x0161 }
            b.c.b.b.i.f.o0 r2 = p002b.p011c.p015b.p028b.p068i.p074f.C2136o0.ON_START_TRACE_NAME     // Catch:{ all -> 0x0161 }
            java.lang.String r2 = r2.f12052e     // Catch:{ all -> 0x0161 }
            r0.mo5572l(r2)     // Catch:{ all -> 0x0161 }
            b.c.b.b.i.f.z0 r2 = r6.f17524i     // Catch:{ all -> 0x0161 }
            long r2 = r2.f12203e     // Catch:{ all -> 0x0161 }
            r0.mo5573m(r2)     // Catch:{ all -> 0x0161 }
            b.c.b.b.i.f.z0 r2 = r6.f17524i     // Catch:{ all -> 0x0161 }
            b.c.b.b.i.f.z0 r3 = r6.f17525j     // Catch:{ all -> 0x0161 }
            long r2 = r2.mo5839c(r3)     // Catch:{ all -> 0x0161 }
            r0.mo5574n(r2)     // Catch:{ all -> 0x0161 }
            b.c.b.b.i.f.a5 r0 = r0.mo5765k()     // Catch:{ all -> 0x0161 }
            b.c.b.b.i.f.q3 r0 = (p002b.p011c.p015b.p028b.p068i.p074f.C2156q3) r0     // Catch:{ all -> 0x0161 }
            b.c.b.b.i.f.e2 r0 = (p002b.p011c.p015b.p028b.p068i.p074f.C2039e2) r0     // Catch:{ all -> 0x0161 }
            r1.add(r0)     // Catch:{ all -> 0x0161 }
            b.c.b.b.i.f.e2$a r0 = p002b.p011c.p015b.p028b.p068i.p074f.C2039e2.m9124q()     // Catch:{ all -> 0x0161 }
            b.c.b.b.i.f.o0 r2 = p002b.p011c.p015b.p028b.p068i.p074f.C2136o0.ON_RESUME_TRACE_NAME     // Catch:{ all -> 0x0161 }
            java.lang.String r2 = r2.f12052e     // Catch:{ all -> 0x0161 }
            r0.mo5572l(r2)     // Catch:{ all -> 0x0161 }
            b.c.b.b.i.f.z0 r2 = r6.f17525j     // Catch:{ all -> 0x0161 }
            long r2 = r2.f12203e     // Catch:{ all -> 0x0161 }
            r0.mo5573m(r2)     // Catch:{ all -> 0x0161 }
            b.c.b.b.i.f.z0 r2 = r6.f17525j     // Catch:{ all -> 0x0161 }
            b.c.b.b.i.f.z0 r3 = r6.f17526k     // Catch:{ all -> 0x0161 }
            long r2 = r2.mo5839c(r3)     // Catch:{ all -> 0x0161 }
            r0.mo5574n(r2)     // Catch:{ all -> 0x0161 }
            b.c.b.b.i.f.a5 r0 = r0.mo5765k()     // Catch:{ all -> 0x0161 }
            b.c.b.b.i.f.q3 r0 = (p002b.p011c.p015b.p028b.p068i.p074f.C2156q3) r0     // Catch:{ all -> 0x0161 }
            b.c.b.b.i.f.e2 r0 = (p002b.p011c.p015b.p028b.p068i.p074f.C2039e2) r0     // Catch:{ all -> 0x0161 }
            r1.add(r0)     // Catch:{ all -> 0x0161 }
            boolean r0 = r7.f12103g     // Catch:{ all -> 0x0161 }
            r2 = 0
            if (r0 == 0) goto L_0x00f5
            r7.mo5763i()     // Catch:{ all -> 0x0161 }
            r7.f12103g = r2     // Catch:{ all -> 0x0161 }
        L_0x00f5:
            MessageType r0 = r7.f12102f     // Catch:{ all -> 0x0161 }
            b.c.b.b.i.f.e2 r0 = (p002b.p011c.p015b.p028b.p068i.p074f.C2039e2) r0     // Catch:{ all -> 0x0161 }
            b.c.b.b.i.f.w3<b.c.b.b.i.f.e2> r3 = r0.zzmi     // Catch:{ all -> 0x0161 }
            boolean r4 = r3.mo5770o0()     // Catch:{ all -> 0x0161 }
            if (r4 != 0) goto L_0x0107
            b.c.b.b.i.f.w3 r3 = p002b.p011c.p015b.p028b.p068i.p074f.C2156q3.m9394h(r3)     // Catch:{ all -> 0x0161 }
            r0.zzmi = r3     // Catch:{ all -> 0x0161 }
        L_0x0107:
            b.c.b.b.i.f.w3<b.c.b.b.i.f.e2> r0 = r0.zzmi     // Catch:{ all -> 0x0161 }
            p002b.p011c.p015b.p028b.p068i.p074f.C2139o2.m9358a(r1, r0)     // Catch:{ all -> 0x0161 }
            com.google.firebase.perf.internal.SessionManager r0 = com.google.firebase.perf.internal.SessionManager.zzco()     // Catch:{ all -> 0x0161 }
            b.c.d.r.b.s r0 = r0.zzcp()     // Catch:{ all -> 0x0161 }
            b.c.b.b.i.f.a2 r0 = r0.mo8831c()     // Catch:{ all -> 0x0161 }
            boolean r1 = r7.f12103g     // Catch:{ all -> 0x0161 }
            if (r1 == 0) goto L_0x0121
            r7.mo5763i()     // Catch:{ all -> 0x0161 }
            r7.f12103g = r2     // Catch:{ all -> 0x0161 }
        L_0x0121:
            MessageType r1 = r7.f12102f     // Catch:{ all -> 0x0161 }
            b.c.b.b.i.f.e2 r1 = (p002b.p011c.p015b.p028b.p068i.p074f.C2039e2) r1     // Catch:{ all -> 0x0161 }
            p002b.p011c.p015b.p028b.p068i.p074f.C2039e2.m9121m(r1, r0)     // Catch:{ all -> 0x0161 }
            b.c.d.r.b.e r0 = r6.f17521f     // Catch:{ all -> 0x0161 }
            if (r0 != 0) goto L_0x0132
            b.c.d.r.b.e r0 = p002b.p011c.p110d.p159r.p160b.C4464e.m13928c()     // Catch:{ all -> 0x0161 }
            r6.f17521f = r0     // Catch:{ all -> 0x0161 }
        L_0x0132:
            b.c.d.r.b.e r0 = r6.f17521f     // Catch:{ all -> 0x0161 }
            if (r0 == 0) goto L_0x0145
            b.c.d.r.b.e r0 = r6.f17521f     // Catch:{ all -> 0x0161 }
            b.c.b.b.i.f.a5 r7 = r7.mo5765k()     // Catch:{ all -> 0x0161 }
            b.c.b.b.i.f.q3 r7 = (p002b.p011c.p015b.p028b.p068i.p074f.C2156q3) r7     // Catch:{ all -> 0x0161 }
            b.c.b.b.i.f.e2 r7 = (p002b.p011c.p015b.p028b.p068i.p074f.C2039e2) r7     // Catch:{ all -> 0x0161 }
            b.c.b.b.i.f.h1 r1 = p002b.p011c.p015b.p028b.p068i.p074f.C2070h1.FOREGROUND_BACKGROUND     // Catch:{ all -> 0x0161 }
            r0.mo8818b(r7, r1)     // Catch:{ all -> 0x0161 }
        L_0x0145:
            boolean r7 = r6.f17520e     // Catch:{ all -> 0x0161 }
            if (r7 == 0) goto L_0x015d
            monitor-enter(r6)     // Catch:{ all -> 0x0161 }
            boolean r7 = r6.f17520e     // Catch:{ all -> 0x015a }
            if (r7 != 0) goto L_0x014f
            goto L_0x0158
        L_0x014f:
            android.content.Context r7 = r6.f17522g     // Catch:{ all -> 0x015a }
            android.app.Application r7 = (android.app.Application) r7     // Catch:{ all -> 0x015a }
            r7.unregisterActivityLifecycleCallbacks(r6)     // Catch:{ all -> 0x015a }
            r6.f17520e = r2     // Catch:{ all -> 0x015a }
        L_0x0158:
            monitor-exit(r6)     // Catch:{ all -> 0x0161 }
            goto L_0x015d
        L_0x015a:
            r7 = move-exception
            monitor-exit(r6)     // Catch:{ all -> 0x0161 }
            throw r7     // Catch:{ all -> 0x0161 }
        L_0x015d:
            monitor-exit(r6)
            return
        L_0x015f:
            monitor-exit(r6)
            return
        L_0x0161:
            r7 = move-exception
            monitor-exit(r6)
            throw r7
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.firebase.perf.metrics.AppStartTrace.onActivityResumed(android.app.Activity):void");
    }

    public void onActivitySaveInstanceState(Activity activity, Bundle bundle) {
    }

    /* JADX WARNING: Code restructure failed: missing block: B:13:0x0018, code lost:
        return;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public synchronized void onActivityStarted(android.app.Activity r1) {
        /*
            r0 = this;
            monitor-enter(r0)
            boolean r1 = r0.f17527l     // Catch:{ all -> 0x0019 }
            if (r1 != 0) goto L_0x0017
            b.c.b.b.i.f.z0 r1 = r0.f17525j     // Catch:{ all -> 0x0019 }
            if (r1 != 0) goto L_0x0017
            boolean r1 = r0.f17523h     // Catch:{ all -> 0x0019 }
            if (r1 == 0) goto L_0x000e
            goto L_0x0017
        L_0x000e:
            b.c.b.b.i.f.z0 r1 = new b.c.b.b.i.f.z0     // Catch:{ all -> 0x0019 }
            r1.<init>()     // Catch:{ all -> 0x0019 }
            r0.f17525j = r1     // Catch:{ all -> 0x0019 }
            monitor-exit(r0)
            return
        L_0x0017:
            monitor-exit(r0)
            return
        L_0x0019:
            r1 = move-exception
            monitor-exit(r0)
            throw r1
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.firebase.perf.metrics.AppStartTrace.onActivityStarted(android.app.Activity):void");
    }

    public synchronized void onActivityStopped(Activity activity) {
    }
}
