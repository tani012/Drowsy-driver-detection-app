package com.google.firebase.remoteconfig;

import android.content.Context;
import androidx.annotation.Keep;
import java.util.Arrays;
import java.util.List;
import p002b.p011c.p110d.C3976c;
import p002b.p011c.p110d.p111f.C3986c;
import p002b.p011c.p110d.p111f.p112d.C3987a;
import p002b.p011c.p110d.p113g.p114a.C3989a;
import p002b.p011c.p110d.p116h.C4007d;
import p002b.p011c.p110d.p116h.C4010e;
import p002b.p011c.p110d.p116h.C4014i;
import p002b.p011c.p110d.p116h.C4022q;
import p002b.p011c.p110d.p117i.p118e.p121k.C4102r0;
import p002b.p011c.p110d.p145o.C4404g;
import p002b.p011c.p110d.p164t.C4514m;
import p002b.p011c.p110d.p164t.C4515n;

@Keep
public class RemoteConfigRegistrar implements C4014i {
    public static C4514m lambda$getComponents$0(C4010e eVar) {
        C3986c cVar;
        Context context = (Context) eVar.mo8352a(Context.class);
        C3976c cVar2 = (C3976c) eVar.mo8352a(C3976c.class);
        C4404g gVar = (C4404g) eVar.mo8352a(C4404g.class);
        C3987a aVar = (C3987a) eVar.mo8352a(C3987a.class);
        synchronized (aVar) {
            if (!aVar.f15716a.containsKey("frc")) {
                aVar.f15716a.put("frc", new C3986c(aVar.f15718c, "frc"));
            }
            cVar = aVar.f15716a.get("frc");
        }
        return new C4514m(context, cVar2, gVar, cVar, (C3989a) eVar.mo8352a(C3989a.class));
    }

    public List<C4007d<?>> getComponents() {
        C4007d.C4009b<C4514m> a = C4007d.m13290a(C4514m.class);
        a.mo8356a(C4022q.m13308c(Context.class));
        a.mo8356a(C4022q.m13308c(C3976c.class));
        a.mo8356a(C4022q.m13308c(C4404g.class));
        a.mo8356a(C4022q.m13308c(C3987a.class));
        a.mo8356a(C4022q.m13307b(C3989a.class));
        a.mo8358c(C4515n.f16826a);
        a.mo8359d(2);
        return Arrays.asList(new C4007d[]{a.mo8357b(), C4102r0.m13482p("fire-rc", "19.2.0")});
    }
}
