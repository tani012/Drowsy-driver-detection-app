package com.google.firebase.remoteconfig.internal;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Build;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.TimeZone;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.json.JSONObject;
import p002b.p011c.p110d.p164t.C4507f;
import p002b.p011c.p110d.p164t.C4508g;

public class ConfigFetchHttpClient {

    /* renamed from: h */
    public static final Pattern f17541h = Pattern.compile("^[^:]+:([0-9]+):(android|ios|web):([0-9a-f]+)");

    /* renamed from: a */
    public final Context f17542a;

    /* renamed from: b */
    public final String f17543b;

    /* renamed from: c */
    public final String f17544c;

    /* renamed from: d */
    public final String f17545d;

    /* renamed from: e */
    public final String f17546e;

    /* renamed from: f */
    public final long f17547f;

    /* renamed from: g */
    public final long f17548g;

    public ConfigFetchHttpClient(Context context, String str, String str2, String str3, long j, long j2) {
        this.f17542a = context;
        this.f17543b = str;
        this.f17544c = str2;
        Matcher matcher = f17541h.matcher(str);
        this.f17545d = matcher.matches() ? matcher.group(1) : null;
        this.f17546e = str3;
        this.f17547f = j;
        this.f17548g = j2;
    }

    /* renamed from: a */
    public final JSONObject mo9819a(String str, String str2, Map<String, String> map) {
        HashMap hashMap = new HashMap();
        if (str != null) {
            hashMap.put("appInstanceId", str);
            hashMap.put("appInstanceIdToken", str2);
            hashMap.put("appId", this.f17543b);
            Locale locale = this.f17542a.getResources().getConfiguration().locale;
            hashMap.put("countryCode", locale.getCountry());
            hashMap.put("languageCode", locale.toLanguageTag());
            hashMap.put("platformVersion", Integer.toString(Build.VERSION.SDK_INT));
            hashMap.put("timeZone", TimeZone.getDefault().getID());
            try {
                PackageInfo packageInfo = this.f17542a.getPackageManager().getPackageInfo(this.f17542a.getPackageName(), 0);
                if (packageInfo != null) {
                    hashMap.put("appVersion", packageInfo.versionName);
                }
            } catch (PackageManager.NameNotFoundException unused) {
            }
            hashMap.put("packageName", this.f17542a.getPackageName());
            hashMap.put("sdkVersion", "19.2.0");
            hashMap.put("analyticsUserProperties", new JSONObject(map));
            return new JSONObject(hashMap);
        }
        throw new C4507f("Fetch failed: Firebase installation id is null.");
    }

    /* renamed from: b */
    public HttpURLConnection mo9820b() {
        try {
            return (HttpURLConnection) new URL(String.format("https://firebaseremoteconfig.googleapis.com/v1/projects/%s/namespaces/%s:fetch", new Object[]{this.f17545d, this.f17546e})).openConnection();
        } catch (IOException e) {
            throw new C4508g(e.getMessage());
        }
    }

    /* renamed from: c */
    public final JSONObject mo9821c(URLConnection uRLConnection) {
        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(uRLConnection.getInputStream(), "utf-8"));
        StringBuilder sb = new StringBuilder();
        while (true) {
            int read = bufferedReader.read();
            if (read == -1) {
                return new JSONObject(sb.toString());
            }
            sb.append((char) read);
        }
    }

    /* renamed from: d */
    public final void mo9822d(HttpURLConnection httpURLConnection, byte[] bArr) {
        httpURLConnection.setFixedLengthStreamingMode(bArr.length);
        BufferedOutputStream bufferedOutputStream = new BufferedOutputStream(httpURLConnection.getOutputStream());
        bufferedOutputStream.write(bArr);
        bufferedOutputStream.flush();
        bufferedOutputStream.close();
    }

    /* JADX WARNING: Can't wrap try/catch for region: R(13:30|31|32|33|34|(2:38|39)|40|(2:42|43)|(2:46|47)|48|49|50|51) */
    /* JADX WARNING: Missing exception handler attribute for start block: B:48:0x0133 */
    /* JADX WARNING: Removed duplicated region for block: B:12:0x00a8 A[LOOP:0: B:10:0x00a2->B:12:0x00a8, LOOP_END] */
    /* JADX WARNING: Removed duplicated region for block: B:16:0x00da A[Catch:{ IOException | JSONException -> 0x015b, all -> 0x0159 }] */
    /* JADX WARNING: Removed duplicated region for block: B:55:0x014f A[SYNTHETIC, Splitter:B:55:0x014f] */
    @androidx.annotation.Keep
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public p002b.p011c.p110d.p164t.p165o.C4530k.C4531a fetch(java.net.HttpURLConnection r7, java.lang.String r8, java.lang.String r9, java.util.Map<java.lang.String, java.lang.String> r10, java.lang.String r11, java.util.Map<java.lang.String, java.lang.String> r12, java.util.Date r13) {
        /*
            r6 = this;
            r0 = 1
            r7.setDoOutput(r0)
            java.util.concurrent.TimeUnit r1 = java.util.concurrent.TimeUnit.SECONDS
            long r2 = r6.f17547f
            long r1 = r1.toMillis(r2)
            int r1 = (int) r1
            r7.setConnectTimeout(r1)
            java.util.concurrent.TimeUnit r1 = java.util.concurrent.TimeUnit.SECONDS
            long r2 = r6.f17548g
            long r1 = r1.toMillis(r2)
            int r1 = (int) r1
            r7.setReadTimeout(r1)
            java.lang.String r1 = "If-None-Match"
            r7.setRequestProperty(r1, r11)
            java.lang.String r11 = r6.f17544c
            java.lang.String r1 = "X-Goog-Api-Key"
            r7.setRequestProperty(r1, r11)
            android.content.Context r11 = r6.f17542a
            java.lang.String r11 = r11.getPackageName()
            java.lang.String r1 = "X-Android-Package"
            r7.setRequestProperty(r1, r11)
            java.lang.String r11 = "FirebaseRemoteConfig"
            r1 = 0
            r2 = 0
            android.content.Context r3 = r6.f17542a     // Catch:{ NameNotFoundException -> 0x0065 }
            android.content.Context r4 = r6.f17542a     // Catch:{ NameNotFoundException -> 0x0065 }
            java.lang.String r4 = r4.getPackageName()     // Catch:{ NameNotFoundException -> 0x0065 }
            byte[] r3 = p002b.p011c.p015b.p028b.p053e.p061r.C0600a.m880a(r3, r4)     // Catch:{ NameNotFoundException -> 0x0065 }
            if (r3 != 0) goto L_0x0060
            java.lang.StringBuilder r3 = new java.lang.StringBuilder     // Catch:{ NameNotFoundException -> 0x0065 }
            r3.<init>()     // Catch:{ NameNotFoundException -> 0x0065 }
            java.lang.String r4 = "Could not get fingerprint hash for package: "
            r3.append(r4)     // Catch:{ NameNotFoundException -> 0x0065 }
            android.content.Context r4 = r6.f17542a     // Catch:{ NameNotFoundException -> 0x0065 }
            java.lang.String r4 = r4.getPackageName()     // Catch:{ NameNotFoundException -> 0x0065 }
            r3.append(r4)     // Catch:{ NameNotFoundException -> 0x0065 }
            java.lang.String r3 = r3.toString()     // Catch:{ NameNotFoundException -> 0x0065 }
            android.util.Log.e(r11, r3)     // Catch:{ NameNotFoundException -> 0x0065 }
            goto L_0x007c
        L_0x0060:
            java.lang.String r11 = p002b.p011c.p015b.p028b.p053e.p061r.C0604e.m890b(r3, r1)     // Catch:{ NameNotFoundException -> 0x0065 }
            goto L_0x007d
        L_0x0065:
            r3 = move-exception
            java.lang.String r4 = "No such package: "
            java.lang.StringBuilder r4 = p002b.p008b.p009a.p010a.C0131a.m379m(r4)
            android.content.Context r5 = r6.f17542a
            java.lang.String r5 = r5.getPackageName()
            r4.append(r5)
            java.lang.String r4 = r4.toString()
            android.util.Log.e(r11, r4, r3)
        L_0x007c:
            r11 = r2
        L_0x007d:
            java.lang.String r3 = "X-Android-Cert"
            r7.setRequestProperty(r3, r11)
            java.lang.String r11 = "X-Google-GFE-Can-Retry"
            java.lang.String r3 = "yes"
            r7.setRequestProperty(r11, r3)
            java.lang.String r11 = "X-Goog-Firebase-Installations-Auth"
            r7.setRequestProperty(r11, r9)
            java.lang.String r11 = "application/json"
            java.lang.String r3 = "Content-Type"
            r7.setRequestProperty(r3, r11)
            java.lang.String r3 = "Accept"
            r7.setRequestProperty(r3, r11)
            java.util.Set r11 = r12.entrySet()
            java.util.Iterator r11 = r11.iterator()
        L_0x00a2:
            boolean r12 = r11.hasNext()
            if (r12 == 0) goto L_0x00be
            java.lang.Object r12 = r11.next()
            java.util.Map$Entry r12 = (java.util.Map.Entry) r12
            java.lang.Object r3 = r12.getKey()
            java.lang.String r3 = (java.lang.String) r3
            java.lang.Object r12 = r12.getValue()
            java.lang.String r12 = (java.lang.String) r12
            r7.setRequestProperty(r3, r12)
            goto L_0x00a2
        L_0x00be:
            org.json.JSONObject r8 = r6.mo9819a(r8, r9, r10)     // Catch:{ IOException -> 0x015d, JSONException -> 0x015b }
            java.lang.String r8 = r8.toString()     // Catch:{ IOException -> 0x015d, JSONException -> 0x015b }
            java.lang.String r9 = "utf-8"
            byte[] r8 = r8.getBytes(r9)     // Catch:{ IOException -> 0x015d, JSONException -> 0x015b }
            r6.mo9822d(r7, r8)     // Catch:{ IOException -> 0x015d, JSONException -> 0x015b }
            r7.connect()     // Catch:{ IOException -> 0x015d, JSONException -> 0x015b }
            int r8 = r7.getResponseCode()     // Catch:{ IOException -> 0x015d, JSONException -> 0x015b }
            r9 = 200(0xc8, float:2.8E-43)
            if (r8 != r9) goto L_0x014f
            java.lang.String r8 = "ETag"
            java.lang.String r8 = r7.getHeaderField(r8)     // Catch:{ IOException -> 0x015d, JSONException -> 0x015b }
            org.json.JSONObject r9 = r6.mo9821c(r7)     // Catch:{ IOException -> 0x015d, JSONException -> 0x015b }
            r7.disconnect()
            java.io.InputStream r7 = r7.getInputStream()     // Catch:{ IOException -> 0x00ee }
            r7.close()     // Catch:{ IOException -> 0x00ee }
        L_0x00ee:
            java.lang.String r7 = "state"
            java.lang.Object r7 = r9.get(r7)     // Catch:{ JSONException -> 0x00fc }
            java.lang.String r10 = "NO_CHANGE"
            boolean r7 = r7.equals(r10)     // Catch:{ JSONException -> 0x00fc }
            r7 = r7 ^ r0
            goto L_0x00fd
        L_0x00fc:
            r7 = r0
        L_0x00fd:
            if (r7 != 0) goto L_0x0105
            b.c.d.t.o.k$a r7 = new b.c.d.t.o.k$a
            r7.<init>(r13, r0, r2, r2)
            return r7
        L_0x0105:
            b.c.d.t.o.f$b r7 = p002b.p011c.p110d.p164t.p165o.C4523f.m13995b()     // Catch:{ JSONException -> 0x0146 }
            r7.f16846b = r13     // Catch:{ JSONException -> 0x0146 }
            java.lang.String r10 = "entries"
            org.json.JSONObject r10 = r9.getJSONObject(r10)     // Catch:{ JSONException -> 0x0112 }
            goto L_0x0113
        L_0x0112:
            r10 = r2
        L_0x0113:
            if (r10 == 0) goto L_0x0120
            org.json.JSONObject r11 = new org.json.JSONObject     // Catch:{ JSONException -> 0x0120 }
            java.lang.String r10 = r10.toString()     // Catch:{ JSONException -> 0x0120 }
            r11.<init>(r10)     // Catch:{ JSONException -> 0x0120 }
            r7.f16845a = r11     // Catch:{ JSONException -> 0x0120 }
        L_0x0120:
            java.lang.String r10 = "experimentDescriptions"
            org.json.JSONArray r2 = r9.getJSONArray(r10)     // Catch:{ JSONException -> 0x0126 }
        L_0x0126:
            if (r2 == 0) goto L_0x0133
            org.json.JSONArray r9 = new org.json.JSONArray     // Catch:{ JSONException -> 0x0133 }
            java.lang.String r10 = r2.toString()     // Catch:{ JSONException -> 0x0133 }
            r9.<init>(r10)     // Catch:{ JSONException -> 0x0133 }
            r7.f16847c = r9     // Catch:{ JSONException -> 0x0133 }
        L_0x0133:
            b.c.d.t.o.f r9 = new b.c.d.t.o.f     // Catch:{ JSONException -> 0x0146 }
            org.json.JSONObject r10 = r7.f16845a     // Catch:{ JSONException -> 0x0146 }
            java.util.Date r11 = r7.f16846b     // Catch:{ JSONException -> 0x0146 }
            org.json.JSONArray r7 = r7.f16847c     // Catch:{ JSONException -> 0x0146 }
            r9.<init>(r10, r11, r7)     // Catch:{ JSONException -> 0x0146 }
            b.c.d.t.o.k$a r7 = new b.c.d.t.o.k$a
            java.util.Date r10 = r9.f16843c
            r7.<init>(r10, r1, r9, r8)
            return r7
        L_0x0146:
            r7 = move-exception
            b.c.d.t.f r8 = new b.c.d.t.f
            java.lang.String r9 = "Fetch failed: fetch response could not be parsed."
            r8.<init>(r9, r7)
            throw r8
        L_0x014f:
            b.c.d.t.i r9 = new b.c.d.t.i     // Catch:{ IOException -> 0x015d, JSONException -> 0x015b }
            java.lang.String r10 = r7.getResponseMessage()     // Catch:{ IOException -> 0x015d, JSONException -> 0x015b }
            r9.<init>(r8, r10)     // Catch:{ IOException -> 0x015d, JSONException -> 0x015b }
            throw r9     // Catch:{ IOException -> 0x015d, JSONException -> 0x015b }
        L_0x0159:
            r8 = move-exception
            goto L_0x0166
        L_0x015b:
            r8 = move-exception
            goto L_0x015e
        L_0x015d:
            r8 = move-exception
        L_0x015e:
            b.c.d.t.f r9 = new b.c.d.t.f     // Catch:{ all -> 0x0159 }
            java.lang.String r10 = "The client had an error while calling the backend!"
            r9.<init>(r10, r8)     // Catch:{ all -> 0x0159 }
            throw r9     // Catch:{ all -> 0x0159 }
        L_0x0166:
            r7.disconnect()
            java.io.InputStream r7 = r7.getInputStream()     // Catch:{ IOException -> 0x0170 }
            r7.close()     // Catch:{ IOException -> 0x0170 }
        L_0x0170:
            throw r8
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.firebase.remoteconfig.internal.ConfigFetchHttpClient.fetch(java.net.HttpURLConnection, java.lang.String, java.lang.String, java.util.Map, java.lang.String, java.util.Map, java.util.Date):b.c.d.t.o.k$a");
    }
}
