package com.google.firebase.p175ml.vision;

import java.util.List;
import p002b.p011c.p015b.p028b.p068i.p076h.C2439m0;
import p002b.p011c.p015b.p028b.p068i.p076h.C2557u4;
import p002b.p011c.p015b.p028b.p068i.p076h.C2570v4;
import p002b.p011c.p110d.p116h.C4007d;
import p002b.p011c.p110d.p116h.C4014i;
import p002b.p011c.p110d.p116h.C4022q;
import p002b.p011c.p110d.p149q.p150a.p151b.C4435b;
import p002b.p011c.p110d.p149q.p152b.C4440a;
import p002b.p011c.p110d.p149q.p152b.C4455g;
import p002b.p011c.p110d.p149q.p152b.C4456h;
import p002b.p011c.p110d.p149q.p152b.C4457i;
import p002b.p011c.p110d.p149q.p152b.p153b.p154b.C4442a;

/* renamed from: com.google.firebase.ml.vision.VisionRegistrar */
public class VisionRegistrar implements C4014i {
    public List<C4007d<?>> getComponents() {
        Class<C4442a> cls = C4442a.class;
        Class<C2557u4> cls2 = C2557u4.class;
        C4007d.C4009b<C4440a> a = C4007d.m13290a(C4440a.class);
        a.mo8356a(C4022q.m13308c(cls2));
        a.mo8358c(C4456h.f16669a);
        C4007d<C4440a> b = a.mo8357b();
        C4007d.C4009b<C4442a> a2 = C4007d.m13290a(cls);
        a2.mo8356a(C4022q.m13308c(C2570v4.C2571a.class));
        a2.mo8356a(C4022q.m13308c(cls2));
        a2.mo8358c(C4455g.f16668a);
        C4007d<C4442a> b2 = a2.mo8357b();
        C4007d.C4009b<C4435b.C4436a> a3 = C4007d.m13290a(C4435b.C4436a.class);
        a3.f15768d = 1;
        a3.mo8356a(new C4022q(cls, 1, 1));
        a3.mo8358c(C4457i.f16670a);
        return C2439m0.m9908r(b, b2, a3.mo8357b());
    }
}
