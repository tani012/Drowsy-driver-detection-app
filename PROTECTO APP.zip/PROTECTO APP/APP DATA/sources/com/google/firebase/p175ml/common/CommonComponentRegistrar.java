package com.google.firebase.p175ml.common;

import android.content.Context;
import java.util.List;
import p002b.p011c.p015b.p028b.p068i.p076h.C2339f5;
import p002b.p011c.p015b.p028b.p068i.p076h.C2385i5;
import p002b.p011c.p015b.p028b.p068i.p076h.C2439m0;
import p002b.p011c.p015b.p028b.p068i.p076h.C2499q4;
import p002b.p011c.p015b.p028b.p068i.p076h.C2557u4;
import p002b.p011c.p015b.p028b.p068i.p076h.C2570v4;
import p002b.p011c.p110d.p116h.C4007d;
import p002b.p011c.p110d.p116h.C4014i;
import p002b.p011c.p110d.p116h.C4022q;
import p002b.p011c.p110d.p149q.p150a.C4438c;
import p002b.p011c.p110d.p149q.p150a.C4439d;
import p002b.p011c.p110d.p149q.p150a.p151b.C4435b;

/* renamed from: com.google.firebase.ml.common.CommonComponentRegistrar */
public class CommonComponentRegistrar implements C4014i {
    public List<C4007d<?>> getComponents() {
        C4007d<?> dVar = C2570v4.f12658m;
        C4007d<?> dVar2 = C2499q4.f12612c;
        C4007d<?> dVar3 = C2339f5.f12284g;
        C4007d<?> dVar4 = C2385i5.f12312c;
        C4007d<C2557u4> dVar5 = C2557u4.f12643b;
        C4007d.C4009b<C2570v4.C2572b> a = C4007d.m13290a(C2570v4.C2572b.class);
        a.mo8356a(C4022q.m13308c(Context.class));
        a.mo8358c(C4439d.f16629a);
        C4007d<C2570v4.C2572b> b = a.mo8357b();
        C4007d.C4009b<C4435b> a2 = C4007d.m13290a(C4435b.class);
        a2.mo8356a(new C4022q(C4435b.C4436a.class, 2, 0));
        a2.mo8358c(C4438c.f16628a);
        return C2439m0.m9909v(dVar, dVar2, dVar3, dVar4, dVar5, b, a2.mo8357b());
    }
}
