package com.google.firebase.installations;

import androidx.annotation.Keep;
import java.util.Arrays;
import java.util.List;
import p002b.p011c.p110d.C3976c;
import p002b.p011c.p110d.p116h.C4007d;
import p002b.p011c.p110d.p116h.C4010e;
import p002b.p011c.p110d.p116h.C4014i;
import p002b.p011c.p110d.p116h.C4022q;
import p002b.p011c.p110d.p117i.p118e.p121k.C4102r0;
import p002b.p011c.p110d.p141l.C4334c;
import p002b.p011c.p110d.p145o.C4402f;
import p002b.p011c.p110d.p145o.C4404g;
import p002b.p011c.p110d.p145o.C4407i;
import p002b.p011c.p110d.p163s.C4501f;

@Keep
public class FirebaseInstallationsRegistrar implements C4014i {
    public static /* synthetic */ C4404g lambda$getComponents$0(C4010e eVar) {
        return new C4402f((C3976c) eVar.mo8352a(C3976c.class), (C4501f) eVar.mo8352a(C4501f.class), (C4334c) eVar.mo8352a(C4334c.class));
    }

    public List<C4007d<?>> getComponents() {
        C4007d.C4009b<C4404g> a = C4007d.m13290a(C4404g.class);
        a.mo8356a(C4022q.m13308c(C3976c.class));
        a.mo8356a(C4022q.m13308c(C4334c.class));
        a.mo8356a(C4022q.m13308c(C4501f.class));
        a.mo8358c(C4407i.f16559a);
        return Arrays.asList(new C4007d[]{a.mo8357b(), C4102r0.m13482p("fire-installations", "16.3.2")});
    }
}
