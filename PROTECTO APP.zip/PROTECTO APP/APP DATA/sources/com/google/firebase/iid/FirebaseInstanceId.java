package com.google.firebase.iid;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Looper;
import android.util.Log;
import android.util.Pair;
import androidx.annotation.Keep;
import java.io.IOException;
import java.util.concurrent.CancellationException;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import javax.annotation.concurrent.GuardedBy;
import p002b.p011c.p015b.p028b.p053e.p061r.C0605f;
import p002b.p011c.p015b.p028b.p053e.p061r.p062j.C0609a;
import p002b.p011c.p015b.p028b.p089n.C3712d0;
import p002b.p011c.p015b.p028b.p089n.C3716f0;
import p002b.p011c.p015b.p028b.p089n.C3719h;
import p002b.p011c.p015b.p028b.p089n.C3720h0;
import p002b.p011c.p015b.p028b.p089n.C3721i;
import p002b.p011c.p015b.p028b.p089n.C3737v;
import p002b.p011c.p110d.C3974a;
import p002b.p011c.p110d.C3976c;
import p002b.p011c.p110d.p140k.C4329b;
import p002b.p011c.p110d.p140k.C4331d;
import p002b.p011c.p110d.p141l.C4334c;
import p002b.p011c.p110d.p142m.C4337a;
import p002b.p011c.p110d.p142m.C4338a0;
import p002b.p011c.p110d.p142m.C4339a1;
import p002b.p011c.p110d.p142m.C4342b1;
import p002b.p011c.p110d.p142m.C4346d;
import p002b.p011c.p110d.p142m.C4347d0;
import p002b.p011c.p110d.p142m.C4373p0;
import p002b.p011c.p110d.p142m.C4374q;
import p002b.p011c.p110d.p142m.C4380s0;
import p002b.p011c.p110d.p142m.C4382t0;
import p002b.p011c.p110d.p142m.C4383u;
import p002b.p011c.p110d.p142m.C4384u0;
import p002b.p011c.p110d.p142m.C4385v;
import p002b.p011c.p110d.p142m.C4386v0;
import p002b.p011c.p110d.p142m.C4388w0;
import p002b.p011c.p110d.p142m.C4393z;
import p002b.p011c.p110d.p142m.C4394z0;
import p002b.p011c.p110d.p145o.C4404g;
import p002b.p011c.p110d.p163s.C4501f;
import p176d.p178b.p179k.C4851q;

public class FirebaseInstanceId {

    /* renamed from: i */
    public static final long f17497i = TimeUnit.HOURS.toSeconds(8);

    /* renamed from: j */
    public static C4338a0 f17498j;
    @GuardedBy("FirebaseInstanceId.class")

    /* renamed from: k */
    public static ScheduledExecutorService f17499k;

    /* renamed from: a */
    public final Executor f17500a;

    /* renamed from: b */
    public final C3976c f17501b;

    /* renamed from: c */
    public final C4374q f17502c;

    /* renamed from: d */
    public final C4339a1 f17503d;

    /* renamed from: e */
    public final C4385v f17504e;

    /* renamed from: f */
    public final C4404g f17505f;
    @GuardedBy("this")

    /* renamed from: g */
    public boolean f17506g = false;

    /* renamed from: h */
    public final C4809a f17507h;

    /* renamed from: com.google.firebase.iid.FirebaseInstanceId$a */
    public class C4809a {

        /* renamed from: a */
        public boolean f17508a;

        /* renamed from: b */
        public final C4331d f17509b;
        @GuardedBy("this")

        /* renamed from: c */
        public boolean f17510c;
        @GuardedBy("this")

        /* renamed from: d */
        public C4329b<C3974a> f17511d;
        @GuardedBy("this")

        /* renamed from: e */
        public Boolean f17512e;

        public C4809a(C4331d dVar) {
            this.f17509b = dVar;
        }

        /* JADX WARNING: Code restructure failed: missing block: B:14:0x0020, code lost:
            return r1.f17508a && r1.f17513f.f17501b.mo8330g();
         */
        /* renamed from: a */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public final synchronized boolean mo9758a() {
            /*
                r1 = this;
                monitor-enter(r1)
                r1.mo9759b()     // Catch:{ all -> 0x0023 }
                java.lang.Boolean r0 = r1.f17512e     // Catch:{ all -> 0x0023 }
                if (r0 == 0) goto L_0x0010
                java.lang.Boolean r0 = r1.f17512e     // Catch:{ all -> 0x0023 }
                boolean r0 = r0.booleanValue()     // Catch:{ all -> 0x0023 }
                monitor-exit(r1)
                return r0
            L_0x0010:
                boolean r0 = r1.f17508a     // Catch:{ all -> 0x0023 }
                if (r0 == 0) goto L_0x0021
                com.google.firebase.iid.FirebaseInstanceId r0 = com.google.firebase.iid.FirebaseInstanceId.this     // Catch:{ all -> 0x0023 }
                b.c.d.c r0 = r0.f17501b     // Catch:{ all -> 0x0023 }
                boolean r0 = r0.mo8330g()     // Catch:{ all -> 0x0023 }
                if (r0 == 0) goto L_0x0021
                r0 = 1
            L_0x001f:
                monitor-exit(r1)
                return r0
            L_0x0021:
                r0 = 0
                goto L_0x001f
            L_0x0023:
                r0 = move-exception
                monitor-exit(r1)
                throw r0
            */
            throw new UnsupportedOperationException("Method not decompiled: com.google.firebase.iid.FirebaseInstanceId.C4809a.mo9758a():boolean");
        }

        /* JADX WARNING: Can't wrap try/catch for region: R(3:10|11|(1:15)) */
        /* JADX WARNING: Code restructure failed: missing block: B:11:?, code lost:
            r1 = r4.f17513f.f17501b;
            r1.mo8325a();
            r1 = r1.f15686a;
            r2 = new android.content.Intent("com.google.firebase.MESSAGING_EVENT");
            r2.setPackage(r1.getPackageName());
            r3 = false;
            r1 = r1.getPackageManager().resolveService(r2, 0);
         */
        /* JADX WARNING: Missing exception handler attribute for start block: B:10:0x000f */
        /* renamed from: b */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public final synchronized void mo9759b() {
            /*
                r4 = this;
                monitor-enter(r4)
                boolean r0 = r4.f17510c     // Catch:{ all -> 0x0056 }
                if (r0 == 0) goto L_0x0007
                monitor-exit(r4)
                return
            L_0x0007:
                r0 = 1
                java.lang.String r1 = "com.google.firebase.messaging.FirebaseMessaging"
                java.lang.Class.forName(r1)     // Catch:{ ClassNotFoundException -> 0x000f }
            L_0x000d:
                r3 = r0
                goto L_0x0036
            L_0x000f:
                com.google.firebase.iid.FirebaseInstanceId r1 = com.google.firebase.iid.FirebaseInstanceId.this     // Catch:{ all -> 0x0056 }
                b.c.d.c r1 = r1.f17501b     // Catch:{ all -> 0x0056 }
                r1.mo8325a()     // Catch:{ all -> 0x0056 }
                android.content.Context r1 = r1.f15686a     // Catch:{ all -> 0x0056 }
                android.content.Intent r2 = new android.content.Intent     // Catch:{ all -> 0x0056 }
                java.lang.String r3 = "com.google.firebase.MESSAGING_EVENT"
                r2.<init>(r3)     // Catch:{ all -> 0x0056 }
                java.lang.String r3 = r1.getPackageName()     // Catch:{ all -> 0x0056 }
                r2.setPackage(r3)     // Catch:{ all -> 0x0056 }
                android.content.pm.PackageManager r1 = r1.getPackageManager()     // Catch:{ all -> 0x0056 }
                r3 = 0
                android.content.pm.ResolveInfo r1 = r1.resolveService(r2, r3)     // Catch:{ all -> 0x0056 }
                if (r1 == 0) goto L_0x0036
                android.content.pm.ServiceInfo r1 = r1.serviceInfo     // Catch:{ all -> 0x0056 }
                if (r1 == 0) goto L_0x0036
                goto L_0x000d
            L_0x0036:
                r4.f17508a = r3     // Catch:{ all -> 0x0056 }
                java.lang.Boolean r1 = r4.mo9760c()     // Catch:{ all -> 0x0056 }
                r4.f17512e = r1     // Catch:{ all -> 0x0056 }
                if (r1 != 0) goto L_0x0052
                boolean r1 = r4.f17508a     // Catch:{ all -> 0x0056 }
                if (r1 == 0) goto L_0x0052
                b.c.d.m.x0 r1 = new b.c.d.m.x0     // Catch:{ all -> 0x0056 }
                r1.<init>(r4)     // Catch:{ all -> 0x0056 }
                r4.f17511d = r1     // Catch:{ all -> 0x0056 }
                b.c.d.k.d r2 = r4.f17509b     // Catch:{ all -> 0x0056 }
                java.lang.Class<b.c.d.a> r3 = p002b.p011c.p110d.C3974a.class
                r2.mo8371a(r3, r1)     // Catch:{ all -> 0x0056 }
            L_0x0052:
                r4.f17510c = r0     // Catch:{ all -> 0x0056 }
                monitor-exit(r4)
                return
            L_0x0056:
                r0 = move-exception
                monitor-exit(r4)
                throw r0
            */
            throw new UnsupportedOperationException("Method not decompiled: com.google.firebase.iid.FirebaseInstanceId.C4809a.mo9759b():void");
        }

        /* renamed from: c */
        public final Boolean mo9760c() {
            ApplicationInfo applicationInfo;
            C3976c cVar = FirebaseInstanceId.this.f17501b;
            cVar.mo8325a();
            Context context = cVar.f15686a;
            SharedPreferences sharedPreferences = context.getSharedPreferences("com.google.firebase.messaging", 0);
            if (sharedPreferences.contains("auto_init")) {
                return Boolean.valueOf(sharedPreferences.getBoolean("auto_init", false));
            }
            try {
                PackageManager packageManager = context.getPackageManager();
                if (packageManager == null || (applicationInfo = packageManager.getApplicationInfo(context.getPackageName(), 128)) == null || applicationInfo.metaData == null || !applicationInfo.metaData.containsKey("firebase_messaging_auto_init_enabled")) {
                    return null;
                }
                return Boolean.valueOf(applicationInfo.metaData.getBoolean("firebase_messaging_auto_init_enabled"));
            } catch (PackageManager.NameNotFoundException unused) {
                return null;
            }
        }
    }

    public FirebaseInstanceId(C3976c cVar, C4331d dVar, C4501f fVar, C4334c cVar2, C4404g gVar) {
        cVar.mo8325a();
        C4374q qVar = new C4374q(cVar.f15686a);
        ExecutorService a = C4373p0.m13822a();
        ExecutorService a2 = C4373p0.m13822a();
        if (C4374q.m13823b(cVar) != null) {
            synchronized (FirebaseInstanceId.class) {
                if (f17498j == null) {
                    cVar.mo8325a();
                    f17498j = new C4338a0(cVar.f15686a);
                }
            }
            this.f17501b = cVar;
            this.f17502c = qVar;
            this.f17503d = new C4339a1(cVar, qVar, a, fVar, cVar2, gVar);
            this.f17500a = a2;
            this.f17507h = new C4809a(dVar);
            this.f17504e = new C4385v(a);
            this.f17505f = gVar;
            ((ThreadPoolExecutor) a2).execute(new C4382t0(this));
            return;
        }
        throw new IllegalStateException("FirebaseInstanceId failed to initialize, FirebaseApp is missing project ID");
    }

    /* renamed from: a */
    public static FirebaseInstanceId m14898a() {
        return getInstance(C3976c.m13233c());
    }

    /* renamed from: c */
    public static void m14899c(Runnable runnable, long j) {
        synchronized (FirebaseInstanceId.class) {
            if (f17499k == null) {
                f17499k = new ScheduledThreadPoolExecutor(1, new C0609a("FirebaseInstanceId"));
            }
            f17499k.schedule(runnable, j, TimeUnit.SECONDS);
        }
    }

    @Keep
    public static FirebaseInstanceId getInstance(C3976c cVar) {
        cVar.mo8325a();
        return (FirebaseInstanceId) cVar.f15689d.mo8352a(FirebaseInstanceId.class);
    }

    /* renamed from: k */
    public static boolean m14902k() {
        return Log.isLoggable("FirebaseInstanceId", 3);
    }

    /* renamed from: b */
    public final synchronized void mo9747b(long j) {
        m14899c(new C4347d0(this, Math.min(Math.max(30, j << 1), f17497i)), j);
        this.f17506g = true;
    }

    /* renamed from: e */
    public final synchronized void mo9748e(boolean z) {
        this.f17506g = z;
    }

    /* renamed from: f */
    public final boolean mo9749f(C4393z zVar) {
        if (zVar != null) {
            return (System.currentTimeMillis() > (zVar.f16526c + C4393z.f16523d) ? 1 : (System.currentTimeMillis() == (zVar.f16526c + C4393z.f16523d) ? 0 : -1)) > 0 || !this.f17502c.mo8706d().equals(zVar.f16525b);
        }
    }

    /* renamed from: g */
    public final C3719h mo9750g(String str, String str2) {
        C3719h<TContinuationResult> hVar;
        String str3 = str;
        String str4 = str2;
        String o = mo9756o();
        C4393z h = mo9751h(str, str2);
        if (!mo9749f(h)) {
            return C0605f.m927F(new C4346d(o, h.f16524a));
        }
        C4385v vVar = this.f17504e;
        synchronized (vVar) {
            Pair pair = new Pair(str3, str4);
            hVar = vVar.f16500b.get(pair);
            if (hVar == null) {
                if (Log.isLoggable("FirebaseInstanceId", 3)) {
                    String valueOf = String.valueOf(pair);
                    StringBuilder sb = new StringBuilder(valueOf.length() + 24);
                    sb.append("Making new request for: ");
                    sb.append(valueOf);
                    Log.d("FirebaseInstanceId", sb.toString());
                }
                C4339a1 a1Var = this.f17503d;
                if (a1Var != null) {
                    Bundle bundle = new Bundle();
                    C3721i iVar = new C3721i();
                    Executor executor = a1Var.f16420d;
                    Pair pair2 = pair;
                    C4394z0 z0Var = r2;
                    C4394z0 z0Var2 = new C4394z0(a1Var, o, str, str2, bundle, iVar);
                    executor.execute(z0Var);
                    Pair pair3 = pair2;
                    hVar = iVar.f15102a.mo8095f(a1Var.f16420d, new C4342b1(a1Var)).mo8102m(this.f17500a, new C4388w0(this, str3, str4, o)).mo8096g(vVar.f16499a, new C4383u(vVar, pair3));
                    vVar.f16500b.put(pair3, hVar);
                } else {
                    throw null;
                }
            } else if (Log.isLoggable("FirebaseInstanceId", 3)) {
                String valueOf2 = String.valueOf(pair);
                StringBuilder sb2 = new StringBuilder(valueOf2.length() + 29);
                sb2.append("Joining ongoing request for: ");
                sb2.append(valueOf2);
                Log.d("FirebaseInstanceId", sb2.toString());
            }
        }
        return hVar;
    }

    /* renamed from: h */
    public final C4393z mo9751h(String str, String str2) {
        C4393z a;
        C4338a0 a0Var = f17498j;
        String p = mo9757p();
        synchronized (a0Var) {
            a = C4393z.m13846a(a0Var.f16414a.getString(C4338a0.m13793d(p, str, str2), (String) null));
        }
        return a;
    }

    /* renamed from: j */
    public final String mo9752j() {
        String b = C4374q.m13823b(this.f17501b);
        if (Looper.getMainLooper() != Looper.myLooper()) {
            try {
                return ((C4337a) C0605f.m1138k(C0605f.m927F(null).mo8096g(this.f17500a, new C4380s0(this, b, "*")), 30000, TimeUnit.MILLISECONDS)).mo8669a();
            } catch (ExecutionException e) {
                Throwable cause = e.getCause();
                if (cause instanceof IOException) {
                    if ("INSTANCE_ID_RESET".equals(cause.getMessage())) {
                        mo9753l();
                    }
                    throw ((IOException) cause);
                } else if (cause instanceof RuntimeException) {
                    throw ((RuntimeException) cause);
                } else {
                    throw new IOException(e);
                }
            } catch (InterruptedException | TimeoutException unused) {
                throw new IOException("SERVICE_NOT_AVAILABLE");
            }
        } else {
            throw new IOException("MAIN_THREAD");
        }
    }

    /* renamed from: l */
    public final synchronized void mo9753l() {
        f17498j.mo8670b();
        if (this.f17507h.mo9758a()) {
            mo9755n();
        }
    }

    /* renamed from: m */
    public final void mo9754m() {
        if (mo9749f(mo9751h(C4374q.m13823b(this.f17501b), "*"))) {
            mo9755n();
        }
    }

    /* renamed from: n */
    public final synchronized void mo9755n() {
        if (!this.f17506g) {
            mo9747b(0);
        }
    }

    /* renamed from: o */
    public final String mo9756o() {
        try {
            f17498j.mo8671c(this.f17501b.mo8327d());
            C3719h<String> s = this.f17505f.mo8747s();
            C4851q.C4862i.m15173u(s, "Task must not be null");
            CountDownLatch countDownLatch = new CountDownLatch(1);
            Executor executor = C4386v0.f16501e;
            C4384u0 u0Var = new C4384u0(countDownLatch);
            C3716f0 f0Var = (C3716f0) s;
            C3712d0<TResult> d0Var = f0Var.f15095b;
            C3720h0.m12928a(executor);
            d0Var.mo8088b(new C3737v(executor, u0Var));
            f0Var.mo8106q();
            countDownLatch.await(30000, TimeUnit.MILLISECONDS);
            if (s.mo8100k()) {
                return s.mo8098i();
            }
            if (((C3716f0) s).f15097d) {
                throw new CancellationException("Task is already canceled");
            }
            throw new IllegalStateException(s.mo8097h());
        } catch (InterruptedException e) {
            throw new IllegalStateException(e);
        }
    }

    /* renamed from: p */
    public final String mo9757p() {
        C3976c cVar = this.f17501b;
        cVar.mo8325a();
        return "[DEFAULT]".equals(cVar.f15687b) ? "" : this.f17501b.mo8327d();
    }
}
