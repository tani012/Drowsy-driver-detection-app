package com.google.firebase.iid;

import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.Parcelable;
import java.util.concurrent.ExecutorService;
import p002b.p011c.p015b.p028b.p089n.C3719h;
import p002b.p011c.p110d.p142m.C4343c;
import p002b.p011c.p110d.p142m.C4351e1;
import p002b.p011c.p110d.p142m.C4373p0;
import p002b.p011c.p110d.p142m.C4392y0;
import p176d.p240m.p241a.C5774a;

public final class FirebaseInstanceIdReceiver extends C5774a {

    /* renamed from: c */
    public final ExecutorService f17514c = C4373p0.m13822a();

    /* renamed from: b */
    public static final /* synthetic */ void m14917b(boolean z, BroadcastReceiver.PendingResult pendingResult, C3719h hVar) {
        if (z) {
            pendingResult.setResultCode(hVar.mo8100k() ? ((Integer) hVar.mo8098i()).intValue() : 500);
        }
        pendingResult.finish();
    }

    public final void onReceive(Context context, Intent intent) {
        if (intent != null) {
            Parcelable parcelableExtra = intent.getParcelableExtra("wrapped_intent");
            Intent intent2 = parcelableExtra instanceof Intent ? (Intent) parcelableExtra : null;
            if (intent2 != null) {
                intent = intent2;
            }
            intent.setComponent((ComponentName) null);
            intent.setPackage(context.getPackageName());
            ("google.com/iid".equals(intent.getStringExtra("from")) ? new C4351e1(this.f17514c) : new C4343c(context, this.f17514c)).mo8674a(intent).mo8091b(this.f17514c, new C4392y0(isOrderedBroadcast(), goAsync()));
        }
    }
}
