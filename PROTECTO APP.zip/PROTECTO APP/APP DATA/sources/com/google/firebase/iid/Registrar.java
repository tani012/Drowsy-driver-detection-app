package com.google.firebase.iid;

import androidx.annotation.Keep;
import java.util.Arrays;
import java.util.List;
import p002b.p011c.p110d.C3976c;
import p002b.p011c.p110d.p116h.C4007d;
import p002b.p011c.p110d.p116h.C4014i;
import p002b.p011c.p110d.p116h.C4022q;
import p002b.p011c.p110d.p117i.p118e.p121k.C4102r0;
import p002b.p011c.p110d.p140k.C4331d;
import p002b.p011c.p110d.p141l.C4334c;
import p002b.p011c.p110d.p142m.C4379s;
import p002b.p011c.p110d.p142m.C4381t;
import p002b.p011c.p110d.p142m.p143b.C4340a;
import p002b.p011c.p110d.p145o.C4404g;
import p002b.p011c.p110d.p163s.C4501f;
import p176d.p178b.p179k.C4851q;

@Keep
public final class Registrar implements C4014i {

    /* renamed from: com.google.firebase.iid.Registrar$a */
    public static class C4810a implements C4340a {

        /* renamed from: a */
        public final FirebaseInstanceId f17515a;

        public C4810a(FirebaseInstanceId firebaseInstanceId) {
            this.f17515a = firebaseInstanceId;
        }

        /* renamed from: s */
        public final String mo8673s() {
            FirebaseInstanceId firebaseInstanceId = this.f17515a;
            C3976c cVar = firebaseInstanceId.f17501b;
            cVar.mo8325a();
            C4851q.C4862i.m15158p(cVar.f15688c.f15704g, "FirebaseApp has to define a valid projectId.");
            cVar.mo8325a();
            C4851q.C4862i.m15158p(cVar.f15688c.f15699b, "FirebaseApp has to define a valid applicationId.");
            cVar.mo8325a();
            C4851q.C4862i.m15158p(cVar.f15688c.f15698a, "FirebaseApp has to define a valid apiKey.");
            firebaseInstanceId.mo9754m();
            return firebaseInstanceId.mo9756o();
        }
    }

    @Keep
    public final List<C4007d<?>> getComponents() {
        Class<FirebaseInstanceId> cls = FirebaseInstanceId.class;
        C4007d.C4009b<FirebaseInstanceId> a = C4007d.m13290a(cls);
        a.mo8356a(C4022q.m13308c(C3976c.class));
        a.mo8356a(C4022q.m13308c(C4331d.class));
        a.mo8356a(C4022q.m13308c(C4501f.class));
        a.mo8356a(C4022q.m13308c(C4334c.class));
        a.mo8356a(C4022q.m13308c(C4404g.class));
        a.mo8358c(C4379s.f16490a);
        a.mo8359d(1);
        C4007d<FirebaseInstanceId> b = a.mo8357b();
        C4007d.C4009b<C4340a> a2 = C4007d.m13290a(C4340a.class);
        a2.mo8356a(C4022q.m13308c(cls));
        a2.mo8358c(C4381t.f16494a);
        return Arrays.asList(new C4007d[]{b, a2.mo8357b(), C4102r0.m13482p("fire-iid", "20.1.5")});
    }
}
