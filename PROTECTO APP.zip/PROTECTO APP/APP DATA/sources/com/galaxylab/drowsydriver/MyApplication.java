package com.galaxylab.drowsydriver;

import android.app.Application;
import android.content.Context;
import android.content.SharedPreferences;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import p002b.p003a.p004a.C0121d;
import p002b.p003a.p004a.C0122e;
import p002b.p003a.p004a.C0123f;
import p002b.p003a.p004a.C0124g;
import p002b.p003a.p004a.C0125h;
import p002b.p003a.p004a.C0126i;
import p002b.p003a.p004a.C0127j;
import p002b.p003a.p004a.C0128k;
import p002b.p003a.p004a.C0129l;
import p002b.p003a.p004a.p005a.C0096f;
import p002b.p003a.p004a.p006b.C0104b;
import p002b.p003a.p004a.p006b.C0107e;
import p002b.p003a.p004a.p006b.C0114l;
import p002b.p003a.p004a.p007c.C0115a;
import p002b.p003a.p004a.p007c.C0119e;
import p002b.p011c.p110d.p117i.p118e.p121k.C4102r0;
import p257h.C5839h;
import p257h.C5842k;
import p257h.p258m.C5846c;
import p257h.p265p.p266a.C5891l;
import p257h.p265p.p267b.C5908e;
import p257h.p265p.p267b.C5910g;
import p257h.p265p.p267b.C5911h;
import p257h.p265p.p267b.C5912i;
import p285k.p286a.p287a.p288a.p289a.C6115b;
import p285k.p286a.p287a.p288a.p289a.C6117d;
import p285k.p286a.p287a.p290b.C6118a;
import p285k.p286a.p293c.C6124b;
import p285k.p286a.p293c.C6125c;
import p285k.p286a.p293c.C6126d;
import p285k.p286a.p293c.C6127e;
import p285k.p286a.p293c.p294g.C6129a;
import p285k.p286a.p293c.p294g.C6130b;
import p285k.p286a.p293c.p294g.C6131c;
import p285k.p286a.p293c.p295h.C6132a;
import p285k.p286a.p293c.p295h.C6134b;
import p285k.p286a.p293c.p295h.C6135c;
import p285k.p286a.p293c.p295h.C6136d;
import p285k.p286a.p293c.p295h.C6137e;
import p285k.p286a.p293c.p298k.C6151b;
import p285k.p286a.p293c.p298k.C6152c;
import p285k.p286a.p293c.p299l.C6153a;
import p285k.p286a.p293c.p301n.C6155a;
import p285k.p286a.p293c.p302o.C6158b;
import p285k.p286a.p293c.p303p.C6160b;
import p305l.p306a.C6163a;

public final class MyApplication extends Application {

    /* renamed from: e */
    public final C6153a f17326e = C4102r0.m13469i0(false, false, new C4785a(this), 3);

    /* renamed from: f */
    public final C6153a f17327f = C4102r0.m13469i0(false, false, new C4786b(this), 3);

    /* renamed from: com.galaxylab.drowsydriver.MyApplication$a */
    public static final class C4785a extends C5911h implements C5891l<C6153a, C5842k> {

        /* renamed from: f */
        public final /* synthetic */ MyApplication f17328f;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        public C4785a(MyApplication myApplication) {
            super(1);
            this.f17328f = myApplication;
        }

        /* renamed from: e */
        public Object mo854e(Object obj) {
            C6153a aVar = (C6153a) obj;
            C6135c cVar = C6135c.Single;
            if (aVar != null) {
                C0122e eVar = new C0122e(this);
                C6160b bVar = aVar.f21157a;
                C6136d a = aVar.mo12721a(false, false);
                C6160b bVar2 = bVar;
                C6135c cVar2 = cVar;
                C6132a aVar2 = r2;
                C6132a aVar3 = new C6132a(bVar2, C5912i.m17233a(SharedPreferences.class), (C6155a) null, eVar, cVar2, C5846c.f20375e, a, (C6137e) null, (C6134b) null, 384);
                C6160b.m17869a(bVar, aVar2, false, 2);
                C0123f fVar = new C0123f(this);
                C6160b bVar3 = aVar.f21157a;
                C6136d a2 = aVar.mo12721a(false, false);
                C6160b bVar4 = bVar3;
                C6160b.m17869a(bVar3, new C6132a(bVar4, C5912i.m17233a(C0107e.class), (C6155a) null, fVar, cVar2, C5846c.f20375e, a2, (C6137e) null, (C6134b) null, 384), false, 2);
                C0124g gVar = C0124g.f749f;
                C6160b bVar5 = aVar.f21157a;
                C6136d a3 = aVar.mo12721a(false, false);
                C6160b bVar6 = bVar5;
                C6160b.m17869a(bVar5, new C6132a(bVar6, C5912i.m17233a(C0104b.class), (C6155a) null, gVar, cVar2, C5846c.f20375e, a3, (C6137e) null, (C6134b) null, 384), false, 2);
                return C5842k.f20369a;
            }
            C5910g.m17230f("$receiver");
            throw null;
        }
    }

    /* renamed from: com.galaxylab.drowsydriver.MyApplication$b */
    public static final class C4786b extends C5911h implements C5891l<C6153a, C5842k> {

        /* renamed from: f */
        public final /* synthetic */ MyApplication f17329f;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        public C4786b(MyApplication myApplication) {
            super(1);
            this.f17329f = myApplication;
        }

        /* renamed from: e */
        public Object mo854e(Object obj) {
            C6153a aVar = (C6153a) obj;
            C6135c cVar = C6135c.Single;
            if (aVar != null) {
                C0125h hVar = C0125h.f750f;
                C6160b bVar = aVar.f21157a;
                C6136d a = aVar.mo12721a(false, false);
                C6160b bVar2 = bVar;
                C6135c cVar2 = cVar;
                C6160b.m17869a(bVar, new C6132a(bVar2, C5912i.m17233a(C0115a.class), (C6155a) null, hVar, cVar2, C5846c.f20375e, a, (C6137e) null, (C6134b) null, 384), false, 2);
                C0126i iVar = C0126i.f751f;
                C6160b bVar3 = aVar.f21157a;
                C6136d a2 = aVar.mo12721a(false, false);
                C6160b bVar4 = bVar3;
                C6160b.m17869a(bVar3, new C6132a(bVar4, C5912i.m17233a(C0119e.class), (C6155a) null, iVar, cVar2, C5846c.f20375e, a2, (C6137e) null, (C6134b) null, 384), false, 2);
                C0127j jVar = C0127j.f752f;
                C6160b bVar5 = aVar.f21157a;
                C6136d a3 = aVar.mo12721a(false, false);
                C6160b bVar6 = bVar5;
                C6160b.m17869a(bVar5, new C6132a(bVar6, C5912i.m17233a(C0121d.class), (C6155a) null, jVar, cVar2, C5846c.f20375e, a3, (C6137e) null, (C6134b) null, 384), false, 2);
                C0128k kVar = C0128k.f753f;
                C6160b bVar7 = aVar.f21157a;
                C6136d a4 = aVar.mo12721a(false, false);
                C6160b bVar8 = bVar7;
                C6132a aVar2 = new C6132a(bVar8, C5912i.m17233a(C0096f.class), (C6155a) null, kVar, C6135c.Factory, C5846c.f20375e, a4, (C6137e) null, (C6134b) null, 384);
                C6160b.m17869a(bVar7, aVar2, false, 2);
                C6137e eVar = aVar2.f21135h;
                Boolean bool = Boolean.TRUE;
                Map<String, Object> map = eVar.f21144a;
                if (bool != null) {
                    map.put("isViewModel", bool);
                    C0129l lVar = new C0129l(this);
                    C6160b bVar9 = aVar.f21157a;
                    C6136d a5 = aVar.mo12721a(false, false);
                    C6160b bVar10 = bVar9;
                    C6160b.m17869a(bVar9, new C6132a(bVar10, C5912i.m17233a(C0114l.class), (C6155a) null, lVar, cVar, C5846c.f20375e, a5, (C6137e) null, (C6134b) null, 384), false, 2);
                    return C5842k.f20369a;
                }
                throw new C5839h("null cannot be cast to non-null type kotlin.Any");
            }
            C5910g.m17230f("$receiver");
            throw null;
        }
    }

    public void onCreate() {
        super.onCreate();
        C6163a.m17877a(new C6163a.C6165b());
        C6129a aVar = new C6129a();
        synchronized (C6131c.f21127b) {
            if (C6131c.f21126a == null) {
                C6131c.f21126a = aVar;
            } else {
                throw new IllegalStateException("A KoinContext is already started".toString());
            }
        }
        C6127e eVar = new C6127e((C5908e) null);
        C6158b bVar = eVar.f21124a.f21117a;
        if (bVar != null) {
            bVar.f21167a.put(C6160b.f21179d.f21163a, new C6160b(C6160b.f21179d, true, new HashSet()));
            C6130b bVar2 = C6131c.f21126a;
            if (bVar2 != null) {
                bVar2.mo12700a(eVar);
                C6151b bVar3 = C6151b.INFO;
                eVar.f21124a.f21118b = new C6118a(bVar3);
                Context applicationContext = getApplicationContext();
                C5910g.m17226b(applicationContext, "applicationContext");
                if (eVar.f21124a.f21118b.mo12720e(bVar3)) {
                    eVar.f21124a.f21118b.mo12719d("[init] declare Android Context");
                }
                int i = 0;
                if (applicationContext instanceof Application) {
                    eVar.f21124a.mo12698b(C4102r0.m13461e0(C4102r0.m13469i0(false, false, new C6115b(applicationContext), 3)));
                }
                eVar.f21124a.mo12698b(C4102r0.m13461e0(C4102r0.m13469i0(false, false, new C6117d(applicationContext), 3)));
                List D0 = C4102r0.m13425D0(new C6153a[]{this.f17326e, this.f17327f});
                if (eVar.f21124a.f21118b.mo12720e(bVar3)) {
                    double g0 = C4102r0.m13465g0(new C6125c(eVar, D0));
                    Collection<C6160b> values = eVar.f21124a.f21117a.f21167a.values();
                    ArrayList arrayList = new ArrayList(C4102r0.m13476m(values, 10));
                    for (C6160b bVar4 : values) {
                        arrayList.add(Integer.valueOf(bVar4.f21183c.size()));
                    }
                    Iterator it = arrayList.iterator();
                    while (it.hasNext()) {
                        i += ((Number) it.next()).intValue();
                    }
                    C6152c cVar = eVar.f21124a.f21118b;
                    cVar.mo12719d("loaded " + i + " definitions - " + g0 + " ms");
                } else {
                    eVar.f21124a.mo12698b(D0);
                }
                if (eVar.f21124a.f21118b.mo12720e(bVar3)) {
                    double g02 = C4102r0.m13465g0(new C6126d(eVar));
                    C6152c cVar2 = eVar.f21124a.f21118b;
                    cVar2.mo12719d("create context - " + g02 + " ms");
                } else {
                    eVar.f21124a.f21117a.mo12728a();
                }
                if (eVar.f21124a.f21118b.mo12720e(C6151b.DEBUG)) {
                    double g03 = C4102r0.m13465g0(new C6124b(eVar));
                    C6152c cVar3 = eVar.f21124a.f21118b;
                    cVar3.mo12716a("instances started in " + g03 + " ms");
                    return;
                }
                eVar.f21124a.mo12697a();
                return;
            }
            throw new IllegalStateException("No Koin Context configured. Please use startKoin or koinApplication DSL. ".toString());
        }
        throw null;
    }
}
