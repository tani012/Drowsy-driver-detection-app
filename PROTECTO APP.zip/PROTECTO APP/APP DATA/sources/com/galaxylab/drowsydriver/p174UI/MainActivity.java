package com.galaxylab.drowsydriver.p174UI;

import android.os.Bundle;
import android.os.RemoteException;
import com.galaxylab.drowsydriver.R;
import p002b.p003a.p004a.p005a.C0085a;
import p002b.p003a.p004a.p005a.C0087b;
import p002b.p003a.p004a.p005a.C0098g;
import p002b.p003a.p004a.p006b.C0107e;
import p002b.p011c.p015b.p028b.p053e.p061r.C0605f;
import p002b.p011c.p015b.p028b.p064f.C0624b;
import p002b.p011c.p015b.p028b.p068i.p069a.C1351qa;
import p002b.p011c.p015b.p028b.p068i.p069a.C1426s;
import p002b.p011c.p015b.p028b.p068i.p069a.C1578va;
import p002b.p011c.p015b.p028b.p068i.p069a.C1741ym;
import p002b.p011c.p015b.p028b.p068i.p069a.gl2;
import p002b.p011c.p015b.p028b.p068i.p069a.kk2;
import p002b.p011c.p015b.p028b.p068i.p069a.lk2;
import p002b.p011c.p015b.p028b.p068i.p069a.mk2;
import p002b.p011c.p015b.p028b.p068i.p069a.nk2;
import p002b.p011c.p015b.p028b.p068i.p069a.ok2;
import p002b.p011c.p015b.p028b.p068i.p069a.zh2;
import p002b.p011c.p110d.p117i.p118e.p121k.C4102r0;
import p176d.p178b.p179k.C4848n;
import p176d.p238l.p239d.C5709a;
import p176d.p238l.p239d.C5753r;
import p257h.p265p.p266a.C5880a;
import p257h.p265p.p267b.C5912i;
import p285k.p286a.p293c.p300m.C6154a;
import p285k.p286a.p293c.p301n.C6155a;

/* renamed from: com.galaxylab.drowsydriver.UI.MainActivity */
public final class MainActivity extends C4848n {

    /* renamed from: s */
    public final C0107e f17330s = ((C0107e) C4102r0.m13448W(this).f21117a.mo12730c().mo12732a(C5912i.m17233a(C0107e.class), (C6155a) null, (C5880a<C6154a>) null));

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView((int) R.layout.activity_main);
        C0098g gVar = C0098g.f677a;
        lk2 c = lk2.m4422c();
        synchronized (c.f5651a) {
            if (!c.f5653c) {
                try {
                    if (C1351qa.f7643b == null) {
                        C1351qa.f7643b = new C1351qa();
                    }
                    C1351qa.f7643b.mo4133b(this, (String) null);
                    c.mo3542b(this);
                    c.f5653c = true;
                    c.f5652b.mo1776h2(new lk2.C1149a(gVar, (ok2) null));
                    c.f5652b.mo1782r2(new C1578va());
                    c.f5652b.mo1773T0();
                    c.f5652b.mo1784y7((String) null, new C0624b(new kk2(c, this)));
                    if (!(c.f5655e.f1131a == -1 && c.f5655e.f1132b == -1)) {
                        try {
                            c.f5652b.mo1777h7(new gl2(c.f5655e));
                        } catch (RemoteException e) {
                            C0605f.m1157m4("Unable to set request configuration parcel.", e);
                        }
                    }
                    C1426s.m6437a(this);
                    if (!((Boolean) zh2.f11224j.f11230f.mo3857a(C1426s.f8484v2)).booleanValue() && !c.mo3541a().endsWith("0")) {
                        C0605f.m1095d5("Google Mobile Ads SDK initialization functionality unavailable for this session. Ad requests can be made at any time.");
                        c.f5656f = new mk2(c);
                        C1741ym.f10953b.post(new nk2(c, gVar));
                    }
                } catch (RemoteException e2) {
                    C0605f.m918D4("MobileAdsSettingManager initialization failed", e2);
                }
            }
        }
        if (this.f17330s.mo855a()) {
            mo9595u();
        } else {
            C5753r m = mo11917m();
            if (m != null) {
                C5709a aVar = new C5709a(m);
                aVar.mo11893d(R.id.fragmentContainer, new C0087b(), (String) null, 2);
                if (aVar.f20269h) {
                    aVar.f20268g = true;
                    aVar.f20270i = null;
                    aVar.mo11892c();
                } else {
                    throw new IllegalStateException("This FragmentTransaction is not allowed to be added to the back stack.");
                }
            } else {
                throw null;
            }
        }
        getWindow().addFlags(128);
    }

    /* renamed from: u */
    public final void mo9595u() {
        C5753r m = mo11917m();
        m.mo12069z(new C5753r.C5759f((String) null, -1, 1), false);
        C5753r m2 = mo11917m();
        if (m2 != null) {
            C5709a aVar = new C5709a(m2);
            aVar.mo11893d(R.id.fragmentContainer, new C0085a(), (String) null, 2);
            aVar.mo11892c();
            return;
        }
        throw null;
    }
}
