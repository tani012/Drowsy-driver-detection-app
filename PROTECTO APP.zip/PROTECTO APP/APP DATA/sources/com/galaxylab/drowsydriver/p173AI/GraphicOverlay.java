package com.galaxylab.drowsydriver.p173AI;

import android.content.Context;
import android.graphics.Canvas;
import android.util.AttributeSet;
import android.view.View;
import java.util.ArrayList;
import java.util.List;
import p257h.p265p.p267b.C5910g;

/* renamed from: com.galaxylab.drowsydriver.AI.GraphicOverlay */
public final class GraphicOverlay extends View {

    /* renamed from: e */
    public int f17318e = 1;

    /* renamed from: f */
    public final List<C4784a> f17319f = new ArrayList();

    /* renamed from: g */
    public float f17320g = 1.0f;

    /* renamed from: h */
    public final Object f17321h = new Object();

    /* renamed from: i */
    public int f17322i;

    /* renamed from: j */
    public int f17323j;

    /* renamed from: k */
    public float f17324k = 1.0f;

    /* renamed from: com.galaxylab.drowsydriver.AI.GraphicOverlay$a */
    public static abstract class C4784a {

        /* renamed from: a */
        public final GraphicOverlay f17325a;

        public C4784a(GraphicOverlay graphicOverlay) {
            this.f17325a = graphicOverlay;
        }

        /* renamed from: a */
        public abstract void mo875a(Canvas canvas);

        /* renamed from: b */
        public final float mo9593b(float f) {
            return this.f17325a.getWidthScaleFactor() * f;
        }
    }

    public GraphicOverlay(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    public final float getHeightScaleFactor() {
        return this.f17320g;
    }

    public final float getWidthScaleFactor() {
        return this.f17324k;
    }

    public void onDraw(Canvas canvas) {
        if (canvas != null) {
            super.onDraw(canvas);
            synchronized (this.f17321h) {
                if (!(this.f17323j == 0 || this.f17322i == 0)) {
                    this.f17324k = ((float) getWidth()) / ((float) this.f17323j);
                    this.f17320g = ((float) getHeight()) / ((float) this.f17322i);
                }
                for (C4784a a : this.f17319f) {
                    a.mo875a(canvas);
                }
            }
            return;
        }
        C5910g.m17230f("canvas");
        throw null;
    }

    public final void setHeightScaleFactor(float f) {
        this.f17320g = f;
    }

    public final void setWidthScaleFactor(float f) {
        this.f17324k = f;
    }
}
