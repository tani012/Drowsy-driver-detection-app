package p002b.p003a.p004a;

import android.content.Context;
import android.content.SharedPreferences;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.widget.Toast;
import p257h.C5839h;
import p257h.p265p.p267b.C5910g;

/* renamed from: b.a.a.d */
public final class C0121d {

    /* renamed from: a */
    public MediaPlayer f739a;

    /* renamed from: b */
    public final AudioManager f740b;

    /* renamed from: c */
    public final int f741c;

    /* renamed from: d */
    public final String f742d;

    /* renamed from: e */
    public final String f743e;

    /* renamed from: f */
    public final Context f744f;

    /* renamed from: g */
    public final SharedPreferences f745g;

    /* renamed from: h */
    public final boolean f746h;

    public C0121d(Context context, SharedPreferences sharedPreferences, boolean z, int i) {
        z = (i & 4) != 0 ? true : z;
        if (context == null) {
            C5910g.m17230f("applicationContext");
            throw null;
        } else if (sharedPreferences != null) {
            this.f744f = context;
            this.f745g = sharedPreferences;
            this.f746h = z;
            this.f741c = 3;
            this.f742d = "LAST_SOUND_URL";
            this.f743e = "short_alert.wav";
            Object systemService = context.getSystemService("audio");
            if (systemService != null) {
                this.f740b = (AudioManager) systemService;
                return;
            }
            throw new C5839h("null cannot be cast to non-null type android.media.AudioManager");
        } else {
            C5910g.m17230f("sharedPreferences");
            throw null;
        }
    }

    /* renamed from: a */
    public final void mo876a() {
        if (this.f746h) {
            MediaPlayer mediaPlayer = this.f739a;
            if (mediaPlayer == null) {
                C5910g.m17231g("mediaPlayer");
                throw null;
            } else if (!mediaPlayer.isPlaying()) {
                if (this.f740b.getStreamVolume(this.f741c) == 0) {
                    Toast.makeText(this.f744f, "Volume is mute", 1).show();
                }
                MediaPlayer mediaPlayer2 = this.f739a;
                if (mediaPlayer2 != null) {
                    mediaPlayer2.start();
                } else {
                    C5910g.m17231g("mediaPlayer");
                    throw null;
                }
            }
        }
    }
}
