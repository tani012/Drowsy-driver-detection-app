package p002b.p003a.p004a.p006b;

import p002b.p011c.p110d.p117i.p118e.p121k.C4102r0;
import p168c.p169a.C4776w;
import p176d.p178b.p179k.C4851q;
import p257h.C5842k;
import p257h.p259n.C5854d;
import p257h.p259n.p260i.C5863a;
import p257h.p259n.p261j.p262a.C5870e;
import p257h.p259n.p261j.p262a.C5875i;
import p257h.p265p.p266a.C5895p;
import p257h.p265p.p267b.C5910g;
import p305l.p306a.C6163a;

@C5870e(mo12279c = "com.galaxylab.drowsydriver.Utility.CoroutinesUtilityKt$launchAndLogException$wrapperBlock$1", mo12280f = "CoroutinesUtility.kt", mo12281l = {17}, mo12282m = "invokeSuspend")
/* renamed from: b.a.a.b.d */
public final class C0106d extends C5875i implements C5895p<C4776w, C5854d<? super C5842k>, Object> {

    /* renamed from: i */
    public C4776w f688i;

    /* renamed from: j */
    public Object f689j;

    /* renamed from: k */
    public int f690k;

    /* renamed from: l */
    public final /* synthetic */ C5895p f691l;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public C0106d(C5895p pVar, C5854d dVar) {
        super(2, dVar);
        this.f691l = pVar;
    }

    /* renamed from: a */
    public final C5854d<C5842k> mo843a(Object obj, C5854d<?> dVar) {
        if (dVar != null) {
            C0106d dVar2 = new C0106d(this.f691l, dVar);
            dVar2.f688i = (C4776w) obj;
            return dVar2;
        }
        C5910g.m17230f("completion");
        throw null;
    }

    /* renamed from: d */
    public final Object mo844d(Object obj, Object obj2) {
        return ((C0106d) mo843a(obj, (C5854d) obj2)).mo845h(C5842k.f20369a);
    }

    /* renamed from: h */
    public final Object mo845h(Object obj) {
        C5863a aVar = C5863a.COROUTINE_SUSPENDED;
        int i = this.f690k;
        if (i == 0) {
            C4102r0.m13499x0(obj);
            C4776w wVar = this.f688i;
            C5895p pVar = this.f691l;
            this.f689j = wVar;
            this.f690k = 1;
            if (pVar.mo844d(wVar, this) == aVar) {
                return aVar;
            }
        } else if (i == 1) {
            C4776w wVar2 = (C4776w) this.f689j;
            try {
                C4102r0.m13499x0(obj);
            } catch (Exception e) {
                C4851q.C4862i.m15113a(e);
                C6163a.f21190d.mo12745c(e);
            }
        } else {
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        }
        return C5842k.f20369a;
    }
}
