package p002b.p003a.p004a.p006b;

import android.app.Activity;
import android.content.DialogInterface;

/* renamed from: b.a.a.b.f */
public final class C0108f implements DialogInterface.OnClickListener {

    /* renamed from: e */
    public final /* synthetic */ C0114l f695e;

    /* renamed from: f */
    public final /* synthetic */ Activity f696f;

    public C0108f(C0114l lVar, Activity activity) {
        this.f695e = lVar;
        this.f696f = activity;
    }

    public final void onClick(DialogInterface dialogInterface, int i) {
        this.f695e.mo864b(this.f696f);
    }
}
