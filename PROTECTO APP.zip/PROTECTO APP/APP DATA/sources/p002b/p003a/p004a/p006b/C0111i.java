package p002b.p003a.p004a.p006b;

import android.app.Activity;
import android.content.DialogInterface;

/* renamed from: b.a.a.b.i */
public final class C0111i implements DialogInterface.OnClickListener {

    /* renamed from: e */
    public final /* synthetic */ C0114l f702e;

    /* renamed from: f */
    public final /* synthetic */ Activity f703f;

    public C0111i(C0114l lVar, Activity activity) {
        this.f702e = lVar;
        this.f703f = activity;
    }

    public final void onClick(DialogInterface dialogInterface, int i) {
        this.f702e.mo866d(this.f703f);
    }
}
