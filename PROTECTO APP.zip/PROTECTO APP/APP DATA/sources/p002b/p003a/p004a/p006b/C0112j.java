package p002b.p003a.p004a.p006b;

import android.content.DialogInterface;

/* renamed from: b.a.a.b.j */
public final class C0112j implements DialogInterface.OnClickListener {

    /* renamed from: e */
    public final /* synthetic */ C0113k f704e;

    public C0112j(C0113k kVar) {
        this.f704e = kVar;
    }

    public final void onClick(DialogInterface dialogInterface, int i) {
        C0113k kVar = this.f704e;
        kVar.f705a.mo863a(kVar.f706b);
    }
}
