package p002b.p003a.p004a.p006b;

import p176d.p178b.p179k.C4851q;
import p257h.C5842k;
import p257h.p265p.p266a.C5891l;
import p257h.p265p.p267b.C5911h;

/* renamed from: b.a.a.b.c */
public final class C0105c extends C5911h implements C5891l<Throwable, C5842k> {

    /* renamed from: f */
    public static final C0105c f687f = new C0105c();

    public C0105c() {
        super(1);
    }

    /* renamed from: e */
    public Object mo854e(Object obj) {
        C4851q.C4862i.m15113a((Throwable) obj);
        return C5842k.f20369a;
    }
}
