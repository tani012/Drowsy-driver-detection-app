package p002b.p003a.p004a.p006b;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import com.galaxylab.drowsydriver.R;
import p002b.p008b.p009a.p010a.C0131a;
import p002b.p011c.p015b.p028b.p053e.p061r.C0605f;
import p002b.p011c.p015b.p095c.p096a.p097a.C3769a;
import p002b.p011c.p015b.p095c.p096a.p097a.C3770b;
import p002b.p011c.p015b.p095c.p096a.p097a.C3775g;
import p002b.p011c.p015b.p095c.p096a.p097a.C3786r;
import p002b.p011c.p015b.p095c.p096a.p097a.C3787s;
import p002b.p011c.p015b.p095c.p096a.p106h.C3971o;
import p176d.p178b.C4824i;
import p257h.p265p.p267b.C5910g;
import p305l.p306a.C6163a;

/* renamed from: b.a.a.b.l */
public final class C0114l {

    /* renamed from: a */
    public final C3971o<C3769a> f707a;

    /* renamed from: b */
    public final String f708b;

    /* renamed from: c */
    public final String f709c;

    /* renamed from: d */
    public final String f710d;

    /* renamed from: e */
    public final String f711e;

    /* renamed from: f */
    public final String f712f;

    /* renamed from: g */
    public final String f713g;

    /* renamed from: h */
    public final SharedPreferences f714h;

    /* renamed from: i */
    public final String f715i;

    /* renamed from: j */
    public final String f716j;

    /* renamed from: k */
    public final long f717k;

    /* renamed from: l */
    public final long f718l;

    /* renamed from: m */
    public final long f719m;

    /* renamed from: n */
    public final long f720n;

    /* renamed from: o */
    public final int f721o;

    /* renamed from: p */
    public final String f722p;

    /* renamed from: q */
    public final String f723q;

    public C0114l(Context context, String str, SharedPreferences sharedPreferences, String str2, String str3, String str4, long j, long j2, long j3, long j4) {
        C3787s sVar;
        SharedPreferences sharedPreferences2 = sharedPreferences;
        String str5 = str2;
        if (context == null) {
            C5910g.m17230f("applicationContext");
            throw null;
        } else if (sharedPreferences2 != null) {
            this.f721o = C4824i.Theme_AppCompat_Light_Dialog_Alert;
            this.f722p = "RATING_WAITING_TIME";
            this.f723q = "SHARE_WAITING_TIME";
            this.f717k = j;
            this.f718l = j2;
            this.f719m = j3;
            this.f720n = j4;
            this.f715i = str3;
            this.f716j = str4;
            this.f714h = sharedPreferences2;
            this.f713g = str;
            synchronized (C3786r.class) {
                if (C3786r.f15244a == null) {
                    Context applicationContext = context.getApplicationContext();
                    if (applicationContext == null) {
                        applicationContext = context;
                    }
                    C3775g gVar = new C3775g(applicationContext);
                    C0605f.m1110g(gVar, C3775g.class);
                    C3786r.f15244a = new C3787s(gVar);
                }
                sVar = C3786r.f15244a;
            }
            C3770b a = sVar.f15250f.mo8148a();
            C5910g.m17226b(a, "AppUpdateManagerFactory.create(applicationContext)");
            C3971o<C3769a> a2 = a.mo8146a();
            C5910g.m17226b(a2, "appUpdateManager.appUpdateInfo");
            this.f707a = a2;
            String packageName = context.getPackageName();
            C5910g.m17226b(packageName, "applicationContext.packageName");
            this.f708b = packageName;
            StringBuilder m = C0131a.m379m("https://play.google.com/store/apps/details?id=");
            m.append(this.f708b);
            this.f709c = m.toString();
            StringBuilder m2 = C0131a.m379m("market://details?id=");
            m2.append(this.f708b);
            this.f710d = m2.toString();
            this.f712f = C0131a.m373g("market://search?q=pub:", str2);
            StringBuilder m3 = C0131a.m379m("https://play.google.com/store/apps/developer?id=");
            String replace = str2.replace(' ', '+');
            C5910g.m17226b(replace, "(this as java.lang.Strin…replace(oldChar, newChar)");
            m3.append(replace);
            this.f711e = m3.toString();
        } else {
            C5910g.m17230f("sharedPreferences");
            throw null;
        }
    }

    /* renamed from: a */
    public final void mo863a(Activity activity) {
        if (activity != null) {
            mo865c(activity, this.f710d, this.f709c);
        } else {
            C5910g.m17230f("activity");
            throw null;
        }
    }

    /* renamed from: b */
    public final void mo864b(Activity activity) {
        if (activity != null) {
            Intent intent = new Intent("android.intent.action.SEND");
            intent.putExtra("android.intent.extra.EMAIL", new String[]{this.f715i});
            intent.putExtra("android.intent.extra.SUBJECT", this.f716j + " 5 vs 1.1: Question & Feedback");
            intent.setType("message/rfc822");
            activity.startActivity(Intent.createChooser(intent, "Select Email App :"));
            return;
        }
        C5910g.m17230f("activity");
        throw null;
    }

    /* renamed from: c */
    public final void mo865c(Context context, String str, String str2) {
        try {
            context.startActivity(new Intent("android.intent.action.VIEW", Uri.parse(str)));
        } catch (Exception unused) {
            context.startActivity(new Intent("android.intent.action.VIEW", Uri.parse(str2)));
        }
    }

    /* renamed from: d */
    public final void mo866d(Activity activity) {
        if (activity != null) {
            try {
                Intent intent = new Intent("android.intent.action.SEND");
                intent.setType("text/plain");
                intent.putExtra("android.intent.extra.SUBJECT", activity.getApplicationContext().getString(R.string.app_name));
                intent.putExtra("android.intent.extra.TEXT", this.f713g + "\n\n " + this.f709c);
                activity.startActivity(Intent.createChooser(intent, "choose one"));
            } catch (Exception e) {
                C6163a.f21190d.mo12745c(e);
            }
        }
    }
}
