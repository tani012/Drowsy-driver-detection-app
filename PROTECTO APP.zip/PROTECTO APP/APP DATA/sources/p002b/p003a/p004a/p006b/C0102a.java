package p002b.p003a.p004a.p006b;

import java.util.concurrent.CancellationException;
import p002b.p011c.p110d.p117i.p118e.p121k.C4102r0;
import p168c.p169a.C4760q0;
import p168c.p169a.C4767t0;
import p168c.p169a.C4776w;
import p168c.p169a.C4777w0;
import p168c.p169a.p170a.C4680e;
import p176d.p242n.C5800r;
import p257h.C5842k;
import p257h.p259n.C5854d;
import p257h.p259n.C5857f;
import p257h.p265p.p266a.C5891l;
import p257h.p265p.p267b.C5911h;
import p257h.p271t.C5926c;
import p305l.p306a.C6163a;

/* renamed from: b.a.a.b.a */
public abstract class C0102a extends C5800r {

    /* renamed from: c */
    public final C4776w f682c;

    /* renamed from: b.a.a.b.a$a */
    /* compiled from: com.android.tools.r8.jetbrains.kotlin-style lambda group */
    public static final class C0103a extends C5911h implements C5891l<Throwable, C5842k> {

        /* renamed from: g */
        public static final C0103a f683g = new C0103a(0);

        /* renamed from: h */
        public static final C0103a f684h = new C0103a(1);

        /* renamed from: f */
        public final /* synthetic */ int f685f;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        public C0103a(int i) {
            super(1);
            this.f685f = i;
        }

        /* renamed from: e */
        public final Object mo854e(Object obj) {
            int i = this.f685f;
            if (i == 0) {
                Throwable th = (Throwable) obj;
                if (th != null) {
                    th.printStackTrace();
                    C6163a.f21190d.mo12745c(th);
                    th.getMessage();
                    C6163a.f21190d.mo12744b("invokeOnCompletion message:" + th.getMessage() + ' ', new Object[0]);
                }
                return C5842k.f20369a;
            } else if (i == 1) {
                Throwable th2 = (Throwable) obj;
                if (th2 != null) {
                    th2.printStackTrace();
                    C6163a.f21190d.mo12745c(th2);
                    th2.getMessage();
                    C6163a.f21190d.mo12744b("Child invokeOnCompletion message:" + th2.getMessage() + ' ', new Object[0]);
                }
                return C5842k.f20369a;
            } else {
                throw null;
            }
        }
    }

    public C0102a(C0104b bVar) {
        C4767t0 t0Var = new C4767t0((C4760q0) null);
        t0Var.mo9537m(false, true, C0103a.f683g);
        C4777w0 w0Var = new C4777w0(t0Var, (C5854d) null);
        C5926c cVar = new C5926c();
        cVar.f20435h = C4102r0.m13484q(w0Var, cVar, cVar);
        while (cVar.hasNext()) {
            ((C4760q0) cVar.next()).mo9535e(C0103a.f684h);
        }
        C5857f d = C5857f.C5858a.C5859a.m17196d(t0Var, bVar.f686a);
        this.f682c = new C4680e(d.get(C4760q0.f17276d) == null ? d.plus(new C4767t0((C4760q0) null)) : d);
    }

    /* renamed from: b */
    public void mo853b() {
        C4776w wVar = this.f682c;
        C4760q0 q0Var = (C4760q0) wVar.mo9406c().get(C4760q0.f17276d);
        if (q0Var != null) {
            q0Var.mo9539p((CancellationException) null);
            return;
        }
        throw new IllegalStateException(("Scope cannot be cancelled because it does not have a job: " + wVar).toString());
    }
}
