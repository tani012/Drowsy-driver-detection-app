package p002b.p003a.p004a.p006b;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import androidx.appcompat.app.AlertController;
import p176d.p178b.p179k.C4846m;

/* renamed from: b.a.a.b.h */
public final class C0110h implements DialogInterface.OnClickListener {

    /* renamed from: e */
    public final /* synthetic */ C0114l f699e;

    /* renamed from: f */
    public final /* synthetic */ long f700f;

    /* renamed from: g */
    public final /* synthetic */ Activity f701g;

    public C0110h(C0114l lVar, long j, Activity activity) {
        this.f699e = lVar;
        this.f700f = j;
        this.f701g = activity;
    }

    public final void onClick(DialogInterface dialogInterface, int i) {
        SharedPreferences.Editor edit = this.f699e.f714h.edit();
        C0114l lVar = this.f699e;
        edit.putLong(lVar.f722p, this.f700f + lVar.f718l).apply();
        C0114l lVar2 = this.f699e;
        Activity activity = this.f701g;
        C4846m.C4847a aVar = new C4846m.C4847a(activity, lVar2.f721o);
        C0108f fVar = new C0108f(lVar2, activity);
        AlertController.C0007b bVar = aVar.f17614a;
        bVar.f77i = "Yes";
        bVar.f78j = fVar;
        bVar.f74f = "FeedBack";
        bVar.f76h = "Do you want to send an email feedback to developer?";
        aVar.mo9868a().show();
    }
}
