package p002b.p003a.p004a.p006b;

import android.content.Context;
import java.util.Collection;
import java.util.List;
import p176d.p219i.p221d.C5600a;
import p257h.p265p.p267b.C5910g;

/* renamed from: b.a.a.b.e */
public final class C0107e {

    /* renamed from: a */
    public final List<String> f692a;

    /* renamed from: b */
    public final Context f693b;

    /* renamed from: c */
    public final int f694c;

    public C0107e(List<String> list, Context context) {
        if (context != null) {
            this.f694c = 12345;
            this.f692a = list;
            this.f693b = context;
            return;
        }
        C5910g.m17230f("context");
        throw null;
    }

    /* renamed from: a */
    public final boolean mo855a() {
        List<String> list = this.f692a;
        if ((list instanceof Collection) && list.isEmpty()) {
            return true;
        }
        for (String b : list) {
            if (!mo856b(this.f693b, b)) {
                return false;
            }
        }
        return true;
    }

    /* renamed from: b */
    public final boolean mo856b(Context context, String str) {
        if (context == null) {
            C5910g.m17230f("context");
            throw null;
        } else if (str != null) {
            return C5600a.m16737a(context, str) == 0;
        } else {
            C5910g.m17230f("permission");
            throw null;
        }
    }
}
