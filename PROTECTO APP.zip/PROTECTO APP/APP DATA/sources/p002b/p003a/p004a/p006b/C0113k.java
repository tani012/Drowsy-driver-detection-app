package p002b.p003a.p004a.p006b;

import android.app.Activity;
import androidx.appcompat.app.AlertController;
import p002b.p011c.p015b.p095c.p096a.p097a.C3769a;
import p002b.p011c.p015b.p095c.p096a.p097a.C3785q;
import p002b.p011c.p015b.p095c.p096a.p106h.C3958b;
import p176d.p178b.p179k.C4846m;

/* renamed from: b.a.a.b.k */
public final class C0113k<ResultT> implements C3958b<C3769a> {

    /* renamed from: a */
    public final /* synthetic */ C0114l f705a;

    /* renamed from: b */
    public final /* synthetic */ Activity f706b;

    public C0113k(C0114l lVar, Activity activity) {
        this.f705a = lVar;
        this.f706b = activity;
    }

    /* renamed from: a */
    public void mo862a(Object obj) {
        if (((C3785q) ((C3769a) obj)).f15232c == 2) {
            C4846m.C4847a aVar = new C4846m.C4847a(this.f706b, this.f705a.f721o);
            AlertController.C0007b bVar = aVar.f17614a;
            bVar.f74f = "Update";
            bVar.f76h = "A new version is available.";
            C0112j jVar = new C0112j(this);
            AlertController.C0007b bVar2 = aVar.f17614a;
            bVar2.f77i = "Update";
            bVar2.f78j = jVar;
            aVar.mo9868a().show();
        }
    }
}
