package p002b.p003a.p004a.p006b;

import android.app.Activity;
import android.content.DialogInterface;

/* renamed from: b.a.a.b.g */
public final class C0109g implements DialogInterface.OnClickListener {

    /* renamed from: e */
    public final /* synthetic */ C0114l f697e;

    /* renamed from: f */
    public final /* synthetic */ Activity f698f;

    public C0109g(C0114l lVar, Activity activity) {
        this.f697e = lVar;
        this.f698f = activity;
    }

    public final void onClick(DialogInterface dialogInterface, int i) {
        this.f697e.f714h.edit().putLong(this.f697e.f722p, Long.MAX_VALUE).commit();
        this.f697e.mo863a(this.f698f);
    }
}
