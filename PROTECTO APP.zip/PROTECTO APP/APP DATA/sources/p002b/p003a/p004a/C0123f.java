package p002b.p003a.p004a;

import com.galaxylab.drowsydriver.MyApplication;
import p002b.p003a.p004a.p006b.C0107e;
import p002b.p011c.p110d.p117i.p118e.p121k.C4102r0;
import p257h.p265p.p266a.C5895p;
import p257h.p265p.p267b.C5910g;
import p257h.p265p.p267b.C5911h;
import p285k.p286a.p293c.p300m.C6154a;
import p285k.p286a.p293c.p303p.C6159a;

/* renamed from: b.a.a.f */
public final class C0123f extends C5911h implements C5895p<C6159a, C6154a, C0107e> {

    /* renamed from: f */
    public final /* synthetic */ MyApplication.C4785a f748f;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public C0123f(MyApplication.C4785a aVar) {
        super(2);
        this.f748f = aVar;
    }

    /* renamed from: d */
    public Object mo844d(Object obj, Object obj2) {
        C6154a aVar = (C6154a) obj2;
        if (((C6159a) obj) == null) {
            C5910g.m17230f("$receiver");
            throw null;
        } else if (aVar != null) {
            return new C0107e(C4102r0.m13461e0("android.permission.CAMERA"), this.f748f.f17328f);
        } else {
            C5910g.m17230f("it");
            throw null;
        }
    }
}
