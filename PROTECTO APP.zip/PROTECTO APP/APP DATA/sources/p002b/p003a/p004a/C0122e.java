package p002b.p003a.p004a;

import android.content.SharedPreferences;
import com.galaxylab.drowsydriver.MyApplication;
import p257h.p265p.p266a.C5895p;
import p257h.p265p.p267b.C5910g;
import p257h.p265p.p267b.C5911h;
import p285k.p286a.p293c.p300m.C6154a;
import p285k.p286a.p293c.p303p.C6159a;

/* renamed from: b.a.a.e */
public final class C0122e extends C5911h implements C5895p<C6159a, C6154a, SharedPreferences> {

    /* renamed from: f */
    public final /* synthetic */ MyApplication.C4785a f747f;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public C0122e(MyApplication.C4785a aVar) {
        super(2);
        this.f747f = aVar;
    }

    /* renamed from: d */
    public Object mo844d(Object obj, Object obj2) {
        C6154a aVar = (C6154a) obj2;
        if (((C6159a) obj) == null) {
            C5910g.m17230f("$receiver");
            throw null;
        } else if (aVar != null) {
            return this.f747f.f17328f.getSharedPreferences("DrowsyDriver", 0);
        } else {
            C5910g.m17230f("it");
            throw null;
        }
    }
}
