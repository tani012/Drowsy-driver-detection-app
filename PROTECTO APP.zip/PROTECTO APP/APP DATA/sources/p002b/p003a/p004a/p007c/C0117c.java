package p002b.p003a.p004a.p007c;

import android.graphics.Bitmap;
import java.util.ArrayList;
import java.util.List;
import p002b.p011c.p015b.p028b.p089n.C3713e;
import p002b.p011c.p110d.p149q.p152b.p157e.C4445a;
import p002b.p011c.p110d.p149q.p152b.p158f.C4449a;
import p168c.p169a.C4708e;
import p176d.p195e.p201b.C5428o1;
import p257h.p265p.p267b.C5910g;

/* renamed from: b.a.a.c.c */
public final class C0117c<TResult> implements C3713e<List<C4449a>> {

    /* renamed from: a */
    public final /* synthetic */ C4708e f731a;

    /* renamed from: b */
    public final /* synthetic */ C4445a f732b;

    /* renamed from: c */
    public final /* synthetic */ C0119e f733c;

    public C0117c(C4708e eVar, C4445a aVar, C0119e eVar2, C5428o1 o1Var) {
        this.f731a = eVar;
        this.f732b = aVar;
        this.f733c = eVar2;
    }

    /* renamed from: a */
    public void mo873a(Object obj) {
        List list = (List) obj;
        C5910g.m17226b(list, "it");
        ArrayList arrayList = new ArrayList();
        for (Object next : list) {
            C4449a aVar = (C4449a) next;
            if (aVar.f16648a.width() >= this.f733c.f736b.f725b && aVar.f16648a.height() >= this.f733c.f736b.f725b) {
                arrayList.add(next);
            }
        }
        C4708e eVar = this.f731a;
        Bitmap c = this.f732b.mo8787c();
        C5910g.m17226b(c, "image.bitmap");
        eVar.mo9459f(new C0116b(c, arrayList));
    }
}
