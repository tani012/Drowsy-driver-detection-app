package p002b.p003a.p004a.p007c;

import android.util.Size;
import p002b.p008b.p009a.p010a.C0131a;

/* renamed from: b.a.a.c.a */
public final class C0115a {

    /* renamed from: a */
    public final Size f724a;

    /* renamed from: b */
    public final int f725b;

    /* renamed from: c */
    public final int f726c;

    /* renamed from: d */
    public final int f727d;

    /* renamed from: e */
    public final int f728e;

    public C0115a() {
        this(0, 0, 0, 0, 15);
    }

    public C0115a(int i, int i2, int i3, int i4, int i5) {
        i = (i5 & 1) != 0 ? 300 : i;
        i2 = (i5 & 2) != 0 ? 720 : i2;
        i3 = (i5 & 4) != 0 ? 1280 : i3;
        i4 = (i5 & 8) != 0 ? 0 : i4;
        this.f725b = i;
        this.f726c = i2;
        this.f727d = i3;
        this.f728e = i4;
        this.f724a = new Size(this.f726c, this.f727d);
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof C0115a)) {
            return false;
        }
        C0115a aVar = (C0115a) obj;
        return this.f725b == aVar.f725b && this.f726c == aVar.f726c && this.f727d == aVar.f727d && this.f728e == aVar.f728e;
    }

    public int hashCode() {
        int hashCode = Integer.hashCode(this.f726c);
        int hashCode2 = Integer.hashCode(this.f727d);
        return Integer.hashCode(this.f728e) + ((hashCode2 + ((hashCode + (Integer.hashCode(this.f725b) * 31)) * 31)) * 31);
    }

    public String toString() {
        StringBuilder m = C0131a.m379m("CameraConfiguration(minBoundingBox=");
        m.append(this.f725b);
        m.append(", with=");
        m.append(this.f726c);
        m.append(", height=");
        m.append(this.f727d);
        m.append(", facingLen=");
        m.append(this.f728e);
        m.append(")");
        return m.toString();
    }
}
