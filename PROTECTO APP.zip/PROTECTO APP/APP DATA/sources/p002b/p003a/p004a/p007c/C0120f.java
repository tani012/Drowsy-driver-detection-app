package p002b.p003a.p004a.p007c;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.CornerPathEffect;
import android.graphics.Paint;
import com.galaxylab.drowsydriver.p173AI.GraphicOverlay;
import p002b.p011c.p110d.p149q.p152b.p158f.C4449a;

/* renamed from: b.a.a.c.f */
public final class C0120f extends GraphicOverlay.C4784a {

    /* renamed from: b */
    public final Paint f737b;

    /* renamed from: c */
    public final C4449a f738c;

    public C0120f(GraphicOverlay graphicOverlay, C4449a aVar, int i, Bitmap bitmap) {
        super(graphicOverlay);
        this.f738c = aVar;
        new Paint().setColor(-1);
        Paint paint = new Paint();
        paint.setColor(-1);
        paint.setTextSize(50.0f);
        Paint paint2 = new Paint();
        paint2.setColor(-16711936);
        paint2.setStyle(Paint.Style.STROKE);
        paint2.setStrokeWidth(25.0f);
        paint2.setStrokeJoin(Paint.Join.ROUND);
        paint2.setStrokeCap(Paint.Cap.ROUND);
        paint2.setPathEffect(new CornerPathEffect(45.0f));
        this.f737b = paint2;
    }

    /* renamed from: a */
    public void mo875a(Canvas canvas) {
        C4449a aVar = this.f738c;
        if (aVar != null) {
            float centerX = (float) aVar.f16648a.centerX();
            GraphicOverlay graphicOverlay = this.f17325a;
            float width = graphicOverlay.f17318e == 0 ? ((float) graphicOverlay.getWidth()) - (this.f17325a.getWidthScaleFactor() * centerX) : graphicOverlay.getWidthScaleFactor() * centerX;
            float heightScaleFactor = this.f17325a.getHeightScaleFactor() * ((float) aVar.f16648a.centerY());
            float b = mo9593b(((float) aVar.f16648a.width()) / 2.0f);
            float heightScaleFactor2 = this.f17325a.getHeightScaleFactor() * (((float) aVar.f16648a.height()) / 2.0f);
            canvas.drawRect(width - b, heightScaleFactor - heightScaleFactor2, width + b, heightScaleFactor + heightScaleFactor2, this.f737b);
        }
    }
}
