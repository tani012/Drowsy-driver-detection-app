package p002b.p003a.p004a.p007c;

import android.graphics.Bitmap;
import java.util.List;
import p002b.p008b.p009a.p010a.C0131a;
import p002b.p011c.p110d.p149q.p152b.p158f.C4449a;
import p257h.p265p.p267b.C5910g;

/* renamed from: b.a.a.c.b */
public final class C0116b {

    /* renamed from: a */
    public final Bitmap f729a;

    /* renamed from: b */
    public final List<C4449a> f730b;

    public C0116b(Bitmap bitmap, List<? extends C4449a> list) {
        this.f729a = bitmap;
        this.f730b = list;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof C0116b)) {
            return false;
        }
        C0116b bVar = (C0116b) obj;
        return C5910g.m17225a(this.f729a, bVar.f729a) && C5910g.m17225a(this.f730b, bVar.f730b);
    }

    public int hashCode() {
        Bitmap bitmap = this.f729a;
        int i = 0;
        int hashCode = (bitmap != null ? bitmap.hashCode() : 0) * 31;
        List<C4449a> list = this.f730b;
        if (list != null) {
            i = list.hashCode();
        }
        return hashCode + i;
    }

    public String toString() {
        StringBuilder m = C0131a.m379m("DetectedFaces(bitmap=");
        m.append(this.f729a);
        m.append(", listFaces=");
        m.append(this.f730b);
        m.append(")");
        return m.toString();
    }
}
