package p002b.p003a.p004a.p007c;

import p002b.p011c.p110d.p149q.p152b.C4440a;
import p002b.p011c.p110d.p149q.p152b.p158f.C4451c;
import p002b.p011c.p110d.p149q.p152b.p158f.C4452d;
import p002b.p011c.p110d.p149q.p152b.p158f.C4454f;
import p176d.p178b.p179k.C4851q;
import p257h.p265p.p267b.C5910g;

/* renamed from: b.a.a.c.e */
public final class C0119e {

    /* renamed from: a */
    public final C4451c f735a;

    /* renamed from: b */
    public final C0115a f736b;

    public C0119e(C0115a aVar) {
        if (aVar != null) {
            this.f736b = aVar;
            C4452d dVar = new C4452d(1, 1, 2, 1, true, 0.5f, (C4454f) null);
            C5910g.m17226b(dVar, "FirebaseVisionFaceDetect…\n                .build()");
            C4440a a = C4440a.m13909a();
            if (a != null) {
                C4851q.C4862i.m15173u(dVar, "Please provide a valid FirebaseVisionFaceDetectorOptions");
                C4451c a2 = C4451c.m13914a(a.f16630a, dVar);
                C5910g.m17226b(a2, "FirebaseVision.getInstan…VisionFaceDetector(build)");
                this.f735a = a2;
                return;
            }
            throw null;
        }
        C5910g.m17230f("cameraConfiguration");
        throw null;
    }
}
