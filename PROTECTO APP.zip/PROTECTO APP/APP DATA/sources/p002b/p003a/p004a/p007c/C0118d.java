package p002b.p003a.p004a.p007c;

import p002b.p011c.p015b.p028b.p089n.C3711d;
import p002b.p011c.p110d.p117i.p118e.p121k.C4102r0;
import p168c.p169a.C4708e;
import p257h.p265p.p267b.C5910g;

/* renamed from: b.a.a.c.d */
public final class C0118d implements C3711d {

    /* renamed from: a */
    public final /* synthetic */ C4708e f734a;

    public C0118d(C4708e eVar) {
        this.f734a = eVar;
    }

    /* renamed from: b */
    public final void mo874b(Exception exc) {
        if (exc != null) {
            this.f734a.mo9459f(C4102r0.m13486r(exc));
        } else {
            C5910g.m17230f("it");
            throw null;
        }
    }
}
