package p002b.p003a.p004a;

import p002b.p003a.p004a.p006b.C0104b;
import p257h.p265p.p266a.C5895p;
import p257h.p265p.p267b.C5910g;
import p257h.p265p.p267b.C5911h;
import p285k.p286a.p293c.p300m.C6154a;
import p285k.p286a.p293c.p303p.C6159a;

/* renamed from: b.a.a.g */
public final class C0124g extends C5911h implements C5895p<C6159a, C6154a, C0104b> {

    /* renamed from: f */
    public static final C0124g f749f = new C0124g();

    public C0124g() {
        super(2);
    }

    /* renamed from: d */
    public Object mo844d(Object obj, Object obj2) {
        C6154a aVar = (C6154a) obj2;
        if (((C6159a) obj) == null) {
            C5910g.m17230f("$receiver");
            throw null;
        } else if (aVar != null) {
            return new C0104b();
        } else {
            C5910g.m17230f("it");
            throw null;
        }
    }
}
