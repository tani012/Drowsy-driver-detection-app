package p002b.p003a.p004a.p005a;

import p002b.p011c.p015b.p028b.p029a.C0297c;
import p002b.p011c.p015b.p028b.p029a.C0310k;
import p002b.p011c.p015b.p028b.p029a.C0311l;
import p305l.p306a.C6163a;

/* renamed from: b.a.a.a.d */
public final class C0094d extends C0297c {

    /* renamed from: a */
    public final /* synthetic */ C0310k f659a;

    public C0094d(C0310k kVar) {
        this.f659a = kVar;
    }

    /* renamed from: c */
    public void mo839c(C0311l lVar) {
        if (lVar != null) {
            C6163a.f21190d.mo12746f(lVar.f1103a, new Object[0]);
        }
    }

    /* renamed from: f */
    public void mo840f() {
        this.f659a.mo1057e();
        C6163a.f21190d.mo12743a("show ads", new Object[0]);
    }
}
