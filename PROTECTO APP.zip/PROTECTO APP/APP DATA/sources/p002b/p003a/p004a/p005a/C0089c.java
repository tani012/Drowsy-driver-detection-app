package p002b.p003a.p004a.p005a;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.appcompat.widget.AppCompatImageButton;
import androidx.appcompat.widget.AppCompatImageView;
import androidx.fragment.app.Fragment;
import com.galaxylab.drowsydriver.R;
import com.galaxylab.drowsydriver.p173AI.GraphicOverlay;
import java.util.HashMap;
import p002b.p003a.p004a.C0130m;
import p002b.p003a.p004a.p007c.C0115a;
import p002b.p003a.p004a.p007c.C0116b;
import p002b.p003a.p004a.p007c.C0120f;
import p002b.p011c.p015b.p028b.p029a.C0301d0;
import p002b.p011c.p015b.p028b.p029a.C0302e;
import p002b.p011c.p015b.p028b.p029a.C0310k;
import p002b.p011c.p107c.p108a.p109a.C3973a;
import p002b.p011c.p110d.p117i.p118e.p121k.C4102r0;
import p002b.p011c.p110d.p149q.p152b.p158f.C4449a;
import p176d.p195e.p201b.p202h2.p203i1.p205d.C5313e;
import p176d.p195e.p207c.C5474c;
import p176d.p219i.p221d.C5600a;
import p176d.p238l.p239d.C5721e;
import p176d.p238l.p239d.C5752q0;
import p176d.p242n.C5792m;
import p176d.p242n.C5793n;
import p176d.p242n.C5806u;
import p257h.C5834d;
import p257h.C5843l;
import p257h.p265p.p266a.C5880a;
import p257h.p265p.p267b.C5910g;
import p257h.p265p.p267b.C5911h;
import p257h.p265p.p267b.C5912i;
import p285k.p286a.p293c.p300m.C6154a;
import p285k.p286a.p293c.p301n.C6155a;
import p305l.p306a.C6163a;

/* renamed from: b.a.a.a.c */
public final class C0089c extends Fragment {

    /* renamed from: Y */
    public final C0115a f647Y = ((C0115a) C4102r0.m13448W(this).f21117a.mo12730c().mo12732a(C5912i.m17233a(C0115a.class), (C6155a) null, (C5880a<C6154a>) null));

    /* renamed from: Z */
    public final SharedPreferences f648Z = ((SharedPreferences) C4102r0.m13448W(this).f21117a.mo12730c().mo12732a(C5912i.m17233a(SharedPreferences.class), (C6155a) null, (C5880a<C6154a>) null));

    /* renamed from: a0 */
    public final C5834d f649a0 = new C5843l(new C0090a(this, (C6155a) null, (C5880a) null));

    /* renamed from: b0 */
    public final String f650b0 = "LAST_TIME_SHOW_ADS";

    /* renamed from: c0 */
    public final int f651c0 = 300000;

    /* renamed from: d0 */
    public HashMap f652d0;

    /* renamed from: b.a.a.a.c$a */
    public static final class C0090a extends C5911h implements C5880a<C0096f> {

        /* renamed from: f */
        public final /* synthetic */ C5806u f653f;

        /* renamed from: g */
        public final /* synthetic */ C6155a f654g = null;

        /* renamed from: h */
        public final /* synthetic */ C5880a f655h = null;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        public C0090a(C5806u uVar, C6155a aVar, C5880a aVar2) {
            super(0);
            this.f653f = uVar;
        }

        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r3v1, resolved type: k.a.b.a.c} */
        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r3v2, resolved type: k.a.b.a.a} */
        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r3v3, resolved type: k.a.b.a.c} */
        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r6v5, resolved type: k.a.b.a.c} */
        /* JADX WARNING: Multi-variable type inference failed */
        /* renamed from: b */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public java.lang.Object mo836b() {
            /*
                r13 = this;
                d.n.u r0 = r13.f653f
                java.lang.Class<b.a.a.a.f> r1 = p002b.p003a.p004a.p005a.C0096f.class
                h.s.a r3 = p257h.p265p.p267b.C5912i.m17233a(r1)
                k.a.c.n.a r4 = r13.f654g
                h.p.a.a r5 = r13.f655h
                java.lang.String r1 = "$this$getViewModel"
                r2 = 0
                if (r0 == 0) goto L_0x007e
                r6 = r0
                android.content.ComponentCallbacks r6 = (android.content.ComponentCallbacks) r6
                k.a.c.a r6 = p002b.p011c.p110d.p117i.p118e.p121k.C4102r0.m13448W(r6)
                if (r6 == 0) goto L_0x007a
                k.a.c.o.b r1 = r6.f21117a
                k.a.c.p.a r1 = r1.mo12730c()
                k.a.b.a.d r12 = new k.a.b.a.d
                r6 = 0
                d.n.t r7 = r0.mo4i()
                java.lang.String r0 = "owner.viewModelStore"
                p257h.p265p.p267b.C5910g.m17226b(r7, r0)
                r8 = 0
                r2 = r12
                r2.<init>(r3, r4, r5, r6, r7, r8)
                d.n.s r0 = new d.n.s
                d.n.t r2 = r12.f21115e
                android.os.Bundle r11 = r12.f21114d
                if (r11 == 0) goto L_0x0053
                d.p.c r10 = r12.f21116f
                if (r10 == 0) goto L_0x0047
                k.a.b.a.c r3 = new k.a.b.a.c
                r6 = r3
                r7 = r1
                r8 = r12
                r9 = r10
                r6.<init>(r7, r8, r9, r10, r11)
                goto L_0x0058
            L_0x0047:
                java.lang.IllegalStateException r0 = new java.lang.IllegalStateException
                java.lang.String r1 = "Can't create SavedStateViewModelFactory without a proper stateRegistryOwner"
                java.lang.String r1 = r1.toString()
                r0.<init>(r1)
                throw r0
            L_0x0053:
                k.a.b.a.a r3 = new k.a.b.a.a
                r3.<init>(r1, r12)
            L_0x0058:
                r0.<init>(r2, r3)
                h.s.a<T> r1 = r12.f21111a
                java.lang.Class r1 = p002b.p011c.p110d.p117i.p118e.p121k.C4102r0.m13446U(r1)
                k.a.c.n.a r2 = r12.f21112b
                if (r2 == 0) goto L_0x0070
                java.lang.String r2 = java.lang.String.valueOf(r2)
                d.n.r r0 = r0.mo12147b(r2, r1)
                java.lang.String r1 = "get(qualifier.toString(), javaClass)"
                goto L_0x0076
            L_0x0070:
                d.n.r r0 = r0.mo12146a(r1)
                java.lang.String r1 = "get(javaClass)"
            L_0x0076:
                p257h.p265p.p267b.C5910g.m17226b(r0, r1)
                return r0
            L_0x007a:
                p257h.p265p.p267b.C5910g.m17230f(r1)
                throw r2
            L_0x007e:
                p257h.p265p.p267b.C5910g.m17230f(r1)
                throw r2
            */
            throw new UnsupportedOperationException("Method not decompiled: p002b.p003a.p004a.p005a.C0089c.C0090a.mo836b():java.lang.Object");
        }
    }

    /* renamed from: b.a.a.a.c$b */
    public static final class C0091b<T> implements C5793n<C0116b> {

        /* renamed from: a */
        public final /* synthetic */ C0089c f656a;

        public C0091b(C0089c cVar) {
            this.f656a = cVar;
        }

        /* renamed from: a */
        public void mo837a(Object obj) {
            C0116b bVar = (C0116b) obj;
            C0089c cVar = this.f656a;
            C5910g.m17226b(bVar, "it");
            GraphicOverlay graphicOverlay = (GraphicOverlay) cVar.mo834Y(C0130m.graphicOverlay);
            synchronized (graphicOverlay.f17321h) {
                graphicOverlay.f17319f.clear();
            }
            graphicOverlay.postInvalidate();
            for (C4449a fVar : bVar.f730b) {
                GraphicOverlay graphicOverlay2 = (GraphicOverlay) cVar.mo834Y(C0130m.graphicOverlay);
                GraphicOverlay graphicOverlay3 = (GraphicOverlay) cVar.mo834Y(C0130m.graphicOverlay);
                C5910g.m17226b(graphicOverlay3, "this.graphicOverlay");
                C0120f fVar2 = new C0120f(graphicOverlay3, fVar, 1, (Bitmap) null);
                synchronized (graphicOverlay2.f17321h) {
                    graphicOverlay2.f17319f.add(fVar2);
                }
            }
            ((GraphicOverlay) cVar.mo834Y(C0130m.graphicOverlay)).invalidate();
        }
    }

    /* renamed from: b.a.a.a.c$c */
    public static final class C0092c<T> implements C5793n<Boolean> {

        /* renamed from: a */
        public final /* synthetic */ C0089c f657a;

        public C0092c(C0089c cVar) {
            this.f657a = cVar;
        }

        /* renamed from: a */
        public void mo837a(Object obj) {
            Boolean bool = (Boolean) obj;
            AppCompatImageView appCompatImageView = (AppCompatImageView) this.f657a.mo834Y(C0130m.alertImage);
            C5910g.m17226b(appCompatImageView, "alertImage");
            C5910g.m17226b(bool, "it");
            appCompatImageView.setVisibility(bool.booleanValue() ? 0 : 8);
        }
    }

    /* renamed from: b.a.a.a.c$d */
    public static final class C0093d implements View.OnClickListener {

        /* renamed from: e */
        public final /* synthetic */ C0089c f658e;

        public C0093d(C0089c cVar) {
            this.f658e = cVar;
        }

        public final void onClick(View view) {
            C5721e g = this.f658e.mo787g();
            if (g != null) {
                g.enterPictureInPictureMode();
            }
        }
    }

    /* renamed from: A */
    public View mo759A(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        if (layoutInflater != null) {
            return layoutInflater.inflate(R.layout.fragment_camera, viewGroup, false);
        }
        C5910g.m17230f("inflater");
        throw null;
    }

    /* renamed from: B */
    public void mo760B() {
        this.f548H = true;
        HashMap hashMap = this.f652d0;
        if (hashMap != null) {
            hashMap.clear();
        }
    }

    /* renamed from: F */
    public void mo764F(boolean z) {
        AppCompatImageButton appCompatImageButton = (AppCompatImageButton) mo834Y(C0130m.PIPBtn);
        C5910g.m17226b(appCompatImageButton, "PIPBtn");
        appCompatImageButton.setVisibility(z ? 8 : 0);
    }

    /* renamed from: K */
    public void mo769K(View view, Bundle bundle) {
        if (view != null) {
            C6163a.f21190d.mo12743a("start camera", new Object[0]);
            Context k = mo791k();
            if (k != null) {
                C3973a<C5474c> b = C5474c.m16416b(k);
                C5910g.m17226b(b, "ProcessCameraProvider.getInstance(context!!)");
                ((C5313e) b).f18974e.mo8323h(new C0095e(this, b), C5600a.m16740d(mo791k()));
                C5792m<C0116b> mVar = mo835Z().f666h;
                C5752q0 q0Var = this.f561U;
                if (q0Var != null) {
                    mVar.mo813d(q0Var, new C0091b(this));
                    C5792m<Boolean> mVar2 = mo835Z().f667i;
                    C5752q0 q0Var2 = this.f561U;
                    if (q0Var2 != null) {
                        mVar2.mo813d(q0Var2, new C0092c(this));
                        ((AppCompatImageButton) mo834Y(C0130m.PIPBtn)).setOnClickListener(new C0093d(this));
                        long currentTimeMillis = System.currentTimeMillis();
                        if (currentTimeMillis >= this.f648Z.getLong(this.f650b0, ((long) this.f651c0) + currentTimeMillis)) {
                            this.f648Z.edit().putLong(this.f650b0, currentTimeMillis + ((long) this.f651c0)).apply();
                            C0310k kVar = new C0310k(mo791k());
                            kVar.mo1055c("ca-app-pub-2331141815165218/4762723623");
                            kVar.mo1054b(new C0094d(kVar));
                            kVar.mo1053a(new C0302e(new C0302e.C0303a(), (C0301d0) null));
                            return;
                        }
                        return;
                    }
                    throw new IllegalStateException("Can't access the Fragment View's LifecycleOwner when getView() is null i.e., before onCreateView() or after onDestroyView()");
                }
                throw new IllegalStateException("Can't access the Fragment View's LifecycleOwner when getView() is null i.e., before onCreateView() or after onDestroyView()");
            }
            C5910g.m17229e();
            throw null;
        }
        C5910g.m17230f("view");
        throw null;
    }

    /* renamed from: Y */
    public View mo834Y(int i) {
        if (this.f652d0 == null) {
            this.f652d0 = new HashMap();
        }
        View view = (View) this.f652d0.get(Integer.valueOf(i));
        if (view != null) {
            return view;
        }
        View view2 = this.f550J;
        if (view2 == null) {
            return null;
        }
        View findViewById = view2.findViewById(i);
        this.f652d0.put(Integer.valueOf(i), findViewById);
        return findViewById;
    }

    /* renamed from: Z */
    public final C0096f mo835Z() {
        return (C0096f) this.f649a0.getValue();
    }
}
