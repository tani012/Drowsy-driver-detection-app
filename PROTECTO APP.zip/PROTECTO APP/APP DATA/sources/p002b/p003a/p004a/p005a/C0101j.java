package p002b.p003a.p004a.p005a;

import android.view.MenuItem;
import android.widget.PopupMenu;
import com.galaxylab.drowsydriver.R;
import p002b.p003a.p004a.p006b.C0114l;
import p176d.p238l.p239d.C5721e;
import p257h.p265p.p267b.C5910g;

/* renamed from: b.a.a.a.j */
public final class C0101j implements PopupMenu.OnMenuItemClickListener {

    /* renamed from: a */
    public final /* synthetic */ C0085a f681a;

    public C0101j(C0085a aVar) {
        this.f681a = aVar;
    }

    public final boolean onMenuItemClick(MenuItem menuItem) {
        C5721e eVar;
        C0114l lVar;
        C5910g.m17226b(menuItem, "it");
        switch (menuItem.getItemId()) {
            case R.id.menuFeedback /*2131230858*/:
                C0085a aVar = this.f681a;
                C0114l lVar2 = aVar.f639Z;
                C5721e g = aVar.mo787g();
                if (g != null) {
                    C5910g.m17226b(g, "activity!!");
                    lVar2.mo864b(g);
                    return false;
                }
                C5910g.m17229e();
                throw null;
            case R.id.menuMoreApp /*2131230859*/:
                C0085a aVar2 = this.f681a;
                C0114l lVar3 = aVar2.f639Z;
                C5721e g2 = aVar2.mo787g();
                if (g2 != null) {
                    C5910g.m17226b(g2, "activity!!");
                    lVar3.mo865c(g2, lVar3.f712f, lVar3.f711e);
                    return false;
                }
                C5910g.m17229e();
                throw null;
            case R.id.menuRate /*2131230860*/:
                C0085a aVar3 = this.f681a;
                lVar = aVar3.f639Z;
                eVar = aVar3.mo787g();
                if (eVar == null) {
                    C5910g.m17229e();
                    throw null;
                }
                break;
            case R.id.menuShare /*2131230861*/:
                C0085a aVar4 = this.f681a;
                C0114l lVar4 = aVar4.f639Z;
                C5721e g3 = aVar4.mo787g();
                if (g3 != null) {
                    lVar4.mo866d(g3);
                    return false;
                }
                C5910g.m17229e();
                throw null;
            case R.id.menuUpdate /*2131230862*/:
                C0085a aVar5 = this.f681a;
                lVar = aVar5.f639Z;
                eVar = aVar5.mo787g();
                if (eVar == null) {
                    C5910g.m17229e();
                    throw null;
                }
                break;
            default:
                return false;
        }
        C5910g.m17226b(eVar, "activity!!");
        lVar.mo863a(eVar);
        return false;
    }
}
