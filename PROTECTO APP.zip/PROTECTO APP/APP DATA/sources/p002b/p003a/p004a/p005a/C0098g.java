package p002b.p003a.p004a.p005a;

import java.util.Map;
import p002b.p008b.p009a.p010a.C0131a;
import p002b.p011c.p015b.p028b.p029a.p038w.C0353a;
import p002b.p011c.p015b.p028b.p029a.p038w.C0355b;
import p002b.p011c.p015b.p028b.p029a.p038w.C0356c;
import p257h.p265p.p267b.C5910g;
import p305l.p306a.C6163a;

/* renamed from: b.a.a.a.g */
public final class C0098g implements C0356c {

    /* renamed from: a */
    public static final C0098g f677a = new C0098g();

    /* renamed from: a */
    public final void mo846a(C0355b bVar) {
        StringBuilder sb = new StringBuilder();
        sb.append("admob init status ");
        C5910g.m17226b(bVar, "it");
        sb.append(bVar.mo1151a().size());
        C6163a.f21190d.mo12743a(sb.toString(), new Object[0]);
        for (Map.Entry value : bVar.mo1151a().entrySet()) {
            StringBuilder m = C0131a.m379m("admob entry ");
            Object value2 = value.getValue();
            C5910g.m17226b(value2, "entry.value");
            m.append(((C0353a) value2).mo1150k0());
            C6163a.f21190d.mo12743a(m.toString(), new Object[0]);
        }
    }
}
