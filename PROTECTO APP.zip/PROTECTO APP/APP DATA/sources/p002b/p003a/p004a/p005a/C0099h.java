package p002b.p003a.p004a.p005a;

import android.content.res.AssetFileDescriptor;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.view.View;
import android.widget.AdapterView;
import java.util.Map;
import p002b.p003a.p004a.C0121d;
import p257h.p265p.p267b.C5910g;
import p305l.p306a.C6163a;

/* renamed from: b.a.a.a.h */
public final class C0099h implements AdapterView.OnItemSelectedListener {

    /* renamed from: e */
    public final /* synthetic */ C0085a f678e;

    /* renamed from: f */
    public final /* synthetic */ Map f679f;

    public C0099h(C0085a aVar, Map map) {
        this.f678e = aVar;
        this.f679f = map;
    }

    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long j) {
        AssetFileDescriptor assetFileDescriptor;
        String valueOf = String.valueOf(adapterView != null ? adapterView.getItemAtPosition(i) : null);
        C6163a.f21190d.mo12743a("select " + valueOf + " to " + ((String) this.f679f.get(valueOf)), new Object[0]);
        C0121d dVar = this.f678e.f638Y;
        String str = (String) this.f679f.get(valueOf);
        if (str == null) {
            throw new IllegalStateException("cannot find sound URI".toString());
        } else if (dVar != null) {
            try {
                assetFileDescriptor = dVar.f744f.getAssets().openFd(str);
                C5910g.m17226b(assetFileDescriptor, "applicationContext.assets.openFd(sound)");
            } catch (Exception e) {
                C6163a.f21190d.mo12745c(e);
                assetFileDescriptor = dVar.f744f.getAssets().openFd(dVar.f743e);
                C5910g.m17226b(assetFileDescriptor, "applicationContext.assets.openFd(DEAULT_SOUND)");
            }
            MediaPlayer mediaPlayer = new MediaPlayer();
            dVar.f739a = mediaPlayer;
            mediaPlayer.setDataSource(assetFileDescriptor.getFileDescriptor(), assetFileDescriptor.getStartOffset(), assetFileDescriptor.getLength());
            MediaPlayer mediaPlayer2 = dVar.f739a;
            if (mediaPlayer2 != null) {
                mediaPlayer2.prepare();
                MediaPlayer mediaPlayer3 = dVar.f739a;
                if (mediaPlayer3 != null) {
                    mediaPlayer3.setAudioAttributes(new AudioAttributes.Builder().setLegacyStreamType(dVar.f741c).build());
                    dVar.f745g.edit().putString(dVar.f742d, str).apply();
                    return;
                }
                C5910g.m17231g("mediaPlayer");
                throw null;
            }
            C5910g.m17231g("mediaPlayer");
            throw null;
        } else {
            throw null;
        }
    }

    public void onNothingSelected(AdapterView<?> adapterView) {
    }
}
