package p002b.p003a.p004a.p005a;

import android.widget.SeekBar;
import p002b.p003a.p004a.C0121d;
import p305l.p306a.C6163a;

/* renamed from: b.a.a.a.i */
public final class C0100i implements SeekBar.OnSeekBarChangeListener {

    /* renamed from: a */
    public final /* synthetic */ C0085a f680a;

    public C0100i(C0085a aVar) {
        this.f680a = aVar;
    }

    public void onProgressChanged(SeekBar seekBar, int i, boolean z) {
        C0121d dVar = this.f680a.f638Y;
        dVar.f740b.setStreamVolume(dVar.f741c, i, 0);
        C6163a.f21190d.mo12743a("setOnSeekBarChangeListener " + i, new Object[0]);
    }

    public void onStartTrackingTouch(SeekBar seekBar) {
    }

    public void onStopTrackingTouch(SeekBar seekBar) {
    }
}
