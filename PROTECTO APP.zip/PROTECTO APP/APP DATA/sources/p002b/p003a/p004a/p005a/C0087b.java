package p002b.p003a.p004a.p005a;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;
import androidx.appcompat.widget.AppCompatButton;
import androidx.fragment.app.Fragment;
import com.galaxylab.drowsydriver.R;
import com.galaxylab.drowsydriver.p174UI.MainActivity;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import p002b.p003a.p004a.C0130m;
import p002b.p003a.p004a.p006b.C0107e;
import p002b.p011c.p110d.p117i.p118e.p121k.C4102r0;
import p176d.p219i.p220c.C5578a;
import p176d.p238l.p239d.C5721e;
import p257h.C5839h;
import p257h.p265p.p266a.C5880a;
import p257h.p265p.p267b.C5910g;
import p257h.p265p.p267b.C5912i;
import p285k.p286a.p293c.p300m.C6154a;
import p285k.p286a.p293c.p301n.C6155a;
import p305l.p306a.C6163a;

/* renamed from: b.a.a.a.b */
public final class C0087b extends Fragment {

    /* renamed from: Y */
    public final C0107e f643Y = ((C0107e) C4102r0.m13448W(this).f21117a.mo12730c().mo12732a(C5912i.m17233a(C0107e.class), (C6155a) null, (C5880a<C6154a>) null));

    /* renamed from: Z */
    public HashMap f644Z;

    /* renamed from: b.a.a.a.b$a */
    /* compiled from: java-style lambda group */
    public static final class C0088a implements View.OnClickListener {

        /* renamed from: e */
        public final /* synthetic */ int f645e;

        /* renamed from: f */
        public final /* synthetic */ Object f646f;

        public C0088a(int i, Object obj) {
            this.f645e = i;
            this.f646f = obj;
        }

        public final void onClick(View view) {
            int i = this.f645e;
            if (i == 0) {
                C0087b bVar = (C0087b) this.f646f;
                C0107e eVar = bVar.f643Y;
                C5721e g = bVar.mo787g();
                if (g != null) {
                    C5910g.m17226b(g, "activity!!");
                    if (eVar != null) {
                        Intent intent = new Intent();
                        intent.setAction("android.settings.APPLICATION_DETAILS_SETTINGS");
                        intent.setData(Uri.fromParts("package", g.getPackageName(), (String) null));
                        g.startActivityForResult(intent, eVar.f694c);
                        C6163a.f21190d.mo12743a("openAppSetting", new Object[0]);
                        return;
                    }
                    throw null;
                }
                C5910g.m17229e();
                throw null;
            } else if (i != 1) {
                throw null;
            } else if (!((C0087b) this.f646f).f643Y.mo855a()) {
                Toast.makeText(((C0087b) this.f646f).mo791k(), R.string.permission_requires, 1).show();
            } else {
                C5721e g2 = ((C0087b) this.f646f).mo787g();
                if (g2 != null) {
                    ((MainActivity) g2).mo9595u();
                    return;
                }
                throw new C5839h("null cannot be cast to non-null type com.galaxylab.drowsydriver.UI.MainActivity");
            }
        }
    }

    /* renamed from: A */
    public View mo759A(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        if (layoutInflater != null) {
            return layoutInflater.inflate(R.layout.fragment_permission, viewGroup, false);
        }
        C5910g.m17230f("inflater");
        throw null;
    }

    /* renamed from: B */
    public void mo760B() {
        this.f548H = true;
        HashMap hashMap = this.f644Z;
        if (hashMap != null) {
            hashMap.clear();
        }
    }

    /* renamed from: K */
    public void mo769K(View view, Bundle bundle) {
        if (view != null) {
            C0107e eVar = this.f643Y;
            C5721e g = mo787g();
            if (g != null) {
                C5910g.m17226b(g, "activity!!");
                List<String> list = eVar.f692a;
                ArrayList arrayList = new ArrayList();
                for (T next : list) {
                    if (true ^ eVar.mo856b(g, (String) next)) {
                        arrayList.add(next);
                    }
                }
                List A0 = C4102r0.m13419A0(arrayList);
                if (!A0.isEmpty()) {
                    Object[] array = A0.toArray(new String[0]);
                    if (array != null) {
                        C5578a.m16721k(g, (String[]) array, eVar.f694c);
                    } else {
                        throw new C5839h("null cannot be cast to non-null type kotlin.Array<T>");
                    }
                }
                ((AppCompatButton) mo832Y(C0130m.permissionBtn)).setOnClickListener(new C0088a(0, this));
                ((AppCompatButton) mo832Y(C0130m.startBtn)).setOnClickListener(new C0088a(1, this));
                return;
            }
            C5910g.m17229e();
            throw null;
        }
        C5910g.m17230f("view");
        throw null;
    }

    /* renamed from: Y */
    public View mo832Y(int i) {
        if (this.f644Z == null) {
            this.f644Z = new HashMap();
        }
        View view = (View) this.f644Z.get(Integer.valueOf(i));
        if (view != null) {
            return view;
        }
        View view2 = this.f550J;
        if (view2 == null) {
            return null;
        }
        View findViewById = view2.findViewById(i);
        this.f644Z.put(Integer.valueOf(i), findViewById);
        return findViewById;
    }
}
