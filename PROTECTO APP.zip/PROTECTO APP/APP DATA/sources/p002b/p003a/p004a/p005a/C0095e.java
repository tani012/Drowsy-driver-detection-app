package p002b.p003a.p004a.p005a;

import p002b.p011c.p107c.p108a.p109a.C3973a;

/* renamed from: b.a.a.a.e */
public final class C0095e implements Runnable {

    /* renamed from: e */
    public final /* synthetic */ C0089c f660e;

    /* renamed from: f */
    public final /* synthetic */ C3973a f661f;

    public C0095e(C0089c cVar, C3973a aVar) {
        this.f660e = cVar;
        this.f661f = aVar;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:52:0x01af, code lost:
        r0 = move-exception;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:53:0x01b0, code lost:
        p305l.p306a.C6163a.f21190d.mo12745c(r0);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:64:?, code lost:
        return;
     */
    /* JADX WARNING: Exception block dominator not found, dom blocks: [] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void run() {
        /*
            r15 = this;
            d.e.b.h2.c0$c r0 = p176d.p195e.p201b.p202h2.C5262c0.C5265c.OPTIONAL
            b.c.c.a.a.a r1 = r15.f661f
            java.lang.Object r1 = r1.get()
            d.e.c.c r1 = (p176d.p195e.p207c.C5474c) r1
            d.e.b.u1$c r2 = new d.e.b.u1$c
            d.e.b.h2.u0 r3 = p176d.p195e.p201b.p202h2.C5364u0.m16215A()
            r2.<init>(r3)
            b.a.a.a.c r3 = r15.f660e
            b.a.a.c.a r3 = r3.f647Y
            android.util.Size r3 = r3.f724a
            d.e.b.h2.u0 r4 = r2.f19230a
            d.e.b.h2.c0$a<android.util.Size> r5 = p176d.p195e.p201b.p202h2.C5334l0.f19012g
            r4.mo11246C(r5, r0, r3)
            if (r3 == 0) goto L_0x0036
            d.e.b.h2.u0 r4 = r2.f19230a
            d.e.b.h2.c0$a<android.util.Rational> r5 = p176d.p195e.p201b.p202h2.C5334l0.f19009d
            android.util.Rational r6 = new android.util.Rational
            int r7 = r3.getWidth()
            int r3 = r3.getHeight()
            r6.<init>(r7, r3)
            r4.mo11246C(r5, r0, r6)
        L_0x0036:
            d.e.b.h2.u0 r3 = r2.f19230a
            d.e.b.h2.c0$a<java.lang.Integer> r4 = p176d.p195e.p201b.p202h2.C5334l0.f19010e
            r5 = 0
            java.lang.Object r3 = r3.mo11123g(r4, r5)
            if (r3 == 0) goto L_0x0054
            d.e.b.h2.u0 r3 = r2.f19230a
            d.e.b.h2.c0$a<android.util.Size> r4 = p176d.p195e.p201b.p202h2.C5334l0.f19012g
            java.lang.Object r3 = r3.mo11123g(r4, r5)
            if (r3 != 0) goto L_0x004c
            goto L_0x0054
        L_0x004c:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r1 = "Cannot use both setTargetResolution and setTargetAspectRatio on the same config."
            r0.<init>(r1)
            throw r0
        L_0x0054:
            d.e.b.h2.u0 r3 = r2.f19230a
            d.e.b.h2.c0$a<d.e.b.h2.a0> r4 = p176d.p195e.p201b.p202h2.C5373x0.f19065w
            java.lang.Object r3 = r3.mo11123g(r4, r5)
            if (r3 == 0) goto L_0x0065
            d.e.b.h2.u0 r3 = r2.f19230a
            d.e.b.h2.c0$a<java.lang.Integer> r4 = p176d.p195e.p201b.p202h2.C5332k0.f19003a
            r6 = 35
            goto L_0x006b
        L_0x0065:
            d.e.b.h2.u0 r3 = r2.f19230a
            d.e.b.h2.c0$a<java.lang.Integer> r4 = p176d.p195e.p201b.p202h2.C5332k0.f19003a
            r6 = 34
        L_0x006b:
            java.lang.Integer r6 = java.lang.Integer.valueOf(r6)
            r3.mo11246C(r4, r0, r6)
            d.e.b.u1 r3 = new d.e.b.u1
            d.e.b.h2.x0 r2 = r2.mo11097b()
            r3.<init>(r2)
            java.lang.String r2 = "Preview.Builder()\n      …                 .build()"
            p257h.p265p.p267b.C5910g.m17226b(r3, r2)
            d.e.b.h1$c r2 = new d.e.b.h1$c
            d.e.b.h2.u0 r4 = p176d.p195e.p201b.p202h2.C5364u0.m16215A()
            r2.<init>(r4)
            b.a.a.a.c r4 = r15.f660e
            b.a.a.c.a r4 = r4.f647Y
            android.util.Size r4 = r4.f724a
            d.e.b.h2.u0 r6 = r2.f18862a
            d.e.b.h2.c0$a<android.util.Size> r7 = p176d.p195e.p201b.p202h2.C5334l0.f19012g
            r6.mo11246C(r7, r0, r4)
            d.e.b.h2.u0 r6 = r2.f18862a
            d.e.b.h2.c0$a<android.util.Rational> r7 = p176d.p195e.p201b.p202h2.C5334l0.f19009d
            android.util.Rational r8 = new android.util.Rational
            int r9 = r4.getWidth()
            int r4 = r4.getHeight()
            r8.<init>(r9, r4)
            r6.mo11246C(r7, r0, r8)
            d.e.b.h2.u0 r4 = r2.f18862a
            d.e.b.h2.c0$a<java.lang.Integer> r6 = p176d.p195e.p201b.p202h2.C5288h0.f18919v
            r7 = 0
            java.lang.Integer r8 = java.lang.Integer.valueOf(r7)
            r4.mo11246C(r6, r0, r8)
            d.e.b.h2.u0 r0 = r2.f18862a
            d.e.b.h2.c0$a<java.lang.Integer> r4 = p176d.p195e.p201b.p202h2.C5334l0.f19010e
            java.lang.Object r0 = r0.mo11123g(r4, r5)
            if (r0 == 0) goto L_0x00d3
            d.e.b.h2.u0 r0 = r2.f18862a
            d.e.b.h2.c0$a<android.util.Size> r4 = p176d.p195e.p201b.p202h2.C5334l0.f19012g
            java.lang.Object r0 = r0.mo11123g(r4, r5)
            if (r0 != 0) goto L_0x00cb
            goto L_0x00d3
        L_0x00cb:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r1 = "Cannot use both setTargetResolution and setTargetAspectRatio on the same config."
            r0.<init>(r1)
            throw r0
        L_0x00d3:
            d.e.b.h1 r0 = new d.e.b.h1
            d.e.b.h2.h0 r2 = r2.mo11110b()
            r0.<init>(r2)
            java.lang.String r2 = "ImageAnalysis.Builder()\n…                 .build()"
            p257h.p265p.p267b.C5910g.m17226b(r0, r2)
            java.util.concurrent.ExecutorService r2 = java.util.concurrent.Executors.newSingleThreadExecutor()
            b.a.a.a.c r4 = r15.f660e
            b.a.a.a.f r4 = r4.mo835Z()
            java.lang.Object r6 = r0.f18859j
            monitor-enter(r6)
            d.e.b.i1 r8 = r0.f18858i     // Catch:{ all -> 0x01b9 }
            r8.mo11274g()     // Catch:{ all -> 0x01b9 }
            d.e.b.i1 r8 = r0.f18858i     // Catch:{ all -> 0x01b9 }
            d.e.b.m r9 = new d.e.b.m     // Catch:{ all -> 0x01b9 }
            r9.<init>(r0, r4)     // Catch:{ all -> 0x01b9 }
            java.lang.Object r10 = r8.f19105d     // Catch:{ all -> 0x01b9 }
            monitor-enter(r10)     // Catch:{ all -> 0x01b9 }
            r8.f19102a = r9     // Catch:{ all -> 0x01b6 }
            r8.f19104c = r2     // Catch:{ all -> 0x01b6 }
            monitor-exit(r10)     // Catch:{ all -> 0x01b6 }
            d.e.b.h1$a r2 = r0.f18860k     // Catch:{ all -> 0x01b9 }
            if (r2 != 0) goto L_0x0109
            r0.mo11079j()     // Catch:{ all -> 0x01b9 }
        L_0x0109:
            r0.f18860k = r4     // Catch:{ all -> 0x01b9 }
            monitor-exit(r6)     // Catch:{ all -> 0x01b9 }
            java.util.LinkedHashSet r2 = new java.util.LinkedHashSet
            r2.<init>()
            b.a.a.a.c r4 = r15.f660e
            b.a.a.c.a r4 = r4.f647Y
            int r4 = r4.f728e
            d.e.b.h2.p0 r6 = new d.e.b.h2.p0
            r6.<init>(r4)
            r2.add(r6)
            d.e.b.z0 r10 = new d.e.b.z0
            r10.<init>(r2)
            java.lang.String r2 = "CameraSelector.Builder()…                 .build()"
            p257h.p265p.p267b.C5910g.m17226b(r10, r2)
            r1.mo11359c()     // Catch:{ Exception -> 0x01af }
            b.a.a.a.c r2 = r15.f660e     // Catch:{ Exception -> 0x01af }
            r4 = 2
            d.e.b.d2[] r4 = new p176d.p195e.p201b.C5227d2[r4]     // Catch:{ Exception -> 0x01af }
            r4[r7] = r0     // Catch:{ Exception -> 0x01af }
            r0 = 1
            r4[r0] = r3     // Catch:{ Exception -> 0x01af }
            d.e.b.u0 r0 = r1.mo11358a(r2, r10, r4)     // Catch:{ Exception -> 0x01af }
            java.lang.String r1 = "cameraProvider.bindToLif…preview\n                )"
            p257h.p265p.p267b.C5910g.m17226b(r0, r1)     // Catch:{ Exception -> 0x01af }
            b.a.a.a.c r0 = r15.f660e     // Catch:{ Exception -> 0x01af }
            int r1 = p002b.p003a.p004a.C0130m.viewFinder     // Catch:{ Exception -> 0x01af }
            android.view.View r0 = r0.mo834Y(r1)     // Catch:{ Exception -> 0x01af }
            androidx.camera.view.PreviewView r0 = (androidx.camera.view.PreviewView) r0     // Catch:{ Exception -> 0x01af }
            d.e.d.s r8 = new d.e.d.s     // Catch:{ Exception -> 0x01af }
            android.view.Display r9 = r0.getDisplay()     // Catch:{ Exception -> 0x01af }
            d.e.d.r r1 = r0.f395f     // Catch:{ Exception -> 0x01af }
            if (r1 != 0) goto L_0x0155
            r11 = r5
            goto L_0x0158
        L_0x0155:
            android.util.Size r1 = r1.f19308a     // Catch:{ Exception -> 0x01af }
            r11 = r1
        L_0x0158:
            d.e.d.x.a.a r1 = r0.f396g     // Catch:{ Exception -> 0x01af }
            androidx.camera.view.PreviewView$c r12 = r1.f19336a     // Catch:{ Exception -> 0x01af }
            int r13 = r0.getWidth()     // Catch:{ Exception -> 0x01af }
            int r14 = r0.getHeight()     // Catch:{ Exception -> 0x01af }
            r8.<init>(r9, r10, r11, r12, r13, r14)     // Catch:{ Exception -> 0x01af }
            b.a.a.a.c r0 = r15.f660e     // Catch:{ Exception -> 0x01af }
            int r1 = p002b.p003a.p004a.C0130m.viewFinder     // Catch:{ Exception -> 0x01af }
            android.view.View r0 = r0.mo834Y(r1)     // Catch:{ Exception -> 0x01af }
            androidx.camera.view.PreviewView r0 = (androidx.camera.view.PreviewView) r0     // Catch:{ Exception -> 0x01af }
            if (r0 == 0) goto L_0x01ae
            p176d.p178b.p179k.C4851q.C4862i.m15149m()     // Catch:{ Exception -> 0x01af }
            r0.removeAllViews()     // Catch:{ Exception -> 0x01af }
            d.e.d.f r1 = new d.e.d.f     // Catch:{ Exception -> 0x01af }
            r1.<init>(r0)     // Catch:{ Exception -> 0x01af }
            r3.mo11335x(r1)     // Catch:{ Exception -> 0x01af }
            b.a.a.a.c r0 = r15.f660e     // Catch:{ Exception -> 0x01af }
            int r1 = p002b.p003a.p004a.C0130m.graphicOverlay     // Catch:{ Exception -> 0x01af }
            android.view.View r0 = r0.mo834Y(r1)     // Catch:{ Exception -> 0x01af }
            com.galaxylab.drowsydriver.AI.GraphicOverlay r0 = (com.galaxylab.drowsydriver.p173AI.GraphicOverlay) r0     // Catch:{ Exception -> 0x01af }
            b.a.a.a.c r1 = r15.f660e     // Catch:{ Exception -> 0x01af }
            b.a.a.c.a r1 = r1.f647Y     // Catch:{ Exception -> 0x01af }
            int r1 = r1.f726c     // Catch:{ Exception -> 0x01af }
            b.a.a.a.c r2 = r15.f660e     // Catch:{ Exception -> 0x01af }
            b.a.a.c.a r2 = r2.f647Y     // Catch:{ Exception -> 0x01af }
            int r2 = r2.f727d     // Catch:{ Exception -> 0x01af }
            b.a.a.a.c r3 = r15.f660e     // Catch:{ Exception -> 0x01af }
            b.a.a.c.a r3 = r3.f647Y     // Catch:{ Exception -> 0x01af }
            int r3 = r3.f728e     // Catch:{ Exception -> 0x01af }
            java.lang.Object r4 = r0.f17321h     // Catch:{ Exception -> 0x01af }
            monitor-enter(r4)     // Catch:{ Exception -> 0x01af }
            r0.f17323j = r1     // Catch:{ all -> 0x01ab }
            r0.f17322i = r2     // Catch:{ all -> 0x01ab }
            r0.f17318e = r3     // Catch:{ all -> 0x01ab }
            monitor-exit(r4)     // Catch:{ Exception -> 0x01af }
            r0.postInvalidate()     // Catch:{ Exception -> 0x01af }
            goto L_0x01b5
        L_0x01ab:
            r0 = move-exception
            monitor-exit(r4)     // Catch:{ Exception -> 0x01af }
            throw r0     // Catch:{ Exception -> 0x01af }
        L_0x01ae:
            throw r5     // Catch:{ Exception -> 0x01af }
        L_0x01af:
            r0 = move-exception
            l.a.a$c r1 = p305l.p306a.C6163a.f21190d
            r1.mo12745c(r0)
        L_0x01b5:
            return
        L_0x01b6:
            r0 = move-exception
            monitor-exit(r10)     // Catch:{ all -> 0x01b6 }
            throw r0     // Catch:{ all -> 0x01b9 }
        L_0x01b9:
            r0 = move-exception
            monitor-exit(r6)     // Catch:{ all -> 0x01b9 }
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: p002b.p003a.p004a.p005a.C0095e.run():void");
    }
}
