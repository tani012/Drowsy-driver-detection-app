package p002b.p003a.p004a.p005a;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.PopupMenu;
import androidx.appcompat.app.AlertController;
import androidx.appcompat.widget.AppCompatButton;
import androidx.appcompat.widget.AppCompatImageButton;
import androidx.appcompat.widget.AppCompatSeekBar;
import androidx.appcompat.widget.AppCompatSpinner;
import androidx.fragment.app.Fragment;
import com.galaxylab.drowsydriver.R;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.NoSuchElementException;
import p002b.p003a.p004a.C0121d;
import p002b.p003a.p004a.C0130m;
import p002b.p003a.p004a.p006b.C0109g;
import p002b.p003a.p004a.p006b.C0110h;
import p002b.p003a.p004a.p006b.C0111i;
import p002b.p003a.p004a.p006b.C0113k;
import p002b.p003a.p004a.p006b.C0114l;
import p002b.p011c.p015b.p095c.p096a.p097a.C3769a;
import p002b.p011c.p015b.p095c.p096a.p106h.C3960d;
import p002b.p011c.p015b.p095c.p096a.p106h.C3971o;
import p002b.p011c.p110d.p117i.p118e.p121k.C4102r0;
import p176d.p178b.p179k.C4846m;
import p176d.p238l.p239d.C5709a;
import p176d.p238l.p239d.C5721e;
import p257h.C5836f;
import p257h.p265p.p266a.C5880a;
import p257h.p265p.p267b.C5910g;
import p257h.p265p.p267b.C5912i;
import p285k.p286a.p293c.p300m.C6154a;
import p285k.p286a.p293c.p301n.C6155a;
import p305l.p306a.C6163a;

/* renamed from: b.a.a.a.a */
public final class C0085a extends Fragment {

    /* renamed from: Y */
    public final C0121d f638Y = ((C0121d) C4102r0.m13448W(this).f21117a.mo12730c().mo12732a(C5912i.m17233a(C0121d.class), (C6155a) null, (C5880a<C6154a>) null));

    /* renamed from: Z */
    public final C0114l f639Z = ((C0114l) C4102r0.m13448W(this).f21117a.mo12730c().mo12732a(C5912i.m17233a(C0114l.class), (C6155a) null, (C5880a<C6154a>) null));

    /* renamed from: a0 */
    public HashMap f640a0;

    /* renamed from: b.a.a.a.a$a */
    /* compiled from: java-style lambda group */
    public static final class C0086a implements View.OnClickListener {

        /* renamed from: e */
        public final /* synthetic */ int f641e;

        /* renamed from: f */
        public final /* synthetic */ Object f642f;

        public C0086a(int i, Object obj) {
            this.f641e = i;
            this.f642f = obj;
        }

        public final void onClick(View view) {
            int i = this.f641e;
            if (i == 0) {
                ((C0085a) this.f642f).f638Y.mo876a();
            } else if (i == 1) {
                C5709a aVar = new C5709a(((C0085a) this.f642f).mo795o());
                aVar.mo11893d(R.id.fragmentContainer, new C0089c(), (String) null, 1);
                if (aVar.f20269h) {
                    aVar.f20268g = true;
                    aVar.f20270i = null;
                    aVar.mo11892c();
                    return;
                }
                throw new IllegalStateException("This FragmentTransaction is not allowed to be added to the back stack.");
            } else if (i == 2) {
                C0085a aVar2 = (C0085a) this.f642f;
                if (aVar2 != null) {
                    PopupMenu popupMenu = new PopupMenu(aVar2.mo791k(), view);
                    popupMenu.getMenuInflater().inflate(R.menu.main_menu, popupMenu.getMenu());
                    popupMenu.setOnMenuItemClickListener(new C0101j(aVar2));
                    popupMenu.show();
                    return;
                }
                throw null;
            } else {
                throw null;
            }
        }
    }

    /* renamed from: A */
    public View mo759A(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        if (layoutInflater != null) {
            return layoutInflater.inflate(R.layout.fragment_option, viewGroup, false);
        }
        C5910g.m17230f("inflater");
        throw null;
    }

    /* renamed from: B */
    public void mo760B() {
        this.f548H = true;
        HashMap hashMap = this.f640a0;
        if (hashMap != null) {
            hashMap.clear();
        }
    }

    /* renamed from: G */
    public void mo765G() {
        this.f548H = true;
        C5721e g = mo787g();
        if (g != null) {
            C0114l lVar = this.f639Z;
            C5910g.m17226b(g, "this");
            if (lVar != null) {
                long currentTimeMillis = System.currentTimeMillis();
                long j = lVar.f714h.getLong(lVar.f722p, -1);
                if (j == -1) {
                    lVar.f714h.edit().putLong(lVar.f722p, currentTimeMillis + lVar.f717k).apply();
                } else if (j <= currentTimeMillis) {
                    C4846m.C4847a aVar = new C4846m.C4847a(g, lVar.f721o);
                    C0109g gVar = new C0109g(lVar, g);
                    AlertController.C0007b bVar = aVar.f17614a;
                    bVar.f77i = "Yes";
                    bVar.f78j = gVar;
                    C0110h hVar = new C0110h(lVar, currentTimeMillis, g);
                    AlertController.C0007b bVar2 = aVar.f17614a;
                    bVar2.f79k = "No";
                    bVar2.f80l = hVar;
                    bVar2.f74f = "Rating";
                    bVar2.f76h = "Do you like this app?";
                    aVar.mo9868a().show();
                }
                C0114l lVar2 = this.f639Z;
                if (lVar2 != null) {
                    long currentTimeMillis2 = System.currentTimeMillis();
                    long j2 = lVar2.f714h.getLong(lVar2.f723q, -1);
                    if (j2 == -1) {
                        lVar2.f714h.edit().putLong(lVar2.f723q, currentTimeMillis2 + lVar2.f719m).apply();
                    } else if (j2 <= currentTimeMillis2) {
                        lVar2.f714h.edit().putLong(lVar2.f723q, currentTimeMillis2 + lVar2.f720n).apply();
                        C4846m.C4847a aVar2 = new C4846m.C4847a(g, lVar2.f721o);
                        AlertController.C0007b bVar3 = aVar2.f17614a;
                        bVar3.f74f = "Share App";
                        bVar3.f76h = "Do you want to share this app with your friends?";
                        C0111i iVar = new C0111i(lVar2, g);
                        AlertController.C0007b bVar4 = aVar2.f17614a;
                        bVar4.f77i = "Yes";
                        bVar4.f78j = iVar;
                        aVar2.mo9868a().show();
                    }
                    C0114l lVar3 = this.f639Z;
                    C3971o<C3769a> oVar = lVar3.f707a;
                    C0113k kVar = new C0113k(lVar3, g);
                    if (oVar != null) {
                        oVar.mo8319c(C3960d.f15658a, kVar);
                        return;
                    }
                    throw null;
                }
                throw null;
            }
            throw null;
        }
    }

    /* renamed from: K */
    public void mo769K(View view, Bundle bundle) {
        if (view != null) {
            C5836f[] fVarArr = {new C5836f("Short Alert", "short_alert.wav"), new C5836f("Cartoon Alert", "cartoon_alert.mp3"), new C5836f("Men Alert", "men_alert.wav"), new C5836f("Notification Up Alert", "notification_up.wav"), new C5836f("Pup Alert", "pup_alert.mp3"), new C5836f("Red Alert", "red_alert.wav"), new C5836f("Sweet Alert", "sweet_alert.wav")};
            LinkedHashMap linkedHashMap = new LinkedHashMap(C4102r0.m13463f0(7));
            for (int i = 0; i < 7; i++) {
                C5836f fVar = fVarArr[i];
                linkedHashMap.put(fVar.f20365e, fVar.f20366f);
            }
            String[] stringArray = mo799p().getStringArray(R.array.sound_arrays);
            C5910g.m17226b(stringArray, "resources.getStringArray(R.array.sound_arrays)");
            C0121d dVar = this.f638Y;
            String string = dVar.f745g.getString(dVar.f742d, dVar.f743e);
            if (string != null) {
                for (Map.Entry entry : linkedHashMap.entrySet()) {
                    if (C5910g.m17225a((String) entry.getValue(), string)) {
                        String str = (String) entry.getKey();
                        C6163a.f21190d.mo12743a("lastSoundUri " + string + " lastKey " + str, new Object[0]);
                        int length = stringArray.length;
                        int i2 = 0;
                        while (true) {
                            if (i2 >= length) {
                                i2 = 0;
                                break;
                            } else if (C5910g.m17225a(str, stringArray[i2])) {
                                break;
                            } else {
                                i2++;
                            }
                        }
                        ((AppCompatSpinner) mo830Y(C0130m.spinnerSoundSelection)).setSelection(i2);
                        AppCompatSpinner appCompatSpinner = (AppCompatSpinner) mo830Y(C0130m.spinnerSoundSelection);
                        C5910g.m17226b(appCompatSpinner, "spinnerSoundSelection");
                        appCompatSpinner.setOnItemSelectedListener(new C0099h(this, linkedHashMap));
                        AppCompatSeekBar appCompatSeekBar = (AppCompatSeekBar) mo830Y(C0130m.seekBarVolume);
                        C5910g.m17226b(appCompatSeekBar, "seekBarVolume");
                        C0121d dVar2 = this.f638Y;
                        appCompatSeekBar.setMax(dVar2.f740b.getStreamMaxVolume(dVar2.f741c));
                        AppCompatSeekBar appCompatSeekBar2 = (AppCompatSeekBar) mo830Y(C0130m.seekBarVolume);
                        C5910g.m17226b(appCompatSeekBar2, "seekBarVolume");
                        C0121d dVar3 = this.f638Y;
                        appCompatSeekBar2.setProgress(dVar3.f740b.getStreamVolume(dVar3.f741c));
                        ((AppCompatSeekBar) mo830Y(C0130m.seekBarVolume)).setOnSeekBarChangeListener(new C0100i(this));
                        ((AppCompatButton) mo830Y(C0130m.testAlertBtn)).setOnClickListener(new C0086a(0, this));
                        ((AppCompatButton) mo830Y(C0130m.startBtn)).setOnClickListener(new C0086a(1, this));
                        ((AppCompatImageButton) mo830Y(C0130m.menuBtn)).setOnClickListener(new C0086a(2, this));
                        return;
                    }
                }
                throw new NoSuchElementException("Collection contains no element matching the predicate.");
            }
            C5910g.m17229e();
            throw null;
        }
        C5910g.m17230f("view");
        throw null;
    }

    /* renamed from: Y */
    public View mo830Y(int i) {
        if (this.f640a0 == null) {
            this.f640a0 = new HashMap();
        }
        View view = (View) this.f640a0.get(Integer.valueOf(i));
        if (view != null) {
            return view;
        }
        View view2 = this.f550J;
        if (view2 == null) {
            return null;
        }
        View findViewById = view2.findViewById(i);
        this.f640a0.put(Integer.valueOf(i), findViewById);
        return findViewById;
    }
}
