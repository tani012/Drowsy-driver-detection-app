package p002b.p003a.p004a.p005a;

import p002b.p003a.p004a.C0121d;
import p002b.p003a.p004a.p006b.C0102a;
import p002b.p003a.p004a.p006b.C0104b;
import p002b.p003a.p004a.p006b.C0105c;
import p002b.p003a.p004a.p006b.C0106d;
import p002b.p003a.p004a.p007c.C0116b;
import p002b.p003a.p004a.p007c.C0119e;
import p002b.p011c.p110d.p117i.p118e.p121k.C4102r0;
import p168c.p169a.C4697a0;
import p168c.p169a.C4710e1;
import p168c.p169a.C4760q0;
import p168c.p169a.C4764s;
import p168c.p169a.C4776w;
import p168c.p169a.C4781y0;
import p176d.p195e.p201b.C5249h1;
import p176d.p195e.p201b.C5428o1;
import p176d.p242n.C5792m;
import p257h.C5842k;
import p257h.p259n.C5854d;
import p257h.p259n.C5857f;
import p257h.p259n.C5862h;
import p257h.p259n.p261j.p262a.C5870e;
import p257h.p259n.p261j.p262a.C5875i;
import p257h.p265p.p266a.C5895p;
import p257h.p265p.p267b.C5910g;

/* renamed from: b.a.a.a.f */
public final class C0096f extends C0102a implements C5249h1.C5250a {

    /* renamed from: d */
    public final long f662d;

    /* renamed from: e */
    public final long f663e;

    /* renamed from: f */
    public long f664f;

    /* renamed from: g */
    public final float f665g;

    /* renamed from: h */
    public final C5792m<C0116b> f666h;

    /* renamed from: i */
    public final C5792m<Boolean> f667i;

    /* renamed from: j */
    public Long f668j;

    /* renamed from: k */
    public final long f669k;

    /* renamed from: l */
    public final C0119e f670l;

    /* renamed from: m */
    public final C0121d f671m;

    @C5870e(mo12279c = "com.galaxylab.drowsydriver.UI.CameraFragmentVM$analyze$1", mo12280f = "CameraFragmentVM.kt", mo12281l = {36}, mo12282m = "invokeSuspend")
    /* renamed from: b.a.a.a.f$a */
    public static final class C0097a extends C5875i implements C5895p<C4776w, C5854d<? super C5842k>, Object> {

        /* renamed from: i */
        public C4776w f672i;

        /* renamed from: j */
        public Object f673j;

        /* renamed from: k */
        public int f674k;

        /* renamed from: l */
        public final /* synthetic */ C0096f f675l;

        /* renamed from: m */
        public final /* synthetic */ C5428o1 f676m;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        public C0097a(C0096f fVar, C5428o1 o1Var, C5854d dVar) {
            super(2, dVar);
            this.f675l = fVar;
            this.f676m = o1Var;
        }

        /* renamed from: a */
        public final C5854d<C5842k> mo843a(Object obj, C5854d<?> dVar) {
            if (dVar != null) {
                C0097a aVar = new C0097a(this.f675l, this.f676m, dVar);
                aVar.f672i = (C4776w) obj;
                return aVar;
            }
            C5910g.m17230f("completion");
            throw null;
        }

        /* renamed from: d */
        public final Object mo844d(Object obj, Object obj2) {
            return ((C0097a) mo843a(obj, (C5854d) obj2)).mo845h(C5842k.f20369a);
        }

        /* JADX INFO: finally extract failed */
        /* JADX WARNING: Removed duplicated region for block: B:216:0x0432  */
        /* JADX WARNING: Removed duplicated region for block: B:217:0x043d  */
        /* renamed from: h */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public final java.lang.Object mo845h(java.lang.Object r25) {
            /*
                r24 = this;
                r1 = r24
                h.n.i.a r0 = p257h.p259n.p260i.C5863a.COROUTINE_SUSPENDED
                int r2 = r1.f674k
                r4 = 0
                r5 = 1
                if (r2 == 0) goto L_0x0020
                if (r2 != r5) goto L_0x0018
                java.lang.Object r0 = r1.f673j
                c.a.w r0 = (p168c.p169a.C4776w) r0
                p002b.p011c.p110d.p117i.p118e.p121k.C4102r0.m13499x0(r25)
                r0 = r25
                r4 = r5
                goto L_0x03d3
            L_0x0018:
                java.lang.IllegalStateException r0 = new java.lang.IllegalStateException
                java.lang.String r2 = "call to 'resume' before 'invoke' with coroutine"
                r0.<init>(r2)
                throw r0
            L_0x0020:
                p002b.p011c.p110d.p117i.p118e.p121k.C4102r0.m13499x0(r25)
                c.a.w r2 = r1.f672i
                b.a.a.a.f r6 = r1.f675l
                b.a.a.c.e r6 = r6.f670l
                d.e.b.o1 r7 = r1.f676m
                r1.f673j = r2
                r1.f674k = r5
                if (r6 == 0) goto L_0x04c0
                c.a.f r2 = new c.a.f
                h.n.d r8 = p002b.p011c.p110d.p117i.p118e.p121k.C4102r0.m13451Z(r24)
                r2.<init>(r8, r5)
                r2.mo9466k()
                android.media.Image r8 = r7.mo11102a0()
                if (r8 == 0) goto L_0x04b7
                android.media.Image r8 = r7.mo11102a0()
                if (r8 == 0) goto L_0x04b1
                java.lang.String r9 = "imageProxy.image!!"
                p257h.p265p.p267b.C5910g.m17226b(r8, r9)
                d.e.b.n1 r9 = r7.mo11051D()
                java.lang.String r10 = "imageProxy.imageInfo"
                p257h.p265p.p267b.C5910g.m17226b(r9, r10)
                int r9 = r9.mo11280c()
                r11 = 2
                if (r9 == 0) goto L_0x0078
                r12 = 90
                if (r9 == r12) goto L_0x0076
                r12 = 180(0xb4, float:2.52E-43)
                if (r9 == r12) goto L_0x0074
                r12 = 270(0x10e, float:3.78E-43)
                if (r9 != r12) goto L_0x006c
                r15 = 3
                goto L_0x0079
            L_0x006c:
                java.lang.Exception r0 = new java.lang.Exception
                java.lang.String r2 = "Rotation must be 0, 90, 180, or 270."
                r0.<init>(r2)
                throw r0
            L_0x0074:
                r15 = r11
                goto L_0x0079
            L_0x0076:
                r15 = r5
                goto L_0x0079
            L_0x0078:
                r15 = r4
            L_0x0079:
                java.lang.String r9 = "Please provide a valid image"
                p176d.p178b.p179k.C4851q.C4862i.m15173u(r8, r9)
                int r9 = r8.getFormat()
                r12 = 256(0x100, float:3.59E-43)
                if (r9 == r12) goto L_0x0091
                int r9 = r8.getFormat()
                r13 = 35
                if (r9 != r13) goto L_0x008f
                goto L_0x0091
            L_0x008f:
                r9 = r4
                goto L_0x0092
            L_0x0091:
                r9 = r5
            L_0x0092:
                java.lang.String r13 = "Only JPEG and YUV_420_888 are supported now"
                p176d.p178b.p179k.C4851q.C4862i.m15140j(r9, r13)
                android.media.Image$Plane[] r9 = r8.getPlanes()
                int r13 = r8.getFormat()
                if (r13 != r12) goto L_0x00da
                if (r9 == 0) goto L_0x00d2
                int r8 = r9.length
                if (r8 != r5) goto L_0x00d2
                r8 = r9[r4]
                java.nio.ByteBuffer r8 = r8.getBuffer()
                int r9 = r8.remaining()
                byte[] r12 = new byte[r9]
                r8.get(r12)
                if (r15 != 0) goto L_0x00c0
                b.c.d.q.b.e.a r8 = new b.c.d.q.b.e.a
                r8.<init>((byte[]) r12)
                r23 = r0
                goto L_0x01ba
            L_0x00c0:
                android.graphics.Bitmap r8 = android.graphics.BitmapFactory.decodeByteArray(r12, r4, r9)
                b.c.d.q.b.e.a r9 = new b.c.d.q.b.e.a
                android.graphics.Bitmap r8 = p002b.p011c.p110d.p149q.p152b.p157e.C4445a.m13910a(r8, r15)
                r9.<init>((android.graphics.Bitmap) r8)
                r23 = r0
                r8 = r9
                goto L_0x01ba
            L_0x00d2:
                java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
                java.lang.String r2 = "Unexpected image format, JPEG should have exactly 1 image plane"
                r0.<init>(r2)
                throw r0
            L_0x00da:
                b.c.d.q.b.e.a r14 = new b.c.d.q.b.e.a
                int r12 = r8.getWidth()
                int r13 = r8.getHeight()
                int r3 = r12 * r13
                int r16 = r3 / 4
                int r16 = r16 * 2
                int r10 = r16 + r3
                byte[] r10 = new byte[r10]
                r16 = r9[r5]
                java.nio.ByteBuffer r5 = r16.getBuffer()
                r16 = r9[r11]
                java.nio.ByteBuffer r11 = r16.getBuffer()
                int r4 = r11.position()
                r22 = r14
                int r14 = r5.limit()
                int r1 = r4 + 1
                r11.position(r1)
                int r1 = r14 + -1
                r5.limit(r1)
                int r1 = r11.remaining()
                int r16 = r3 * 2
                int r16 = r16 / 4
                r23 = r0
                int r0 = r16 + -2
                if (r1 != r0) goto L_0x0124
                int r0 = r11.compareTo(r5)
                if (r0 != 0) goto L_0x0124
                r0 = 1
                goto L_0x0125
            L_0x0124:
                r0 = 0
            L_0x0125:
                r11.position(r4)
                r5.limit(r14)
                if (r0 == 0) goto L_0x014f
                r0 = 0
                r1 = r9[r0]
                java.nio.ByteBuffer r1 = r1.getBuffer()
                r1.get(r10, r0, r3)
                r1 = 1
                r4 = r9[r1]
                java.nio.ByteBuffer r4 = r4.getBuffer()
                r5 = 2
                r9 = r9[r5]
                java.nio.ByteBuffer r5 = r9.getBuffer()
                r5.get(r10, r3, r1)
                int r3 = r3 + r1
                int r1 = r16 + -1
                r4.get(r10, r3, r1)
                goto L_0x0174
            L_0x014f:
                r0 = 0
                r16 = r9[r0]
                r20 = 0
                r21 = 1
                r17 = r12
                r18 = r13
                r19 = r10
                p002b.p011c.p015b.p028b.p068i.p076h.C2446m5.m9914a(r16, r17, r18, r19, r20, r21)
                r0 = 1
                r16 = r9[r0]
                int r20 = r3 + 1
                r0 = 2
                r21 = 2
                p002b.p011c.p015b.p028b.p068i.p076h.C2446m5.m9914a(r16, r17, r18, r19, r20, r21)
                r1 = 2
                r16 = r9[r1]
                r20 = r3
                r21 = r0
                p002b.p011c.p015b.p028b.p068i.p076h.C2446m5.m9914a(r16, r17, r18, r19, r20, r21)
            L_0x0174:
                java.nio.ByteBuffer r0 = java.nio.ByteBuffer.wrap(r10)
                r16 = 17
                r1 = 1
                p176d.p178b.p179k.C4851q.C4862i.m15137i(r1)
                int r13 = r8.getWidth()
                if (r13 <= 0) goto L_0x0186
                r1 = 1
                goto L_0x0187
            L_0x0186:
                r1 = 0
            L_0x0187:
                java.lang.String r3 = "Image buffer width should be positive."
                p176d.p178b.p179k.C4851q.C4862i.m15140j(r1, r3)
                int r14 = r8.getHeight()
                if (r14 <= 0) goto L_0x0194
                r1 = 1
                goto L_0x0195
            L_0x0194:
                r1 = 0
            L_0x0195:
                java.lang.String r3 = "Image buffer height should be positive."
                p176d.p178b.p179k.C4851q.C4862i.m15140j(r1, r3)
                if (r15 == 0) goto L_0x01a8
                r1 = 1
                if (r15 == r1) goto L_0x01a8
                r1 = 2
                if (r15 == r1) goto L_0x01a8
                r1 = 3
                if (r15 != r1) goto L_0x01a6
                goto L_0x01a8
            L_0x01a6:
                r1 = 0
                goto L_0x01a9
            L_0x01a8:
                r1 = 1
            L_0x01a9:
                p176d.p178b.p179k.C4851q.C4862i.m15137i(r1)
                b.c.d.q.b.e.b r1 = new b.c.d.q.b.e.b
                r17 = 0
                r12 = r1
                r3 = r22
                r12.<init>(r13, r14, r15, r16, r17)
                r3.<init>(r0, r1)
                r8 = r3
            L_0x01ba:
                java.lang.String r0 = "FirebaseVisionImage.from…ediaImage, imageRotation)"
                p257h.p265p.p267b.C5910g.m17226b(r8, r0)
                b.c.d.q.b.f.c r0 = r6.f735a
                if (r0 == 0) goto L_0x04ad
                java.lang.String r1 = "FirebaseVisionImage can not be null"
                p176d.p178b.p179k.C4851q.C4862i.m15173u(r8, r1)
                monitor-enter(r8)
                java.lang.String r1 = "Can't restrict to bitmap-only and NV21 byte buffer-only"
                r3 = 1
                p176d.p178b.p179k.C4851q.C4862i.m15140j(r3, r1)     // Catch:{ all -> 0x04a8 }
                b.c.b.b.o.b r1 = r8.f16639d     // Catch:{ all -> 0x04a8 }
                if (r1 != 0) goto L_0x030f
                b.c.b.b.o.b r1 = new b.c.b.b.o.b     // Catch:{ all -> 0x04a8 }
                r3 = 0
                r1.<init>(r3)     // Catch:{ all -> 0x04a8 }
                java.nio.ByteBuffer r3 = r8.f16637b     // Catch:{ all -> 0x04a8 }
                if (r3 == 0) goto L_0x02e2
                r3 = 842094169(0x32315659, float:1.0322389E-8)
                r4 = 17
                b.c.d.q.b.e.b r5 = r8.f16638c     // Catch:{ all -> 0x04a8 }
                int r5 = r5.f16645d     // Catch:{ all -> 0x04a8 }
                if (r5 == r4) goto L_0x0251
                b.c.d.q.b.e.b r5 = r8.f16638c     // Catch:{ all -> 0x04a8 }
                int r5 = r5.f16645d     // Catch:{ all -> 0x04a8 }
                if (r5 != r3) goto L_0x0249
                java.nio.ByteBuffer r5 = r8.f16637b     // Catch:{ all -> 0x04a8 }
                r5.rewind()     // Catch:{ all -> 0x04a8 }
                int r9 = r5.limit()     // Catch:{ all -> 0x04a8 }
                byte[] r10 = new byte[r9]     // Catch:{ all -> 0x04a8 }
                r11 = 0
                r5.get(r10, r11, r9)     // Catch:{ all -> 0x04a8 }
                byte[] r5 = p002b.p011c.p015b.p028b.p068i.p076h.C2446m5.m9916c(r10)     // Catch:{ all -> 0x04a8 }
                java.nio.ByteBuffer r5 = java.nio.ByteBuffer.wrap(r5)     // Catch:{ all -> 0x04a8 }
                r8.f16637b = r5     // Catch:{ all -> 0x04a8 }
                r13 = 17
                r5 = 1
                p176d.p178b.p179k.C4851q.C4862i.m15137i(r5)     // Catch:{ all -> 0x04a8 }
                b.c.d.q.b.e.b r5 = r8.f16638c     // Catch:{ all -> 0x04a8 }
                int r10 = r5.f16642a     // Catch:{ all -> 0x04a8 }
                if (r10 <= 0) goto L_0x0215
                r5 = 1
                goto L_0x0216
            L_0x0215:
                r5 = 0
            L_0x0216:
                java.lang.String r9 = "Image buffer width should be positive."
                p176d.p178b.p179k.C4851q.C4862i.m15140j(r5, r9)     // Catch:{ all -> 0x04a8 }
                b.c.d.q.b.e.b r5 = r8.f16638c     // Catch:{ all -> 0x04a8 }
                int r11 = r5.f16643b     // Catch:{ all -> 0x04a8 }
                if (r11 <= 0) goto L_0x0223
                r5 = 1
                goto L_0x0224
            L_0x0223:
                r5 = 0
            L_0x0224:
                java.lang.String r9 = "Image buffer height should be positive."
                p176d.p178b.p179k.C4851q.C4862i.m15140j(r5, r9)     // Catch:{ all -> 0x04a8 }
                b.c.d.q.b.e.b r5 = r8.f16638c     // Catch:{ all -> 0x04a8 }
                int r12 = r5.f16644c     // Catch:{ all -> 0x04a8 }
                if (r12 == 0) goto L_0x023b
                r5 = 1
                if (r12 == r5) goto L_0x023b
                r5 = 2
                if (r12 == r5) goto L_0x023b
                r5 = 3
                if (r12 != r5) goto L_0x0239
                goto L_0x023b
            L_0x0239:
                r5 = 0
                goto L_0x023c
            L_0x023b:
                r5 = 1
            L_0x023c:
                p176d.p178b.p179k.C4851q.C4862i.m15137i(r5)     // Catch:{ all -> 0x04a8 }
                b.c.d.q.b.e.b r5 = new b.c.d.q.b.e.b     // Catch:{ all -> 0x04a8 }
                r14 = 0
                r9 = r5
                r9.<init>(r10, r11, r12, r13, r14)     // Catch:{ all -> 0x04a8 }
                r8.f16638c = r5     // Catch:{ all -> 0x04a8 }
                goto L_0x0251
            L_0x0249:
                java.lang.IllegalStateException r0 = new java.lang.IllegalStateException     // Catch:{ all -> 0x04a8 }
                java.lang.String r1 = "Must be one of: IMAGE_FORMAT_NV21, IMAGE_FORMAT_YV12"
                r0.<init>(r1)     // Catch:{ all -> 0x04a8 }
                throw r0     // Catch:{ all -> 0x04a8 }
            L_0x0251:
                java.nio.ByteBuffer r5 = r8.f16637b     // Catch:{ all -> 0x04a8 }
                b.c.d.q.b.e.b r9 = r8.f16638c     // Catch:{ all -> 0x04a8 }
                int r9 = r9.f16642a     // Catch:{ all -> 0x04a8 }
                b.c.d.q.b.e.b r10 = r8.f16638c     // Catch:{ all -> 0x04a8 }
                int r10 = r10.f16643b     // Catch:{ all -> 0x04a8 }
                b.c.d.q.b.e.b r11 = r8.f16638c     // Catch:{ all -> 0x04a8 }
                int r11 = r11.f16645d     // Catch:{ all -> 0x04a8 }
                if (r11 == r4) goto L_0x0267
                if (r11 == r3) goto L_0x0265
                r11 = 0
                goto L_0x0268
            L_0x0265:
                r11 = r3
                goto L_0x0268
            L_0x0267:
                r11 = r4
            L_0x0268:
                if (r5 == 0) goto L_0x02da
                int r12 = r5.capacity()     // Catch:{ all -> 0x04a8 }
                int r13 = r9 * r10
                if (r12 < r13) goto L_0x02d2
                r12 = 16
                if (r11 == r12) goto L_0x0294
                if (r11 == r4) goto L_0x0294
                if (r11 != r3) goto L_0x027b
                goto L_0x0294
            L_0x027b:
                java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException     // Catch:{ all -> 0x04a8 }
                r1 = 37
                java.lang.StringBuilder r2 = new java.lang.StringBuilder     // Catch:{ all -> 0x04a8 }
                r2.<init>(r1)     // Catch:{ all -> 0x04a8 }
                java.lang.String r1 = "Unsupported image format: "
                r2.append(r1)     // Catch:{ all -> 0x04a8 }
                r2.append(r11)     // Catch:{ all -> 0x04a8 }
                java.lang.String r1 = r2.toString()     // Catch:{ all -> 0x04a8 }
                r0.<init>(r1)     // Catch:{ all -> 0x04a8 }
                throw r0     // Catch:{ all -> 0x04a8 }
            L_0x0294:
                r1.f15150b = r5     // Catch:{ all -> 0x04a8 }
                b.c.b.b.o.b$a r3 = r1.f15149a     // Catch:{ all -> 0x04a8 }
                r3.f15152a = r9     // Catch:{ all -> 0x04a8 }
                r3.f15153b = r10     // Catch:{ all -> 0x04a8 }
                r3.f15156e = r11     // Catch:{ all -> 0x04a8 }
                b.c.d.q.b.e.b r3 = r8.f16638c     // Catch:{ all -> 0x04a8 }
                int r3 = r3.f16644c     // Catch:{ all -> 0x04a8 }
                if (r3 == 0) goto L_0x02cc
                r4 = 1
                if (r3 == r4) goto L_0x02ca
                r4 = 2
                if (r3 == r4) goto L_0x02c8
                r4 = 3
                if (r3 != r4) goto L_0x02af
                r3 = 3
                goto L_0x02cd
            L_0x02af:
                java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException     // Catch:{ all -> 0x04a8 }
                r1 = 29
                java.lang.StringBuilder r2 = new java.lang.StringBuilder     // Catch:{ all -> 0x04a8 }
                r2.<init>(r1)     // Catch:{ all -> 0x04a8 }
                java.lang.String r1 = "Invalid rotation: "
                r2.append(r1)     // Catch:{ all -> 0x04a8 }
                r2.append(r3)     // Catch:{ all -> 0x04a8 }
                java.lang.String r1 = r2.toString()     // Catch:{ all -> 0x04a8 }
                r0.<init>(r1)     // Catch:{ all -> 0x04a8 }
                throw r0     // Catch:{ all -> 0x04a8 }
            L_0x02c8:
                r3 = 2
                goto L_0x02cd
            L_0x02ca:
                r3 = 1
                goto L_0x02cd
            L_0x02cc:
                r3 = 0
            L_0x02cd:
                b.c.b.b.o.b$a r4 = r1.f15149a     // Catch:{ all -> 0x04a8 }
                r4.f15155d = r3     // Catch:{ all -> 0x04a8 }
                goto L_0x02f6
            L_0x02d2:
                java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException     // Catch:{ all -> 0x04a8 }
                java.lang.String r1 = "Invalid image data size."
                r0.<init>(r1)     // Catch:{ all -> 0x04a8 }
                throw r0     // Catch:{ all -> 0x04a8 }
            L_0x02da:
                java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException     // Catch:{ all -> 0x04a8 }
                java.lang.String r1 = "Null image data supplied."
                r0.<init>(r1)     // Catch:{ all -> 0x04a8 }
                throw r0     // Catch:{ all -> 0x04a8 }
            L_0x02e2:
                android.graphics.Bitmap r3 = r8.mo8787c()     // Catch:{ all -> 0x04a8 }
                int r4 = r3.getWidth()     // Catch:{ all -> 0x04a8 }
                int r5 = r3.getHeight()     // Catch:{ all -> 0x04a8 }
                r1.f15151c = r3     // Catch:{ all -> 0x04a8 }
                b.c.b.b.o.b$a r3 = r1.f15149a     // Catch:{ all -> 0x04a8 }
                r3.f15152a = r4     // Catch:{ all -> 0x04a8 }
                r3.f15153b = r5     // Catch:{ all -> 0x04a8 }
            L_0x02f6:
                long r3 = r8.f16641f     // Catch:{ all -> 0x04a8 }
                b.c.b.b.o.b$a r5 = r1.f15149a     // Catch:{ all -> 0x04a8 }
                r5.f15154c = r3     // Catch:{ all -> 0x04a8 }
                java.nio.ByteBuffer r3 = r1.f15150b     // Catch:{ all -> 0x04a8 }
                if (r3 != 0) goto L_0x030d
                android.graphics.Bitmap r3 = r1.f15151c     // Catch:{ all -> 0x04a8 }
                if (r3 == 0) goto L_0x0305
                goto L_0x030d
            L_0x0305:
                java.lang.IllegalStateException r0 = new java.lang.IllegalStateException     // Catch:{ all -> 0x04a8 }
                java.lang.String r1 = "Missing image data.  Call either setBitmap or setImageData to specify the image"
                r0.<init>(r1)     // Catch:{ all -> 0x04a8 }
                throw r0     // Catch:{ all -> 0x04a8 }
            L_0x030d:
                r8.f16639d = r1     // Catch:{ all -> 0x04a8 }
            L_0x030f:
                b.c.b.b.o.b r1 = r8.f16639d     // Catch:{ all -> 0x04a8 }
                monitor-exit(r8)
                b.c.b.b.o.b$a r3 = r1.f15149a
                int r4 = r3.f15152a
                r5 = 32
                if (r4 < r5) goto L_0x0355
                int r3 = r3.f15153b
                if (r3 < r5) goto L_0x0355
                b.c.b.b.i.h.q4 r3 = r0.f12519f
                b.c.b.b.i.h.k4<TDetectionResult, b.c.b.b.i.h.n5> r0 = r0.f12518e
                b.c.b.b.i.h.n5 r4 = new b.c.b.b.i.h.n5
                r4.<init>(r8, r1)
                monitor-enter(r3)
                java.lang.String r1 = "Operation can not be null"
                p176d.p178b.p179k.C4851q.C4862i.m15173u(r0, r1)     // Catch:{ all -> 0x0352 }
                java.lang.String r1 = "Input can not be null"
                p176d.p178b.p179k.C4851q.C4862i.m15173u(r4, r1)     // Catch:{ all -> 0x0352 }
                b.c.b.b.e.o.i r1 = p002b.p011c.p015b.p028b.p068i.p076h.C2499q4.f12611b     // Catch:{ all -> 0x0352 }
                java.lang.String r5 = "MLTaskManager"
                java.lang.String r9 = "Execute task"
                r1.mo1475b(r5, r9)     // Catch:{ all -> 0x0352 }
                r1 = r0
                b.c.b.b.i.h.p5 r1 = (p002b.p011c.p015b.p028b.p068i.p076h.C2482p5) r1     // Catch:{ all -> 0x0352 }
                b.c.b.b.i.h.f5 r5 = r3.f12613a     // Catch:{ all -> 0x0352 }
                r5.mo5959a(r1)     // Catch:{ all -> 0x0352 }
                b.c.b.b.i.h.n4 r5 = p002b.p011c.p015b.p028b.p068i.p076h.C2457n4.m9927c()     // Catch:{ all -> 0x0352 }
                b.c.b.b.i.h.s4 r9 = new b.c.b.b.i.h.s4     // Catch:{ all -> 0x0352 }
                r9.<init>(r3, r1, r0, r4)     // Catch:{ all -> 0x0352 }
                b.c.b.b.n.h r0 = r5.mo6079a(r9)     // Catch:{ all -> 0x0352 }
                monitor-exit(r3)
                goto L_0x0361
            L_0x0352:
                r0 = move-exception
                monitor-exit(r3)
                throw r0
            L_0x0355:
                b.c.d.q.a.a r0 = new b.c.d.q.a.a
                java.lang.String r1 = "Image width and height should be at least 32!"
                r3 = 3
                r0.<init>(r1, r3)
                b.c.b.b.n.h r0 = p002b.p011c.p015b.p028b.p053e.p061r.C0605f.m920E(r0)
            L_0x0361:
                java.lang.String r1 = "detector.detectInImage(image!!)"
                p257h.p265p.p267b.C5910g.m17226b(r0, r1)
                b.a.a.c.c r1 = new b.a.a.c.c
                r1.<init>(r2, r8, r6, r7)
                b.c.b.b.n.f0 r0 = (p002b.p011c.p015b.p028b.p089n.C3716f0) r0
                java.util.concurrent.Executor r3 = p002b.p011c.p015b.p028b.p089n.C3723j.f15103a
                r0.mo8093d(r3, r1)
                b.a.a.c.d r1 = new b.a.a.c.d
                r1.<init>(r2)
                java.util.concurrent.Executor r3 = p002b.p011c.p015b.p028b.p089n.C3723j.f15103a
                r0.mo8092c(r3, r1)
                r2.mo9466k()
            L_0x037f:
                int r0 = r2._decision
                r1 = 2
                if (r0 == 0) goto L_0x0395
                if (r0 != r1) goto L_0x0389
                r0 = 0
                r4 = 1
                goto L_0x03a0
            L_0x0389:
                java.lang.IllegalStateException r0 = new java.lang.IllegalStateException
                java.lang.String r1 = "Already suspended"
                java.lang.String r1 = r1.toString()
                r0.<init>(r1)
                throw r0
            L_0x0395:
                java.util.concurrent.atomic.AtomicIntegerFieldUpdater r0 = p168c.p169a.C4711f.f17185j
                r3 = 0
                r4 = 1
                boolean r0 = r0.compareAndSet(r2, r3, r4)
                if (r0 == 0) goto L_0x04a4
                r0 = r4
            L_0x03a0:
                if (r0 == 0) goto L_0x03a5
                r0 = r23
                goto L_0x03ce
            L_0x03a5:
                java.lang.Object r0 = r2._state
                boolean r1 = r0 instanceof p168c.p169a.C4753n
                if (r1 != 0) goto L_0x049d
                int r1 = r2.f17176g
                if (r1 != r4) goto L_0x03ca
                h.n.f r1 = r2.f17187h
                c.a.q0$a r3 = p168c.p169a.C4760q0.f17276d
                h.n.f$a r1 = r1.get(r3)
                c.a.q0 r1 = (p168c.p169a.C4760q0) r1
                if (r1 == 0) goto L_0x03ca
                boolean r3 = r1.mo9458a()
                if (r3 == 0) goto L_0x03c2
                goto L_0x03ca
            L_0x03c2:
                java.util.concurrent.CancellationException r1 = r1.mo9538o()
                r2.mo9439a(r0, r1)
                throw r1
            L_0x03ca:
                java.lang.Object r0 = r2.mo9441c(r0)
            L_0x03ce:
                r3 = r23
                if (r0 != r3) goto L_0x03d3
                return r3
            L_0x03d3:
                b.a.a.c.b r0 = (p002b.p003a.p004a.p007c.C0116b) r0
                r5 = r24
                b.a.a.a.f r1 = r5.f675l
                d.n.m<b.a.a.c.b> r1 = r1.f666h
                r1.mo12121i(r0)
                b.a.a.a.f r1 = r5.f675l
                if (r1 == 0) goto L_0x049b
                java.util.List<b.c.d.q.b.f.a> r2 = r0.f730b
                boolean r2 = r2.isEmpty()
                if (r2 == 0) goto L_0x03fd
                d.n.m<java.lang.Boolean> r0 = r1.f667i
                java.lang.Boolean r1 = java.lang.Boolean.FALSE
                r0.mo12121i(r1)
                r0 = 0
                java.lang.Object[] r0 = new java.lang.Object[r0]
                l.a.a$c r1 = p305l.p306a.C6163a.f21190d
                java.lang.String r2 = "empty"
                r1.mo12743a(r2, r0)
                goto L_0x0493
            L_0x03fd:
                java.util.List<b.c.d.q.b.f.a> r0 = r0.f730b
                boolean r2 = r0 instanceof java.util.Collection
                if (r2 == 0) goto L_0x040a
                boolean r2 = r0.isEmpty()
                if (r2 == 0) goto L_0x040a
                goto L_0x042f
            L_0x040a:
                java.util.Iterator r0 = r0.iterator()
            L_0x040e:
                boolean r2 = r0.hasNext()
                if (r2 == 0) goto L_0x042f
                java.lang.Object r2 = r0.next()
                b.c.d.q.b.f.a r2 = (p002b.p011c.p110d.p149q.p152b.p158f.C4449a) r2
                float r3 = r2.f16651d
                float r6 = r1.f665g
                int r3 = (r3 > r6 ? 1 : (r3 == r6 ? 0 : -1))
                if (r3 > 0) goto L_0x042a
                float r2 = r2.f16650c
                int r2 = (r2 > r6 ? 1 : (r2 == r6 ? 0 : -1))
                if (r2 > 0) goto L_0x042a
                r2 = r4
                goto L_0x042b
            L_0x042a:
                r2 = 0
            L_0x042b:
                if (r2 != 0) goto L_0x040e
                r0 = 0
                goto L_0x0430
            L_0x042f:
                r0 = r4
            L_0x0430:
                if (r0 != 0) goto L_0x043d
                r0 = 0
                r1.f668j = r0
                d.n.m<java.lang.Boolean> r0 = r1.f667i
                java.lang.Boolean r1 = java.lang.Boolean.FALSE
                r0.mo12121i(r1)
                goto L_0x0493
            L_0x043d:
                long r2 = java.lang.System.currentTimeMillis()
                java.lang.Long r0 = r1.f668j
                if (r0 != 0) goto L_0x045d
                java.lang.Long r0 = java.lang.Long.valueOf(r2)
                r1.f668j = r0
                d.n.m<java.lang.Boolean> r0 = r1.f667i
                java.lang.Boolean r1 = java.lang.Boolean.FALSE
                r0.mo12121i(r1)
                r0 = 0
                java.lang.Object[] r0 = new java.lang.Object[r0]
                l.a.a$c r1 = p305l.p306a.C6163a.f21190d
                java.lang.String r2 = "first time close"
                r1.mo12743a(r2, r0)
                goto L_0x0493
            L_0x045d:
                long r6 = r0.longValue()
                long r2 = r2 - r6
                long r6 = r1.f669k
                int r0 = (r2 > r6 ? 1 : (r2 == r6 ? 0 : -1))
                if (r0 < 0) goto L_0x0469
                goto L_0x046a
            L_0x0469:
                r4 = 0
            L_0x046a:
                d.n.m<java.lang.Boolean> r0 = r1.f667i
                java.lang.Boolean r2 = java.lang.Boolean.valueOf(r4)
                r0.mo12121i(r2)
                if (r4 == 0) goto L_0x047a
                b.a.a.d r0 = r1.f671m
                r0.mo876a()
            L_0x047a:
                java.lang.StringBuilder r0 = new java.lang.StringBuilder
                r0.<init>()
                java.lang.String r1 = "shouldAlert "
                r0.append(r1)
                r0.append(r4)
                java.lang.String r0 = r0.toString()
                r6 = 0
                java.lang.Object[] r1 = new java.lang.Object[r6]
                l.a.a$c r2 = p305l.p306a.C6163a.f21190d
                r2.mo12743a(r0, r1)
            L_0x0493:
                d.e.b.o1 r0 = r5.f676m
                r0.close()
                h.k r0 = p257h.C5842k.f20369a
                return r0
            L_0x049b:
                r0 = 0
                throw r0
            L_0x049d:
                r5 = r24
                c.a.n r0 = (p168c.p169a.C4753n) r0
                java.lang.Throwable r0 = r0.f17269a
                throw r0
            L_0x04a4:
                r5 = r24
                goto L_0x037f
            L_0x04a8:
                r0 = move-exception
                r5 = r24
                monitor-exit(r8)
                throw r0
            L_0x04ad:
                r5 = r24
                r0 = 0
                throw r0
            L_0x04b1:
                r5 = r1
                r0 = 0
                p257h.p265p.p267b.C5910g.m17229e()
                throw r0
            L_0x04b7:
                r5 = r1
                java.lang.NullPointerException r0 = new java.lang.NullPointerException
                java.lang.String r1 = "imageProxy.image must be not null"
                r0.<init>(r1)
                throw r0
            L_0x04c0:
                r5 = r1
                r0 = 0
                throw r0
            */
            throw new UnsupportedOperationException("Method not decompiled: p002b.p003a.p004a.p005a.C0096f.C0097a.mo845h(java.lang.Object):java.lang.Object");
        }
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public C0096f(C0104b bVar, C0119e eVar, C0121d dVar) {
        super(bVar);
        if (bVar == null) {
            C5910g.m17230f("contextProvider");
            throw null;
        } else if (eVar == null) {
            C5910g.m17230f("faceDetector");
            throw null;
        } else if (dVar != null) {
            this.f670l = eVar;
            this.f671m = dVar;
            this.f662d = 3;
            this.f663e = ((long) 1000) / 3;
            this.f665g = 0.5f;
            this.f666h = new C5792m<>();
            this.f667i = new C5792m<>(Boolean.FALSE);
            this.f669k = 500;
        } else {
            C5910g.m17230f("alertController");
            throw null;
        }
    }

    /* JADX WARNING: type inference failed for: r0v1, types: [c.a.e1, c.a.q0, c.a.v0, java.lang.Object, h.n.d] */
    /* JADX WARNING: type inference failed for: r0v4 */
    /* JADX WARNING: type inference failed for: r0v5 */
    /* renamed from: a */
    public void mo842a(C5428o1 o1Var) {
        boolean z;
        if (o1Var != null) {
            long currentTimeMillis = System.currentTimeMillis();
            if (currentTimeMillis - this.f664f > this.f663e) {
                this.f664f = currentTimeMillis;
                z = true;
            } else {
                z = false;
            }
            if (z) {
                C4776w wVar = this.f682c;
                C0097a aVar = new C0097a(this, o1Var, (C5854d) null);
                C5862h hVar = C5862h.f20386e;
                if (wVar != null) {
                    C0106d dVar = new C0106d(aVar, (C5854d) null);
                    C5857f b = C4764s.m14723b(wVar, hVar);
                    ? y0Var = 0 != 0 ? new C4781y0(b, dVar) : new C4710e1(b, true);
                    y0Var.mo9553C((C4760q0) y0Var.f17184g.get(C4760q0.f17276d));
                    try {
                        C4697a0.m14598a(C4102r0.m13451Z(C4102r0.m13484q(dVar, y0Var, y0Var)), C5842k.f20369a);
                    } catch (Throwable th) {
                        y0Var.mo9459f(C4102r0.m13486r(th));
                    }
                    y0Var.mo9535e(C0105c.f687f);
                    return;
                }
                C5910g.m17230f("$this$launchAndLogException");
                throw null;
            }
            o1Var.close();
            return;
        }
        C5910g.m17230f("imageProxy");
        throw null;
    }
}
