package p002b.p003a.p004a;

import p002b.p003a.p004a.p005a.C0096f;
import p002b.p003a.p004a.p006b.C0104b;
import p002b.p003a.p004a.p007c.C0119e;
import p257h.p265p.p266a.C5880a;
import p257h.p265p.p266a.C5895p;
import p257h.p265p.p267b.C5910g;
import p257h.p265p.p267b.C5911h;
import p257h.p265p.p267b.C5912i;
import p285k.p286a.p293c.p300m.C6154a;
import p285k.p286a.p293c.p301n.C6155a;
import p285k.p286a.p293c.p303p.C6159a;

/* renamed from: b.a.a.k */
public final class C0128k extends C5911h implements C5895p<C6159a, C6154a, C0096f> {

    /* renamed from: f */
    public static final C0128k f753f = new C0128k();

    public C0128k() {
        super(2);
    }

    /* renamed from: d */
    public Object mo844d(Object obj, Object obj2) {
        C6159a aVar = (C6159a) obj;
        C6154a aVar2 = (C6154a) obj2;
        if (aVar == null) {
            C5910g.m17230f("$receiver");
            throw null;
        } else if (aVar2 != null) {
            return new C0096f((C0104b) aVar.mo12732a(C5912i.m17233a(C0104b.class), (C6155a) null, (C5880a<C6154a>) null), (C0119e) aVar.mo12732a(C5912i.m17233a(C0119e.class), (C6155a) null, (C5880a<C6154a>) null), (C0121d) aVar.mo12732a(C5912i.m17233a(C0121d.class), (C6155a) null, (C5880a<C6154a>) null));
        } else {
            C5910g.m17230f("it");
            throw null;
        }
    }
}
