package p002b.p003a.p004a;

import p002b.p003a.p004a.p007c.C0115a;
import p002b.p003a.p004a.p007c.C0119e;
import p257h.p265p.p266a.C5880a;
import p257h.p265p.p266a.C5895p;
import p257h.p265p.p267b.C5910g;
import p257h.p265p.p267b.C5911h;
import p257h.p265p.p267b.C5912i;
import p285k.p286a.p293c.p300m.C6154a;
import p285k.p286a.p293c.p301n.C6155a;
import p285k.p286a.p293c.p303p.C6159a;

/* renamed from: b.a.a.i */
public final class C0126i extends C5911h implements C5895p<C6159a, C6154a, C0119e> {

    /* renamed from: f */
    public static final C0126i f751f = new C0126i();

    public C0126i() {
        super(2);
    }

    /* renamed from: d */
    public Object mo844d(Object obj, Object obj2) {
        C6159a aVar = (C6159a) obj;
        C6154a aVar2 = (C6154a) obj2;
        if (aVar == null) {
            C5910g.m17230f("$receiver");
            throw null;
        } else if (aVar2 != null) {
            return new C0119e((C0115a) aVar.mo12732a(C5912i.m17233a(C0115a.class), (C6155a) null, (C5880a<C6154a>) null));
        } else {
            C5910g.m17230f("it");
            throw null;
        }
    }
}
