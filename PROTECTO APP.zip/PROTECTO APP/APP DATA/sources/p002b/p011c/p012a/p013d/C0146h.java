package p002b.p011c.p012a.p013d;

import com.google.ads.mediation.AbstractAdViewAdapter;
import p002b.p011c.p015b.p028b.p029a.p031b0.C0293a;

/* renamed from: b.c.a.d.h */
public final class C0146h extends C0293a {

    /* renamed from: a */
    public final /* synthetic */ AbstractAdViewAdapter f778a;

    public C0146h(AbstractAdViewAdapter abstractAdViewAdapter) {
        this.f778a = abstractAdViewAdapter;
    }

    /* JADX WARNING: Removed duplicated region for block: B:15:0x003b  */
    /* JADX WARNING: Removed duplicated region for block: B:20:0x0050  */
    /* renamed from: c */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void mo887c() {
        /*
            r4 = this;
            java.lang.String r0 = "#007 Could not call remote method."
            com.google.ads.mediation.AbstractAdViewAdapter r1 = r4.f778a
            b.c.b.b.a.k r1 = r1.zzmm
            if (r1 == 0) goto L_0x0052
            com.google.ads.mediation.AbstractAdViewAdapter r1 = r4.f778a
            b.c.b.b.a.b0.d.a r1 = r1.zzmn
            if (r1 == 0) goto L_0x0052
            com.google.ads.mediation.AbstractAdViewAdapter r1 = r4.f778a
            b.c.b.b.a.k r1 = r1.zzmm
            b.c.b.b.i.a.ik2 r1 = r1.f1129a
            r2 = 0
            if (r1 == 0) goto L_0x0051
            b.c.b.b.i.a.ni2 r3 = r1.f4545e     // Catch:{ RemoteException -> 0x0028 }
            if (r3 == 0) goto L_0x002c
            b.c.b.b.i.a.ni2 r1 = r1.f4545e     // Catch:{ RemoteException -> 0x0028 }
            android.os.Bundle r1 = r1.mo1225G()     // Catch:{ RemoteException -> 0x0028 }
            goto L_0x0031
        L_0x0028:
            r1 = move-exception
            p002b.p011c.p015b.p028b.p053e.p061r.C0605f.m995O4(r0, r1)
        L_0x002c:
            android.os.Bundle r1 = new android.os.Bundle
            r1.<init>()
        L_0x0031:
            com.google.ads.mediation.AbstractAdViewAdapter r3 = r4.f778a
            b.c.b.b.a.b0.d.a r3 = r3.zzmn
            b.c.b.b.i.a.ih r3 = (p002b.p011c.p015b.p028b.p068i.p069a.C1019ih) r3
            if (r3 == 0) goto L_0x0050
            java.lang.String r2 = "#008 Must be called on the main UI thread."
            p176d.p178b.p179k.C4851q.C4862i.m15152n(r2)
            java.lang.String r2 = "Adapter called onAdMetadataChanged."
            p002b.p011c.p015b.p028b.p053e.p061r.C0605f.m1030T4(r2)
            b.c.b.b.i.a.dh r2 = r3.f4517a     // Catch:{ RemoteException -> 0x004b }
            r2.mo2173j0(r1)     // Catch:{ RemoteException -> 0x004b }
            goto L_0x0052
        L_0x004b:
            r1 = move-exception
            p002b.p011c.p015b.p028b.p053e.p061r.C0605f.m995O4(r0, r1)
            goto L_0x0052
        L_0x0050:
            throw r2
        L_0x0051:
            throw r2
        L_0x0052:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: p002b.p011c.p012a.p013d.C0146h.mo887c():void");
    }
}
