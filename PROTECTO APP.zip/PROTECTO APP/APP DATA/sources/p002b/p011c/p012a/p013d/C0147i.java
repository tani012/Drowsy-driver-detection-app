package p002b.p011c.p012a.p013d;

import com.google.ads.mediation.AbstractAdViewAdapter;
import p002b.p011c.p015b.p028b.p029a.p031b0.C0295c;

/* renamed from: b.c.a.d.i */
public final class C0147i implements C0295c {

    /* renamed from: a */
    public final /* synthetic */ AbstractAdViewAdapter f779a;

    public C0147i(AbstractAdViewAdapter abstractAdViewAdapter) {
        this.f779a = abstractAdViewAdapter;
    }
}
