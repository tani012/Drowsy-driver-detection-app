package p002b.p011c.p012a.p013d.p014g;

@Deprecated
/* renamed from: b.c.a.d.g.a */
public interface C0143a {
}
