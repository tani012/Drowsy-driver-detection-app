package p002b.p011c.p012a.p013d.p014g;

import p002b.p011c.p012a.p013d.C0139e;

/* renamed from: b.c.a.d.g.c */
public final class C0145c extends C0139e {
    @C0139e.C0141b(name = "label", required = true)

    /* renamed from: a */
    public String f775a;
    @C0139e.C0141b(name = "class_name", required = true)

    /* renamed from: b */
    public String f776b;
    @C0139e.C0141b(name = "parameter", required = false)

    /* renamed from: c */
    public String f777c = null;
}
