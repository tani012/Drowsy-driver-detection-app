package p002b.p011c.p012a.p013d;

import android.location.Location;
import java.util.Date;
import java.util.Set;
import p002b.p011c.p012a.C0133b;

@Deprecated
/* renamed from: b.c.a.d.a */
public class C0135a {

    /* renamed from: a */
    public final Location f774a;

    public C0135a(Date date, C0133b bVar, Set<String> set, boolean z, Location location) {
        this.f774a = location;
    }
}
