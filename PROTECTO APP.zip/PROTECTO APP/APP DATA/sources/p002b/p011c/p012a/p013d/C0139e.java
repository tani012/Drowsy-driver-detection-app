package p002b.p011c.p012a.p013d;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Map;
import p002b.p008b.p009a.p010a.C0131a;
import p002b.p011c.p015b.p028b.p053e.p061r.C0605f;

@Deprecated
/* renamed from: b.c.a.d.e */
public class C0139e {

    /* renamed from: b.c.a.d.e$a */
    public static final class C0140a extends Exception {
        public C0140a(String str) {
            super(str);
        }
    }

    @Target({ElementType.FIELD})
    @Retention(RetentionPolicy.RUNTIME)
    /* renamed from: b.c.a.d.e$b */
    public @interface C0141b {
        String name();

        boolean required() default true;
    }

    /* renamed from: a */
    public void mo884a(Map<String, String> map) {
        StringBuilder sb;
        String str;
        HashMap hashMap = new HashMap();
        for (Field field : getClass().getFields()) {
            C0141b bVar = (C0141b) field.getAnnotation(C0141b.class);
            if (bVar != null) {
                hashMap.put(bVar.name(), field);
            }
        }
        if (hashMap.isEmpty()) {
            C0605f.m1109f5("No server options fields detected. To suppress this message either add a field with the @Parameter annotation, or override the load() method.");
        }
        for (Map.Entry next : map.entrySet()) {
            Field field2 = (Field) hashMap.remove(next.getKey());
            if (field2 != null) {
                try {
                    field2.set(this, next.getValue());
                } catch (IllegalAccessException unused) {
                    String str2 = (String) next.getKey();
                    sb = new StringBuilder(C0131a.m368b(str2, 49));
                    sb.append("Server option \"");
                    sb.append(str2);
                    str = "\" could not be set: Illegal Access";
                } catch (IllegalArgumentException unused2) {
                    String str3 = (String) next.getKey();
                    sb = new StringBuilder(C0131a.m368b(str3, 43));
                    sb.append("Server option \"");
                    sb.append(str3);
                    str = "\" could not be set: Bad Type";
                }
            } else {
                String str4 = (String) next.getKey();
                String str5 = (String) next.getValue();
                StringBuilder k = C0131a.m377k(C0131a.m368b(str5, C0131a.m368b(str4, 31)), "Unexpected server option: ", str4, " = \"", str5);
                k.append("\"");
                C0605f.m1030T4(k.toString());
            }
        }
        StringBuilder sb2 = new StringBuilder();
        for (Field field3 : hashMap.values()) {
            if (((C0141b) field3.getAnnotation(C0141b.class)).required()) {
                String valueOf = String.valueOf(((C0141b) field3.getAnnotation(C0141b.class)).name());
                C0605f.m1109f5(valueOf.length() != 0 ? "Required server option missing: ".concat(valueOf) : new String("Required server option missing: "));
                if (sb2.length() > 0) {
                    sb2.append(", ");
                }
                sb2.append(((C0141b) field3.getAnnotation(C0141b.class)).name());
            }
        }
        if (sb2.length() > 0) {
            String valueOf2 = String.valueOf(sb2.toString());
            throw new C0140a(valueOf2.length() != 0 ? "Required server option(s) missing: ".concat(valueOf2) : new String("Required server option(s) missing: "));
        }
        return;
        sb.append(str);
        C0605f.m1109f5(sb.toString());
    }
}
