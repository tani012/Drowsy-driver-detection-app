package p002b.p011c.p012a.p013d;

import p002b.p011c.p012a.p013d.C0139e;

@Deprecated
/* renamed from: b.c.a.d.b */
public interface C0136b<ADDITIONAL_PARAMETERS, SERVER_PARAMETERS extends C0139e> {
    void destroy();

    Class<ADDITIONAL_PARAMETERS> getAdditionalParametersType();

    Class<SERVER_PARAMETERS> getServerParametersType();
}
