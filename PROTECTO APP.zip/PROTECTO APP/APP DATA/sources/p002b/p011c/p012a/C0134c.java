package p002b.p011c.p012a;

import p002b.p011c.p015b.p028b.p029a.C0305f;

@Deprecated
/* renamed from: b.c.a.c */
public final class C0134c {

    /* renamed from: b */
    public static final C0134c f767b = new C0134c(-1, -2);

    /* renamed from: c */
    public static final C0134c f768c = new C0134c(320, 50);

    /* renamed from: d */
    public static final C0134c f769d = new C0134c(300, 250);

    /* renamed from: e */
    public static final C0134c f770e = new C0134c(468, 60);

    /* renamed from: f */
    public static final C0134c f771f = new C0134c(728, 90);

    /* renamed from: g */
    public static final C0134c f772g = new C0134c(160, 600);

    /* renamed from: a */
    public final C0305f f773a;

    public C0134c(int i, int i2) {
        this.f773a = new C0305f(i, i2);
    }

    public C0134c(C0305f fVar) {
        this.f773a = fVar;
    }

    public final boolean equals(Object obj) {
        if (!(obj instanceof C0134c)) {
            return false;
        }
        return this.f773a.equals(((C0134c) obj).f773a);
    }

    public final int hashCode() {
        return this.f773a.hashCode();
    }

    public final String toString() {
        return this.f773a.f1125c;
    }
}
