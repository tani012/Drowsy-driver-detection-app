package p002b.p011c.p015b.p016a;

/* renamed from: b.c.b.a.c */
public interface C0150c<T, U> {
}
