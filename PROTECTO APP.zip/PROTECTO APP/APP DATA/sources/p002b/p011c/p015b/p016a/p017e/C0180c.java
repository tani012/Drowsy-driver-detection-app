package p002b.p011c.p015b.p016a.p017e;

/* renamed from: b.c.b.a.e.c */
public final /* synthetic */ class C0180c {

    /* renamed from: a */
    public final C0182e f886a;

    public C0180c(C0182e eVar) {
        this.f886a = eVar;
    }

    /* JADX WARNING: Missing exception handler attribute for start block: B:47:0x0126 */
    /* JADX WARNING: Missing exception handler attribute for start block: B:59:0x0144 */
    /* JADX WARNING: Missing exception handler attribute for start block: B:65:0x014b */
    /* renamed from: a */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public java.lang.Object mo917a(java.lang.Object r14) {
        /*
            r13 = this;
            b.c.b.a.e.e r0 = r13.f886a
            b.c.b.a.e.e$a r14 = (p002b.p011c.p015b.p016a.p017e.C0182e.C0183a) r14
            r1 = 0
            if (r0 == 0) goto L_0x016c
            java.net.URL r2 = r14.f894a
            java.lang.String r3 = "CctTransportBackend"
            java.lang.String r4 = "Making request to: %s"
            p176d.p178b.p179k.C4851q.C4862i.m15091P(r3, r4, r2)
            java.net.URL r2 = r14.f894a
            java.net.URLConnection r2 = r2.openConnection()
            java.lang.Object r2 = com.google.firebase.perf.network.FirebasePerfUrlConnection.instrument(r2)
            java.net.URLConnection r2 = (java.net.URLConnection) r2
            java.net.HttpURLConnection r2 = (java.net.HttpURLConnection) r2
            r4 = 30000(0x7530, float:4.2039E-41)
            r2.setConnectTimeout(r4)
            int r4 = r0.f893f
            r2.setReadTimeout(r4)
            r4 = 1
            r2.setDoOutput(r4)
            r5 = 0
            r2.setInstanceFollowRedirects(r5)
            java.lang.String r6 = "POST"
            r2.setRequestMethod(r6)
            java.lang.Object[] r4 = new java.lang.Object[r4]
            java.lang.String r6 = "2.3.0"
            r4[r5] = r6
            java.lang.String r5 = "datatransport/%s android/"
            java.lang.String r4 = java.lang.String.format(r5, r4)
            java.lang.String r5 = "User-Agent"
            r2.setRequestProperty(r5, r4)
            java.lang.String r4 = "Content-Encoding"
            java.lang.String r5 = "gzip"
            r2.setRequestProperty(r4, r5)
            java.lang.String r6 = "Content-Type"
            java.lang.String r7 = "application/json"
            r2.setRequestProperty(r6, r7)
            java.lang.String r7 = "Accept-Encoding"
            r2.setRequestProperty(r7, r5)
            java.lang.String r7 = r14.f896c
            if (r7 == 0) goto L_0x0062
            java.lang.String r8 = "X-Goog-Api-Key"
            r2.setRequestProperty(r8, r7)
        L_0x0062:
            r7 = 0
            java.io.OutputStream r9 = r2.getOutputStream()     // Catch:{ ConnectException -> 0x015e, UnknownHostException -> 0x015c, c -> 0x014e, IOException -> 0x014c }
            java.util.zip.GZIPOutputStream r10 = new java.util.zip.GZIPOutputStream     // Catch:{ all -> 0x0145 }
            r10.<init>(r9)     // Catch:{ all -> 0x0145 }
            b.c.d.j.a r0 = r0.f888a     // Catch:{ all -> 0x0140 }
            b.c.b.a.e.b.j r14 = r14.f895b     // Catch:{ all -> 0x0140 }
            java.io.BufferedWriter r11 = new java.io.BufferedWriter     // Catch:{ all -> 0x0140 }
            java.io.OutputStreamWriter r12 = new java.io.OutputStreamWriter     // Catch:{ all -> 0x0140 }
            r12.<init>(r10)     // Catch:{ all -> 0x0140 }
            r11.<init>(r12)     // Catch:{ all -> 0x0140 }
            b.c.d.j.i.d r0 = (p002b.p011c.p110d.p137j.p139i.C4324d) r0
            r0.mo8662a(r14, r11)     // Catch:{ all -> 0x0140 }
            r10.close()     // Catch:{ all -> 0x0145 }
            if (r9 == 0) goto L_0x0088
            r9.close()     // Catch:{ ConnectException -> 0x015e, UnknownHostException -> 0x015c, c -> 0x014e, IOException -> 0x014c }
        L_0x0088:
            int r14 = r2.getResponseCode()
            java.lang.StringBuilder r0 = new java.lang.StringBuilder
            r0.<init>()
            java.lang.String r9 = "Status Code: "
            r0.append(r9)
            r0.append(r14)
            java.lang.String r0 = r0.toString()
            p176d.p178b.p179k.C4851q.C4862i.m15138i0(r3, r0)
            java.lang.StringBuilder r0 = new java.lang.StringBuilder
            r0.<init>()
            java.lang.String r9 = "Content-Type: "
            r0.append(r9)
            java.lang.String r6 = r2.getHeaderField(r6)
            r0.append(r6)
            java.lang.String r0 = r0.toString()
            p176d.p178b.p179k.C4851q.C4862i.m15138i0(r3, r0)
            java.lang.StringBuilder r0 = new java.lang.StringBuilder
            r0.<init>()
            java.lang.String r6 = "Content-Encoding: "
            r0.append(r6)
            java.lang.String r6 = r2.getHeaderField(r4)
            r0.append(r6)
            java.lang.String r0 = r0.toString()
            p176d.p178b.p179k.C4851q.C4862i.m15138i0(r3, r0)
            r0 = 302(0x12e, float:4.23E-43)
            if (r14 == r0) goto L_0x012e
            r0 = 301(0x12d, float:4.22E-43)
            if (r14 == r0) goto L_0x012e
            r0 = 307(0x133, float:4.3E-43)
            if (r14 != r0) goto L_0x00dd
            goto L_0x012e
        L_0x00dd:
            r0 = 200(0xc8, float:2.8E-43)
            if (r14 == r0) goto L_0x00e8
            b.c.b.a.e.e$b r0 = new b.c.b.a.e.e$b
            r0.<init>(r14, r1, r7)
            goto L_0x016b
        L_0x00e8:
            java.io.InputStream r0 = r2.getInputStream()
            java.lang.String r2 = r2.getHeaderField(r4)     // Catch:{ all -> 0x0127 }
            boolean r2 = r5.equals(r2)     // Catch:{ all -> 0x0127 }
            if (r2 == 0) goto L_0x00fc
            java.util.zip.GZIPInputStream r2 = new java.util.zip.GZIPInputStream     // Catch:{ all -> 0x0127 }
            r2.<init>(r0)     // Catch:{ all -> 0x0127 }
            goto L_0x00fd
        L_0x00fc:
            r2 = r0
        L_0x00fd:
            java.io.BufferedReader r3 = new java.io.BufferedReader     // Catch:{ all -> 0x0120 }
            java.io.InputStreamReader r4 = new java.io.InputStreamReader     // Catch:{ all -> 0x0120 }
            r4.<init>(r2)     // Catch:{ all -> 0x0120 }
            r3.<init>(r4)     // Catch:{ all -> 0x0120 }
            b.c.b.a.e.b.n r3 = p002b.p011c.p015b.p016a.p017e.p018b.C0175n.m403a(r3)     // Catch:{ all -> 0x0120 }
            b.c.b.a.e.b.h r3 = (p002b.p011c.p015b.p016a.p017e.p018b.C0167h) r3     // Catch:{ all -> 0x0120 }
            long r3 = r3.f830a     // Catch:{ all -> 0x0120 }
            b.c.b.a.e.e$b r5 = new b.c.b.a.e.e$b     // Catch:{ all -> 0x0120 }
            r5.<init>(r14, r1, r3)     // Catch:{ all -> 0x0120 }
            if (r2 == 0) goto L_0x0119
            r2.close()     // Catch:{ all -> 0x0127 }
        L_0x0119:
            if (r0 == 0) goto L_0x011e
            r0.close()
        L_0x011e:
            r0 = r5
            goto L_0x016b
        L_0x0120:
            r14 = move-exception
            if (r2 == 0) goto L_0x0126
            r2.close()     // Catch:{ all -> 0x0126 }
        L_0x0126:
            throw r14     // Catch:{ all -> 0x0127 }
        L_0x0127:
            r14 = move-exception
            if (r0 == 0) goto L_0x012d
            r0.close()     // Catch:{ all -> 0x012d }
        L_0x012d:
            throw r14
        L_0x012e:
            java.lang.String r0 = "Location"
            java.lang.String r0 = r2.getHeaderField(r0)
            b.c.b.a.e.e$b r1 = new b.c.b.a.e.e$b
            java.net.URL r2 = new java.net.URL
            r2.<init>(r0)
            r1.<init>(r14, r2, r7)
            r0 = r1
            goto L_0x016b
        L_0x0140:
            r14 = move-exception
            r10.close()     // Catch:{ all -> 0x0144 }
        L_0x0144:
            throw r14     // Catch:{ all -> 0x0145 }
        L_0x0145:
            r14 = move-exception
            if (r9 == 0) goto L_0x014b
            r9.close()     // Catch:{ all -> 0x014b }
        L_0x014b:
            throw r14     // Catch:{ ConnectException -> 0x015e, UnknownHostException -> 0x015c, c -> 0x014e, IOException -> 0x014c }
        L_0x014c:
            r14 = move-exception
            goto L_0x014f
        L_0x014e:
            r14 = move-exception
        L_0x014f:
            java.lang.String r0 = "Couldn't encode request, returning with 400"
            p176d.p178b.p179k.C4851q.C4862i.m15099T(r3, r0, r14)
            b.c.b.a.e.e$b r0 = new b.c.b.a.e.e$b
            r14 = 400(0x190, float:5.6E-43)
            r0.<init>(r14, r1, r7)
            goto L_0x016b
        L_0x015c:
            r14 = move-exception
            goto L_0x015f
        L_0x015e:
            r14 = move-exception
        L_0x015f:
            java.lang.String r0 = "Couldn't open connection, returning with 500"
            p176d.p178b.p179k.C4851q.C4862i.m15099T(r3, r0, r14)
            b.c.b.a.e.e$b r0 = new b.c.b.a.e.e$b
            r14 = 500(0x1f4, float:7.0E-43)
            r0.<init>(r14, r1, r7)
        L_0x016b:
            return r0
        L_0x016c:
            throw r1
        */
        throw new UnsupportedOperationException("Method not decompiled: p002b.p011c.p015b.p016a.p017e.C0180c.mo917a(java.lang.Object):java.lang.Object");
    }
}
