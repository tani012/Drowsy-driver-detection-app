package p002b.p011c.p015b.p016a.p017e.p018b;

import p002b.p008b.p009a.p010a.C0131a;
import p002b.p011c.p015b.p016a.p017e.p018b.C0170k;

/* renamed from: b.c.b.a.e.b.e */
public final class C0163e extends C0170k {

    /* renamed from: a */
    public final C0170k.C0171a f807a;

    /* renamed from: b */
    public final C0153a f808b;

    public /* synthetic */ C0163e(C0170k.C0171a aVar, C0153a aVar2) {
        this.f807a = aVar;
        this.f808b = aVar2;
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof C0170k)) {
            return false;
        }
        C0170k.C0171a aVar = this.f807a;
        if (aVar != null ? aVar.equals(((C0163e) obj).f807a) : ((C0163e) obj).f807a == null) {
            C0153a aVar2 = this.f808b;
            C0153a aVar3 = ((C0163e) obj).f808b;
            if (aVar2 == null) {
                if (aVar3 == null) {
                    return true;
                }
            } else if (aVar2.equals(aVar3)) {
                return true;
            }
        }
        return false;
    }

    public int hashCode() {
        C0170k.C0171a aVar = this.f807a;
        int i = 0;
        int hashCode = ((aVar == null ? 0 : aVar.hashCode()) ^ 1000003) * 1000003;
        C0153a aVar2 = this.f808b;
        if (aVar2 != null) {
            i = aVar2.hashCode();
        }
        return hashCode ^ i;
    }

    public String toString() {
        StringBuilder m = C0131a.m379m("ClientInfo{clientType=");
        m.append(this.f807a);
        m.append(", androidClientInfo=");
        m.append(this.f808b);
        m.append("}");
        return m.toString();
    }
}
