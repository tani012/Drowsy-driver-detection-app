package p002b.p011c.p015b.p016a.p017e;

import p002b.p011c.p015b.p016a.p019f.p021o.C0222a;

/* renamed from: b.c.b.a.e.d */
public final /* synthetic */ class C0181d implements C0222a {

    /* renamed from: a */
    public static final C0181d f887a = new C0181d();
}
