package p002b.p011c.p015b.p016a;

/* renamed from: b.c.b.a.d */
public interface C0151d<T> {
}
