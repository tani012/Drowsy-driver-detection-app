package p002b.p011c.p015b.p016a.p017e.p018b;

import java.util.List;
import p002b.p008b.p009a.p010a.C0131a;

/* renamed from: b.c.b.a.e.b.g */
public final class C0166g extends C0174m {

    /* renamed from: a */
    public final long f823a;

    /* renamed from: b */
    public final long f824b;

    /* renamed from: c */
    public final C0170k f825c;

    /* renamed from: d */
    public final Integer f826d;

    /* renamed from: e */
    public final String f827e;

    /* renamed from: f */
    public final List<C0172l> f828f;

    /* renamed from: g */
    public final C0179p f829g;

    public /* synthetic */ C0166g(long j, long j2, C0170k kVar, Integer num, String str, List list, C0179p pVar) {
        this.f823a = j;
        this.f824b = j2;
        this.f825c = kVar;
        this.f826d = num;
        this.f827e = str;
        this.f828f = list;
        this.f829g = pVar;
    }

    public boolean equals(Object obj) {
        C0170k kVar;
        Integer num;
        String str;
        List<C0172l> list;
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof C0174m)) {
            return false;
        }
        C0166g gVar = (C0166g) ((C0174m) obj);
        if (this.f823a == gVar.f823a && this.f824b == gVar.f824b && ((kVar = this.f825c) != null ? kVar.equals(gVar.f825c) : gVar.f825c == null) && ((num = this.f826d) != null ? num.equals(gVar.f826d) : gVar.f826d == null) && ((str = this.f827e) != null ? str.equals(gVar.f827e) : gVar.f827e == null) && ((list = this.f828f) != null ? list.equals(gVar.f828f) : gVar.f828f == null)) {
            C0179p pVar = this.f829g;
            C0179p pVar2 = gVar.f829g;
            if (pVar == null) {
                if (pVar2 == null) {
                    return true;
                }
            } else if (pVar.equals(pVar2)) {
                return true;
            }
        }
        return false;
    }

    public int hashCode() {
        long j = this.f823a;
        long j2 = this.f824b;
        int i = (((((int) (j ^ (j >>> 32))) ^ 1000003) * 1000003) ^ ((int) ((j2 >>> 32) ^ j2))) * 1000003;
        C0170k kVar = this.f825c;
        int i2 = 0;
        int hashCode = (i ^ (kVar == null ? 0 : kVar.hashCode())) * 1000003;
        Integer num = this.f826d;
        int hashCode2 = (hashCode ^ (num == null ? 0 : num.hashCode())) * 1000003;
        String str = this.f827e;
        int hashCode3 = (hashCode2 ^ (str == null ? 0 : str.hashCode())) * 1000003;
        List<C0172l> list = this.f828f;
        int hashCode4 = (hashCode3 ^ (list == null ? 0 : list.hashCode())) * 1000003;
        C0179p pVar = this.f829g;
        if (pVar != null) {
            i2 = pVar.hashCode();
        }
        return hashCode4 ^ i2;
    }

    public String toString() {
        StringBuilder m = C0131a.m379m("LogRequest{requestTimeMs=");
        m.append(this.f823a);
        m.append(", requestUptimeMs=");
        m.append(this.f824b);
        m.append(", clientInfo=");
        m.append(this.f825c);
        m.append(", logSource=");
        m.append(this.f826d);
        m.append(", logSourceName=");
        m.append(this.f827e);
        m.append(", logEvents=");
        m.append(this.f828f);
        m.append(", qosTier=");
        m.append(this.f829g);
        m.append("}");
        return m.toString();
    }
}
