package p002b.p011c.p015b.p016a.p017e.p018b;

import java.util.List;
import p002b.p008b.p009a.p010a.C0131a;

/* renamed from: b.c.b.a.e.b.d */
public final class C0162d extends C0169j {

    /* renamed from: a */
    public final List<C0174m> f806a;

    public C0162d(List<C0174m> list) {
        if (list != null) {
            this.f806a = list;
            return;
        }
        throw new NullPointerException("Null logRequests");
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (obj instanceof C0169j) {
            return this.f806a.equals(((C0162d) ((C0169j) obj)).f806a);
        }
        return false;
    }

    public int hashCode() {
        return this.f806a.hashCode() ^ 1000003;
    }

    public String toString() {
        StringBuilder m = C0131a.m379m("BatchedLogRequest{logRequests=");
        m.append(this.f806a);
        m.append("}");
        return m.toString();
    }
}
