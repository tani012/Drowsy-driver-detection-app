package p002b.p011c.p015b.p016a.p017e.p018b;

import p002b.p008b.p009a.p010a.C0131a;
import p002b.p011c.p015b.p016a.p017e.p018b.C0176o;

/* renamed from: b.c.b.a.e.b.i */
public final class C0168i extends C0176o {

    /* renamed from: a */
    public final C0176o.C0178b f831a;

    /* renamed from: b */
    public final C0176o.C0177a f832b;

    public /* synthetic */ C0168i(C0176o.C0178b bVar, C0176o.C0177a aVar) {
        this.f831a = bVar;
        this.f832b = aVar;
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof C0176o)) {
            return false;
        }
        C0176o.C0178b bVar = this.f831a;
        if (bVar != null ? bVar.equals(((C0168i) obj).f831a) : ((C0168i) obj).f831a == null) {
            C0176o.C0177a aVar = this.f832b;
            C0176o.C0177a aVar2 = ((C0168i) obj).f832b;
            if (aVar == null) {
                if (aVar2 == null) {
                    return true;
                }
            } else if (aVar.equals(aVar2)) {
                return true;
            }
        }
        return false;
    }

    public int hashCode() {
        C0176o.C0178b bVar = this.f831a;
        int i = 0;
        int hashCode = ((bVar == null ? 0 : bVar.hashCode()) ^ 1000003) * 1000003;
        C0176o.C0177a aVar = this.f832b;
        if (aVar != null) {
            i = aVar.hashCode();
        }
        return hashCode ^ i;
    }

    public String toString() {
        StringBuilder m = C0131a.m379m("NetworkConnectionInfo{networkType=");
        m.append(this.f831a);
        m.append(", mobileSubtype=");
        m.append(this.f832b);
        m.append("}");
        return m.toString();
    }
}
