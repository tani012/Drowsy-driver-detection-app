package p002b.p011c.p015b.p016a;

import p002b.p008b.p009a.p010a.C0131a;

/* renamed from: b.c.b.a.a */
public final class C0148a {

    /* renamed from: a */
    public final String f780a;

    public C0148a(String str) {
        if (str != null) {
            this.f780a = str;
            return;
        }
        throw new NullPointerException("name is null");
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof C0148a)) {
            return false;
        }
        return this.f780a.equals(((C0148a) obj).f780a);
    }

    public int hashCode() {
        return this.f780a.hashCode() ^ 1000003;
    }

    public String toString() {
        return C0131a.m375i(C0131a.m379m("Encoding{name=\""), this.f780a, "\"}");
    }
}
