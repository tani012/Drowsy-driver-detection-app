package p002b.p011c.p015b.p016a.p017e.p018b;

import p002b.p008b.p009a.p010a.C0131a;

/* renamed from: b.c.b.a.e.b.c */
public final class C0161c extends C0153a {

    /* renamed from: a */
    public final Integer f798a;

    /* renamed from: b */
    public final String f799b;

    /* renamed from: c */
    public final String f800c;

    /* renamed from: d */
    public final String f801d;

    /* renamed from: e */
    public final String f802e;

    /* renamed from: f */
    public final String f803f;

    /* renamed from: g */
    public final String f804g;

    /* renamed from: h */
    public final String f805h;

    public /* synthetic */ C0161c(Integer num, String str, String str2, String str3, String str4, String str5, String str6, String str7) {
        this.f798a = num;
        this.f799b = str;
        this.f800c = str2;
        this.f801d = str3;
        this.f802e = str4;
        this.f803f = str5;
        this.f804g = str6;
        this.f805h = str7;
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof C0153a)) {
            return false;
        }
        Integer num = this.f798a;
        if (num != null ? num.equals(((C0161c) obj).f798a) : ((C0161c) obj).f798a == null) {
            String str = this.f799b;
            if (str != null ? str.equals(((C0161c) obj).f799b) : ((C0161c) obj).f799b == null) {
                String str2 = this.f800c;
                if (str2 != null ? str2.equals(((C0161c) obj).f800c) : ((C0161c) obj).f800c == null) {
                    String str3 = this.f801d;
                    if (str3 != null ? str3.equals(((C0161c) obj).f801d) : ((C0161c) obj).f801d == null) {
                        String str4 = this.f802e;
                        if (str4 != null ? str4.equals(((C0161c) obj).f802e) : ((C0161c) obj).f802e == null) {
                            String str5 = this.f803f;
                            if (str5 != null ? str5.equals(((C0161c) obj).f803f) : ((C0161c) obj).f803f == null) {
                                String str6 = this.f804g;
                                if (str6 != null ? str6.equals(((C0161c) obj).f804g) : ((C0161c) obj).f804g == null) {
                                    String str7 = this.f805h;
                                    String str8 = ((C0161c) obj).f805h;
                                    if (str7 == null) {
                                        if (str8 == null) {
                                            return true;
                                        }
                                    } else if (str7.equals(str8)) {
                                        return true;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        return false;
    }

    public int hashCode() {
        Integer num = this.f798a;
        int i = 0;
        int hashCode = ((num == null ? 0 : num.hashCode()) ^ 1000003) * 1000003;
        String str = this.f799b;
        int hashCode2 = (hashCode ^ (str == null ? 0 : str.hashCode())) * 1000003;
        String str2 = this.f800c;
        int hashCode3 = (hashCode2 ^ (str2 == null ? 0 : str2.hashCode())) * 1000003;
        String str3 = this.f801d;
        int hashCode4 = (hashCode3 ^ (str3 == null ? 0 : str3.hashCode())) * 1000003;
        String str4 = this.f802e;
        int hashCode5 = (hashCode4 ^ (str4 == null ? 0 : str4.hashCode())) * 1000003;
        String str5 = this.f803f;
        int hashCode6 = (hashCode5 ^ (str5 == null ? 0 : str5.hashCode())) * 1000003;
        String str6 = this.f804g;
        int hashCode7 = (hashCode6 ^ (str6 == null ? 0 : str6.hashCode())) * 1000003;
        String str7 = this.f805h;
        if (str7 != null) {
            i = str7.hashCode();
        }
        return hashCode7 ^ i;
    }

    public String toString() {
        StringBuilder m = C0131a.m379m("AndroidClientInfo{sdkVersion=");
        m.append(this.f798a);
        m.append(", model=");
        m.append(this.f799b);
        m.append(", hardware=");
        m.append(this.f800c);
        m.append(", device=");
        m.append(this.f801d);
        m.append(", product=");
        m.append(this.f802e);
        m.append(", osBuild=");
        m.append(this.f803f);
        m.append(", manufacturer=");
        m.append(this.f804g);
        m.append(", fingerprint=");
        return C0131a.m375i(m, this.f805h, "}");
    }
}
