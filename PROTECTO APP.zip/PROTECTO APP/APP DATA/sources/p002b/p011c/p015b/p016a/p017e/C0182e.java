package p002b.p011c.p015b.p016a.p017e;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build;
import android.util.Log;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;
import p002b.p008b.p009a.p010a.C0131a;
import p002b.p011c.p015b.p016a.C0148a;
import p002b.p011c.p015b.p016a.p017e.p018b.C0154b;
import p002b.p011c.p015b.p016a.p017e.p018b.C0161c;
import p002b.p011c.p015b.p016a.p017e.p018b.C0162d;
import p002b.p011c.p015b.p016a.p017e.p018b.C0163e;
import p002b.p011c.p015b.p016a.p017e.p018b.C0164f;
import p002b.p011c.p015b.p016a.p017e.p018b.C0166g;
import p002b.p011c.p015b.p016a.p017e.p018b.C0168i;
import p002b.p011c.p015b.p016a.p017e.p018b.C0169j;
import p002b.p011c.p015b.p016a.p017e.p018b.C0170k;
import p002b.p011c.p015b.p016a.p017e.p018b.C0176o;
import p002b.p011c.p015b.p016a.p017e.p018b.C0179p;
import p002b.p011c.p015b.p016a.p019f.C0185a;
import p002b.p011c.p015b.p016a.p019f.C0193d;
import p002b.p011c.p015b.p016a.p019f.C0194e;
import p002b.p011c.p015b.p016a.p019f.p020n.C0206a;
import p002b.p011c.p015b.p016a.p019f.p020n.C0208b;
import p002b.p011c.p015b.p016a.p019f.p020n.C0212f;
import p002b.p011c.p015b.p016a.p019f.p020n.C0213g;
import p002b.p011c.p015b.p016a.p019f.p020n.C0221m;
import p002b.p011c.p015b.p016a.p019f.p026r.C0284a;
import p002b.p011c.p110d.p137j.C4312a;
import p002b.p011c.p110d.p137j.p139i.C4324d;
import p002b.p011c.p110d.p137j.p139i.C4325e;
import p176d.p178b.p179k.C4851q;

/* renamed from: b.c.b.a.e.e */
public final class C0182e implements C0221m {

    /* renamed from: a */
    public final C4312a f888a;

    /* renamed from: b */
    public final ConnectivityManager f889b;

    /* renamed from: c */
    public final URL f890c = m405c(C0152a.f785c);

    /* renamed from: d */
    public final C0284a f891d;

    /* renamed from: e */
    public final C0284a f892e;

    /* renamed from: f */
    public final int f893f;

    /* renamed from: b.c.b.a.e.e$a */
    public static final class C0183a {

        /* renamed from: a */
        public final URL f894a;

        /* renamed from: b */
        public final C0169j f895b;

        /* renamed from: c */
        public final String f896c;

        public C0183a(URL url, C0169j jVar, String str) {
            this.f894a = url;
            this.f895b = jVar;
            this.f896c = str;
        }
    }

    /* renamed from: b.c.b.a.e.e$b */
    public static final class C0184b {

        /* renamed from: a */
        public final int f897a;

        /* renamed from: b */
        public final URL f898b;

        /* renamed from: c */
        public final long f899c;

        public C0184b(int i, URL url, long j) {
            this.f897a = i;
            this.f898b = url;
            this.f899c = j;
        }
    }

    public C0182e(Context context, C0284a aVar, C0284a aVar2) {
        C4325e eVar = new C4325e();
        ((C0154b) C0154b.f791a).mo894a(eVar);
        eVar.f16395d = true;
        this.f888a = new C4324d(eVar);
        this.f889b = (ConnectivityManager) context.getSystemService("connectivity");
        this.f891d = aVar2;
        this.f892e = aVar;
        this.f893f = 40000;
    }

    /* renamed from: c */
    public static URL m405c(String str) {
        try {
            return new URL(str);
        } catch (MalformedURLException e) {
            throw new IllegalArgumentException(C0131a.m373g("Invalid url: ", str), e);
        }
    }

    /* renamed from: a */
    public C0194e mo918a(C0194e eVar) {
        int i;
        int i2;
        C0176o.C0177a aVar;
        NetworkInfo activeNetworkInfo = this.f889b.getActiveNetworkInfo();
        C0194e.C0195a c = eVar.mo939c();
        c.mo924c().put("sdk-version", String.valueOf(Build.VERSION.SDK_INT));
        c.mo924c().put("model", Build.MODEL);
        c.mo924c().put("hardware", Build.HARDWARE);
        c.mo924c().put("device", Build.DEVICE);
        c.mo924c().put("product", Build.PRODUCT);
        c.mo924c().put("os-uild", Build.ID);
        c.mo924c().put("manufacturer", Build.MANUFACTURER);
        c.mo924c().put("fingerprint", Build.FINGERPRINT);
        Calendar.getInstance();
        c.mo924c().put("tz-offset", String.valueOf((long) (TimeZone.getDefault().getOffset(Calendar.getInstance().getTimeInMillis()) / 1000)));
        if (activeNetworkInfo == null) {
            i = C0176o.C0178b.NONE.f878e;
        } else {
            i = activeNetworkInfo.getType();
        }
        c.mo924c().put("net-type", String.valueOf(i));
        if (activeNetworkInfo == null) {
            aVar = C0176o.C0177a.UNKNOWN_MOBILE_SUBTYPE;
        } else {
            i2 = activeNetworkInfo.getSubtype();
            if (i2 == -1) {
                aVar = C0176o.C0177a.COMBINED;
            } else {
                if (C0176o.C0177a.f835A.get(i2) == null) {
                    i2 = 0;
                }
                c.mo924c().put("mobile-subtype", String.valueOf(i2));
                return c.mo923b();
            }
        }
        i2 = aVar.f857e;
        c.mo924c().put("mobile-subtype", String.valueOf(i2));
        return c.mo923b();
    }

    /* renamed from: b */
    public C0213g mo919b(C0212f fVar) {
        C0213g.C0214a aVar;
        String str;
        Integer num;
        C0164f.C0165a aVar2;
        C0182e eVar = this;
        C0213g.C0214a aVar3 = C0213g.C0214a.TRANSIENT_ERROR;
        HashMap hashMap = new HashMap();
        C0206a aVar4 = (C0206a) fVar;
        for (C0194e next : aVar4.f950a) {
            String str2 = ((C0185a) next).f900a;
            if (!hashMap.containsKey(str2)) {
                ArrayList arrayList = new ArrayList();
                arrayList.add(next);
                hashMap.put(str2, arrayList);
            } else {
                ((List) hashMap.get(str2)).add(next);
            }
        }
        ArrayList arrayList2 = new ArrayList();
        Iterator it = hashMap.entrySet().iterator();
        while (true) {
            String str3 = null;
            if (it.hasNext()) {
                Map.Entry entry = (Map.Entry) it.next();
                C0194e eVar2 = (C0194e) ((List) entry.getValue()).get(0);
                C0179p pVar = C0179p.DEFAULT;
                Long valueOf = Long.valueOf(eVar.f892e.mo1019a());
                Long valueOf2 = Long.valueOf(eVar.f891d.mo1019a());
                C0163e eVar3 = new C0163e(C0170k.C0171a.ANDROID_FIREBASE, new C0161c(Integer.valueOf(eVar2.mo938b("sdk-version")), eVar2.mo937a("model"), eVar2.mo937a("hardware"), eVar2.mo937a("device"), eVar2.mo937a("product"), eVar2.mo937a("os-uild"), eVar2.mo937a("manufacturer"), eVar2.mo937a("fingerprint")));
                try {
                    str = null;
                    num = Integer.valueOf(Integer.parseInt((String) entry.getKey()));
                } catch (NumberFormatException unused) {
                    num = null;
                    str = (String) entry.getKey();
                }
                ArrayList arrayList3 = new ArrayList();
                Iterator it2 = ((List) entry.getValue()).iterator();
                while (it2.hasNext()) {
                    C0194e eVar4 = (C0194e) it2.next();
                    C0185a aVar5 = (C0185a) eVar4;
                    Iterator it3 = it;
                    C0193d dVar = aVar5.f902c;
                    Iterator it4 = it2;
                    C0148a aVar6 = dVar.f930a;
                    String str4 = "";
                    C0213g.C0214a aVar7 = aVar3;
                    if (aVar6.equals(new C0148a("proto"))) {
                        byte[] bArr = dVar.f931b;
                        aVar2 = new C0164f.C0165a();
                        aVar2.f819d = bArr;
                    } else if (aVar6.equals(new C0148a("json"))) {
                        String str5 = new String(dVar.f931b, Charset.forName("UTF-8"));
                        C0164f.C0165a aVar8 = new C0164f.C0165a();
                        aVar8.f820e = str5;
                        aVar2 = aVar8;
                    } else {
                        Log.w(C4851q.C4862i.m15126e0("CctTransportBackend"), String.format("Received event of unsupported encoding %s. Skipping...", new Object[]{aVar6}));
                        it2 = it4;
                        it = it3;
                        aVar3 = aVar7;
                    }
                    aVar2.f816a = Long.valueOf(aVar5.f903d);
                    aVar2.f818c = Long.valueOf(aVar5.f904e);
                    String str6 = aVar5.f905f.get("tz-offset");
                    aVar2.f821f = Long.valueOf(str6 == null ? 0 : Long.valueOf(str6).longValue());
                    aVar2.f822g = new C0168i(C0176o.C0178b.f877y.get(eVar4.mo938b("net-type")), C0176o.C0177a.f835A.get(eVar4.mo938b("mobile-subtype")));
                    Integer num2 = aVar5.f901b;
                    if (num2 != null) {
                        aVar2.f817b = num2;
                    }
                    String str7 = aVar2.f816a == null ? " eventTimeMs" : str4;
                    if (aVar2.f818c == null) {
                        str7 = C0131a.m373g(str7, " eventUptimeMs");
                    }
                    if (aVar2.f821f == null) {
                        str7 = C0131a.m373g(str7, " timezoneOffsetSeconds");
                    }
                    if (str7.isEmpty()) {
                        arrayList3.add(new C0164f(aVar2.f816a.longValue(), aVar2.f817b, aVar2.f818c.longValue(), aVar2.f819d, aVar2.f820e, aVar2.f821f.longValue(), aVar2.f822g));
                        it2 = it4;
                        it = it3;
                        aVar3 = aVar7;
                    } else {
                        throw new IllegalStateException(C0131a.m373g("Missing required properties:", str7));
                    }
                }
                Iterator it5 = it;
                C0213g.C0214a aVar9 = aVar3;
                String str8 = valueOf == null ? " requestTimeMs" : "";
                if (valueOf2 == null) {
                    str8 = C0131a.m373g(str8, " requestUptimeMs");
                }
                if (str8.isEmpty()) {
                    arrayList2.add(new C0166g(valueOf.longValue(), valueOf2.longValue(), eVar3, num, str, arrayList3, pVar));
                    eVar = this;
                    it = it5;
                    aVar3 = aVar9;
                } else {
                    throw new IllegalStateException(C0131a.m373g("Missing required properties:", str8));
                }
            } else {
                C0213g.C0214a aVar10 = aVar3;
                C0162d dVar2 = new C0162d(arrayList2);
                URL url = this.f890c;
                if (aVar4.f951b != null) {
                    try {
                        C0152a a = C0152a.m392a(((C0206a) fVar).f951b);
                        if (a.f790b != null) {
                            str3 = a.f790b;
                        }
                        if (a.f789a != null) {
                            url = m405c(a.f789a);
                        }
                    } catch (IllegalArgumentException unused2) {
                        return C0213g.m434a();
                    }
                }
                try {
                    C0184b bVar = (C0184b) C4851q.C4862i.m15082K0(5, new C0183a(url, dVar2, str3), new C0180c(this), C0181d.f887a);
                    if (bVar.f897a == 200) {
                        return new C0208b(C0213g.C0214a.OK, bVar.f899c);
                    }
                    int i = bVar.f897a;
                    if (i < 500) {
                        if (i != 404) {
                            return C0213g.m434a();
                        }
                    }
                    aVar = aVar10;
                    try {
                        return new C0208b(aVar, -1);
                    } catch (IOException e) {
                        e = e;
                        C4851q.C4862i.m15099T("CctTransportBackend", "Could not make request to the backend", e);
                        return new C0208b(aVar, -1);
                    }
                } catch (IOException e2) {
                    e = e2;
                    aVar = aVar10;
                    C4851q.C4862i.m15099T("CctTransportBackend", "Could not make request to the backend", e);
                    return new C0208b(aVar, -1);
                }
            }
        }
    }
}
