package p002b.p011c.p015b.p016a.p017e.p018b;

import java.util.Arrays;
import p002b.p008b.p009a.p010a.C0131a;
import p002b.p011c.p015b.p016a.p017e.p018b.C0172l;

/* renamed from: b.c.b.a.e.b.f */
public final class C0164f extends C0172l {

    /* renamed from: a */
    public final long f809a;

    /* renamed from: b */
    public final Integer f810b;

    /* renamed from: c */
    public final long f811c;

    /* renamed from: d */
    public final byte[] f812d;

    /* renamed from: e */
    public final String f813e;

    /* renamed from: f */
    public final long f814f;

    /* renamed from: g */
    public final C0176o f815g;

    /* renamed from: b.c.b.a.e.b.f$a */
    public static final class C0165a extends C0172l.C0173a {

        /* renamed from: a */
        public Long f816a;

        /* renamed from: b */
        public Integer f817b;

        /* renamed from: c */
        public Long f818c;

        /* renamed from: d */
        public byte[] f819d;

        /* renamed from: e */
        public String f820e;

        /* renamed from: f */
        public Long f821f;

        /* renamed from: g */
        public C0176o f822g;
    }

    public /* synthetic */ C0164f(long j, Integer num, long j2, byte[] bArr, String str, long j3, C0176o oVar) {
        this.f809a = j;
        this.f810b = num;
        this.f811c = j2;
        this.f812d = bArr;
        this.f813e = str;
        this.f814f = j3;
        this.f815g = oVar;
    }

    public boolean equals(Object obj) {
        Integer num;
        byte[] bArr;
        String str;
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof C0172l)) {
            return false;
        }
        C0172l lVar = (C0172l) obj;
        C0164f fVar = (C0164f) lVar;
        if (this.f809a == fVar.f809a && ((num = this.f810b) != null ? num.equals(fVar.f810b) : fVar.f810b == null) && this.f811c == fVar.f811c) {
            byte[] bArr2 = this.f812d;
            if (lVar instanceof C0164f) {
                bArr = fVar.f812d;
            } else {
                bArr = fVar.f812d;
            }
            if (Arrays.equals(bArr2, bArr) && ((str = this.f813e) != null ? str.equals(fVar.f813e) : fVar.f813e == null) && this.f814f == fVar.f814f) {
                C0176o oVar = this.f815g;
                if (oVar == null) {
                    if (fVar.f815g == null) {
                        return true;
                    }
                } else if (oVar.equals(fVar.f815g)) {
                    return true;
                }
            }
        }
        return false;
    }

    public int hashCode() {
        long j = this.f809a;
        int i = (((int) (j ^ (j >>> 32))) ^ 1000003) * 1000003;
        Integer num = this.f810b;
        int i2 = 0;
        int hashCode = num == null ? 0 : num.hashCode();
        long j2 = this.f811c;
        int hashCode2 = (((((i ^ hashCode) * 1000003) ^ ((int) (j2 ^ (j2 >>> 32)))) * 1000003) ^ Arrays.hashCode(this.f812d)) * 1000003;
        String str = this.f813e;
        int hashCode3 = str == null ? 0 : str.hashCode();
        long j3 = this.f814f;
        int i3 = (((hashCode2 ^ hashCode3) * 1000003) ^ ((int) ((j3 >>> 32) ^ j3))) * 1000003;
        C0176o oVar = this.f815g;
        if (oVar != null) {
            i2 = oVar.hashCode();
        }
        return i3 ^ i2;
    }

    public String toString() {
        StringBuilder m = C0131a.m379m("LogEvent{eventTimeMs=");
        m.append(this.f809a);
        m.append(", eventCode=");
        m.append(this.f810b);
        m.append(", eventUptimeMs=");
        m.append(this.f811c);
        m.append(", sourceExtension=");
        m.append(Arrays.toString(this.f812d));
        m.append(", sourceExtensionJsonProto3=");
        m.append(this.f813e);
        m.append(", timezoneOffsetSeconds=");
        m.append(this.f814f);
        m.append(", networkConnectionInfo=");
        m.append(this.f815g);
        m.append("}");
        return m.toString();
    }
}
