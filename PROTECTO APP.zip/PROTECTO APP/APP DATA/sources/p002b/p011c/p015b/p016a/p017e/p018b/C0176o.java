package p002b.p011c.p015b.p016a.p017e.p018b;

import android.util.SparseArray;

/* renamed from: b.c.b.a.e.b.o */
public abstract class C0176o {

    /* renamed from: b.c.b.a.e.b.o$a */
    public enum C0177a {
        UNKNOWN_MOBILE_SUBTYPE(0),
        GPRS(1),
        EDGE(2),
        UMTS(3),
        CDMA(4),
        EVDO_0(5),
        EVDO_A(6),
        RTT(7),
        HSDPA(8),
        HSUPA(9),
        HSPA(10),
        IDEN(11),
        EVDO_B(12),
        LTE(13),
        EHRPD(14),
        HSPAP(15),
        GSM(16),
        TD_SCDMA(17),
        IWLAN(18),
        LTE_CA(19),
        COMBINED(100);
        

        /* renamed from: A */
        public static final SparseArray<C0177a> f835A = null;

        /* renamed from: e */
        public final int f857e;

        /* access modifiers changed from: public */
        static {
            UNKNOWN_MOBILE_SUBTYPE = new C0177a("UNKNOWN_MOBILE_SUBTYPE", 0, 0);
            GPRS = new C0177a("GPRS", 1, 1);
            EDGE = new C0177a("EDGE", 2, 2);
            UMTS = new C0177a("UMTS", 3, 3);
            CDMA = new C0177a("CDMA", 4, 4);
            EVDO_0 = new C0177a("EVDO_0", 5, 5);
            EVDO_A = new C0177a("EVDO_A", 6, 6);
            RTT = new C0177a("RTT", 7, 7);
            HSDPA = new C0177a("HSDPA", 8, 8);
            HSUPA = new C0177a("HSUPA", 9, 9);
            HSPA = new C0177a("HSPA", 10, 10);
            IDEN = new C0177a("IDEN", 11, 11);
            EVDO_B = new C0177a("EVDO_B", 12, 12);
            LTE = new C0177a("LTE", 13, 13);
            EHRPD = new C0177a("EHRPD", 14, 14);
            HSPAP = new C0177a("HSPAP", 15, 15);
            GSM = new C0177a("GSM", 16, 16);
            TD_SCDMA = new C0177a("TD_SCDMA", 17, 17);
            IWLAN = new C0177a("IWLAN", 18, 18);
            LTE_CA = new C0177a("LTE_CA", 19, 19);
            COMBINED = new C0177a("COMBINED", 20, 100);
            SparseArray<C0177a> sparseArray = new SparseArray<>();
            f835A = sparseArray;
            sparseArray.put(0, UNKNOWN_MOBILE_SUBTYPE);
            f835A.put(1, GPRS);
            f835A.put(2, EDGE);
            f835A.put(3, UMTS);
            f835A.put(4, CDMA);
            f835A.put(5, EVDO_0);
            f835A.put(6, EVDO_A);
            f835A.put(7, RTT);
            f835A.put(8, HSDPA);
            f835A.put(9, HSUPA);
            f835A.put(10, HSPA);
            f835A.put(11, IDEN);
            f835A.put(12, EVDO_B);
            f835A.put(13, LTE);
            f835A.put(14, EHRPD);
            f835A.put(15, HSPAP);
            f835A.put(16, GSM);
            f835A.put(17, TD_SCDMA);
            f835A.put(18, IWLAN);
            f835A.put(19, LTE_CA);
        }

        /* access modifiers changed from: public */
        C0177a(int i) {
            this.f857e = i;
        }
    }

    /* renamed from: b.c.b.a.e.b.o$b */
    public enum C0178b {
        MOBILE(0),
        WIFI(1),
        MOBILE_MMS(2),
        MOBILE_SUPL(3),
        MOBILE_DUN(4),
        MOBILE_HIPRI(5),
        WIMAX(6),
        BLUETOOTH(7),
        DUMMY(8),
        ETHERNET(9),
        MOBILE_FOTA(10),
        MOBILE_IMS(11),
        MOBILE_CBS(12),
        WIFI_P2P(13),
        MOBILE_IA(14),
        MOBILE_EMERGENCY(15),
        PROXY(16),
        VPN(17),
        NONE(-1);
        

        /* renamed from: y */
        public static final SparseArray<C0178b> f877y = null;

        /* renamed from: e */
        public final int f878e;

        /* access modifiers changed from: public */
        static {
            MOBILE = new C0178b("MOBILE", 0, 0);
            WIFI = new C0178b("WIFI", 1, 1);
            MOBILE_MMS = new C0178b("MOBILE_MMS", 2, 2);
            MOBILE_SUPL = new C0178b("MOBILE_SUPL", 3, 3);
            MOBILE_DUN = new C0178b("MOBILE_DUN", 4, 4);
            MOBILE_HIPRI = new C0178b("MOBILE_HIPRI", 5, 5);
            WIMAX = new C0178b("WIMAX", 6, 6);
            BLUETOOTH = new C0178b("BLUETOOTH", 7, 7);
            DUMMY = new C0178b("DUMMY", 8, 8);
            ETHERNET = new C0178b("ETHERNET", 9, 9);
            MOBILE_FOTA = new C0178b("MOBILE_FOTA", 10, 10);
            MOBILE_IMS = new C0178b("MOBILE_IMS", 11, 11);
            MOBILE_CBS = new C0178b("MOBILE_CBS", 12, 12);
            WIFI_P2P = new C0178b("WIFI_P2P", 13, 13);
            MOBILE_IA = new C0178b("MOBILE_IA", 14, 14);
            MOBILE_EMERGENCY = new C0178b("MOBILE_EMERGENCY", 15, 15);
            PROXY = new C0178b("PROXY", 16, 16);
            VPN = new C0178b("VPN", 17, 17);
            NONE = new C0178b("NONE", 18, -1);
            SparseArray<C0178b> sparseArray = new SparseArray<>();
            f877y = sparseArray;
            sparseArray.put(0, MOBILE);
            f877y.put(1, WIFI);
            f877y.put(2, MOBILE_MMS);
            f877y.put(3, MOBILE_SUPL);
            f877y.put(4, MOBILE_DUN);
            f877y.put(5, MOBILE_HIPRI);
            f877y.put(6, WIMAX);
            f877y.put(7, BLUETOOTH);
            f877y.put(8, DUMMY);
            f877y.put(9, ETHERNET);
            f877y.put(10, MOBILE_FOTA);
            f877y.put(11, MOBILE_IMS);
            f877y.put(12, MOBILE_CBS);
            f877y.put(13, WIFI_P2P);
            f877y.put(14, MOBILE_IA);
            f877y.put(15, MOBILE_EMERGENCY);
            f877y.put(16, PROXY);
            f877y.put(17, VPN);
            f877y.put(-1, NONE);
        }

        /* access modifiers changed from: public */
        C0178b(int i) {
            this.f878e = i;
        }
    }
}
