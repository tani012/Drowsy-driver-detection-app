package p002b.p011c.p015b.p016a.p017e.p018b;

import p002b.p011c.p110d.p137j.C4315d;
import p002b.p011c.p110d.p137j.C4316e;
import p002b.p011c.p110d.p137j.p138h.C4319a;
import p002b.p011c.p110d.p137j.p138h.C4320b;
import p002b.p011c.p110d.p137j.p139i.C4325e;

/* renamed from: b.c.b.a.e.b.b */
public final class C0154b implements C4319a {

    /* renamed from: a */
    public static final C4319a f791a = new C0154b();

    /* renamed from: b.c.b.a.e.b.b$a */
    public static final class C0155a implements C4315d<C0153a> {

        /* renamed from: a */
        public static final C0155a f792a = new C0155a();

        /* renamed from: a */
        public void mo895a(Object obj, Object obj2) {
            C4316e eVar = (C4316e) obj2;
            C0161c cVar = (C0161c) ((C0153a) obj);
            eVar.mo8659f("sdkVersion", cVar.f798a);
            eVar.mo8659f("model", cVar.f799b);
            eVar.mo8659f("hardware", cVar.f800c);
            eVar.mo8659f("device", cVar.f801d);
            eVar.mo8659f("product", cVar.f802e);
            eVar.mo8659f("osBuild", cVar.f803f);
            eVar.mo8659f("manufacturer", cVar.f804g);
            eVar.mo8659f("fingerprint", cVar.f805h);
        }
    }

    /* renamed from: b.c.b.a.e.b.b$b */
    public static final class C0156b implements C4315d<C0169j> {

        /* renamed from: a */
        public static final C0156b f793a = new C0156b();

        /* renamed from: a */
        public void mo895a(Object obj, Object obj2) {
            ((C4316e) obj2).mo8659f("logRequest", ((C0162d) ((C0169j) obj)).f806a);
        }
    }

    /* renamed from: b.c.b.a.e.b.b$c */
    public static final class C0157c implements C4315d<C0170k> {

        /* renamed from: a */
        public static final C0157c f794a = new C0157c();

        /* renamed from: a */
        public void mo895a(Object obj, Object obj2) {
            C4316e eVar = (C4316e) obj2;
            C0163e eVar2 = (C0163e) ((C0170k) obj);
            eVar.mo8659f("clientType", eVar2.f807a);
            eVar.mo8659f("androidClientInfo", eVar2.f808b);
        }
    }

    /* renamed from: b.c.b.a.e.b.b$d */
    public static final class C0158d implements C4315d<C0172l> {

        /* renamed from: a */
        public static final C0158d f795a = new C0158d();

        /* renamed from: a */
        public void mo895a(Object obj, Object obj2) {
            C4316e eVar = (C4316e) obj2;
            C0164f fVar = (C0164f) ((C0172l) obj);
            eVar.mo8657b("eventTimeMs", fVar.f809a);
            eVar.mo8659f("eventCode", fVar.f810b);
            eVar.mo8657b("eventUptimeMs", fVar.f811c);
            eVar.mo8659f("sourceExtension", fVar.f812d);
            eVar.mo8659f("sourceExtensionJsonProto3", fVar.f813e);
            eVar.mo8657b("timezoneOffsetSeconds", fVar.f814f);
            eVar.mo8659f("networkConnectionInfo", fVar.f815g);
        }
    }

    /* renamed from: b.c.b.a.e.b.b$e */
    public static final class C0159e implements C4315d<C0174m> {

        /* renamed from: a */
        public static final C0159e f796a = new C0159e();

        /* renamed from: a */
        public void mo895a(Object obj, Object obj2) {
            C4316e eVar = (C4316e) obj2;
            C0166g gVar = (C0166g) ((C0174m) obj);
            eVar.mo8657b("requestTimeMs", gVar.f823a);
            eVar.mo8657b("requestUptimeMs", gVar.f824b);
            eVar.mo8659f("clientInfo", gVar.f825c);
            eVar.mo8659f("logSource", gVar.f826d);
            eVar.mo8659f("logSourceName", gVar.f827e);
            eVar.mo8659f("logEvent", gVar.f828f);
            eVar.mo8659f("qosTier", gVar.f829g);
        }
    }

    /* renamed from: b.c.b.a.e.b.b$f */
    public static final class C0160f implements C4315d<C0176o> {

        /* renamed from: a */
        public static final C0160f f797a = new C0160f();

        /* renamed from: a */
        public void mo895a(Object obj, Object obj2) {
            C4316e eVar = (C4316e) obj2;
            C0168i iVar = (C0168i) ((C0176o) obj);
            eVar.mo8659f("networkType", iVar.f831a);
            eVar.mo8659f("mobileSubtype", iVar.f832b);
        }
    }

    /* renamed from: a */
    public void mo894a(C4320b<?> bVar) {
        Class<C0169j> cls = C0169j.class;
        C4325e eVar = (C4325e) bVar;
        eVar.f16392a.put(cls, C0156b.f793a);
        eVar.f16393b.remove(cls);
        Class<C0162d> cls2 = C0162d.class;
        eVar.f16392a.put(cls2, C0156b.f793a);
        eVar.f16393b.remove(cls2);
        Class<C0174m> cls3 = C0174m.class;
        eVar.f16392a.put(cls3, C0159e.f796a);
        eVar.f16393b.remove(cls3);
        Class<C0166g> cls4 = C0166g.class;
        eVar.f16392a.put(cls4, C0159e.f796a);
        eVar.f16393b.remove(cls4);
        Class<C0170k> cls5 = C0170k.class;
        eVar.f16392a.put(cls5, C0157c.f794a);
        eVar.f16393b.remove(cls5);
        Class<C0163e> cls6 = C0163e.class;
        eVar.f16392a.put(cls6, C0157c.f794a);
        eVar.f16393b.remove(cls6);
        Class<C0153a> cls7 = C0153a.class;
        eVar.f16392a.put(cls7, C0155a.f792a);
        eVar.f16393b.remove(cls7);
        Class<C0161c> cls8 = C0161c.class;
        eVar.f16392a.put(cls8, C0155a.f792a);
        eVar.f16393b.remove(cls8);
        Class<C0172l> cls9 = C0172l.class;
        eVar.f16392a.put(cls9, C0158d.f795a);
        eVar.f16393b.remove(cls9);
        Class<C0164f> cls10 = C0164f.class;
        eVar.f16392a.put(cls10, C0158d.f795a);
        eVar.f16393b.remove(cls10);
        Class<C0176o> cls11 = C0176o.class;
        eVar.f16392a.put(cls11, C0160f.f797a);
        eVar.f16393b.remove(cls11);
        Class<C0168i> cls12 = C0168i.class;
        eVar.f16392a.put(cls12, C0160f.f797a);
        eVar.f16393b.remove(cls12);
    }
}
