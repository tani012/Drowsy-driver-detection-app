package p002b.p011c.p015b.p016a;

/* renamed from: b.c.b.a.b */
public enum C0149b {
    DEFAULT,
    VERY_LOW,
    HIGHEST
}
