package p002b.p011c.p015b.p016a.p017e.p018b;

/* renamed from: b.c.b.a.e.b.k */
public abstract class C0170k {

    /* renamed from: b.c.b.a.e.b.k$a */
    public enum C0171a {
        UNKNOWN,
        ANDROID_FIREBASE;

        /* access modifiers changed from: public */
        static {
            UNKNOWN = new C0171a("UNKNOWN", 0);
            ANDROID_FIREBASE = new C0171a("ANDROID_FIREBASE", 1);
        }
    }
}
