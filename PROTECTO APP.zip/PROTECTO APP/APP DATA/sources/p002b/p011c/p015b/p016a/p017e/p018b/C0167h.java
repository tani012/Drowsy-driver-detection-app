package p002b.p011c.p015b.p016a.p017e.p018b;

import p002b.p008b.p009a.p010a.C0131a;

/* renamed from: b.c.b.a.e.b.h */
public final class C0167h extends C0175n {

    /* renamed from: a */
    public final long f830a;

    public C0167h(long j) {
        this.f830a = j;
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (obj instanceof C0175n) {
            return this.f830a == ((C0167h) ((C0175n) obj)).f830a;
        }
        return false;
    }

    public int hashCode() {
        long j = this.f830a;
        return ((int) (j ^ (j >>> 32))) ^ 1000003;
    }

    public String toString() {
        StringBuilder m = C0131a.m379m("LogResponse{nextRequestWaitMillis=");
        m.append(this.f830a);
        m.append("}");
        return m.toString();
    }
}
