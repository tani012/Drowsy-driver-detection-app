package p002b.p008b.p009a.p010a;

import android.os.Parcel;
import android.os.RemoteException;
import android.util.Log;
import androidx.fragment.app.Fragment;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import p002b.p011c.p015b.p028b.p053e.p061r.C0605f;
import p002b.p011c.p015b.p028b.p064f.C0621a;
import p002b.p011c.p015b.p028b.p068i.p069a.z02;
import p002b.p011c.p110d.p117i.p118e.C4036b;
import p176d.p195e.p201b.p202h2.C5260b1;
import p176d.p195e.p201b.p202h2.C5266c1;
import p176d.p195e.p201b.p202h2.C5331k;

/* renamed from: b.b.a.a.a */
/* compiled from: outline */
public class C0131a {
    /* renamed from: a */
    public static int m367a(int i, int i2, int i3, int i4) {
        return ((i * i2) / i3) + i4;
    }

    /* renamed from: b */
    public static int m368b(String str, int i) {
        return String.valueOf(str).length() + i;
    }

    /* renamed from: c */
    public static String m369c(int i, String str, String str2, String str3) {
        StringBuilder sb = new StringBuilder(i);
        sb.append(str);
        sb.append(str2);
        sb.append(str3);
        return sb.toString();
    }

    /* renamed from: d */
    public static String m370d(int i, String str, String str2, String str3, String str4) {
        StringBuilder sb = new StringBuilder(i);
        sb.append(str);
        sb.append(str2);
        sb.append(str3);
        sb.append(str4);
        return sb.toString();
    }

    /* renamed from: e */
    public static String m371e(String str, int i) {
        return str + i;
    }

    /* renamed from: f */
    public static String m372f(String str, Fragment fragment, String str2) {
        return str + fragment + str2;
    }

    /* renamed from: g */
    public static String m373g(String str, String str2) {
        return str + str2;
    }

    /* renamed from: h */
    public static String m374h(String str, String str2, String str3) {
        return str + str2 + str3;
    }

    /* renamed from: i */
    public static String m375i(StringBuilder sb, String str, String str2) {
        sb.append(str);
        sb.append(str2);
        return sb.toString();
    }

    /* renamed from: j */
    public static StringBuilder m376j(int i, String str, int i2, String str2, int i3) {
        StringBuilder sb = new StringBuilder(i);
        sb.append(str);
        sb.append(i2);
        sb.append(str2);
        sb.append(i3);
        return sb;
    }

    /* renamed from: k */
    public static StringBuilder m377k(int i, String str, String str2, String str3, String str4) {
        StringBuilder sb = new StringBuilder(i);
        sb.append(str);
        sb.append(str2);
        sb.append(str3);
        sb.append(str4);
        return sb;
    }

    /* renamed from: l */
    public static RemoteException m378l(String str, Throwable th) {
        C0605f.m1157m4(str, th);
        return new RemoteException();
    }

    /* renamed from: m */
    public static StringBuilder m379m(String str) {
        StringBuilder sb = new StringBuilder();
        sb.append(str);
        return sb;
    }

    /* renamed from: n */
    public static void m380n(String str, String str2, z02 z02, String str3, LinkedHashMap linkedHashMap, String str4, z02 z022) {
        C0605f.m1147l1(str, str2);
        C0605f.m1147l1(z02, str3);
        linkedHashMap.put(str4, z022);
    }

    /* renamed from: o */
    public static void m381o(String str, String str2, C4036b bVar) {
        bVar.mo8384b(str + str2);
    }

    /* renamed from: p */
    public static void m382p(StringBuilder sb, Fragment fragment, String str) {
        sb.append(fragment);
        Log.d(str, sb.toString());
    }

    /* renamed from: q */
    public static C5331k m383q(List list, C5331k kVar, C5266c1.C5268b bVar, C5266c1.C5267a aVar) {
        list.add(kVar);
        return new C5331k(bVar, aVar);
    }

    /* renamed from: r */
    public static C5260b1 m384r(List list, C5331k kVar, ArrayList arrayList, C5260b1 b1Var) {
        list.add(kVar);
        arrayList.add(b1Var);
        return new C5260b1();
    }

    /* renamed from: s */
    public static C0621a m385s(Parcel parcel) {
        C0621a c2 = C0621a.C0622a.m1272c2(parcel.readStrongBinder());
        parcel.recycle();
        return c2;
    }

    /* renamed from: t */
    public static String m386t(int i, String str, int i2) {
        StringBuilder sb = new StringBuilder(i);
        sb.append(str);
        sb.append(i2);
        return sb.toString();
    }

    /* renamed from: u */
    public static String m387u(int i, String str, int i2, String str2) {
        StringBuilder sb = new StringBuilder(i);
        sb.append(str);
        sb.append(i2);
        sb.append(str2);
        return sb.toString();
    }

    /* renamed from: v */
    public static String m388v(int i, String str, int i2, String str2, int i3) {
        StringBuilder sb = new StringBuilder(i);
        sb.append(str);
        sb.append(i2);
        sb.append(str2);
        sb.append(i3);
        return sb.toString();
    }

    /* renamed from: w */
    public static String m389w(int i, String str, String str2) {
        StringBuilder sb = new StringBuilder(i);
        sb.append(str);
        sb.append(str2);
        return sb.toString();
    }
}
