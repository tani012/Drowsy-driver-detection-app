package androidx.fragment.app;

import android.animation.Animator;
import android.content.ComponentCallbacks;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Bundle;
import android.os.Looper;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.SparseArray;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.view.ViewGroup;
import java.lang.reflect.InvocationTargetException;
import java.util.UUID;
import p002b.p008b.p009a.p010a.C0131a;
import p176d.p219i.p220c.C5598m;
import p176d.p238l.p239d.C5721e;
import p176d.p238l.p239d.C5744n;
import p176d.p238l.p239d.C5746o;
import p176d.p238l.p239d.C5752q0;
import p176d.p238l.p239d.C5753r;
import p176d.p238l.p239d.C5763t;
import p176d.p238l.p239d.C5766v;
import p176d.p242n.C5781e;
import p176d.p242n.C5784f;
import p176d.p242n.C5786h;
import p176d.p242n.C5787i;
import p176d.p242n.C5792m;
import p176d.p242n.C5805t;
import p176d.p242n.C5806u;
import p176d.p245p.C5813a;
import p176d.p245p.C5816b;
import p176d.p245p.C5817c;

public class Fragment implements ComponentCallbacks, View.OnCreateContextMenuListener, C5786h, C5806u, C5817c {

    /* renamed from: X */
    public static final Object f540X = new Object();

    /* renamed from: A */
    public int f541A;

    /* renamed from: B */
    public String f542B;

    /* renamed from: C */
    public boolean f543C;

    /* renamed from: D */
    public boolean f544D;

    /* renamed from: E */
    public boolean f545E;

    /* renamed from: F */
    public boolean f546F;

    /* renamed from: G */
    public boolean f547G = true;

    /* renamed from: H */
    public boolean f548H;

    /* renamed from: I */
    public ViewGroup f549I;

    /* renamed from: J */
    public View f550J;

    /* renamed from: K */
    public boolean f551K;

    /* renamed from: L */
    public boolean f552L = true;

    /* renamed from: M */
    public C0075b f553M;

    /* renamed from: N */
    public boolean f554N;

    /* renamed from: O */
    public boolean f555O;

    /* renamed from: P */
    public float f556P;

    /* renamed from: Q */
    public LayoutInflater f557Q;

    /* renamed from: R */
    public boolean f558R;

    /* renamed from: S */
    public C5781e.C5783b f559S = C5781e.C5783b.RESUMED;

    /* renamed from: T */
    public C5787i f560T;

    /* renamed from: U */
    public C5752q0 f561U;

    /* renamed from: V */
    public C5792m<C5786h> f562V = new C5792m<>();

    /* renamed from: W */
    public C5816b f563W;

    /* renamed from: e */
    public int f564e = -1;

    /* renamed from: f */
    public Bundle f565f;

    /* renamed from: g */
    public SparseArray<Parcelable> f566g;

    /* renamed from: h */
    public Boolean f567h;

    /* renamed from: i */
    public String f568i = UUID.randomUUID().toString();

    /* renamed from: j */
    public Bundle f569j;

    /* renamed from: k */
    public Fragment f570k;

    /* renamed from: l */
    public String f571l = null;

    /* renamed from: m */
    public int f572m;

    /* renamed from: n */
    public Boolean f573n = null;

    /* renamed from: o */
    public boolean f574o;

    /* renamed from: p */
    public boolean f575p;

    /* renamed from: q */
    public boolean f576q;

    /* renamed from: r */
    public boolean f577r;

    /* renamed from: s */
    public boolean f578s;

    /* renamed from: t */
    public boolean f579t;

    /* renamed from: u */
    public int f580u;

    /* renamed from: v */
    public C5753r f581v;

    /* renamed from: w */
    public C5746o<?> f582w;

    /* renamed from: x */
    public C5753r f583x = new C5763t();

    /* renamed from: y */
    public Fragment f584y;

    /* renamed from: z */
    public int f585z;

    /* renamed from: androidx.fragment.app.Fragment$a */
    public class C0074a implements Runnable {
        public C0074a() {
        }

        public void run() {
            Fragment.this.mo783b();
        }
    }

    /* renamed from: androidx.fragment.app.Fragment$b */
    public static class C0075b {

        /* renamed from: a */
        public View f588a;

        /* renamed from: b */
        public Animator f589b;

        /* renamed from: c */
        public int f590c;

        /* renamed from: d */
        public int f591d;

        /* renamed from: e */
        public int f592e;

        /* renamed from: f */
        public Object f593f = null;

        /* renamed from: g */
        public Object f594g;

        /* renamed from: h */
        public Object f595h;

        /* renamed from: i */
        public Object f596i;

        /* renamed from: j */
        public Object f597j;

        /* renamed from: k */
        public Object f598k;

        /* renamed from: l */
        public Boolean f599l;

        /* renamed from: m */
        public Boolean f600m;

        /* renamed from: n */
        public C5598m f601n;

        /* renamed from: o */
        public C5598m f602o;

        /* renamed from: p */
        public boolean f603p;

        /* renamed from: q */
        public C0077d f604q;

        /* renamed from: r */
        public boolean f605r;

        public C0075b() {
            Object obj = Fragment.f540X;
            this.f594g = obj;
            this.f595h = null;
            this.f596i = obj;
            this.f597j = null;
            this.f598k = obj;
            this.f601n = null;
            this.f602o = null;
        }
    }

    /* renamed from: androidx.fragment.app.Fragment$c */
    public static class C0076c extends RuntimeException {
        public C0076c(String str, Exception exc) {
            super(str, exc);
        }
    }

    /* renamed from: androidx.fragment.app.Fragment$d */
    public interface C0077d {
    }

    public Fragment() {
        mo802s();
    }

    @Deprecated
    /* renamed from: t */
    public static Fragment m236t(Context context, String str, Bundle bundle) {
        try {
            Fragment fragment = (Fragment) C5744n.m16987d(context.getClassLoader(), str).getConstructor(new Class[0]).newInstance(new Object[0]);
            if (bundle != null) {
                bundle.setClassLoader(fragment.getClass().getClassLoader());
                fragment.mo777S(bundle);
            }
            return fragment;
        } catch (InstantiationException e) {
            throw new C0076c(C0131a.m374h("Unable to instantiate fragment ", str, ": make sure class name exists, is public, and has an empty constructor that is public"), e);
        } catch (IllegalAccessException e2) {
            throw new C0076c(C0131a.m374h("Unable to instantiate fragment ", str, ": make sure class name exists, is public, and has an empty constructor that is public"), e2);
        } catch (NoSuchMethodException e3) {
            throw new C0076c(C0131a.m374h("Unable to instantiate fragment ", str, ": could not find Fragment constructor"), e3);
        } catch (InvocationTargetException e4) {
            throw new C0076c(C0131a.m374h("Unable to instantiate fragment ", str, ": calling Fragment constructor caused an exception"), e4);
        }
    }

    /* renamed from: A */
    public View mo759A(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        return null;
    }

    /* renamed from: B */
    public void mo760B() {
        this.f548H = true;
    }

    /* renamed from: C */
    public void mo761C() {
        this.f548H = true;
    }

    /* renamed from: D */
    public LayoutInflater mo762D(Bundle bundle) {
        C5746o<?> oVar = this.f582w;
        if (oVar != null) {
            C5721e.C5722a aVar = (C5721e.C5722a) oVar;
            LayoutInflater cloneInContext = C5721e.this.getLayoutInflater().cloneInContext(C5721e.this);
            cloneInContext.setFactory2(this.f583x.f20197f);
            return cloneInContext;
        }
        throw new IllegalStateException("onGetLayoutInflater() cannot be executed until the Fragment is attached to the FragmentManager.");
    }

    /* renamed from: E */
    public void mo763E(AttributeSet attributeSet, Bundle bundle) {
        this.f548H = true;
        C5746o<?> oVar = this.f582w;
        if ((oVar == null ? null : oVar.f20177e) != null) {
            this.f548H = false;
            this.f548H = true;
        }
    }

    /* renamed from: F */
    public void mo764F(boolean z) {
    }

    /* renamed from: G */
    public void mo765G() {
        this.f548H = true;
    }

    /* renamed from: H */
    public void mo766H(Bundle bundle) {
    }

    /* renamed from: I */
    public void mo767I() {
        this.f548H = true;
    }

    /* renamed from: J */
    public void mo768J() {
        this.f548H = true;
    }

    /* renamed from: K */
    public void mo769K(View view, Bundle bundle) {
    }

    /* renamed from: L */
    public boolean mo770L(Menu menu, MenuInflater menuInflater) {
        if (!this.f543C) {
            return false | this.f583x.mo12055m(menu, menuInflater);
        }
        return false;
    }

    /* renamed from: M */
    public void mo771M(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        this.f583x.mo12027S();
        boolean z = true;
        this.f579t = true;
        this.f561U = new C5752q0();
        View A = mo759A(layoutInflater, viewGroup, bundle);
        this.f550J = A;
        if (A != null) {
            C5752q0 q0Var = this.f561U;
            if (q0Var.f20187e == null) {
                q0Var.f20187e = new C5787i(q0Var);
            }
            this.f562V.mo817h(this.f561U);
            return;
        }
        if (this.f561U.f20187e == null) {
            z = false;
        }
        if (!z) {
            this.f561U = null;
            return;
        }
        throw new IllegalStateException("Called getViewLifecycleOwner() but onCreateView() returned null");
    }

    /* renamed from: N */
    public void mo772N() {
        this.f548H = true;
        this.f583x.mo12057o();
    }

    /* renamed from: O */
    public boolean mo773O(Menu menu) {
        if (!this.f543C) {
            return false | this.f583x.mo12064u(menu);
        }
        return false;
    }

    /* renamed from: P */
    public final View mo774P() {
        View view = this.f550J;
        if (view != null) {
            return view;
        }
        throw new IllegalStateException(C0131a.m372f("Fragment ", this, " did not return a View from onCreateView() or this was called before onCreateView()."));
    }

    /* renamed from: Q */
    public void mo775Q(View view) {
        mo786f().f588a = view;
    }

    /* renamed from: R */
    public void mo776R(Animator animator) {
        mo786f().f589b = animator;
    }

    /* renamed from: S */
    public void mo777S(Bundle bundle) {
        C5753r rVar = this.f581v;
        if (rVar != null) {
            if (rVar == null ? false : rVar.mo12022N()) {
                throw new IllegalStateException("Fragment already added and state has been saved");
            }
        }
        this.f569j = bundle;
    }

    /* renamed from: T */
    public void mo778T(boolean z) {
        mo786f().f605r = z;
    }

    /* renamed from: U */
    public void mo779U(int i) {
        if (this.f553M != null || i != 0) {
            mo786f().f591d = i;
        }
    }

    /* renamed from: V */
    public void mo780V(C0077d dVar) {
        mo786f();
        C0077d dVar2 = this.f553M.f604q;
        if (dVar != dVar2) {
            if (dVar == null || dVar2 == null) {
                C0075b bVar = this.f553M;
                if (bVar.f603p) {
                    bVar.f604q = dVar;
                }
                if (dVar != null) {
                    ((C5753r.C5760g) dVar).f20228c++;
                    return;
                }
                return;
            }
            throw new IllegalStateException("Trying to set a replacement startPostponedEnterTransition on " + this);
        }
    }

    /* renamed from: W */
    public void mo781W(int i) {
        mo786f().f590c = i;
    }

    /* renamed from: X */
    public void mo782X() {
        C5753r rVar = this.f581v;
        if (rVar == null || rVar.f20205n == null) {
            mo786f().f603p = false;
        } else if (Looper.myLooper() != this.f581v.f20205n.f20179g.getLooper()) {
            this.f581v.f20205n.f20179g.postAtFrontOfQueue(new C0074a());
        } else {
            mo783b();
        }
    }

    /* renamed from: a */
    public C5781e mo1a() {
        return this.f560T;
    }

    /* renamed from: b */
    public void mo783b() {
        C0075b bVar = this.f553M;
        Object obj = null;
        if (bVar != null) {
            bVar.f603p = false;
            Object obj2 = bVar.f604q;
            bVar.f604q = null;
            obj = obj2;
        }
        if (obj != null) {
            C5753r.C5760g gVar = (C5753r.C5760g) obj;
            int i = gVar.f20228c - 1;
            gVar.f20228c = i;
            if (i == 0) {
                gVar.f20227b.f20050r.mo12036a0();
            }
        }
    }

    /* renamed from: d */
    public final C5813a mo3d() {
        return this.f563W.f20337b;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:22:0x0125, code lost:
        r1 = r2.f571l;
     */
    /* renamed from: e */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void mo784e(java.lang.String r3, java.io.FileDescriptor r4, java.io.PrintWriter r5, java.lang.String[] r6) {
        /*
            r2 = this;
            r5.print(r3)
            java.lang.String r0 = "mFragmentId=#"
            r5.print(r0)
            int r0 = r2.f585z
            java.lang.String r0 = java.lang.Integer.toHexString(r0)
            r5.print(r0)
            java.lang.String r0 = " mContainerId=#"
            r5.print(r0)
            int r0 = r2.f541A
            java.lang.String r0 = java.lang.Integer.toHexString(r0)
            r5.print(r0)
            java.lang.String r0 = " mTag="
            r5.print(r0)
            java.lang.String r0 = r2.f542B
            r5.println(r0)
            r5.print(r3)
            java.lang.String r0 = "mState="
            r5.print(r0)
            int r0 = r2.f564e
            r5.print(r0)
            java.lang.String r0 = " mWho="
            r5.print(r0)
            java.lang.String r0 = r2.f568i
            r5.print(r0)
            java.lang.String r0 = " mBackStackNesting="
            r5.print(r0)
            int r0 = r2.f580u
            r5.println(r0)
            r5.print(r3)
            java.lang.String r0 = "mAdded="
            r5.print(r0)
            boolean r0 = r2.f574o
            r5.print(r0)
            java.lang.String r0 = " mRemoving="
            r5.print(r0)
            boolean r0 = r2.f575p
            r5.print(r0)
            java.lang.String r0 = " mFromLayout="
            r5.print(r0)
            boolean r0 = r2.f576q
            r5.print(r0)
            java.lang.String r0 = " mInLayout="
            r5.print(r0)
            boolean r0 = r2.f577r
            r5.println(r0)
            r5.print(r3)
            java.lang.String r0 = "mHidden="
            r5.print(r0)
            boolean r0 = r2.f543C
            r5.print(r0)
            java.lang.String r0 = " mDetached="
            r5.print(r0)
            boolean r0 = r2.f544D
            r5.print(r0)
            java.lang.String r0 = " mMenuVisible="
            r5.print(r0)
            boolean r0 = r2.f547G
            r5.print(r0)
            java.lang.String r0 = " mHasMenu="
            r5.print(r0)
            r0 = 0
            r5.println(r0)
            r5.print(r3)
            java.lang.String r0 = "mRetainInstance="
            r5.print(r0)
            boolean r0 = r2.f545E
            r5.print(r0)
            java.lang.String r0 = " mUserVisibleHint="
            r5.print(r0)
            boolean r0 = r2.f552L
            r5.println(r0)
            d.l.d.r r0 = r2.f581v
            if (r0 == 0) goto L_0x00c7
            r5.print(r3)
            java.lang.String r0 = "mFragmentManager="
            r5.print(r0)
            d.l.d.r r0 = r2.f581v
            r5.println(r0)
        L_0x00c7:
            d.l.d.o<?> r0 = r2.f582w
            if (r0 == 0) goto L_0x00d8
            r5.print(r3)
            java.lang.String r0 = "mHost="
            r5.print(r0)
            d.l.d.o<?> r0 = r2.f582w
            r5.println(r0)
        L_0x00d8:
            androidx.fragment.app.Fragment r0 = r2.f584y
            if (r0 == 0) goto L_0x00e9
            r5.print(r3)
            java.lang.String r0 = "mParentFragment="
            r5.print(r0)
            androidx.fragment.app.Fragment r0 = r2.f584y
            r5.println(r0)
        L_0x00e9:
            android.os.Bundle r0 = r2.f569j
            if (r0 == 0) goto L_0x00fa
            r5.print(r3)
            java.lang.String r0 = "mArguments="
            r5.print(r0)
            android.os.Bundle r0 = r2.f569j
            r5.println(r0)
        L_0x00fa:
            android.os.Bundle r0 = r2.f565f
            if (r0 == 0) goto L_0x010b
            r5.print(r3)
            java.lang.String r0 = "mSavedFragmentState="
            r5.print(r0)
            android.os.Bundle r0 = r2.f565f
            r5.println(r0)
        L_0x010b:
            android.util.SparseArray<android.os.Parcelable> r0 = r2.f566g
            if (r0 == 0) goto L_0x011c
            r5.print(r3)
            java.lang.String r0 = "mSavedViewState="
            r5.print(r0)
            android.util.SparseArray<android.os.Parcelable> r0 = r2.f566g
            r5.println(r0)
        L_0x011c:
            androidx.fragment.app.Fragment r0 = r2.f570k
            if (r0 == 0) goto L_0x0121
            goto L_0x0131
        L_0x0121:
            d.l.d.r r0 = r2.f581v
            if (r0 == 0) goto L_0x0130
            java.lang.String r1 = r2.f571l
            if (r1 == 0) goto L_0x0130
            d.l.d.y r0 = r0.f20194c
            androidx.fragment.app.Fragment r0 = r0.mo12095e(r1)
            goto L_0x0131
        L_0x0130:
            r0 = 0
        L_0x0131:
            if (r0 == 0) goto L_0x0148
            r5.print(r3)
            java.lang.String r1 = "mTarget="
            r5.print(r1)
            r5.print(r0)
            java.lang.String r0 = " mTargetRequestCode="
            r5.print(r0)
            int r0 = r2.f572m
            r5.println(r0)
        L_0x0148:
            int r0 = r2.mo794n()
            if (r0 == 0) goto L_0x015d
            r5.print(r3)
            java.lang.String r0 = "mNextAnim="
            r5.print(r0)
            int r0 = r2.mo794n()
            r5.println(r0)
        L_0x015d:
            android.view.ViewGroup r0 = r2.f549I
            if (r0 == 0) goto L_0x016e
            r5.print(r3)
            java.lang.String r0 = "mContainer="
            r5.print(r0)
            android.view.ViewGroup r0 = r2.f549I
            r5.println(r0)
        L_0x016e:
            android.view.View r0 = r2.f550J
            if (r0 == 0) goto L_0x017f
            r5.print(r3)
            java.lang.String r0 = "mView="
            r5.print(r0)
            android.view.View r0 = r2.f550J
            r5.println(r0)
        L_0x017f:
            android.view.View r0 = r2.mo788h()
            if (r0 == 0) goto L_0x01a3
            r5.print(r3)
            java.lang.String r0 = "mAnimatingAway="
            r5.print(r0)
            android.view.View r0 = r2.mo788h()
            r5.println(r0)
            r5.print(r3)
            java.lang.String r0 = "mStateAfterAnimating="
            r5.print(r0)
            int r0 = r2.mo801r()
            r5.println(r0)
        L_0x01a3:
            android.content.Context r0 = r2.mo791k()
            if (r0 == 0) goto L_0x01b0
            d.o.a.a r0 = p176d.p243o.p244a.C5807a.m17145b(r2)
            r0.mo12149a(r3, r4, r5, r6)
        L_0x01b0:
            r5.print(r3)
            java.lang.StringBuilder r0 = new java.lang.StringBuilder
            r0.<init>()
            java.lang.String r1 = "Child "
            r0.append(r1)
            d.l.d.r r1 = r2.f583x
            r0.append(r1)
            java.lang.String r1 = ":"
            r0.append(r1)
            java.lang.String r0 = r0.toString()
            r5.println(r0)
            d.l.d.r r0 = r2.f583x
            java.lang.String r1 = "  "
            java.lang.String r3 = p002b.p008b.p009a.p010a.C0131a.m373g(r3, r1)
            r0.mo12067x(r3, r4, r5, r6)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.fragment.app.Fragment.mo784e(java.lang.String, java.io.FileDescriptor, java.io.PrintWriter, java.lang.String[]):void");
    }

    public final boolean equals(Object obj) {
        return super.equals(obj);
    }

    /* renamed from: f */
    public final C0075b mo786f() {
        if (this.f553M == null) {
            this.f553M = new C0075b();
        }
        return this.f553M;
    }

    /* renamed from: g */
    public final C5721e mo787g() {
        C5746o<?> oVar = this.f582w;
        if (oVar == null) {
            return null;
        }
        return (C5721e) oVar.f20177e;
    }

    /* renamed from: h */
    public View mo788h() {
        C0075b bVar = this.f553M;
        if (bVar == null) {
            return null;
        }
        return bVar.f588a;
    }

    public final int hashCode() {
        return super.hashCode();
    }

    /* renamed from: i */
    public C5805t mo4i() {
        C5753r rVar = this.f581v;
        if (rVar != null) {
            C5766v vVar = rVar.f20190C;
            C5805t tVar = vVar.f20240e.get(this.f568i);
            if (tVar != null) {
                return tVar;
            }
            C5805t tVar2 = new C5805t();
            vVar.f20240e.put(this.f568i, tVar2);
            return tVar2;
        }
        throw new IllegalStateException("Can't access ViewModels from detached fragment");
    }

    /* renamed from: j */
    public final C5753r mo790j() {
        if (this.f582w != null) {
            return this.f583x;
        }
        throw new IllegalStateException(C0131a.m372f("Fragment ", this, " has not been attached yet."));
    }

    /* renamed from: k */
    public Context mo791k() {
        C5746o<?> oVar = this.f582w;
        if (oVar == null) {
            return null;
        }
        return oVar.f20178f;
    }

    /* renamed from: l */
    public Object mo792l() {
        C0075b bVar = this.f553M;
        if (bVar == null) {
            return null;
        }
        return bVar.f593f;
    }

    /* renamed from: m */
    public Object mo793m() {
        C0075b bVar = this.f553M;
        if (bVar == null) {
            return null;
        }
        return bVar.f595h;
    }

    /* renamed from: n */
    public int mo794n() {
        C0075b bVar = this.f553M;
        if (bVar == null) {
            return 0;
        }
        return bVar.f591d;
    }

    /* renamed from: o */
    public final C5753r mo795o() {
        C5753r rVar = this.f581v;
        if (rVar != null) {
            return rVar;
        }
        throw new IllegalStateException(C0131a.m372f("Fragment ", this, " not associated with a fragment manager."));
    }

    public void onConfigurationChanged(Configuration configuration) {
        this.f548H = true;
    }

    public void onCreateContextMenu(ContextMenu contextMenu, View view, ContextMenu.ContextMenuInfo contextMenuInfo) {
        C5721e g = mo787g();
        if (g != null) {
            g.onCreateContextMenu(contextMenu, view, contextMenuInfo);
            return;
        }
        throw new IllegalStateException(C0131a.m372f("Fragment ", this, " not attached to an activity."));
    }

    public void onLowMemory() {
        this.f548H = true;
    }

    /* renamed from: p */
    public final Resources mo799p() {
        Context k = mo791k();
        if (k != null) {
            return k.getResources();
        }
        throw new IllegalStateException(C0131a.m372f("Fragment ", this, " not attached to a context."));
    }

    /* renamed from: q */
    public Object mo800q() {
        C0075b bVar = this.f553M;
        if (bVar == null) {
            return null;
        }
        return bVar.f597j;
    }

    /* renamed from: r */
    public int mo801r() {
        C0075b bVar = this.f553M;
        if (bVar == null) {
            return 0;
        }
        return bVar.f590c;
    }

    /* renamed from: s */
    public final void mo802s() {
        this.f560T = new C5787i(this);
        this.f563W = new C5816b(this);
        this.f560T.mo12114a(new C5784f() {
            /* renamed from: d */
            public void mo9d(C5786h hVar, C5781e.C5782a aVar) {
                View view;
                if (aVar == C5781e.C5782a.ON_STOP && (view = Fragment.this.f550J) != null) {
                    view.cancelPendingInputEvents();
                }
            }
        });
    }

    public String toString() {
        StringBuilder sb = new StringBuilder(128);
        sb.append(getClass().getSimpleName());
        sb.append("{");
        sb.append(Integer.toHexString(System.identityHashCode(this)));
        sb.append("}");
        sb.append(" (");
        sb.append(this.f568i);
        sb.append(")");
        if (this.f585z != 0) {
            sb.append(" id=0x");
            sb.append(Integer.toHexString(this.f585z));
        }
        if (this.f542B != null) {
            sb.append(" ");
            sb.append(this.f542B);
        }
        sb.append('}');
        return sb.toString();
    }

    /* renamed from: u */
    public boolean mo804u() {
        C0075b bVar = this.f553M;
        if (bVar == null) {
            return false;
        }
        return bVar.f605r;
    }

    /* renamed from: v */
    public final boolean mo805v() {
        return this.f580u > 0;
    }

    /* renamed from: w */
    public final boolean mo806w() {
        Fragment fragment = this.f584y;
        return fragment != null && (fragment.f575p || fragment.mo806w());
    }

    /* renamed from: x */
    public void mo807x(Bundle bundle) {
        this.f548H = true;
    }

    /* renamed from: y */
    public void mo808y(Context context) {
        this.f548H = true;
        C5746o<?> oVar = this.f582w;
        if ((oVar == null ? null : oVar.f20177e) != null) {
            this.f548H = false;
            this.f548H = true;
        }
    }

    /* renamed from: z */
    public void mo809z(Bundle bundle) {
        Parcelable parcelable;
        boolean z = true;
        this.f548H = true;
        if (!(bundle == null || (parcelable = bundle.getParcelable("android:support:fragments")) == null)) {
            this.f583x.mo12033Y(parcelable);
            this.f583x.mo12054l();
        }
        if (this.f583x.f20204m < 1) {
            z = false;
        }
        if (!z) {
            this.f583x.mo12054l();
        }
    }
}
