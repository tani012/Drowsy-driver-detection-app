package androidx.activity;

import android.os.Bundle;
import android.view.View;
import android.view.Window;
import p176d.p177a.C4815c;
import p176d.p219i.p220c.C5586d;
import p176d.p242n.C5781e;
import p176d.p242n.C5784f;
import p176d.p242n.C5786h;
import p176d.p242n.C5787i;
import p176d.p242n.C5795p;
import p176d.p242n.C5805t;
import p176d.p242n.C5806u;
import p176d.p245p.C5813a;
import p176d.p245p.C5816b;
import p176d.p245p.C5817c;

public class ComponentActivity extends C5586d implements C5786h, C5806u, C5817c, C4815c {

    /* renamed from: f */
    public final C5787i f0f = new C5787i(this);

    /* renamed from: g */
    public final C5816b f1g = new C5816b(this);

    /* renamed from: h */
    public C5805t f2h;

    /* renamed from: i */
    public final OnBackPressedDispatcher f3i = new OnBackPressedDispatcher(new C0003a());

    /* renamed from: androidx.activity.ComponentActivity$a */
    public class C0003a implements Runnable {
        public C0003a() {
        }

        public void run() {
            ComponentActivity.super.onBackPressed();
        }
    }

    /* renamed from: androidx.activity.ComponentActivity$b */
    public static final class C0004b {

        /* renamed from: a */
        public C5805t f7a;
    }

    public ComponentActivity() {
        C5787i iVar = this.f0f;
        if (iVar != null) {
            iVar.mo12114a(new C5784f() {
                /* renamed from: d */
                public void mo9d(C5786h hVar, C5781e.C5782a aVar) {
                    if (aVar == C5781e.C5782a.ON_STOP) {
                        Window window = ComponentActivity.this.getWindow();
                        View peekDecorView = window != null ? window.peekDecorView() : null;
                        if (peekDecorView != null) {
                            peekDecorView.cancelPendingInputEvents();
                        }
                    }
                }
            });
            this.f0f.mo12114a(new C5784f() {
                /* renamed from: d */
                public void mo9d(C5786h hVar, C5781e.C5782a aVar) {
                    if (aVar == C5781e.C5782a.ON_DESTROY && !ComponentActivity.this.isChangingConfigurations()) {
                        ComponentActivity.this.mo4i().mo12148a();
                    }
                }
            });
            return;
        }
        throw new IllegalStateException("getLifecycle() returned null in ComponentActivity's constructor. Please make sure you are lazily constructing your Lifecycle in the first call to getLifecycle() rather than relying on field initialization.");
    }

    /* renamed from: a */
    public C5781e mo1a() {
        return this.f0f;
    }

    /* renamed from: c */
    public final OnBackPressedDispatcher mo2c() {
        return this.f3i;
    }

    /* renamed from: d */
    public final C5813a mo3d() {
        return this.f1g.f20337b;
    }

    /* renamed from: i */
    public C5805t mo4i() {
        if (getApplication() != null) {
            if (this.f2h == null) {
                C0004b bVar = (C0004b) getLastNonConfigurationInstance();
                if (bVar != null) {
                    this.f2h = bVar.f7a;
                }
                if (this.f2h == null) {
                    this.f2h = new C5805t();
                }
            }
            return this.f2h;
        }
        throw new IllegalStateException("Your activity is not yet attached to the Application instance. You can't request ViewModel before onCreate call.");
    }

    public void onBackPressed() {
        this.f3i.mo11a();
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.f1g.mo12154a(bundle);
        C5795p.m17130c(this);
    }

    public final Object onRetainNonConfigurationInstance() {
        C0004b bVar;
        C5805t tVar = this.f2h;
        if (tVar == null && (bVar = (C0004b) getLastNonConfigurationInstance()) != null) {
            tVar = bVar.f7a;
        }
        if (tVar == null) {
            return null;
        }
        C0004b bVar2 = new C0004b();
        bVar2.f7a = tVar;
        return bVar2;
    }

    public void onSaveInstanceState(Bundle bundle) {
        C5787i iVar = this.f0f;
        if (iVar instanceof C5787i) {
            iVar.mo12117f(C5781e.C5783b.CREATED);
        }
        super.onSaveInstanceState(bundle);
        this.f1g.mo12155b(bundle);
    }
}
