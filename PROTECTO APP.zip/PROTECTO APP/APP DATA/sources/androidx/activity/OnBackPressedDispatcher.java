package androidx.activity;

import java.util.ArrayDeque;
import java.util.Iterator;
import p176d.p177a.C4813a;
import p176d.p177a.C4814b;
import p176d.p238l.p239d.C5753r;
import p176d.p242n.C5781e;
import p176d.p242n.C5784f;
import p176d.p242n.C5786h;
import p176d.p242n.C5787i;

public final class OnBackPressedDispatcher {

    /* renamed from: a */
    public final Runnable f13a;

    /* renamed from: b */
    public final ArrayDeque<C4814b> f14b = new ArrayDeque<>();

    public class LifecycleOnBackPressedCancellable implements C5784f, C4813a {

        /* renamed from: a */
        public final C5781e f15a;

        /* renamed from: b */
        public final C4814b f16b;

        /* renamed from: c */
        public C4813a f17c;

        public LifecycleOnBackPressedCancellable(C5781e eVar, C4814b bVar) {
            this.f15a = eVar;
            this.f16b = bVar;
            eVar.mo12114a(this);
        }

        public void cancel() {
            ((C5787i) this.f15a).f20305a.mo10689r(this);
            this.f16b.f17550b.remove(this);
            C4813a aVar = this.f17c;
            if (aVar != null) {
                aVar.cancel();
                this.f17c = null;
            }
        }

        /* renamed from: d */
        public void mo9d(C5786h hVar, C5781e.C5782a aVar) {
            if (aVar == C5781e.C5782a.ON_START) {
                OnBackPressedDispatcher onBackPressedDispatcher = OnBackPressedDispatcher.this;
                C4814b bVar = this.f16b;
                onBackPressedDispatcher.f14b.add(bVar);
                C0005a aVar2 = new C0005a(bVar);
                bVar.f17550b.add(aVar2);
                this.f17c = aVar2;
            } else if (aVar == C5781e.C5782a.ON_STOP) {
                C4813a aVar3 = this.f17c;
                if (aVar3 != null) {
                    aVar3.cancel();
                }
            } else if (aVar == C5781e.C5782a.ON_DESTROY) {
                cancel();
            }
        }
    }

    /* renamed from: androidx.activity.OnBackPressedDispatcher$a */
    public class C0005a implements C4813a {

        /* renamed from: a */
        public final C4814b f19a;

        public C0005a(C4814b bVar) {
            this.f19a = bVar;
        }

        public void cancel() {
            OnBackPressedDispatcher.this.f14b.remove(this.f19a);
            this.f19a.f17550b.remove(this);
        }
    }

    public OnBackPressedDispatcher(Runnable runnable) {
        this.f13a = runnable;
    }

    /* renamed from: a */
    public void mo11a() {
        Iterator<C4814b> descendingIterator = this.f14b.descendingIterator();
        while (descendingIterator.hasNext()) {
            C4814b next = descendingIterator.next();
            if (next.f17549a) {
                C5753r rVar = C5753r.this;
                rVar.mo12011B(true);
                if (rVar.f20199h.f17549a) {
                    rVar.mo12028T();
                    return;
                } else {
                    rVar.f20198g.mo11a();
                    return;
                }
            }
        }
        Runnable runnable = this.f13a;
        if (runnable != null) {
            runnable.run();
        }
    }
}
