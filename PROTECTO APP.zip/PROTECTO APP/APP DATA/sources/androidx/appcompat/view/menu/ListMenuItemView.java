package androidx.appcompat.view.menu;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.TextView;
import p176d.p178b.C4816a;
import p176d.p178b.C4821f;
import p176d.p178b.C4822g;
import p176d.p178b.C4823h;
import p176d.p178b.C4825j;
import p176d.p178b.p185o.p186i.C4911i;
import p176d.p178b.p185o.p186i.C4924n;
import p176d.p178b.p187p.C4991r0;
import p176d.p219i.p231k.C5662k;

public class ListMenuItemView extends LinearLayout implements C4924n.C4925a, AbsListView.SelectionBoundsAdjuster {

    /* renamed from: e */
    public C4911i f105e;

    /* renamed from: f */
    public ImageView f106f;

    /* renamed from: g */
    public RadioButton f107g;

    /* renamed from: h */
    public TextView f108h;

    /* renamed from: i */
    public CheckBox f109i;

    /* renamed from: j */
    public TextView f110j;

    /* renamed from: k */
    public ImageView f111k;

    /* renamed from: l */
    public ImageView f112l;

    /* renamed from: m */
    public LinearLayout f113m;

    /* renamed from: n */
    public Drawable f114n;

    /* renamed from: o */
    public int f115o;

    /* renamed from: p */
    public Context f116p;

    /* renamed from: q */
    public boolean f117q;

    /* renamed from: r */
    public Drawable f118r;

    /* renamed from: s */
    public boolean f119s;

    /* renamed from: t */
    public LayoutInflater f120t;

    /* renamed from: u */
    public boolean f121u;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public ListMenuItemView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        int i = C4816a.listMenuViewStyle;
        C4991r0 o = C4991r0.m15539o(getContext(), attributeSet, C4825j.MenuView, i, 0);
        this.f114n = o.mo10605e(C4825j.MenuView_android_itemBackground);
        this.f115o = o.mo10610j(C4825j.MenuView_android_itemTextAppearance, -1);
        this.f117q = o.mo10601a(C4825j.MenuView_preserveIconSpacing, false);
        this.f116p = context;
        this.f118r = o.mo10605e(C4825j.MenuView_subMenuArrow);
        TypedArray obtainStyledAttributes = context.getTheme().obtainStyledAttributes((AttributeSet) null, new int[]{16843049}, C4816a.dropDownListViewStyle, 0);
        this.f119s = obtainStyledAttributes.hasValue(0);
        o.f18227b.recycle();
        obtainStyledAttributes.recycle();
    }

    private LayoutInflater getInflater() {
        if (this.f120t == null) {
            this.f120t = LayoutInflater.from(getContext());
        }
        return this.f120t;
    }

    private void setSubMenuArrowVisible(boolean z) {
        ImageView imageView = this.f111k;
        if (imageView != null) {
            imageView.setVisibility(z ? 0 : 8);
        }
    }

    /* renamed from: a */
    public boolean mo21a() {
        return false;
    }

    public void adjustListItemSelectionBounds(Rect rect) {
        ImageView imageView = this.f112l;
        if (imageView != null && imageView.getVisibility() == 0) {
            LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams) this.f112l.getLayoutParams();
            rect.top = this.f112l.getHeight() + layoutParams.topMargin + layoutParams.bottomMargin + rect.top;
        }
    }

    /* renamed from: b */
    public final void mo50b() {
        CheckBox checkBox = (CheckBox) getInflater().inflate(C4822g.abc_list_menu_item_checkbox, this, false);
        this.f109i = checkBox;
        LinearLayout linearLayout = this.f113m;
        if (linearLayout != null) {
            linearLayout.addView(checkBox, -1);
        } else {
            addView(checkBox, -1);
        }
    }

    /* renamed from: c */
    public final void mo51c() {
        RadioButton radioButton = (RadioButton) getInflater().inflate(C4822g.abc_list_menu_item_radio, this, false);
        this.f107g = radioButton;
        LinearLayout linearLayout = this.f113m;
        if (linearLayout != null) {
            linearLayout.addView(radioButton, -1);
        } else {
            addView(radioButton, -1);
        }
    }

    /* renamed from: d */
    public void mo24d(C4911i iVar, int i) {
        CharSequence charSequence;
        this.f105e = iVar;
        setVisibility(iVar.isVisible() ? 0 : 8);
        if (mo21a()) {
            charSequence = iVar.getTitleCondensed();
        } else {
            charSequence = iVar.f17936e;
        }
        setTitle(charSequence);
        setCheckable(iVar.isCheckable());
        boolean m = iVar.mo10249m();
        iVar.mo10224e();
        mo52e(m);
        setIcon(iVar.getIcon());
        setEnabled(iVar.isEnabled());
        setSubMenuArrowVisible(iVar.hasSubMenu());
        setContentDescription(iVar.f17948q);
    }

    /* renamed from: e */
    public void mo52e(boolean z) {
        String str;
        int i;
        int i2 = (!z || !this.f105e.mo10249m()) ? 8 : 0;
        if (i2 == 0) {
            TextView textView = this.f110j;
            C4911i iVar = this.f105e;
            char e = iVar.mo10224e();
            if (e == 0) {
                str = "";
            } else {
                Resources resources = iVar.f17945n.f17900a.getResources();
                StringBuilder sb = new StringBuilder();
                if (ViewConfiguration.get(iVar.f17945n.f17900a).hasPermanentMenuKey()) {
                    sb.append(resources.getString(C4823h.abc_prepend_shortcut_label));
                }
                int i3 = iVar.f17945n.mo10197n() ? iVar.f17942k : iVar.f17940i;
                C4911i.m15337c(sb, i3, 65536, resources.getString(C4823h.abc_menu_meta_shortcut_label));
                C4911i.m15337c(sb, i3, 4096, resources.getString(C4823h.abc_menu_ctrl_shortcut_label));
                C4911i.m15337c(sb, i3, 2, resources.getString(C4823h.abc_menu_alt_shortcut_label));
                C4911i.m15337c(sb, i3, 1, resources.getString(C4823h.abc_menu_shift_shortcut_label));
                C4911i.m15337c(sb, i3, 4, resources.getString(C4823h.abc_menu_sym_shortcut_label));
                C4911i.m15337c(sb, i3, 8, resources.getString(C4823h.abc_menu_function_shortcut_label));
                if (e == 8) {
                    i = C4823h.abc_menu_delete_shortcut_label;
                } else if (e == 10) {
                    i = C4823h.abc_menu_enter_shortcut_label;
                } else if (e != ' ') {
                    sb.append(e);
                    str = sb.toString();
                } else {
                    i = C4823h.abc_menu_space_shortcut_label;
                }
                sb.append(resources.getString(i));
                str = sb.toString();
            }
            textView.setText(str);
        }
        if (this.f110j.getVisibility() != i2) {
            this.f110j.setVisibility(i2);
        }
    }

    public C4911i getItemData() {
        return this.f105e;
    }

    public void onFinishInflate() {
        super.onFinishInflate();
        C5662k.m16845v(this, this.f114n);
        TextView textView = (TextView) findViewById(C4821f.title);
        this.f108h = textView;
        int i = this.f115o;
        if (i != -1) {
            textView.setTextAppearance(this.f116p, i);
        }
        this.f110j = (TextView) findViewById(C4821f.shortcut);
        ImageView imageView = (ImageView) findViewById(C4821f.submenuarrow);
        this.f111k = imageView;
        if (imageView != null) {
            imageView.setImageDrawable(this.f118r);
        }
        this.f112l = (ImageView) findViewById(C4821f.group_divider);
        this.f113m = (LinearLayout) findViewById(C4821f.content);
    }

    public void onMeasure(int i, int i2) {
        if (this.f106f != null && this.f117q) {
            ViewGroup.LayoutParams layoutParams = getLayoutParams();
            LinearLayout.LayoutParams layoutParams2 = (LinearLayout.LayoutParams) this.f106f.getLayoutParams();
            int i3 = layoutParams.height;
            if (i3 > 0 && layoutParams2.width <= 0) {
                layoutParams2.width = i3;
            }
        }
        super.onMeasure(i, i2);
    }

    public void setCheckable(boolean z) {
        CompoundButton compoundButton;
        CompoundButton compoundButton2;
        if (z || this.f107g != null || this.f109i != null) {
            if (this.f105e.mo10239h()) {
                if (this.f107g == null) {
                    mo51c();
                }
                compoundButton2 = this.f107g;
                compoundButton = this.f109i;
            } else {
                if (this.f109i == null) {
                    mo50b();
                }
                compoundButton2 = this.f109i;
                compoundButton = this.f107g;
            }
            if (z) {
                compoundButton2.setChecked(this.f105e.isChecked());
                if (compoundButton2.getVisibility() != 0) {
                    compoundButton2.setVisibility(0);
                }
                if (compoundButton != null && compoundButton.getVisibility() != 8) {
                    compoundButton.setVisibility(8);
                    return;
                }
                return;
            }
            CheckBox checkBox = this.f109i;
            if (checkBox != null) {
                checkBox.setVisibility(8);
            }
            RadioButton radioButton = this.f107g;
            if (radioButton != null) {
                radioButton.setVisibility(8);
            }
        }
    }

    public void setChecked(boolean z) {
        CompoundButton compoundButton;
        if (this.f105e.mo10239h()) {
            if (this.f107g == null) {
                mo51c();
            }
            compoundButton = this.f107g;
        } else {
            if (this.f109i == null) {
                mo50b();
            }
            compoundButton = this.f109i;
        }
        compoundButton.setChecked(z);
    }

    public void setForceShowIcon(boolean z) {
        this.f121u = z;
        this.f117q = z;
    }

    public void setGroupDividerEnabled(boolean z) {
        ImageView imageView = this.f112l;
        if (imageView != null) {
            imageView.setVisibility((this.f119s || !z) ? 8 : 0);
        }
    }

    public void setIcon(Drawable drawable) {
        boolean z = this.f105e.f17945n.f17918s || this.f121u;
        if (!z && !this.f117q) {
            return;
        }
        if (this.f106f != null || drawable != null || this.f117q) {
            if (this.f106f == null) {
                ImageView imageView = (ImageView) getInflater().inflate(C4822g.abc_list_menu_item_icon, this, false);
                this.f106f = imageView;
                LinearLayout linearLayout = this.f113m;
                if (linearLayout != null) {
                    linearLayout.addView(imageView, 0);
                } else {
                    addView(imageView, 0);
                }
            }
            if (drawable != null || this.f117q) {
                ImageView imageView2 = this.f106f;
                if (!z) {
                    drawable = null;
                }
                imageView2.setImageDrawable(drawable);
                if (this.f106f.getVisibility() != 0) {
                    this.f106f.setVisibility(0);
                    return;
                }
                return;
            }
            this.f106f.setVisibility(8);
        }
    }

    public void setTitle(CharSequence charSequence) {
        TextView textView;
        int i;
        if (charSequence != null) {
            this.f108h.setText(charSequence);
            if (this.f108h.getVisibility() != 0) {
                textView = this.f108h;
                i = 0;
            } else {
                return;
            }
        } else {
            i = 8;
            if (this.f108h.getVisibility() != 8) {
                textView = this.f108h;
            } else {
                return;
            }
        }
        textView.setVisibility(i);
    }
}
