package androidx.appcompat.view.menu;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import androidx.appcompat.widget.ActionMenuView;
import androidx.appcompat.widget.AppCompatTextView;
import p176d.p178b.C4825j;
import p176d.p178b.p185o.p186i.C4907g;
import p176d.p178b.p185o.p186i.C4911i;
import p176d.p178b.p185o.p186i.C4924n;
import p176d.p178b.p185o.p186i.C4927p;
import p176d.p178b.p187p.C4937b0;
import p176d.p178b.p187p.C4940c;

public class ActionMenuItemView extends AppCompatTextView implements C4924n.C4925a, View.OnClickListener, ActionMenuView.C0018a {

    /* renamed from: i */
    public C4911i f91i;

    /* renamed from: j */
    public CharSequence f92j;

    /* renamed from: k */
    public Drawable f93k;

    /* renamed from: l */
    public C4907g.C4909b f94l;

    /* renamed from: m */
    public C4937b0 f95m;

    /* renamed from: n */
    public C0011b f96n;

    /* renamed from: o */
    public boolean f97o = mo26f();

    /* renamed from: p */
    public boolean f98p;

    /* renamed from: q */
    public int f99q;

    /* renamed from: r */
    public int f100r;

    /* renamed from: s */
    public int f101s;

    /* renamed from: androidx.appcompat.view.menu.ActionMenuItemView$a */
    public class C0010a extends C4937b0 {
        public C0010a() {
            super(ActionMenuItemView.this);
        }

        /* renamed from: b */
        public C4927p mo42b() {
            C4940c.C4941a aVar;
            C0011b bVar = ActionMenuItemView.this.f96n;
            if (bVar == null || (aVar = C4940c.this.f18048y) == null) {
                return null;
            }
            return aVar.mo10330a();
        }

        /* JADX WARNING: Code restructure failed: missing block: B:4:0x000f, code lost:
            r0 = mo42b();
         */
        /* renamed from: c */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public boolean mo43c() {
            /*
                r3 = this;
                androidx.appcompat.view.menu.ActionMenuItemView r0 = androidx.appcompat.view.menu.ActionMenuItemView.this
                d.b.o.i.g$b r1 = r0.f94l
                r2 = 0
                if (r1 == 0) goto L_0x001c
                d.b.o.i.i r0 = r0.f91i
                boolean r0 = r1.mo44a(r0)
                if (r0 == 0) goto L_0x001c
                d.b.o.i.p r0 = r3.mo42b()
                if (r0 == 0) goto L_0x001c
                boolean r0 = r0.mo10131b0()
                if (r0 == 0) goto L_0x001c
                r2 = 1
            L_0x001c:
                return r2
            */
            throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.view.menu.ActionMenuItemView.C0010a.mo43c():boolean");
        }
    }

    /* renamed from: androidx.appcompat.view.menu.ActionMenuItemView$b */
    public static abstract class C0011b {
    }

    public ActionMenuItemView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, 0);
        Resources resources = context.getResources();
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, C4825j.ActionMenuItemView, 0, 0);
        this.f99q = obtainStyledAttributes.getDimensionPixelSize(C4825j.ActionMenuItemView_android_minWidth, 0);
        obtainStyledAttributes.recycle();
        this.f101s = (int) ((resources.getDisplayMetrics().density * 32.0f) + 0.5f);
        setOnClickListener(this);
        this.f100r = -1;
        setSaveEnabled(false);
    }

    /* renamed from: a */
    public boolean mo21a() {
        return true;
    }

    /* renamed from: b */
    public boolean mo22b() {
        return mo25e();
    }

    /* renamed from: c */
    public boolean mo23c() {
        return mo25e() && this.f91i.getIcon() == null;
    }

    /* renamed from: d */
    public void mo24d(C4911i iVar, int i) {
        CharSequence charSequence;
        this.f91i = iVar;
        setIcon(iVar.getIcon());
        if (mo21a()) {
            charSequence = iVar.getTitleCondensed();
        } else {
            charSequence = iVar.f17936e;
        }
        setTitle(charSequence);
        setId(iVar.f17932a);
        setVisibility(iVar.isVisible() ? 0 : 8);
        setEnabled(iVar.isEnabled());
        if (iVar.hasSubMenu() && this.f95m == null) {
            this.f95m = new C0010a();
        }
    }

    /* renamed from: e */
    public boolean mo25e() {
        return !TextUtils.isEmpty(getText());
    }

    /* renamed from: f */
    public final boolean mo26f() {
        Configuration configuration = getContext().getResources().getConfiguration();
        int i = configuration.screenWidthDp;
        return i >= 480 || (i >= 640 && configuration.screenHeightDp >= 480) || configuration.orientation == 2;
    }

    /* renamed from: g */
    public final void mo27g() {
        boolean z = true;
        boolean z2 = !TextUtils.isEmpty(this.f92j);
        if (this.f93k != null) {
            if (!((this.f91i.f17956y & 4) == 4) || (!this.f97o && !this.f98p)) {
                z = false;
            }
        }
        boolean z3 = z2 & z;
        CharSequence charSequence = null;
        setText(z3 ? this.f92j : null);
        CharSequence charSequence2 = this.f91i.f17948q;
        if (TextUtils.isEmpty(charSequence2)) {
            if (z3) {
                charSequence2 = null;
            } else {
                charSequence2 = this.f91i.f17936e;
            }
        }
        setContentDescription(charSequence2);
        CharSequence charSequence3 = this.f91i.f17949r;
        if (TextUtils.isEmpty(charSequence3)) {
            if (!z3) {
                charSequence = this.f91i.f17936e;
            }
            setTooltipText(charSequence);
            return;
        }
        setTooltipText(charSequence3);
    }

    public C4911i getItemData() {
        return this.f91i;
    }

    public void onClick(View view) {
        C4907g.C4909b bVar = this.f94l;
        if (bVar != null) {
            bVar.mo44a(this.f91i);
        }
    }

    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        this.f97o = mo26f();
        mo27g();
    }

    public void onMeasure(int i, int i2) {
        int i3;
        boolean e = mo25e();
        if (e && (i3 = this.f100r) >= 0) {
            super.setPadding(i3, getPaddingTop(), getPaddingRight(), getPaddingBottom());
        }
        super.onMeasure(i, i2);
        int mode = View.MeasureSpec.getMode(i);
        int size = View.MeasureSpec.getSize(i);
        int measuredWidth = getMeasuredWidth();
        int min = mode == Integer.MIN_VALUE ? Math.min(size, this.f99q) : this.f99q;
        if (mode != 1073741824 && this.f99q > 0 && measuredWidth < min) {
            super.onMeasure(View.MeasureSpec.makeMeasureSpec(min, 1073741824), i2);
        }
        if (!e && this.f93k != null) {
            super.setPadding((getMeasuredWidth() - this.f93k.getBounds().width()) / 2, getPaddingTop(), getPaddingRight(), getPaddingBottom());
        }
    }

    public void onRestoreInstanceState(Parcelable parcelable) {
        super.onRestoreInstanceState((Parcelable) null);
    }

    public boolean onTouchEvent(MotionEvent motionEvent) {
        C4937b0 b0Var;
        if (!this.f91i.hasSubMenu() || (b0Var = this.f95m) == null || !b0Var.onTouch(this, motionEvent)) {
            return super.onTouchEvent(motionEvent);
        }
        return true;
    }

    public void setCheckable(boolean z) {
    }

    public void setChecked(boolean z) {
    }

    public void setExpandedFormat(boolean z) {
        if (this.f98p != z) {
            this.f98p = z;
            C4911i iVar = this.f91i;
            if (iVar != null) {
                iVar.f17945n.mo10199p();
            }
        }
    }

    public void setIcon(Drawable drawable) {
        this.f93k = drawable;
        if (drawable != null) {
            int intrinsicWidth = drawable.getIntrinsicWidth();
            int intrinsicHeight = drawable.getIntrinsicHeight();
            int i = this.f101s;
            if (intrinsicWidth > i) {
                intrinsicHeight = (int) (((float) intrinsicHeight) * (((float) i) / ((float) intrinsicWidth)));
                intrinsicWidth = i;
            }
            int i2 = this.f101s;
            if (intrinsicHeight > i2) {
                intrinsicWidth = (int) (((float) intrinsicWidth) * (((float) i2) / ((float) intrinsicHeight)));
                intrinsicHeight = i2;
            }
            drawable.setBounds(0, 0, intrinsicWidth, intrinsicHeight);
        }
        setCompoundDrawables(drawable, (Drawable) null, (Drawable) null, (Drawable) null);
        mo27g();
    }

    public void setItemInvoker(C4907g.C4909b bVar) {
        this.f94l = bVar;
    }

    public void setPadding(int i, int i2, int i3, int i4) {
        this.f100r = i;
        super.setPadding(i, i2, i3, i4);
    }

    public void setPopupCallback(C0011b bVar) {
        this.f96n = bVar;
    }

    public void setTitle(CharSequence charSequence) {
        this.f92j = charSequence;
        mo27g();
    }
}
