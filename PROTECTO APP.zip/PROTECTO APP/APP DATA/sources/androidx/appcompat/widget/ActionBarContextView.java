package androidx.appcompat.widget;

import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import android.widget.LinearLayout;
import android.widget.TextView;
import p176d.p178b.C4821f;
import p176d.p178b.C4822g;
import p176d.p178b.p185o.C4882a;
import p176d.p178b.p187p.C4933a;
import p176d.p178b.p187p.C4940c;
import p176d.p178b.p187p.C5004v0;

public class ActionBarContextView extends C4933a {

    /* renamed from: m */
    public CharSequence f132m;

    /* renamed from: n */
    public CharSequence f133n;

    /* renamed from: o */
    public View f134o;

    /* renamed from: p */
    public View f135p;

    /* renamed from: q */
    public LinearLayout f136q;

    /* renamed from: r */
    public TextView f137r;

    /* renamed from: s */
    public TextView f138s;

    /* renamed from: t */
    public int f139t;

    /* renamed from: u */
    public int f140u;

    /* renamed from: v */
    public boolean f141v;

    /* renamed from: w */
    public int f142w;

    /* renamed from: androidx.appcompat.widget.ActionBarContextView$a */
    public class C0012a implements View.OnClickListener {

        /* renamed from: e */
        public final /* synthetic */ C4882a f143e;

        public C0012a(C4882a aVar) {
            this.f143e = aVar;
        }

        public void onClick(View view) {
            this.f143e.mo9840c();
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:2:0x0014, code lost:
        r1 = r5.getResourceId(r0, 0);
     */
    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public ActionBarContextView(android.content.Context r4, android.util.AttributeSet r5) {
        /*
            r3 = this;
            int r0 = p176d.p178b.C4816a.actionModeStyle
            r3.<init>(r4, r5, r0)
            int[] r1 = p176d.p178b.C4825j.ActionMode
            r2 = 0
            android.content.res.TypedArray r5 = r4.obtainStyledAttributes(r5, r1, r0, r2)
            int r0 = p176d.p178b.C4825j.ActionMode_background
            boolean r1 = r5.hasValue(r0)
            if (r1 == 0) goto L_0x001f
            int r1 = r5.getResourceId(r0, r2)
            if (r1 == 0) goto L_0x001f
            android.graphics.drawable.Drawable r4 = p176d.p178b.p180l.p181a.C4879a.m15208b(r4, r1)
            goto L_0x0023
        L_0x001f:
            android.graphics.drawable.Drawable r4 = r5.getDrawable(r0)
        L_0x0023:
            p176d.p219i.p231k.C5662k.m16845v(r3, r4)
            int r4 = p176d.p178b.C4825j.ActionMode_titleTextStyle
            int r4 = r5.getResourceId(r4, r2)
            r3.f139t = r4
            int r4 = p176d.p178b.C4825j.ActionMode_subtitleTextStyle
            int r4 = r5.getResourceId(r4, r2)
            r3.f140u = r4
            int r4 = p176d.p178b.C4825j.ActionMode_height
            int r4 = r5.getLayoutDimension(r4, r2)
            r3.f18014i = r4
            int r4 = p176d.p178b.C4825j.ActionMode_closeItemLayout
            int r0 = p176d.p178b.C4822g.abc_action_mode_close_item_material
            int r4 = r5.getResourceId(r4, r0)
            r3.f142w = r4
            r5.recycle()
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.ActionBarContextView.<init>(android.content.Context, android.util.AttributeSet):void");
    }

    /* JADX WARNING: Removed duplicated region for block: B:12:0x0062  */
    /* JADX WARNING: Removed duplicated region for block: B:15:0x007a  */
    /* JADX WARNING: Removed duplicated region for block: B:9:0x003b  */
    /* renamed from: f */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void mo81f(p176d.p178b.p185o.C4882a r7) {
        /*
            r6 = this;
            android.view.View r0 = r6.f134o
            r1 = 0
            if (r0 != 0) goto L_0x0016
            android.content.Context r0 = r6.getContext()
            android.view.LayoutInflater r0 = android.view.LayoutInflater.from(r0)
            int r2 = r6.f142w
            android.view.View r0 = r0.inflate(r2, r6, r1)
            r6.f134o = r0
            goto L_0x001e
        L_0x0016:
            android.view.ViewParent r0 = r0.getParent()
            if (r0 != 0) goto L_0x0021
            android.view.View r0 = r6.f134o
        L_0x001e:
            r6.addView(r0)
        L_0x0021:
            android.view.View r0 = r6.f134o
            int r2 = p176d.p178b.C4821f.action_mode_close_button
            android.view.View r0 = r0.findViewById(r2)
            androidx.appcompat.widget.ActionBarContextView$a r2 = new androidx.appcompat.widget.ActionBarContextView$a
            r2.<init>(r7)
            r0.setOnClickListener(r2)
            android.view.Menu r7 = r7.mo9842e()
            d.b.o.i.g r7 = (p176d.p178b.p185o.p186i.C4907g) r7
            d.b.p.c r0 = r6.f18013h
            if (r0 == 0) goto L_0x003e
            r0.mo10402j()
        L_0x003e:
            d.b.p.c r0 = new d.b.p.c
            android.content.Context r2 = r6.getContext()
            r0.<init>(r2)
            r6.f18013h = r0
            r2 = 1
            r0.f18039p = r2
            r0.f18040q = r2
            android.view.ViewGroup$LayoutParams r0 = new android.view.ViewGroup$LayoutParams
            r3 = -2
            r4 = -1
            r0.<init>(r3, r4)
            d.b.p.c r3 = r6.f18013h
            android.content.Context r4 = r6.f18011f
            r7.mo10178b(r3, r4)
            d.b.p.c r7 = r6.f18013h
            d.b.o.i.n r3 = r7.f17841l
            if (r3 != 0) goto L_0x0076
            android.view.LayoutInflater r4 = r7.f17837h
            int r5 = r7.f17839j
            android.view.View r1 = r4.inflate(r5, r6, r1)
            d.b.o.i.n r1 = (p176d.p178b.p185o.p186i.C4924n) r1
            r7.f17841l = r1
            d.b.o.i.g r4 = r7.f17836g
            r1.mo45b(r4)
            r7.mo567d(r2)
        L_0x0076:
            d.b.o.i.n r1 = r7.f17841l
            if (r3 == r1) goto L_0x0080
            r2 = r1
            androidx.appcompat.widget.ActionMenuView r2 = (androidx.appcompat.widget.ActionMenuView) r2
            r2.setPresenter(r7)
        L_0x0080:
            androidx.appcompat.widget.ActionMenuView r1 = (androidx.appcompat.widget.ActionMenuView) r1
            r6.f18012g = r1
            r7 = 0
            p176d.p219i.p231k.C5662k.m16845v(r1, r7)
            androidx.appcompat.widget.ActionMenuView r7 = r6.f18012g
            r6.addView(r7, r0)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.ActionBarContextView.mo81f(d.b.o.a):void");
    }

    /* renamed from: g */
    public final void mo82g() {
        if (this.f136q == null) {
            LayoutInflater.from(getContext()).inflate(C4822g.abc_action_bar_title_item, this);
            LinearLayout linearLayout = (LinearLayout) getChildAt(getChildCount() - 1);
            this.f136q = linearLayout;
            this.f137r = (TextView) linearLayout.findViewById(C4821f.action_bar_title);
            this.f138s = (TextView) this.f136q.findViewById(C4821f.action_bar_subtitle);
            if (this.f139t != 0) {
                this.f137r.setTextAppearance(getContext(), this.f139t);
            }
            if (this.f140u != 0) {
                this.f138s.setTextAppearance(getContext(), this.f140u);
            }
        }
        this.f137r.setText(this.f132m);
        this.f138s.setText(this.f133n);
        boolean z = !TextUtils.isEmpty(this.f132m);
        boolean z2 = !TextUtils.isEmpty(this.f133n);
        int i = 0;
        this.f138s.setVisibility(z2 ? 0 : 8);
        LinearLayout linearLayout2 = this.f136q;
        if (!z && !z2) {
            i = 8;
        }
        linearLayout2.setVisibility(i);
        if (this.f136q.getParent() == null) {
            addView(this.f136q);
        }
    }

    public ViewGroup.LayoutParams generateDefaultLayoutParams() {
        return new ViewGroup.MarginLayoutParams(-1, -2);
    }

    public ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new ViewGroup.MarginLayoutParams(getContext(), attributeSet);
    }

    public /* bridge */ /* synthetic */ int getAnimatedVisibility() {
        return super.getAnimatedVisibility();
    }

    public /* bridge */ /* synthetic */ int getContentHeight() {
        return super.getContentHeight();
    }

    public CharSequence getSubtitle() {
        return this.f133n;
    }

    public CharSequence getTitle() {
        return this.f132m;
    }

    /* renamed from: h */
    public void mo89h() {
        removeAllViews();
        this.f135p = null;
        this.f18012g = null;
    }

    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        C4940c cVar = this.f18013h;
        if (cVar != null) {
            cVar.mo10403k();
            this.f18013h.mo10404l();
        }
    }

    public void onInitializeAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        if (accessibilityEvent.getEventType() == 32) {
            accessibilityEvent.setSource(this);
            accessibilityEvent.setClassName(ActionBarContextView.class.getName());
            accessibilityEvent.setPackageName(getContext().getPackageName());
            accessibilityEvent.setContentDescription(this.f132m);
            return;
        }
        super.onInitializeAccessibilityEvent(accessibilityEvent);
    }

    public void onLayout(boolean z, int i, int i2, int i3, int i4) {
        boolean b = C5004v0.m15611b(this);
        int paddingRight = b ? (i3 - i) - getPaddingRight() : getPaddingLeft();
        int paddingTop = getPaddingTop();
        int paddingTop2 = ((i4 - i2) - getPaddingTop()) - getPaddingBottom();
        View view = this.f134o;
        if (!(view == null || view.getVisibility() == 8)) {
            ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) this.f134o.getLayoutParams();
            int i5 = b ? marginLayoutParams.rightMargin : marginLayoutParams.leftMargin;
            int i6 = b ? marginLayoutParams.leftMargin : marginLayoutParams.rightMargin;
            int i7 = b ? paddingRight - i5 : paddingRight + i5;
            int d = i7 + mo10384d(this.f134o, i7, paddingTop, paddingTop2, b);
            paddingRight = b ? d - i6 : d + i6;
        }
        int i8 = paddingRight;
        LinearLayout linearLayout = this.f136q;
        if (!(linearLayout == null || this.f135p != null || linearLayout.getVisibility() == 8)) {
            i8 += mo10384d(this.f136q, i8, paddingTop, paddingTop2, b);
        }
        int i9 = i8;
        View view2 = this.f135p;
        if (view2 != null) {
            mo10384d(view2, i9, paddingTop, paddingTop2, b);
        }
        int paddingLeft = b ? getPaddingLeft() : (i3 - i) - getPaddingRight();
        ActionMenuView actionMenuView = this.f18012g;
        if (actionMenuView != null) {
            mo10384d(actionMenuView, paddingLeft, paddingTop, paddingTop2, !b);
        }
    }

    public void onMeasure(int i, int i2) {
        int i3 = 1073741824;
        if (View.MeasureSpec.getMode(i) != 1073741824) {
            throw new IllegalStateException(ActionBarContextView.class.getSimpleName() + " can only be used with android:layout_width=\"match_parent\" (or fill_parent)");
        } else if (View.MeasureSpec.getMode(i2) != 0) {
            int size = View.MeasureSpec.getSize(i);
            int i4 = this.f18014i;
            if (i4 <= 0) {
                i4 = View.MeasureSpec.getSize(i2);
            }
            int paddingBottom = getPaddingBottom() + getPaddingTop();
            int paddingLeft = (size - getPaddingLeft()) - getPaddingRight();
            int i5 = i4 - paddingBottom;
            int makeMeasureSpec = View.MeasureSpec.makeMeasureSpec(i5, Integer.MIN_VALUE);
            View view = this.f134o;
            if (view != null) {
                int c = mo10383c(view, paddingLeft, makeMeasureSpec, 0);
                ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) this.f134o.getLayoutParams();
                paddingLeft = c - (marginLayoutParams.leftMargin + marginLayoutParams.rightMargin);
            }
            ActionMenuView actionMenuView = this.f18012g;
            if (actionMenuView != null && actionMenuView.getParent() == this) {
                paddingLeft = mo10383c(this.f18012g, paddingLeft, makeMeasureSpec, 0);
            }
            LinearLayout linearLayout = this.f136q;
            if (linearLayout != null && this.f135p == null) {
                if (this.f141v) {
                    this.f136q.measure(View.MeasureSpec.makeMeasureSpec(0, 0), makeMeasureSpec);
                    int measuredWidth = this.f136q.getMeasuredWidth();
                    boolean z = measuredWidth <= paddingLeft;
                    if (z) {
                        paddingLeft -= measuredWidth;
                    }
                    this.f136q.setVisibility(z ? 0 : 8);
                } else {
                    paddingLeft = mo10383c(linearLayout, paddingLeft, makeMeasureSpec, 0);
                }
            }
            View view2 = this.f135p;
            if (view2 != null) {
                ViewGroup.LayoutParams layoutParams = view2.getLayoutParams();
                int i6 = layoutParams.width != -2 ? 1073741824 : Integer.MIN_VALUE;
                int i7 = layoutParams.width;
                if (i7 >= 0) {
                    paddingLeft = Math.min(i7, paddingLeft);
                }
                if (layoutParams.height == -2) {
                    i3 = Integer.MIN_VALUE;
                }
                int i8 = layoutParams.height;
                if (i8 >= 0) {
                    i5 = Math.min(i8, i5);
                }
                this.f135p.measure(View.MeasureSpec.makeMeasureSpec(paddingLeft, i6), View.MeasureSpec.makeMeasureSpec(i5, i3));
            }
            if (this.f18014i <= 0) {
                int childCount = getChildCount();
                i4 = 0;
                for (int i9 = 0; i9 < childCount; i9++) {
                    int measuredHeight = getChildAt(i9).getMeasuredHeight() + paddingBottom;
                    if (measuredHeight > i4) {
                        i4 = measuredHeight;
                    }
                }
            }
            setMeasuredDimension(size, i4);
        } else {
            throw new IllegalStateException(ActionBarContextView.class.getSimpleName() + " can only be used with android:layout_height=\"wrap_content\"");
        }
    }

    public void setContentHeight(int i) {
        this.f18014i = i;
    }

    public void setCustomView(View view) {
        LinearLayout linearLayout;
        View view2 = this.f135p;
        if (view2 != null) {
            removeView(view2);
        }
        this.f135p = view;
        if (!(view == null || (linearLayout = this.f136q) == null)) {
            removeView(linearLayout);
            this.f136q = null;
        }
        if (view != null) {
            addView(view);
        }
        requestLayout();
    }

    public void setSubtitle(CharSequence charSequence) {
        this.f133n = charSequence;
        mo82g();
    }

    public void setTitle(CharSequence charSequence) {
        this.f132m = charSequence;
        mo82g();
    }

    public void setTitleOptional(boolean z) {
        if (z != this.f141v) {
            requestLayout();
        }
        this.f141v = z;
    }

    public /* bridge */ /* synthetic */ void setVisibility(int i) {
        super.setVisibility(i);
    }

    public boolean shouldDelayChildPressedState() {
        return false;
    }
}
