package androidx.appcompat.widget;

import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.widget.SeekBar;
import p176d.p178b.p187p.C4988q;

public class AppCompatSeekBar extends SeekBar {

    /* renamed from: e */
    public final C4988q f206e;

    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public AppCompatSeekBar(android.content.Context r2, android.util.AttributeSet r3) {
        /*
            r1 = this;
            int r0 = p176d.p178b.C4816a.seekBarStyle
            r1.<init>(r2, r3, r0)
            android.content.Context r2 = r1.getContext()
            p176d.p178b.p187p.C4981m0.m15526a(r1, r2)
            d.b.p.q r2 = new d.b.p.q
            r2.<init>(r1)
            r1.f206e = r2
            r2.mo10580a(r3, r0)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.AppCompatSeekBar.<init>(android.content.Context, android.util.AttributeSet):void");
    }

    public void drawableStateChanged() {
        super.drawableStateChanged();
        C4988q qVar = this.f206e;
        Drawable drawable = qVar.f18219e;
        if (drawable != null && drawable.isStateful() && drawable.setState(qVar.f18218d.getDrawableState())) {
            qVar.f18218d.invalidateDrawable(drawable);
        }
    }

    public void jumpDrawablesToCurrentState() {
        super.jumpDrawablesToCurrentState();
        Drawable drawable = this.f206e.f18219e;
        if (drawable != null) {
            drawable.jumpToCurrentState();
        }
    }

    public synchronized void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        this.f206e.mo10600d(canvas);
    }
}
