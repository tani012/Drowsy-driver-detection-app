package androidx.appcompat.widget;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.text.TextDirectionHeuristic;
import android.text.TextDirectionHeuristics;
import android.util.AttributeSet;
import android.view.ActionMode;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.view.textclassifier.TextClassifier;
import android.widget.TextView;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import p176d.p178b.p179k.C4851q;
import p176d.p178b.p180l.p181a.C4879a;
import p176d.p178b.p187p.C4952e;
import p176d.p178b.p187p.C4981m0;
import p176d.p178b.p187p.C4985o0;
import p176d.p178b.p187p.C4987p0;
import p176d.p178b.p187p.C4992s;
import p176d.p178b.p187p.C4994t;
import p176d.p219i.p223e.C5612c;
import p176d.p219i.p229i.C5645a;
import p176d.p219i.p233l.C5694b;

public class AppCompatTextView extends TextView implements C5694b {

    /* renamed from: e */
    public final C4952e f234e;

    /* renamed from: f */
    public final C4994t f235f;

    /* renamed from: g */
    public final C4992s f236g;

    /* renamed from: h */
    public Future<C5645a> f237h;

    public AppCompatTextView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 16842884);
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public AppCompatTextView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        C4985o0.m15532a(context);
        C4981m0.m15526a(this, getContext());
        C4952e eVar = new C4952e(this);
        this.f234e = eVar;
        eVar.mo10458d(attributeSet, i);
        C4994t tVar = new C4994t(this);
        this.f235f = tVar;
        tVar.mo10619e(attributeSet, i);
        this.f235f.mo10617b();
        this.f236g = new C4992s(this);
    }

    public void drawableStateChanged() {
        super.drawableStateChanged();
        C4952e eVar = this.f234e;
        if (eVar != null) {
            eVar.mo10455a();
        }
        C4994t tVar = this.f235f;
        if (tVar != null) {
            tVar.mo10617b();
        }
    }

    public int getAutoSizeMaxTextSize() {
        if (C5694b.f20026a) {
            return super.getAutoSizeMaxTextSize();
        }
        C4994t tVar = this.f235f;
        if (tVar != null) {
            return Math.round(tVar.f18241i.f18277e);
        }
        return -1;
    }

    public int getAutoSizeMinTextSize() {
        if (C5694b.f20026a) {
            return super.getAutoSizeMinTextSize();
        }
        C4994t tVar = this.f235f;
        if (tVar != null) {
            return Math.round(tVar.f18241i.f18276d);
        }
        return -1;
    }

    public int getAutoSizeStepGranularity() {
        if (C5694b.f20026a) {
            return super.getAutoSizeStepGranularity();
        }
        C4994t tVar = this.f235f;
        if (tVar != null) {
            return Math.round(tVar.f18241i.f18275c);
        }
        return -1;
    }

    public int[] getAutoSizeTextAvailableSizes() {
        if (C5694b.f20026a) {
            return super.getAutoSizeTextAvailableSizes();
        }
        C4994t tVar = this.f235f;
        return tVar != null ? tVar.f18241i.f18278f : new int[0];
    }

    @SuppressLint({"WrongConstant"})
    public int getAutoSizeTextType() {
        if (C5694b.f20026a) {
            return super.getAutoSizeTextType() == 1 ? 1 : 0;
        }
        C4994t tVar = this.f235f;
        if (tVar != null) {
            return tVar.f18241i.f18273a;
        }
        return 0;
    }

    public int getFirstBaselineToTopHeight() {
        return getPaddingTop() - getPaint().getFontMetricsInt().top;
    }

    public int getLastBaselineToBottomHeight() {
        return getPaddingBottom() + getPaint().getFontMetricsInt().bottom;
    }

    public ColorStateList getSupportBackgroundTintList() {
        C4952e eVar = this.f234e;
        if (eVar != null) {
            return eVar.mo10456b();
        }
        return null;
    }

    public PorterDuff.Mode getSupportBackgroundTintMode() {
        C4952e eVar = this.f234e;
        if (eVar != null) {
            return eVar.mo10457c();
        }
        return null;
    }

    public ColorStateList getSupportCompoundDrawablesTintList() {
        C4987p0 p0Var = this.f235f.f18240h;
        if (p0Var != null) {
            return p0Var.f18214a;
        }
        return null;
    }

    public PorterDuff.Mode getSupportCompoundDrawablesTintMode() {
        C4987p0 p0Var = this.f235f.f18240h;
        if (p0Var != null) {
            return p0Var.f18215b;
        }
        return null;
    }

    public CharSequence getText() {
        Future<C5645a> future = this.f237h;
        if (future != null) {
            try {
                this.f237h = null;
                C4851q.C4862i.m15096R0(this, future.get());
            } catch (InterruptedException | ExecutionException unused) {
            }
        }
        return super.getText();
    }

    /* JADX WARNING: Code restructure failed: missing block: B:2:0x0006, code lost:
        r0 = r2.f236g;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public android.view.textclassifier.TextClassifier getTextClassifier() {
        /*
            r2 = this;
            int r0 = android.os.Build.VERSION.SDK_INT
            r1 = 28
            if (r0 >= r1) goto L_0x0010
            d.b.p.s r0 = r2.f236g
            if (r0 != 0) goto L_0x000b
            goto L_0x0010
        L_0x000b:
            android.view.textclassifier.TextClassifier r0 = r0.mo10614a()
            return r0
        L_0x0010:
            android.view.textclassifier.TextClassifier r0 = super.getTextClassifier()
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.AppCompatTextView.getTextClassifier():android.view.textclassifier.TextClassifier");
    }

    public C5645a.C5646a getTextMetricsParamsCompat() {
        return C4851q.C4862i.m15132g0(this);
    }

    public InputConnection onCreateInputConnection(EditorInfo editorInfo) {
        InputConnection onCreateInputConnection = super.onCreateInputConnection(editorInfo);
        C4851q.C4862i.m15180w0(onCreateInputConnection, editorInfo, this);
        return onCreateInputConnection;
    }

    public void onLayout(boolean z, int i, int i2, int i3, int i4) {
        super.onLayout(z, i, i2, i3, i4);
        C4994t tVar = this.f235f;
        if (tVar != null && !C5694b.f20026a) {
            tVar.f18241i.mo10659a();
        }
    }

    public void onMeasure(int i, int i2) {
        Future<C5645a> future = this.f237h;
        if (future != null) {
            try {
                this.f237h = null;
                C4851q.C4862i.m15096R0(this, future.get());
            } catch (InterruptedException | ExecutionException unused) {
            }
        }
        super.onMeasure(i, i2);
    }

    public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
        super.onTextChanged(charSequence, i, i2, i3);
        C4994t tVar = this.f235f;
        if (tVar != null && !C5694b.f20026a && tVar.mo10618d()) {
            this.f235f.f18241i.mo10659a();
        }
    }

    public void setAutoSizeTextTypeUniformWithConfiguration(int i, int i2, int i3, int i4) {
        if (C5694b.f20026a) {
            super.setAutoSizeTextTypeUniformWithConfiguration(i, i2, i3, i4);
            return;
        }
        C4994t tVar = this.f235f;
        if (tVar != null) {
            tVar.mo10621g(i, i2, i3, i4);
        }
    }

    public void setAutoSizeTextTypeUniformWithPresetSizes(int[] iArr, int i) {
        if (C5694b.f20026a) {
            super.setAutoSizeTextTypeUniformWithPresetSizes(iArr, i);
            return;
        }
        C4994t tVar = this.f235f;
        if (tVar != null) {
            tVar.mo10622h(iArr, i);
        }
    }

    public void setAutoSizeTextTypeWithDefaults(int i) {
        if (C5694b.f20026a) {
            super.setAutoSizeTextTypeWithDefaults(i);
            return;
        }
        C4994t tVar = this.f235f;
        if (tVar != null) {
            tVar.mo10623i(i);
        }
    }

    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        C4952e eVar = this.f234e;
        if (eVar != null) {
            eVar.mo10459e();
        }
    }

    public void setBackgroundResource(int i) {
        super.setBackgroundResource(i);
        C4952e eVar = this.f234e;
        if (eVar != null) {
            eVar.mo10460f(i);
        }
    }

    public void setCompoundDrawables(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawables(drawable, drawable2, drawable3, drawable4);
        C4994t tVar = this.f235f;
        if (tVar != null) {
            tVar.mo10617b();
        }
    }

    public void setCompoundDrawablesRelative(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawablesRelative(drawable, drawable2, drawable3, drawable4);
        C4994t tVar = this.f235f;
        if (tVar != null) {
            tVar.mo10617b();
        }
    }

    public void setCompoundDrawablesRelativeWithIntrinsicBounds(int i, int i2, int i3, int i4) {
        Context context = getContext();
        Drawable drawable = null;
        Drawable b = i != 0 ? C4879a.m15208b(context, i) : null;
        Drawable b2 = i2 != 0 ? C4879a.m15208b(context, i2) : null;
        Drawable b3 = i3 != 0 ? C4879a.m15208b(context, i3) : null;
        if (i4 != 0) {
            drawable = C4879a.m15208b(context, i4);
        }
        setCompoundDrawablesRelativeWithIntrinsicBounds(b, b2, b3, drawable);
        C4994t tVar = this.f235f;
        if (tVar != null) {
            tVar.mo10617b();
        }
    }

    public void setCompoundDrawablesWithIntrinsicBounds(int i, int i2, int i3, int i4) {
        Context context = getContext();
        Drawable drawable = null;
        Drawable b = i != 0 ? C4879a.m15208b(context, i) : null;
        Drawable b2 = i2 != 0 ? C4879a.m15208b(context, i2) : null;
        Drawable b3 = i3 != 0 ? C4879a.m15208b(context, i3) : null;
        if (i4 != 0) {
            drawable = C4879a.m15208b(context, i4);
        }
        setCompoundDrawablesWithIntrinsicBounds(b, b2, b3, drawable);
        C4994t tVar = this.f235f;
        if (tVar != null) {
            tVar.mo10617b();
        }
    }

    public void setCustomSelectionActionModeCallback(ActionMode.Callback callback) {
        super.setCustomSelectionActionModeCallback(C4851q.C4862i.m15115a1(this, callback));
    }

    public void setFirstBaselineToTopHeight(int i) {
        if (Build.VERSION.SDK_INT >= 28) {
            super.setFirstBaselineToTopHeight(i);
        } else {
            C4851q.C4862i.m15088N0(this, i);
        }
    }

    public void setLastBaselineToBottomHeight(int i) {
        if (Build.VERSION.SDK_INT >= 28) {
            super.setLastBaselineToBottomHeight(i);
        } else {
            C4851q.C4862i.m15090O0(this, i);
        }
    }

    public void setLineHeight(int i) {
        C4851q.C4862i.m15092P0(this, i);
    }

    public void setPrecomputedText(C5645a aVar) {
        C4851q.C4862i.m15096R0(this, aVar);
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        C4952e eVar = this.f234e;
        if (eVar != null) {
            eVar.mo10462h(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        C4952e eVar = this.f234e;
        if (eVar != null) {
            eVar.mo10463i(mode);
        }
    }

    public void setSupportCompoundDrawablesTintList(ColorStateList colorStateList) {
        this.f235f.mo10624j(colorStateList);
        this.f235f.mo10617b();
    }

    public void setSupportCompoundDrawablesTintMode(PorterDuff.Mode mode) {
        this.f235f.mo10625k(mode);
        this.f235f.mo10617b();
    }

    public void setTextAppearance(Context context, int i) {
        super.setTextAppearance(context, i);
        C4994t tVar = this.f235f;
        if (tVar != null) {
            tVar.mo10620f(context, i);
        }
    }

    public void setTextClassifier(TextClassifier textClassifier) {
        C4992s sVar;
        if (Build.VERSION.SDK_INT >= 28 || (sVar = this.f236g) == null) {
            super.setTextClassifier(textClassifier);
        } else {
            sVar.f18230b = textClassifier;
        }
    }

    public void setTextFuture(Future<C5645a> future) {
        this.f237h = future;
        if (future != null) {
            requestLayout();
        }
    }

    public void setTextMetricsParamsCompat(C5645a.C5646a aVar) {
        TextDirectionHeuristic textDirectionHeuristic = aVar.f19925b;
        int i = 1;
        if (!(textDirectionHeuristic == TextDirectionHeuristics.FIRSTSTRONG_RTL || textDirectionHeuristic == TextDirectionHeuristics.FIRSTSTRONG_LTR)) {
            if (textDirectionHeuristic == TextDirectionHeuristics.ANYRTL_LTR) {
                i = 2;
            } else if (textDirectionHeuristic == TextDirectionHeuristics.LTR) {
                i = 3;
            } else if (textDirectionHeuristic == TextDirectionHeuristics.RTL) {
                i = 4;
            } else if (textDirectionHeuristic == TextDirectionHeuristics.LOCALE) {
                i = 5;
            } else if (textDirectionHeuristic == TextDirectionHeuristics.FIRSTSTRONG_LTR) {
                i = 6;
            } else if (textDirectionHeuristic == TextDirectionHeuristics.FIRSTSTRONG_RTL) {
                i = 7;
            }
        }
        setTextDirection(i);
        getPaint().set(aVar.f19924a);
        setBreakStrategy(aVar.f19926c);
        setHyphenationFrequency(aVar.f19927d);
    }

    public void setTextSize(int i, float f) {
        boolean z = C5694b.f20026a;
        if (z) {
            super.setTextSize(i, f);
            return;
        }
        C4994t tVar = this.f235f;
        if (tVar != null && !z && !tVar.mo10618d()) {
            tVar.f18241i.mo10662f(i, f);
        }
    }

    public void setTypeface(Typeface typeface, int i) {
        Typeface a = (typeface == null || i <= 0) ? null : C5612c.m16751a(getContext(), typeface, i);
        if (a != null) {
            typeface = a;
        }
        super.setTypeface(typeface, i);
    }

    public void setCompoundDrawablesRelativeWithIntrinsicBounds(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawablesRelativeWithIntrinsicBounds(drawable, drawable2, drawable3, drawable4);
        C4994t tVar = this.f235f;
        if (tVar != null) {
            tVar.mo10617b();
        }
    }

    public void setCompoundDrawablesWithIntrinsicBounds(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawablesWithIntrinsicBounds(drawable, drawable2, drawable3, drawable4);
        C4994t tVar = this.f235f;
        if (tVar != null) {
            tVar.mo10617b();
        }
    }
}
