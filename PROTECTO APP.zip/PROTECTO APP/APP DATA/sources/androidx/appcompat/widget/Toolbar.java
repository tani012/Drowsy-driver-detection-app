package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.drawable.Drawable;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.ContextThemeWrapper;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.widget.ActionMenuView;
import java.util.ArrayList;
import java.util.List;
import p176d.p178b.C4816a;
import p176d.p178b.p179k.C4840j;
import p176d.p178b.p180l.p181a.C4879a;
import p176d.p178b.p185o.C4884b;
import p176d.p178b.p185o.C4889f;
import p176d.p178b.p185o.p186i.C4907g;
import p176d.p178b.p185o.p186i.C4911i;
import p176d.p178b.p185o.p186i.C4922m;
import p176d.p178b.p185o.p186i.C4931r;
import p176d.p178b.p187p.C4940c;
import p176d.p178b.p187p.C4973j0;
import p176d.p178b.p187p.C4996t0;
import p176d.p178b.p187p.C5004v0;
import p176d.p178b.p187p.C5007x;
import p176d.p219i.p231k.C5662k;
import p176d.p236k.p237a.C5703a;

public class Toolbar extends ViewGroup {

    /* renamed from: A */
    public int f327A = 8388627;

    /* renamed from: B */
    public CharSequence f328B;

    /* renamed from: C */
    public CharSequence f329C;

    /* renamed from: D */
    public ColorStateList f330D;

    /* renamed from: E */
    public ColorStateList f331E;

    /* renamed from: F */
    public boolean f332F;

    /* renamed from: G */
    public boolean f333G;

    /* renamed from: H */
    public final ArrayList<View> f334H = new ArrayList<>();

    /* renamed from: I */
    public final ArrayList<View> f335I = new ArrayList<>();

    /* renamed from: J */
    public final int[] f336J = new int[2];

    /* renamed from: K */
    public C0057f f337K;

    /* renamed from: L */
    public final ActionMenuView.C0022e f338L = new C0052a();

    /* renamed from: M */
    public C4996t0 f339M;

    /* renamed from: N */
    public C4940c f340N;

    /* renamed from: O */
    public C0055d f341O;

    /* renamed from: P */
    public boolean f342P;

    /* renamed from: Q */
    public final Runnable f343Q = new C0053b();

    /* renamed from: e */
    public ActionMenuView f344e;

    /* renamed from: f */
    public TextView f345f;

    /* renamed from: g */
    public TextView f346g;

    /* renamed from: h */
    public ImageButton f347h;

    /* renamed from: i */
    public ImageView f348i;

    /* renamed from: j */
    public Drawable f349j;

    /* renamed from: k */
    public CharSequence f350k;

    /* renamed from: l */
    public ImageButton f351l;

    /* renamed from: m */
    public View f352m;

    /* renamed from: n */
    public Context f353n;

    /* renamed from: o */
    public int f354o;

    /* renamed from: p */
    public int f355p;

    /* renamed from: q */
    public int f356q;

    /* renamed from: r */
    public int f357r;

    /* renamed from: s */
    public int f358s;

    /* renamed from: t */
    public int f359t;

    /* renamed from: u */
    public int f360u;

    /* renamed from: v */
    public int f361v;

    /* renamed from: w */
    public int f362w;

    /* renamed from: x */
    public C4973j0 f363x;

    /* renamed from: y */
    public int f364y;

    /* renamed from: z */
    public int f365z;

    /* renamed from: androidx.appcompat.widget.Toolbar$a */
    public class C0052a implements ActionMenuView.C0022e {
        public C0052a() {
        }
    }

    /* renamed from: androidx.appcompat.widget.Toolbar$b */
    public class C0053b implements Runnable {
        public C0053b() {
        }

        public void run() {
            Toolbar.this.mo561u();
        }
    }

    /* renamed from: androidx.appcompat.widget.Toolbar$c */
    public class C0054c implements View.OnClickListener {
        public C0054c() {
        }

        public void onClick(View view) {
            C0055d dVar = Toolbar.this.f341O;
            C4911i iVar = dVar == null ? null : dVar.f370f;
            if (iVar != null) {
                iVar.collapseActionView();
            }
        }
    }

    /* renamed from: androidx.appcompat.widget.Toolbar$d */
    public class C0055d implements C4922m {

        /* renamed from: e */
        public C4907g f369e;

        /* renamed from: f */
        public C4911i f370f;

        public C0055d() {
        }

        /* renamed from: a */
        public void mo564a(C4907g gVar, boolean z) {
        }

        /* renamed from: b */
        public void mo565b(Context context, C4907g gVar) {
            C4911i iVar;
            C4907g gVar2 = this.f369e;
            if (!(gVar2 == null || (iVar = this.f370f) == null)) {
                gVar2.mo10183d(iVar);
            }
            this.f369e = gVar;
        }

        /* renamed from: c */
        public boolean mo566c(C4931r rVar) {
            return false;
        }

        /* renamed from: d */
        public void mo567d(boolean z) {
            if (this.f370f != null) {
                C4907g gVar = this.f369e;
                boolean z2 = false;
                if (gVar != null) {
                    int size = gVar.size();
                    int i = 0;
                    while (true) {
                        if (i >= size) {
                            break;
                        } else if (this.f369e.getItem(i) == this.f370f) {
                            z2 = true;
                            break;
                        } else {
                            i++;
                        }
                    }
                }
                if (!z2) {
                    mo569f(this.f369e, this.f370f);
                }
            }
        }

        /* renamed from: e */
        public boolean mo568e() {
            return false;
        }

        /* renamed from: f */
        public boolean mo569f(C4907g gVar, C4911i iVar) {
            View view = Toolbar.this.f352m;
            if (view instanceof C4884b) {
                ((C4884b) view).mo390d();
            }
            Toolbar toolbar = Toolbar.this;
            toolbar.removeView(toolbar.f352m);
            Toolbar toolbar2 = Toolbar.this;
            toolbar2.removeView(toolbar2.f351l);
            Toolbar toolbar3 = Toolbar.this;
            toolbar3.f352m = null;
            int size = toolbar3.f335I.size();
            while (true) {
                size--;
                if (size >= 0) {
                    toolbar3.addView(toolbar3.f335I.get(size));
                } else {
                    toolbar3.f335I.clear();
                    this.f370f = null;
                    Toolbar.this.requestLayout();
                    iVar.f17930C = false;
                    iVar.f17945n.mo10202q(false);
                    return true;
                }
            }
        }

        /* renamed from: g */
        public boolean mo570g(C4907g gVar, C4911i iVar) {
            Toolbar.this.mo470c();
            ViewParent parent = Toolbar.this.f351l.getParent();
            Toolbar toolbar = Toolbar.this;
            if (parent != toolbar) {
                if (parent instanceof ViewGroup) {
                    ((ViewGroup) parent).removeView(toolbar.f351l);
                }
                Toolbar toolbar2 = Toolbar.this;
                toolbar2.addView(toolbar2.f351l);
            }
            Toolbar.this.f352m = iVar.getActionView();
            this.f370f = iVar;
            ViewParent parent2 = Toolbar.this.f352m.getParent();
            Toolbar toolbar3 = Toolbar.this;
            if (parent2 != toolbar3) {
                if (parent2 instanceof ViewGroup) {
                    ((ViewGroup) parent2).removeView(toolbar3.f352m);
                }
                C0056e h = Toolbar.this.generateDefaultLayoutParams();
                Toolbar toolbar4 = Toolbar.this;
                h.f17608a = 8388611 | (toolbar4.f357r & 112);
                h.f372b = 2;
                toolbar4.f352m.setLayoutParams(h);
                Toolbar toolbar5 = Toolbar.this;
                toolbar5.addView(toolbar5.f352m);
            }
            Toolbar toolbar6 = Toolbar.this;
            int childCount = toolbar6.getChildCount();
            while (true) {
                childCount--;
                if (childCount < 0) {
                    break;
                }
                View childAt = toolbar6.getChildAt(childCount);
                if (!(((C0056e) childAt.getLayoutParams()).f372b == 2 || childAt == toolbar6.f344e)) {
                    toolbar6.removeViewAt(childCount);
                    toolbar6.f335I.add(childAt);
                }
            }
            Toolbar.this.requestLayout();
            iVar.f17930C = true;
            iVar.f17945n.mo10202q(false);
            View view = Toolbar.this.f352m;
            if (view instanceof C4884b) {
                ((C4884b) view).mo388c();
            }
            return true;
        }

        /* renamed from: h */
        public void mo571h(C4922m.C4923a aVar) {
        }
    }

    /* renamed from: androidx.appcompat.widget.Toolbar$e */
    public static class C0056e extends C4840j.C4841a {

        /* renamed from: b */
        public int f372b = 0;

        public C0056e(int i, int i2) {
            super(i, i2);
            this.f17608a = 8388627;
        }

        public C0056e(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
        }

        public C0056e(ViewGroup.LayoutParams layoutParams) {
            super(layoutParams);
        }

        public C0056e(ViewGroup.MarginLayoutParams marginLayoutParams) {
            super((ViewGroup.LayoutParams) marginLayoutParams);
            this.leftMargin = marginLayoutParams.leftMargin;
            this.topMargin = marginLayoutParams.topMargin;
            this.rightMargin = marginLayoutParams.rightMargin;
            this.bottomMargin = marginLayoutParams.bottomMargin;
        }

        public C0056e(C0056e eVar) {
            super((C4840j.C4841a) eVar);
            this.f372b = eVar.f372b;
        }

        public C0056e(C4840j.C4841a aVar) {
            super(aVar);
        }
    }

    /* renamed from: androidx.appcompat.widget.Toolbar$f */
    public interface C0057f {
        boolean onMenuItemClick(MenuItem menuItem);
    }

    /* renamed from: androidx.appcompat.widget.Toolbar$g */
    public static class C0058g extends C5703a {
        public static final Parcelable.Creator<C0058g> CREATOR = new C0059a();

        /* renamed from: g */
        public int f373g;

        /* renamed from: h */
        public boolean f374h;

        /* renamed from: androidx.appcompat.widget.Toolbar$g$a */
        public class C0059a implements Parcelable.ClassLoaderCreator<C0058g> {
            public Object createFromParcel(Parcel parcel) {
                return new C0058g(parcel, (ClassLoader) null);
            }

            public Object[] newArray(int i) {
                return new C0058g[i];
            }

            public Object createFromParcel(Parcel parcel, ClassLoader classLoader) {
                return new C0058g(parcel, classLoader);
            }
        }

        public C0058g(Parcel parcel, ClassLoader classLoader) {
            super(parcel, classLoader);
            this.f373g = parcel.readInt();
            this.f374h = parcel.readInt() != 0;
        }

        public C0058g(Parcelable parcelable) {
            super(parcelable);
        }

        public void writeToParcel(Parcel parcel, int i) {
            parcel.writeParcelable(this.f20049e, i);
            parcel.writeInt(this.f373g);
            parcel.writeInt(this.f374h ? 1 : 0);
        }
    }

    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public Toolbar(android.content.Context r10, android.util.AttributeSet r11) {
        /*
            r9 = this;
            int r5 = p176d.p178b.C4816a.toolbarStyle
            r9.<init>(r10, r11, r5)
            r0 = 8388627(0x800013, float:1.175497E-38)
            r9.f327A = r0
            java.util.ArrayList r0 = new java.util.ArrayList
            r0.<init>()
            r9.f334H = r0
            java.util.ArrayList r0 = new java.util.ArrayList
            r0.<init>()
            r9.f335I = r0
            r0 = 2
            int[] r0 = new int[r0]
            r9.f336J = r0
            androidx.appcompat.widget.Toolbar$a r0 = new androidx.appcompat.widget.Toolbar$a
            r0.<init>()
            r9.f338L = r0
            androidx.appcompat.widget.Toolbar$b r0 = new androidx.appcompat.widget.Toolbar$b
            r0.<init>()
            r9.f343Q = r0
            android.content.Context r0 = r9.getContext()
            int[] r1 = p176d.p178b.C4825j.Toolbar
            r7 = 0
            d.b.p.r0 r8 = p176d.p178b.p187p.C4991r0.m15539o(r0, r11, r1, r5, r7)
            int[] r2 = p176d.p178b.C4825j.Toolbar
            android.content.res.TypedArray r4 = r8.f18227b
            r6 = 0
            r0 = r9
            r1 = r10
            r3 = r11
            p176d.p219i.p231k.C5662k.m16843t(r0, r1, r2, r3, r4, r5, r6)
            int r10 = p176d.p178b.C4825j.Toolbar_titleTextAppearance
            int r10 = r8.mo10610j(r10, r7)
            r9.f355p = r10
            int r10 = p176d.p178b.C4825j.Toolbar_subtitleTextAppearance
            int r10 = r8.mo10610j(r10, r7)
            r9.f356q = r10
            int r10 = p176d.p178b.C4825j.Toolbar_android_gravity
            int r11 = r9.f327A
            android.content.res.TypedArray r0 = r8.f18227b
            int r10 = r0.getInteger(r10, r11)
            r9.f327A = r10
            int r10 = p176d.p178b.C4825j.Toolbar_buttonGravity
            r11 = 48
            android.content.res.TypedArray r0 = r8.f18227b
            int r10 = r0.getInteger(r10, r11)
            r9.f357r = r10
            int r10 = p176d.p178b.C4825j.Toolbar_titleMargin
            int r10 = r8.mo10603c(r10, r7)
            int r11 = p176d.p178b.C4825j.Toolbar_titleMargins
            boolean r11 = r8.mo10613m(r11)
            if (r11 == 0) goto L_0x007d
            int r11 = p176d.p178b.C4825j.Toolbar_titleMargins
            int r10 = r8.mo10603c(r11, r10)
        L_0x007d:
            r9.f362w = r10
            r9.f361v = r10
            r9.f360u = r10
            r9.f359t = r10
            int r10 = p176d.p178b.C4825j.Toolbar_titleMarginStart
            r11 = -1
            int r10 = r8.mo10603c(r10, r11)
            if (r10 < 0) goto L_0x0090
            r9.f359t = r10
        L_0x0090:
            int r10 = p176d.p178b.C4825j.Toolbar_titleMarginEnd
            int r10 = r8.mo10603c(r10, r11)
            if (r10 < 0) goto L_0x009a
            r9.f360u = r10
        L_0x009a:
            int r10 = p176d.p178b.C4825j.Toolbar_titleMarginTop
            int r10 = r8.mo10603c(r10, r11)
            if (r10 < 0) goto L_0x00a4
            r9.f361v = r10
        L_0x00a4:
            int r10 = p176d.p178b.C4825j.Toolbar_titleMarginBottom
            int r10 = r8.mo10603c(r10, r11)
            if (r10 < 0) goto L_0x00ae
            r9.f362w = r10
        L_0x00ae:
            int r10 = p176d.p178b.C4825j.Toolbar_maxButtonHeight
            int r10 = r8.mo10604d(r10, r11)
            r9.f358s = r10
            int r10 = p176d.p178b.C4825j.Toolbar_contentInsetStart
            r11 = -2147483648(0xffffffff80000000, float:-0.0)
            int r10 = r8.mo10603c(r10, r11)
            int r0 = p176d.p178b.C4825j.Toolbar_contentInsetEnd
            int r0 = r8.mo10603c(r0, r11)
            int r1 = p176d.p178b.C4825j.Toolbar_contentInsetLeft
            int r1 = r8.mo10604d(r1, r7)
            int r2 = p176d.p178b.C4825j.Toolbar_contentInsetRight
            int r2 = r8.mo10604d(r2, r7)
            r9.mo472d()
            d.b.p.j0 r3 = r9.f363x
            r3.f18166h = r7
            if (r1 == r11) goto L_0x00dd
            r3.f18163e = r1
            r3.f18159a = r1
        L_0x00dd:
            if (r2 == r11) goto L_0x00e3
            r3.f18164f = r2
            r3.f18160b = r2
        L_0x00e3:
            if (r10 != r11) goto L_0x00e7
            if (r0 == r11) goto L_0x00ec
        L_0x00e7:
            d.b.p.j0 r1 = r9.f363x
            r1.mo10534a(r10, r0)
        L_0x00ec:
            int r10 = p176d.p178b.C4825j.Toolbar_contentInsetStartWithNavigation
            int r10 = r8.mo10603c(r10, r11)
            r9.f364y = r10
            int r10 = p176d.p178b.C4825j.Toolbar_contentInsetEndWithActions
            int r10 = r8.mo10603c(r10, r11)
            r9.f365z = r10
            int r10 = p176d.p178b.C4825j.Toolbar_collapseIcon
            android.graphics.drawable.Drawable r10 = r8.mo10605e(r10)
            r9.f349j = r10
            int r10 = p176d.p178b.C4825j.Toolbar_collapseContentDescription
            java.lang.CharSequence r10 = r8.mo10612l(r10)
            r9.f350k = r10
            int r10 = p176d.p178b.C4825j.Toolbar_title
            java.lang.CharSequence r10 = r8.mo10612l(r10)
            boolean r11 = android.text.TextUtils.isEmpty(r10)
            if (r11 != 0) goto L_0x011b
            r9.setTitle((java.lang.CharSequence) r10)
        L_0x011b:
            int r10 = p176d.p178b.C4825j.Toolbar_subtitle
            java.lang.CharSequence r10 = r8.mo10612l(r10)
            boolean r11 = android.text.TextUtils.isEmpty(r10)
            if (r11 != 0) goto L_0x012a
            r9.setSubtitle((java.lang.CharSequence) r10)
        L_0x012a:
            android.content.Context r10 = r9.getContext()
            r9.f353n = r10
            int r10 = p176d.p178b.C4825j.Toolbar_popupTheme
            int r10 = r8.mo10610j(r10, r7)
            r9.setPopupTheme(r10)
            int r10 = p176d.p178b.C4825j.Toolbar_navigationIcon
            android.graphics.drawable.Drawable r10 = r8.mo10605e(r10)
            if (r10 == 0) goto L_0x0144
            r9.setNavigationIcon((android.graphics.drawable.Drawable) r10)
        L_0x0144:
            int r10 = p176d.p178b.C4825j.Toolbar_navigationContentDescription
            java.lang.CharSequence r10 = r8.mo10612l(r10)
            boolean r11 = android.text.TextUtils.isEmpty(r10)
            if (r11 != 0) goto L_0x0153
            r9.setNavigationContentDescription((java.lang.CharSequence) r10)
        L_0x0153:
            int r10 = p176d.p178b.C4825j.Toolbar_logo
            android.graphics.drawable.Drawable r10 = r8.mo10605e(r10)
            if (r10 == 0) goto L_0x015e
            r9.setLogo((android.graphics.drawable.Drawable) r10)
        L_0x015e:
            int r10 = p176d.p178b.C4825j.Toolbar_logoDescription
            java.lang.CharSequence r10 = r8.mo10612l(r10)
            boolean r11 = android.text.TextUtils.isEmpty(r10)
            if (r11 != 0) goto L_0x016d
            r9.setLogoDescription((java.lang.CharSequence) r10)
        L_0x016d:
            int r10 = p176d.p178b.C4825j.Toolbar_titleTextColor
            boolean r10 = r8.mo10613m(r10)
            if (r10 == 0) goto L_0x017e
            int r10 = p176d.p178b.C4825j.Toolbar_titleTextColor
            android.content.res.ColorStateList r10 = r8.mo10602b(r10)
            r9.setTitleTextColor((android.content.res.ColorStateList) r10)
        L_0x017e:
            int r10 = p176d.p178b.C4825j.Toolbar_subtitleTextColor
            boolean r10 = r8.mo10613m(r10)
            if (r10 == 0) goto L_0x018f
            int r10 = p176d.p178b.C4825j.Toolbar_subtitleTextColor
            android.content.res.ColorStateList r10 = r8.mo10602b(r10)
            r9.setSubtitleTextColor((android.content.res.ColorStateList) r10)
        L_0x018f:
            int r10 = p176d.p178b.C4825j.Toolbar_menu
            boolean r10 = r8.mo10613m(r10)
            if (r10 == 0) goto L_0x01a8
            int r10 = p176d.p178b.C4825j.Toolbar_menu
            int r10 = r8.mo10610j(r10, r7)
            android.view.MenuInflater r11 = r9.getMenuInflater()
            android.view.Menu r0 = r9.getMenu()
            r11.inflate(r10, r0)
        L_0x01a8:
            android.content.res.TypedArray r10 = r8.f18227b
            r10.recycle()
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.Toolbar.<init>(android.content.Context, android.util.AttributeSet):void");
    }

    private MenuInflater getMenuInflater() {
        return new C4889f(getContext());
    }

    /* renamed from: a */
    public final void mo468a(List<View> list, int i) {
        boolean z = C5662k.m16829f(this) == 1;
        int childCount = getChildCount();
        int absoluteGravity = Gravity.getAbsoluteGravity(i, getLayoutDirection());
        list.clear();
        if (z) {
            for (int i2 = childCount - 1; i2 >= 0; i2--) {
                View childAt = getChildAt(i2);
                C0056e eVar = (C0056e) childAt.getLayoutParams();
                if (eVar.f372b == 0 && mo560t(childAt) && mo511j(eVar.f17608a) == absoluteGravity) {
                    list.add(childAt);
                }
            }
            return;
        }
        for (int i3 = 0; i3 < childCount; i3++) {
            View childAt2 = getChildAt(i3);
            C0056e eVar2 = (C0056e) childAt2.getLayoutParams();
            if (eVar2.f372b == 0 && mo560t(childAt2) && mo511j(eVar2.f17608a) == absoluteGravity) {
                list.add(childAt2);
            }
        }
    }

    /* renamed from: b */
    public final void mo469b(View view, boolean z) {
        ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
        C0056e h = layoutParams == null ? generateDefaultLayoutParams() : !checkLayoutParams(layoutParams) ? generateLayoutParams(layoutParams) : (C0056e) layoutParams;
        h.f372b = 1;
        if (!z || this.f352m == null) {
            addView(view, h);
            return;
        }
        view.setLayoutParams(h);
        this.f335I.add(view);
    }

    /* renamed from: c */
    public void mo470c() {
        if (this.f351l == null) {
            AppCompatImageButton appCompatImageButton = new AppCompatImageButton(getContext(), (AttributeSet) null, C4816a.toolbarNavigationButtonStyle);
            this.f351l = appCompatImageButton;
            appCompatImageButton.setImageDrawable(this.f349j);
            this.f351l.setContentDescription(this.f350k);
            C0056e h = generateDefaultLayoutParams();
            h.f17608a = 8388611 | (this.f357r & 112);
            h.f372b = 2;
            this.f351l.setLayoutParams(h);
            this.f351l.setOnClickListener(new C0054c());
        }
    }

    public boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return super.checkLayoutParams(layoutParams) && (layoutParams instanceof C0056e);
    }

    /* renamed from: d */
    public final void mo472d() {
        if (this.f363x == null) {
            this.f363x = new C4973j0();
        }
    }

    /* renamed from: e */
    public final void mo473e() {
        mo474f();
        ActionMenuView actionMenuView = this.f344e;
        if (actionMenuView.f185t == null) {
            C4907g gVar = (C4907g) actionMenuView.getMenu();
            if (this.f341O == null) {
                this.f341O = new C0055d();
            }
            this.f344e.setExpandedActionViewsExclusive(true);
            gVar.mo10178b(this.f341O, this.f353n);
        }
    }

    /* renamed from: f */
    public final void mo474f() {
        if (this.f344e == null) {
            ActionMenuView actionMenuView = new ActionMenuView(getContext(), (AttributeSet) null);
            this.f344e = actionMenuView;
            actionMenuView.setPopupTheme(this.f354o);
            this.f344e.setOnMenuItemClickListener(this.f338L);
            ActionMenuView actionMenuView2 = this.f344e;
            actionMenuView2.f190y = null;
            actionMenuView2.f191z = null;
            C0056e h = generateDefaultLayoutParams();
            h.f17608a = 8388613 | (this.f357r & 112);
            this.f344e.setLayoutParams(h);
            mo469b(this.f344e, false);
        }
    }

    /* renamed from: g */
    public final void mo475g() {
        if (this.f347h == null) {
            this.f347h = new AppCompatImageButton(getContext(), (AttributeSet) null, C4816a.toolbarNavigationButtonStyle);
            C0056e h = generateDefaultLayoutParams();
            h.f17608a = 8388611 | (this.f357r & 112);
            this.f347h.setLayoutParams(h);
        }
    }

    public ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new C0056e(getContext(), attributeSet);
    }

    public CharSequence getCollapseContentDescription() {
        ImageButton imageButton = this.f351l;
        if (imageButton != null) {
            return imageButton.getContentDescription();
        }
        return null;
    }

    public Drawable getCollapseIcon() {
        ImageButton imageButton = this.f351l;
        if (imageButton != null) {
            return imageButton.getDrawable();
        }
        return null;
    }

    public int getContentInsetEnd() {
        C4973j0 j0Var = this.f363x;
        if (j0Var != null) {
            return j0Var.f18165g ? j0Var.f18159a : j0Var.f18160b;
        }
        return 0;
    }

    public int getContentInsetEndWithActions() {
        int i = this.f365z;
        return i != Integer.MIN_VALUE ? i : getContentInsetEnd();
    }

    public int getContentInsetLeft() {
        C4973j0 j0Var = this.f363x;
        if (j0Var != null) {
            return j0Var.f18159a;
        }
        return 0;
    }

    public int getContentInsetRight() {
        C4973j0 j0Var = this.f363x;
        if (j0Var != null) {
            return j0Var.f18160b;
        }
        return 0;
    }

    public int getContentInsetStart() {
        C4973j0 j0Var = this.f363x;
        if (j0Var != null) {
            return j0Var.f18165g ? j0Var.f18160b : j0Var.f18159a;
        }
        return 0;
    }

    public int getContentInsetStartWithNavigation() {
        int i = this.f364y;
        return i != Integer.MIN_VALUE ? i : getContentInsetStart();
    }

    /* JADX WARNING: Code restructure failed: missing block: B:2:0x0005, code lost:
        r0 = r0.f185t;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public int getCurrentContentInsetEnd() {
        /*
            r3 = this;
            androidx.appcompat.widget.ActionMenuView r0 = r3.f344e
            r1 = 0
            if (r0 == 0) goto L_0x0011
            d.b.o.i.g r0 = r0.f185t
            if (r0 == 0) goto L_0x0011
            boolean r0 = r0.hasVisibleItems()
            if (r0 == 0) goto L_0x0011
            r0 = 1
            goto L_0x0012
        L_0x0011:
            r0 = r1
        L_0x0012:
            if (r0 == 0) goto L_0x0023
            int r0 = r3.getContentInsetEnd()
            int r2 = r3.f365z
            int r1 = java.lang.Math.max(r2, r1)
            int r0 = java.lang.Math.max(r0, r1)
            goto L_0x0027
        L_0x0023:
            int r0 = r3.getContentInsetEnd()
        L_0x0027:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.Toolbar.getCurrentContentInsetEnd():int");
    }

    public int getCurrentContentInsetLeft() {
        return C5662k.m16829f(this) == 1 ? getCurrentContentInsetEnd() : getCurrentContentInsetStart();
    }

    public int getCurrentContentInsetRight() {
        return C5662k.m16829f(this) == 1 ? getCurrentContentInsetStart() : getCurrentContentInsetEnd();
    }

    public int getCurrentContentInsetStart() {
        return getNavigationIcon() != null ? Math.max(getContentInsetStart(), Math.max(this.f364y, 0)) : getContentInsetStart();
    }

    public Drawable getLogo() {
        ImageView imageView = this.f348i;
        if (imageView != null) {
            return imageView.getDrawable();
        }
        return null;
    }

    public CharSequence getLogoDescription() {
        ImageView imageView = this.f348i;
        if (imageView != null) {
            return imageView.getContentDescription();
        }
        return null;
    }

    public Menu getMenu() {
        mo473e();
        return this.f344e.getMenu();
    }

    public CharSequence getNavigationContentDescription() {
        ImageButton imageButton = this.f347h;
        if (imageButton != null) {
            return imageButton.getContentDescription();
        }
        return null;
    }

    public Drawable getNavigationIcon() {
        ImageButton imageButton = this.f347h;
        if (imageButton != null) {
            return imageButton.getDrawable();
        }
        return null;
    }

    public C4940c getOuterActionMenuPresenter() {
        return this.f340N;
    }

    public Drawable getOverflowIcon() {
        mo473e();
        return this.f344e.getOverflowIcon();
    }

    public Context getPopupContext() {
        return this.f353n;
    }

    public int getPopupTheme() {
        return this.f354o;
    }

    public CharSequence getSubtitle() {
        return this.f329C;
    }

    public final TextView getSubtitleTextView() {
        return this.f346g;
    }

    public CharSequence getTitle() {
        return this.f328B;
    }

    public int getTitleMarginBottom() {
        return this.f362w;
    }

    public int getTitleMarginEnd() {
        return this.f360u;
    }

    public int getTitleMarginStart() {
        return this.f359t;
    }

    public int getTitleMarginTop() {
        return this.f361v;
    }

    public final TextView getTitleTextView() {
        return this.f345f;
    }

    public C5007x getWrapper() {
        if (this.f339M == null) {
            this.f339M = new C4996t0(this, true);
        }
        return this.f339M;
    }

    /* renamed from: h */
    public C0056e generateDefaultLayoutParams() {
        return new C0056e(-2, -2);
    }

    /* renamed from: i */
    public C0056e generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof C0056e ? new C0056e((C0056e) layoutParams) : layoutParams instanceof C4840j.C4841a ? new C0056e((C4840j.C4841a) layoutParams) : layoutParams instanceof ViewGroup.MarginLayoutParams ? new C0056e((ViewGroup.MarginLayoutParams) layoutParams) : new C0056e(layoutParams);
    }

    /* renamed from: j */
    public final int mo511j(int i) {
        int f = C5662k.m16829f(this);
        int absoluteGravity = Gravity.getAbsoluteGravity(i, f) & 7;
        if (absoluteGravity == 1 || absoluteGravity == 3 || absoluteGravity == 5) {
            return absoluteGravity;
        }
        return f == 1 ? 5 : 3;
    }

    /* renamed from: k */
    public final int mo512k(View view, int i) {
        C0056e eVar = (C0056e) view.getLayoutParams();
        int measuredHeight = view.getMeasuredHeight();
        int i2 = i > 0 ? (measuredHeight - i) / 2 : 0;
        int i3 = eVar.f17608a & 112;
        if (!(i3 == 16 || i3 == 48 || i3 == 80)) {
            i3 = this.f327A & 112;
        }
        if (i3 == 48) {
            return getPaddingTop() - i2;
        }
        if (i3 == 80) {
            return (((getHeight() - getPaddingBottom()) - measuredHeight) - eVar.bottomMargin) - i2;
        }
        int paddingTop = getPaddingTop();
        int paddingBottom = getPaddingBottom();
        int height = getHeight();
        int i4 = (((height - paddingTop) - paddingBottom) - measuredHeight) / 2;
        int i5 = eVar.topMargin;
        if (i4 < i5) {
            i4 = i5;
        } else {
            int i6 = (((height - paddingBottom) - measuredHeight) - i4) - paddingTop;
            int i7 = eVar.bottomMargin;
            if (i6 < i7) {
                i4 = Math.max(0, i4 - (i7 - i6));
            }
        }
        return paddingTop + i4;
    }

    /* renamed from: l */
    public final int mo513l(View view) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        return marginLayoutParams.getMarginStart() + marginLayoutParams.getMarginEnd();
    }

    /* renamed from: m */
    public final int mo514m(View view) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        return marginLayoutParams.topMargin + marginLayoutParams.bottomMargin;
    }

    /* renamed from: n */
    public final boolean mo515n(View view) {
        return view.getParent() == this || this.f335I.contains(view);
    }

    /* renamed from: o */
    public boolean mo516o() {
        ActionMenuView actionMenuView = this.f344e;
        if (actionMenuView != null) {
            C4940c cVar = actionMenuView.f189x;
            if (cVar != null && cVar.mo10405m()) {
                return true;
            }
        }
        return false;
    }

    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        removeCallbacks(this.f343Q);
    }

    public boolean onHoverEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 9) {
            this.f333G = false;
        }
        if (!this.f333G) {
            boolean onHoverEvent = super.onHoverEvent(motionEvent);
            if (actionMasked == 9 && !onHoverEvent) {
                this.f333G = true;
            }
        }
        if (actionMasked == 10 || actionMasked == 3) {
            this.f333G = false;
        }
        return true;
    }

    /* JADX WARNING: Removed duplicated region for block: B:107:0x0295 A[LOOP:0: B:106:0x0293->B:107:0x0295, LOOP_END] */
    /* JADX WARNING: Removed duplicated region for block: B:110:0x02b7 A[LOOP:1: B:109:0x02b5->B:110:0x02b7, LOOP_END] */
    /* JADX WARNING: Removed duplicated region for block: B:113:0x02dc A[LOOP:2: B:112:0x02da->B:113:0x02dc, LOOP_END] */
    /* JADX WARNING: Removed duplicated region for block: B:116:0x031d  */
    /* JADX WARNING: Removed duplicated region for block: B:121:0x0331 A[LOOP:3: B:120:0x032f->B:121:0x0331, LOOP_END] */
    /* JADX WARNING: Removed duplicated region for block: B:18:0x005d  */
    /* JADX WARNING: Removed duplicated region for block: B:24:0x0072  */
    /* JADX WARNING: Removed duplicated region for block: B:30:0x00ad  */
    /* JADX WARNING: Removed duplicated region for block: B:36:0x00c2  */
    /* JADX WARNING: Removed duplicated region for block: B:42:0x00dd  */
    /* JADX WARNING: Removed duplicated region for block: B:43:0x00f6  */
    /* JADX WARNING: Removed duplicated region for block: B:45:0x00fb  */
    /* JADX WARNING: Removed duplicated region for block: B:46:0x0113  */
    /* JADX WARNING: Removed duplicated region for block: B:51:0x0122  */
    /* JADX WARNING: Removed duplicated region for block: B:52:0x0125  */
    /* JADX WARNING: Removed duplicated region for block: B:54:0x0129  */
    /* JADX WARNING: Removed duplicated region for block: B:55:0x012c  */
    /* JADX WARNING: Removed duplicated region for block: B:67:0x015d  */
    /* JADX WARNING: Removed duplicated region for block: B:77:0x019b  */
    /* JADX WARNING: Removed duplicated region for block: B:79:0x01ac  */
    /* JADX WARNING: Removed duplicated region for block: B:92:0x021b  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void onLayout(boolean r21, int r22, int r23, int r24, int r25) {
        /*
            r20 = this;
            r0 = r20
            int r1 = p176d.p219i.p231k.C5662k.m16829f(r20)
            r2 = 1
            r3 = 0
            if (r1 != r2) goto L_0x000c
            r1 = r2
            goto L_0x000d
        L_0x000c:
            r1 = r3
        L_0x000d:
            int r4 = r20.getWidth()
            int r5 = r20.getHeight()
            int r6 = r20.getPaddingLeft()
            int r7 = r20.getPaddingRight()
            int r8 = r20.getPaddingTop()
            int r9 = r20.getPaddingBottom()
            int r10 = r4 - r7
            int[] r11 = r0.f336J
            r11[r2] = r3
            r11[r3] = r3
            int r12 = r20.getMinimumHeight()
            if (r12 < 0) goto L_0x003a
            int r13 = r25 - r23
            int r12 = java.lang.Math.min(r12, r13)
            goto L_0x003b
        L_0x003a:
            r12 = r3
        L_0x003b:
            android.widget.ImageButton r13 = r0.f347h
            boolean r13 = r0.mo560t(r13)
            if (r13 == 0) goto L_0x0053
            android.widget.ImageButton r13 = r0.f347h
            if (r1 == 0) goto L_0x004e
            int r13 = r0.mo526q(r13, r10, r11, r12)
            r14 = r13
            r13 = r6
            goto L_0x0055
        L_0x004e:
            int r13 = r0.mo525p(r13, r6, r11, r12)
            goto L_0x0054
        L_0x0053:
            r13 = r6
        L_0x0054:
            r14 = r10
        L_0x0055:
            android.widget.ImageButton r15 = r0.f351l
            boolean r15 = r0.mo560t(r15)
            if (r15 == 0) goto L_0x006a
            android.widget.ImageButton r15 = r0.f351l
            if (r1 == 0) goto L_0x0066
            int r14 = r0.mo526q(r15, r14, r11, r12)
            goto L_0x006a
        L_0x0066:
            int r13 = r0.mo525p(r15, r13, r11, r12)
        L_0x006a:
            androidx.appcompat.widget.ActionMenuView r15 = r0.f344e
            boolean r15 = r0.mo560t(r15)
            if (r15 == 0) goto L_0x007f
            androidx.appcompat.widget.ActionMenuView r15 = r0.f344e
            if (r1 == 0) goto L_0x007b
            int r13 = r0.mo525p(r15, r13, r11, r12)
            goto L_0x007f
        L_0x007b:
            int r14 = r0.mo526q(r15, r14, r11, r12)
        L_0x007f:
            int r15 = r20.getCurrentContentInsetLeft()
            int r16 = r20.getCurrentContentInsetRight()
            int r2 = r15 - r13
            int r2 = java.lang.Math.max(r3, r2)
            r11[r3] = r2
            int r2 = r10 - r14
            int r2 = r16 - r2
            int r2 = java.lang.Math.max(r3, r2)
            r17 = 1
            r11[r17] = r2
            int r2 = java.lang.Math.max(r13, r15)
            int r10 = r10 - r16
            int r10 = java.lang.Math.min(r14, r10)
            android.view.View r13 = r0.f352m
            boolean r13 = r0.mo560t(r13)
            if (r13 == 0) goto L_0x00ba
            android.view.View r13 = r0.f352m
            if (r1 == 0) goto L_0x00b6
            int r10 = r0.mo526q(r13, r10, r11, r12)
            goto L_0x00ba
        L_0x00b6:
            int r2 = r0.mo525p(r13, r2, r11, r12)
        L_0x00ba:
            android.widget.ImageView r13 = r0.f348i
            boolean r13 = r0.mo560t(r13)
            if (r13 == 0) goto L_0x00cf
            android.widget.ImageView r13 = r0.f348i
            if (r1 == 0) goto L_0x00cb
            int r10 = r0.mo526q(r13, r10, r11, r12)
            goto L_0x00cf
        L_0x00cb:
            int r2 = r0.mo525p(r13, r2, r11, r12)
        L_0x00cf:
            android.widget.TextView r13 = r0.f345f
            boolean r13 = r0.mo560t(r13)
            android.widget.TextView r14 = r0.f346g
            boolean r14 = r0.mo560t(r14)
            if (r13 == 0) goto L_0x00f6
            android.widget.TextView r15 = r0.f345f
            android.view.ViewGroup$LayoutParams r15 = r15.getLayoutParams()
            androidx.appcompat.widget.Toolbar$e r15 = (androidx.appcompat.widget.Toolbar.C0056e) r15
            int r3 = r15.topMargin
            r24 = r7
            android.widget.TextView r7 = r0.f345f
            int r7 = r7.getMeasuredHeight()
            int r7 = r7 + r3
            int r3 = r15.bottomMargin
            int r7 = r7 + r3
            r3 = 0
            int r7 = r7 + r3
            goto L_0x00f9
        L_0x00f6:
            r24 = r7
            r7 = 0
        L_0x00f9:
            if (r14 == 0) goto L_0x0113
            android.widget.TextView r3 = r0.f346g
            android.view.ViewGroup$LayoutParams r3 = r3.getLayoutParams()
            androidx.appcompat.widget.Toolbar$e r3 = (androidx.appcompat.widget.Toolbar.C0056e) r3
            int r15 = r3.topMargin
            r16 = r4
            android.widget.TextView r4 = r0.f346g
            int r4 = r4.getMeasuredHeight()
            int r4 = r4 + r15
            int r3 = r3.bottomMargin
            int r4 = r4 + r3
            int r7 = r7 + r4
            goto L_0x0115
        L_0x0113:
            r16 = r4
        L_0x0115:
            if (r13 != 0) goto L_0x0120
            if (r14 == 0) goto L_0x011a
            goto L_0x0120
        L_0x011a:
            r18 = r6
            r23 = r12
            goto L_0x0285
        L_0x0120:
            if (r13 == 0) goto L_0x0125
            android.widget.TextView r3 = r0.f345f
            goto L_0x0127
        L_0x0125:
            android.widget.TextView r3 = r0.f346g
        L_0x0127:
            if (r14 == 0) goto L_0x012c
            android.widget.TextView r4 = r0.f346g
            goto L_0x012e
        L_0x012c:
            android.widget.TextView r4 = r0.f345f
        L_0x012e:
            android.view.ViewGroup$LayoutParams r3 = r3.getLayoutParams()
            androidx.appcompat.widget.Toolbar$e r3 = (androidx.appcompat.widget.Toolbar.C0056e) r3
            android.view.ViewGroup$LayoutParams r4 = r4.getLayoutParams()
            androidx.appcompat.widget.Toolbar$e r4 = (androidx.appcompat.widget.Toolbar.C0056e) r4
            if (r13 == 0) goto L_0x0144
            android.widget.TextView r15 = r0.f345f
            int r15 = r15.getMeasuredWidth()
            if (r15 > 0) goto L_0x014e
        L_0x0144:
            if (r14 == 0) goto L_0x0151
            android.widget.TextView r15 = r0.f346g
            int r15 = r15.getMeasuredWidth()
            if (r15 <= 0) goto L_0x0151
        L_0x014e:
            r17 = 1
            goto L_0x0153
        L_0x0151:
            r17 = 0
        L_0x0153:
            int r15 = r0.f327A
            r15 = r15 & 112(0x70, float:1.57E-43)
            r18 = r6
            r6 = 48
            if (r15 == r6) goto L_0x019b
            r6 = 80
            if (r15 == r6) goto L_0x018d
            int r6 = r5 - r8
            int r6 = r6 - r9
            int r6 = r6 - r7
            int r6 = r6 / 2
            int r15 = r3.topMargin
            r23 = r12
            int r12 = r0.f361v
            r25 = r2
            int r2 = r15 + r12
            if (r6 >= r2) goto L_0x0176
            int r6 = r15 + r12
            goto L_0x018b
        L_0x0176:
            int r5 = r5 - r9
            int r5 = r5 - r7
            int r5 = r5 - r6
            int r5 = r5 - r8
            int r2 = r3.bottomMargin
            int r3 = r0.f362w
            int r2 = r2 + r3
            if (r5 >= r2) goto L_0x018b
            int r2 = r4.bottomMargin
            int r2 = r2 + r3
            int r2 = r2 - r5
            int r6 = r6 - r2
            r2 = 0
            int r6 = java.lang.Math.max(r2, r6)
        L_0x018b:
            int r8 = r8 + r6
            goto L_0x01aa
        L_0x018d:
            r25 = r2
            r23 = r12
            int r5 = r5 - r9
            int r2 = r4.bottomMargin
            int r5 = r5 - r2
            int r2 = r0.f362w
            int r5 = r5 - r2
            int r8 = r5 - r7
            goto L_0x01aa
        L_0x019b:
            r25 = r2
            r23 = r12
            int r2 = r20.getPaddingTop()
            int r3 = r3.topMargin
            int r2 = r2 + r3
            int r3 = r0.f361v
            int r8 = r2 + r3
        L_0x01aa:
            if (r1 == 0) goto L_0x021b
            if (r17 == 0) goto L_0x01b1
            int r1 = r0.f359t
            goto L_0x01b2
        L_0x01b1:
            r1 = 0
        L_0x01b2:
            r2 = 1
            r3 = r11[r2]
            int r1 = r1 - r3
            r3 = 0
            int r4 = java.lang.Math.max(r3, r1)
            int r10 = r10 - r4
            int r1 = -r1
            int r1 = java.lang.Math.max(r3, r1)
            r11[r2] = r1
            if (r13 == 0) goto L_0x01e9
            android.widget.TextView r1 = r0.f345f
            android.view.ViewGroup$LayoutParams r1 = r1.getLayoutParams()
            androidx.appcompat.widget.Toolbar$e r1 = (androidx.appcompat.widget.Toolbar.C0056e) r1
            android.widget.TextView r2 = r0.f345f
            int r2 = r2.getMeasuredWidth()
            int r2 = r10 - r2
            android.widget.TextView r3 = r0.f345f
            int r3 = r3.getMeasuredHeight()
            int r3 = r3 + r8
            android.widget.TextView r4 = r0.f345f
            r4.layout(r2, r8, r10, r3)
            int r4 = r0.f360u
            int r2 = r2 - r4
            int r1 = r1.bottomMargin
            int r8 = r3 + r1
            goto L_0x01ea
        L_0x01e9:
            r2 = r10
        L_0x01ea:
            if (r14 == 0) goto L_0x0210
            android.widget.TextView r1 = r0.f346g
            android.view.ViewGroup$LayoutParams r1 = r1.getLayoutParams()
            androidx.appcompat.widget.Toolbar$e r1 = (androidx.appcompat.widget.Toolbar.C0056e) r1
            int r1 = r1.topMargin
            int r8 = r8 + r1
            android.widget.TextView r1 = r0.f346g
            int r1 = r1.getMeasuredWidth()
            int r1 = r10 - r1
            android.widget.TextView r3 = r0.f346g
            int r3 = r3.getMeasuredHeight()
            int r3 = r3 + r8
            android.widget.TextView r4 = r0.f346g
            r4.layout(r1, r8, r10, r3)
            int r1 = r0.f360u
            int r1 = r10 - r1
            goto L_0x0211
        L_0x0210:
            r1 = r10
        L_0x0211:
            if (r17 == 0) goto L_0x0218
            int r1 = java.lang.Math.min(r2, r1)
            r10 = r1
        L_0x0218:
            r2 = r25
            goto L_0x0285
        L_0x021b:
            if (r17 == 0) goto L_0x0220
            int r1 = r0.f359t
            goto L_0x0221
        L_0x0220:
            r1 = 0
        L_0x0221:
            r2 = 0
            r3 = r11[r2]
            int r1 = r1 - r3
            int r3 = java.lang.Math.max(r2, r1)
            int r3 = r3 + r25
            int r1 = -r1
            int r1 = java.lang.Math.max(r2, r1)
            r11[r2] = r1
            if (r13 == 0) goto L_0x0257
            android.widget.TextView r1 = r0.f345f
            android.view.ViewGroup$LayoutParams r1 = r1.getLayoutParams()
            androidx.appcompat.widget.Toolbar$e r1 = (androidx.appcompat.widget.Toolbar.C0056e) r1
            android.widget.TextView r2 = r0.f345f
            int r2 = r2.getMeasuredWidth()
            int r2 = r2 + r3
            android.widget.TextView r4 = r0.f345f
            int r4 = r4.getMeasuredHeight()
            int r4 = r4 + r8
            android.widget.TextView r5 = r0.f345f
            r5.layout(r3, r8, r2, r4)
            int r5 = r0.f360u
            int r2 = r2 + r5
            int r1 = r1.bottomMargin
            int r8 = r4 + r1
            goto L_0x0258
        L_0x0257:
            r2 = r3
        L_0x0258:
            if (r14 == 0) goto L_0x027c
            android.widget.TextView r1 = r0.f346g
            android.view.ViewGroup$LayoutParams r1 = r1.getLayoutParams()
            androidx.appcompat.widget.Toolbar$e r1 = (androidx.appcompat.widget.Toolbar.C0056e) r1
            int r1 = r1.topMargin
            int r8 = r8 + r1
            android.widget.TextView r1 = r0.f346g
            int r1 = r1.getMeasuredWidth()
            int r1 = r1 + r3
            android.widget.TextView r4 = r0.f346g
            int r4 = r4.getMeasuredHeight()
            int r4 = r4 + r8
            android.widget.TextView r5 = r0.f346g
            r5.layout(r3, r8, r1, r4)
            int r4 = r0.f360u
            int r1 = r1 + r4
            goto L_0x027d
        L_0x027c:
            r1 = r3
        L_0x027d:
            if (r17 == 0) goto L_0x0284
            int r2 = java.lang.Math.max(r2, r1)
            goto L_0x0285
        L_0x0284:
            r2 = r3
        L_0x0285:
            java.util.ArrayList<android.view.View> r1 = r0.f334H
            r3 = 3
            r0.mo468a(r1, r3)
            java.util.ArrayList<android.view.View> r1 = r0.f334H
            int r1 = r1.size()
            r3 = r2
            r2 = 0
        L_0x0293:
            if (r2 >= r1) goto L_0x02a6
            java.util.ArrayList<android.view.View> r4 = r0.f334H
            java.lang.Object r4 = r4.get(r2)
            android.view.View r4 = (android.view.View) r4
            r12 = r23
            int r3 = r0.mo525p(r4, r3, r11, r12)
            int r2 = r2 + 1
            goto L_0x0293
        L_0x02a6:
            r12 = r23
            java.util.ArrayList<android.view.View> r1 = r0.f334H
            r2 = 5
            r0.mo468a(r1, r2)
            java.util.ArrayList<android.view.View> r1 = r0.f334H
            int r1 = r1.size()
            r2 = 0
        L_0x02b5:
            if (r2 >= r1) goto L_0x02c6
            java.util.ArrayList<android.view.View> r4 = r0.f334H
            java.lang.Object r4 = r4.get(r2)
            android.view.View r4 = (android.view.View) r4
            int r10 = r0.mo526q(r4, r10, r11, r12)
            int r2 = r2 + 1
            goto L_0x02b5
        L_0x02c6:
            java.util.ArrayList<android.view.View> r1 = r0.f334H
            r2 = 1
            r0.mo468a(r1, r2)
            java.util.ArrayList<android.view.View> r1 = r0.f334H
            r4 = 0
            r5 = r11[r4]
            r2 = r11[r2]
            int r4 = r1.size()
            r7 = r5
            r5 = 0
            r6 = 0
        L_0x02da:
            if (r5 >= r4) goto L_0x030d
            java.lang.Object r8 = r1.get(r5)
            android.view.View r8 = (android.view.View) r8
            android.view.ViewGroup$LayoutParams r9 = r8.getLayoutParams()
            androidx.appcompat.widget.Toolbar$e r9 = (androidx.appcompat.widget.Toolbar.C0056e) r9
            int r13 = r9.leftMargin
            int r13 = r13 - r7
            int r7 = r9.rightMargin
            int r7 = r7 - r2
            r2 = 0
            int r9 = java.lang.Math.max(r2, r13)
            int r14 = java.lang.Math.max(r2, r7)
            int r13 = -r13
            int r13 = java.lang.Math.max(r2, r13)
            int r7 = -r7
            int r7 = java.lang.Math.max(r2, r7)
            int r8 = r8.getMeasuredWidth()
            int r8 = r8 + r9
            int r8 = r8 + r14
            int r6 = r6 + r8
            int r5 = r5 + 1
            r2 = r7
            r7 = r13
            goto L_0x02da
        L_0x030d:
            r2 = 0
            int r4 = r16 - r18
            int r4 = r4 - r24
            int r4 = r4 / 2
            int r4 = r4 + r18
            int r1 = r6 / 2
            int r4 = r4 - r1
            int r6 = r6 + r4
            if (r4 >= r3) goto L_0x031d
            goto L_0x0324
        L_0x031d:
            if (r6 <= r10) goto L_0x0323
            int r6 = r6 - r10
            int r3 = r4 - r6
            goto L_0x0324
        L_0x0323:
            r3 = r4
        L_0x0324:
            java.util.ArrayList<android.view.View> r1 = r0.f334H
            int r1 = r1.size()
            r19 = r3
            r3 = r2
            r2 = r19
        L_0x032f:
            if (r3 >= r1) goto L_0x0340
            java.util.ArrayList<android.view.View> r4 = r0.f334H
            java.lang.Object r4 = r4.get(r3)
            android.view.View r4 = (android.view.View) r4
            int r2 = r0.mo525p(r4, r2, r11, r12)
            int r3 = r3 + 1
            goto L_0x032f
        L_0x0340:
            java.util.ArrayList<android.view.View> r1 = r0.f334H
            r1.clear()
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.Toolbar.onLayout(boolean, int, int, int, int):void");
    }

    public void onMeasure(int i, int i2) {
        char c;
        char c2;
        int i3;
        int i4;
        int i5;
        int i6;
        int i7;
        int i8;
        int i9;
        int[] iArr = this.f336J;
        boolean z = true;
        int i10 = 0;
        if (C5004v0.m15611b(this)) {
            c2 = 1;
            c = 0;
        } else {
            c = 1;
            c2 = 0;
        }
        if (mo560t(this.f347h)) {
            mo528s(this.f347h, i, 0, i2, 0, this.f358s);
            i5 = mo513l(this.f347h) + this.f347h.getMeasuredWidth();
            i4 = Math.max(0, mo514m(this.f347h) + this.f347h.getMeasuredHeight());
            i3 = View.combineMeasuredStates(0, this.f347h.getMeasuredState());
        } else {
            i5 = 0;
            i4 = 0;
            i3 = 0;
        }
        if (mo560t(this.f351l)) {
            mo528s(this.f351l, i, 0, i2, 0, this.f358s);
            i5 = mo513l(this.f351l) + this.f351l.getMeasuredWidth();
            i4 = Math.max(i4, mo514m(this.f351l) + this.f351l.getMeasuredHeight());
            i3 = View.combineMeasuredStates(i3, this.f351l.getMeasuredState());
        }
        int currentContentInsetStart = getCurrentContentInsetStart();
        int max = Math.max(currentContentInsetStart, i5) + 0;
        iArr[c2] = Math.max(0, currentContentInsetStart - i5);
        if (mo560t(this.f344e)) {
            mo528s(this.f344e, i, max, i2, 0, this.f358s);
            i6 = mo513l(this.f344e) + this.f344e.getMeasuredWidth();
            i4 = Math.max(i4, mo514m(this.f344e) + this.f344e.getMeasuredHeight());
            i3 = View.combineMeasuredStates(i3, this.f344e.getMeasuredState());
        } else {
            i6 = 0;
        }
        int currentContentInsetEnd = getCurrentContentInsetEnd();
        int max2 = Math.max(currentContentInsetEnd, i6) + max;
        iArr[c] = Math.max(0, currentContentInsetEnd - i6);
        if (mo560t(this.f352m)) {
            max2 += mo527r(this.f352m, i, max2, i2, 0, iArr);
            i4 = Math.max(i4, mo514m(this.f352m) + this.f352m.getMeasuredHeight());
            i3 = View.combineMeasuredStates(i3, this.f352m.getMeasuredState());
        }
        if (mo560t(this.f348i)) {
            max2 += mo527r(this.f348i, i, max2, i2, 0, iArr);
            i4 = Math.max(i4, mo514m(this.f348i) + this.f348i.getMeasuredHeight());
            i3 = View.combineMeasuredStates(i3, this.f348i.getMeasuredState());
        }
        int childCount = getChildCount();
        for (int i11 = 0; i11 < childCount; i11++) {
            View childAt = getChildAt(i11);
            if (((C0056e) childAt.getLayoutParams()).f372b == 0 && mo560t(childAt)) {
                View view = childAt;
                max2 += mo527r(childAt, i, max2, i2, 0, iArr);
                View view2 = view;
                i4 = Math.max(i4, mo514m(view2) + view.getMeasuredHeight());
                i3 = View.combineMeasuredStates(i3, view2.getMeasuredState());
            }
        }
        int i12 = this.f361v + this.f362w;
        int i13 = this.f359t + this.f360u;
        if (mo560t(this.f345f)) {
            mo527r(this.f345f, i, max2 + i13, i2, i12, iArr);
            int l = mo513l(this.f345f) + this.f345f.getMeasuredWidth();
            i7 = mo514m(this.f345f) + this.f345f.getMeasuredHeight();
            i9 = View.combineMeasuredStates(i3, this.f345f.getMeasuredState());
            i8 = l;
        } else {
            i7 = 0;
            i9 = i3;
            i8 = 0;
        }
        if (mo560t(this.f346g)) {
            i8 = Math.max(i8, mo527r(this.f346g, i, max2 + i13, i2, i7 + i12, iArr));
            i7 = mo514m(this.f346g) + this.f346g.getMeasuredHeight() + i7;
            i9 = View.combineMeasuredStates(i9, this.f346g.getMeasuredState());
        } else {
            int i14 = i9;
        }
        int max3 = Math.max(i4, i7);
        int paddingRight = getPaddingRight() + getPaddingLeft();
        int paddingBottom = getPaddingBottom() + getPaddingTop() + max3;
        int resolveSizeAndState = View.resolveSizeAndState(Math.max(paddingRight + max2 + i8, getSuggestedMinimumWidth()), i, -16777216 & i9);
        int resolveSizeAndState2 = View.resolveSizeAndState(Math.max(paddingBottom, getSuggestedMinimumHeight()), i2, i9 << 16);
        if (this.f342P) {
            int childCount2 = getChildCount();
            int i15 = 0;
            while (true) {
                if (i15 >= childCount2) {
                    break;
                }
                View childAt2 = getChildAt(i15);
                if (mo560t(childAt2) && childAt2.getMeasuredWidth() > 0 && childAt2.getMeasuredHeight() > 0) {
                    break;
                }
                i15++;
            }
        }
        z = false;
        if (!z) {
            i10 = resolveSizeAndState2;
        }
        setMeasuredDimension(resolveSizeAndState, i10);
    }

    public void onRestoreInstanceState(Parcelable parcelable) {
        MenuItem findItem;
        if (!(parcelable instanceof C0058g)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        C0058g gVar = (C0058g) parcelable;
        super.onRestoreInstanceState(gVar.f20049e);
        ActionMenuView actionMenuView = this.f344e;
        C4907g gVar2 = actionMenuView != null ? actionMenuView.f185t : null;
        int i = gVar.f373g;
        if (!(i == 0 || this.f341O == null || gVar2 == null || (findItem = gVar2.findItem(i)) == null)) {
            findItem.expandActionView();
        }
        if (gVar.f374h) {
            removeCallbacks(this.f343Q);
            post(this.f343Q);
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:13:0x0027, code lost:
        if (r1 != Integer.MIN_VALUE) goto L_0x003e;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:18:0x0035, code lost:
        if (r1 != Integer.MIN_VALUE) goto L_0x003e;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void onRtlPropertiesChanged(int r3) {
        /*
            r2 = this;
            super.onRtlPropertiesChanged(r3)
            r2.mo472d()
            d.b.p.j0 r0 = r2.f363x
            r1 = 1
            if (r3 != r1) goto L_0x000c
            goto L_0x000d
        L_0x000c:
            r1 = 0
        L_0x000d:
            boolean r3 = r0.f18165g
            if (r1 != r3) goto L_0x0012
            goto L_0x0040
        L_0x0012:
            r0.f18165g = r1
            boolean r3 = r0.f18166h
            if (r3 == 0) goto L_0x0038
            r3 = -2147483648(0xffffffff80000000, float:-0.0)
            if (r1 == 0) goto L_0x002a
            int r1 = r0.f18162d
            if (r1 == r3) goto L_0x0021
            goto L_0x0023
        L_0x0021:
            int r1 = r0.f18163e
        L_0x0023:
            r0.f18159a = r1
            int r1 = r0.f18161c
            if (r1 == r3) goto L_0x003c
            goto L_0x003e
        L_0x002a:
            int r1 = r0.f18161c
            if (r1 == r3) goto L_0x002f
            goto L_0x0031
        L_0x002f:
            int r1 = r0.f18163e
        L_0x0031:
            r0.f18159a = r1
            int r1 = r0.f18162d
            if (r1 == r3) goto L_0x003c
            goto L_0x003e
        L_0x0038:
            int r3 = r0.f18163e
            r0.f18159a = r3
        L_0x003c:
            int r1 = r0.f18164f
        L_0x003e:
            r0.f18160b = r1
        L_0x0040:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.Toolbar.onRtlPropertiesChanged(int):void");
    }

    public Parcelable onSaveInstanceState() {
        C4911i iVar;
        C0058g gVar = new C0058g(super.onSaveInstanceState());
        C0055d dVar = this.f341O;
        if (!(dVar == null || (iVar = dVar.f370f) == null)) {
            gVar.f373g = iVar.f17932a;
        }
        gVar.f374h = mo516o();
        return gVar;
    }

    public boolean onTouchEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 0) {
            this.f332F = false;
        }
        if (!this.f332F) {
            boolean onTouchEvent = super.onTouchEvent(motionEvent);
            if (actionMasked == 0 && !onTouchEvent) {
                this.f332F = true;
            }
        }
        if (actionMasked == 1 || actionMasked == 3) {
            this.f332F = false;
        }
        return true;
    }

    /* renamed from: p */
    public final int mo525p(View view, int i, int[] iArr, int i2) {
        C0056e eVar = (C0056e) view.getLayoutParams();
        int i3 = eVar.leftMargin - iArr[0];
        int max = Math.max(0, i3) + i;
        iArr[0] = Math.max(0, -i3);
        int k = mo512k(view, i2);
        int measuredWidth = view.getMeasuredWidth();
        view.layout(max, k, max + measuredWidth, view.getMeasuredHeight() + k);
        return measuredWidth + eVar.rightMargin + max;
    }

    /* renamed from: q */
    public final int mo526q(View view, int i, int[] iArr, int i2) {
        C0056e eVar = (C0056e) view.getLayoutParams();
        int i3 = eVar.rightMargin - iArr[1];
        int max = i - Math.max(0, i3);
        iArr[1] = Math.max(0, -i3);
        int k = mo512k(view, i2);
        int measuredWidth = view.getMeasuredWidth();
        view.layout(max - measuredWidth, k, max, view.getMeasuredHeight() + k);
        return max - (measuredWidth + eVar.leftMargin);
    }

    /* renamed from: r */
    public final int mo527r(View view, int i, int i2, int i3, int i4, int[] iArr) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        int i5 = marginLayoutParams.leftMargin - iArr[0];
        int i6 = marginLayoutParams.rightMargin - iArr[1];
        int max = Math.max(0, i6) + Math.max(0, i5);
        iArr[0] = Math.max(0, -i5);
        iArr[1] = Math.max(0, -i6);
        view.measure(ViewGroup.getChildMeasureSpec(i, getPaddingRight() + getPaddingLeft() + max + i2, marginLayoutParams.width), ViewGroup.getChildMeasureSpec(i3, getPaddingBottom() + getPaddingTop() + marginLayoutParams.topMargin + marginLayoutParams.bottomMargin + i4, marginLayoutParams.height));
        return view.getMeasuredWidth() + max;
    }

    /* renamed from: s */
    public final void mo528s(View view, int i, int i2, int i3, int i4, int i5) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        int childMeasureSpec = ViewGroup.getChildMeasureSpec(i, getPaddingRight() + getPaddingLeft() + marginLayoutParams.leftMargin + marginLayoutParams.rightMargin + i2, marginLayoutParams.width);
        int childMeasureSpec2 = ViewGroup.getChildMeasureSpec(i3, getPaddingBottom() + getPaddingTop() + marginLayoutParams.topMargin + marginLayoutParams.bottomMargin + i4, marginLayoutParams.height);
        int mode = View.MeasureSpec.getMode(childMeasureSpec2);
        if (mode != 1073741824 && i5 >= 0) {
            if (mode != 0) {
                i5 = Math.min(View.MeasureSpec.getSize(childMeasureSpec2), i5);
            }
            childMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(i5, 1073741824);
        }
        view.measure(childMeasureSpec, childMeasureSpec2);
    }

    public void setCollapseContentDescription(int i) {
        setCollapseContentDescription(i != 0 ? getContext().getText(i) : null);
    }

    public void setCollapseContentDescription(CharSequence charSequence) {
        if (!TextUtils.isEmpty(charSequence)) {
            mo470c();
        }
        ImageButton imageButton = this.f351l;
        if (imageButton != null) {
            imageButton.setContentDescription(charSequence);
        }
    }

    public void setCollapseIcon(int i) {
        setCollapseIcon(C4879a.m15208b(getContext(), i));
    }

    public void setCollapseIcon(Drawable drawable) {
        if (drawable != null) {
            mo470c();
            this.f351l.setImageDrawable(drawable);
            return;
        }
        ImageButton imageButton = this.f351l;
        if (imageButton != null) {
            imageButton.setImageDrawable(this.f349j);
        }
    }

    public void setCollapsible(boolean z) {
        this.f342P = z;
        requestLayout();
    }

    public void setContentInsetEndWithActions(int i) {
        if (i < 0) {
            i = Integer.MIN_VALUE;
        }
        if (i != this.f365z) {
            this.f365z = i;
            if (getNavigationIcon() != null) {
                requestLayout();
            }
        }
    }

    public void setContentInsetStartWithNavigation(int i) {
        if (i < 0) {
            i = Integer.MIN_VALUE;
        }
        if (i != this.f364y) {
            this.f364y = i;
            if (getNavigationIcon() != null) {
                requestLayout();
            }
        }
    }

    public void setLogo(int i) {
        setLogo(C4879a.m15208b(getContext(), i));
    }

    public void setLogo(Drawable drawable) {
        if (drawable != null) {
            if (this.f348i == null) {
                this.f348i = new AppCompatImageView(getContext(), (AttributeSet) null);
            }
            if (!mo515n(this.f348i)) {
                mo469b(this.f348i, true);
            }
        } else {
            ImageView imageView = this.f348i;
            if (imageView != null && mo515n(imageView)) {
                removeView(this.f348i);
                this.f335I.remove(this.f348i);
            }
        }
        ImageView imageView2 = this.f348i;
        if (imageView2 != null) {
            imageView2.setImageDrawable(drawable);
        }
    }

    public void setLogoDescription(int i) {
        setLogoDescription(getContext().getText(i));
    }

    public void setLogoDescription(CharSequence charSequence) {
        if (!TextUtils.isEmpty(charSequence) && this.f348i == null) {
            this.f348i = new AppCompatImageView(getContext(), (AttributeSet) null);
        }
        ImageView imageView = this.f348i;
        if (imageView != null) {
            imageView.setContentDescription(charSequence);
        }
    }

    public void setNavigationContentDescription(int i) {
        setNavigationContentDescription(i != 0 ? getContext().getText(i) : null);
    }

    public void setNavigationContentDescription(CharSequence charSequence) {
        if (!TextUtils.isEmpty(charSequence)) {
            mo475g();
        }
        ImageButton imageButton = this.f347h;
        if (imageButton != null) {
            imageButton.setContentDescription(charSequence);
        }
    }

    public void setNavigationIcon(int i) {
        setNavigationIcon(C4879a.m15208b(getContext(), i));
    }

    public void setNavigationIcon(Drawable drawable) {
        if (drawable != null) {
            mo475g();
            if (!mo515n(this.f347h)) {
                mo469b(this.f347h, true);
            }
        } else {
            ImageButton imageButton = this.f347h;
            if (imageButton != null && mo515n(imageButton)) {
                removeView(this.f347h);
                this.f335I.remove(this.f347h);
            }
        }
        ImageButton imageButton2 = this.f347h;
        if (imageButton2 != null) {
            imageButton2.setImageDrawable(drawable);
        }
    }

    public void setNavigationOnClickListener(View.OnClickListener onClickListener) {
        mo475g();
        this.f347h.setOnClickListener(onClickListener);
    }

    public void setOnMenuItemClickListener(C0057f fVar) {
        this.f337K = fVar;
    }

    public void setOverflowIcon(Drawable drawable) {
        mo473e();
        this.f344e.setOverflowIcon(drawable);
    }

    public void setPopupTheme(int i) {
        if (this.f354o != i) {
            this.f354o = i;
            if (i == 0) {
                this.f353n = getContext();
            } else {
                this.f353n = new ContextThemeWrapper(getContext(), i);
            }
        }
    }

    public void setSubtitle(int i) {
        setSubtitle(getContext().getText(i));
    }

    public void setSubtitle(CharSequence charSequence) {
        if (!TextUtils.isEmpty(charSequence)) {
            if (this.f346g == null) {
                Context context = getContext();
                AppCompatTextView appCompatTextView = new AppCompatTextView(context, (AttributeSet) null);
                this.f346g = appCompatTextView;
                appCompatTextView.setSingleLine();
                this.f346g.setEllipsize(TextUtils.TruncateAt.END);
                int i = this.f356q;
                if (i != 0) {
                    this.f346g.setTextAppearance(context, i);
                }
                ColorStateList colorStateList = this.f331E;
                if (colorStateList != null) {
                    this.f346g.setTextColor(colorStateList);
                }
            }
            if (!mo515n(this.f346g)) {
                mo469b(this.f346g, true);
            }
        } else {
            TextView textView = this.f346g;
            if (textView != null && mo515n(textView)) {
                removeView(this.f346g);
                this.f335I.remove(this.f346g);
            }
        }
        TextView textView2 = this.f346g;
        if (textView2 != null) {
            textView2.setText(charSequence);
        }
        this.f329C = charSequence;
    }

    public void setSubtitleTextColor(int i) {
        setSubtitleTextColor(ColorStateList.valueOf(i));
    }

    public void setSubtitleTextColor(ColorStateList colorStateList) {
        this.f331E = colorStateList;
        TextView textView = this.f346g;
        if (textView != null) {
            textView.setTextColor(colorStateList);
        }
    }

    public void setTitle(int i) {
        setTitle(getContext().getText(i));
    }

    public void setTitle(CharSequence charSequence) {
        if (!TextUtils.isEmpty(charSequence)) {
            if (this.f345f == null) {
                Context context = getContext();
                AppCompatTextView appCompatTextView = new AppCompatTextView(context, (AttributeSet) null);
                this.f345f = appCompatTextView;
                appCompatTextView.setSingleLine();
                this.f345f.setEllipsize(TextUtils.TruncateAt.END);
                int i = this.f355p;
                if (i != 0) {
                    this.f345f.setTextAppearance(context, i);
                }
                ColorStateList colorStateList = this.f330D;
                if (colorStateList != null) {
                    this.f345f.setTextColor(colorStateList);
                }
            }
            if (!mo515n(this.f345f)) {
                mo469b(this.f345f, true);
            }
        } else {
            TextView textView = this.f345f;
            if (textView != null && mo515n(textView)) {
                removeView(this.f345f);
                this.f335I.remove(this.f345f);
            }
        }
        TextView textView2 = this.f345f;
        if (textView2 != null) {
            textView2.setText(charSequence);
        }
        this.f328B = charSequence;
    }

    public void setTitleMarginBottom(int i) {
        this.f362w = i;
        requestLayout();
    }

    public void setTitleMarginEnd(int i) {
        this.f360u = i;
        requestLayout();
    }

    public void setTitleMarginStart(int i) {
        this.f359t = i;
        requestLayout();
    }

    public void setTitleMarginTop(int i) {
        this.f361v = i;
        requestLayout();
    }

    public void setTitleTextColor(int i) {
        setTitleTextColor(ColorStateList.valueOf(i));
    }

    public void setTitleTextColor(ColorStateList colorStateList) {
        this.f330D = colorStateList;
        TextView textView = this.f345f;
        if (textView != null) {
            textView.setTextColor(colorStateList);
        }
    }

    /* renamed from: t */
    public final boolean mo560t(View view) {
        return (view == null || view.getParent() != this || view.getVisibility() == 8) ? false : true;
    }

    /* renamed from: u */
    public boolean mo561u() {
        ActionMenuView actionMenuView = this.f344e;
        if (actionMenuView != null) {
            C4940c cVar = actionMenuView.f189x;
            if (cVar != null && cVar.mo10406n()) {
                return true;
            }
        }
        return false;
    }
}
