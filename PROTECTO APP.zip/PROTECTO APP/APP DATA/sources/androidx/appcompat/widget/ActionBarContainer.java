package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.ActionMode;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import p176d.p178b.C4821f;
import p176d.p178b.C4825j;
import p176d.p178b.p187p.C4936b;
import p176d.p178b.p187p.C4975k0;
import p176d.p219i.p231k.C5662k;

public class ActionBarContainer extends FrameLayout {

    /* renamed from: e */
    public boolean f122e;

    /* renamed from: f */
    public View f123f;

    /* renamed from: g */
    public View f124g;

    /* renamed from: h */
    public View f125h;

    /* renamed from: i */
    public Drawable f126i;

    /* renamed from: j */
    public Drawable f127j;

    /* renamed from: k */
    public Drawable f128k;

    /* renamed from: l */
    public boolean f129l;

    /* renamed from: m */
    public boolean f130m;

    /* renamed from: n */
    public int f131n;

    public ActionBarContainer(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        C5662k.m16845v(this, new C4936b(this));
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, C4825j.ActionBar);
        this.f126i = obtainStyledAttributes.getDrawable(C4825j.ActionBar_background);
        this.f127j = obtainStyledAttributes.getDrawable(C4825j.ActionBar_backgroundStacked);
        this.f131n = obtainStyledAttributes.getDimensionPixelSize(C4825j.ActionBar_height, -1);
        boolean z = true;
        if (getId() == C4821f.split_action_bar) {
            this.f129l = true;
            this.f128k = obtainStyledAttributes.getDrawable(C4825j.ActionBar_backgroundSplit);
        }
        obtainStyledAttributes.recycle();
        if (!this.f129l ? !(this.f126i == null && this.f127j == null) : this.f128k != null) {
            z = false;
        }
        setWillNotDraw(z);
    }

    /* renamed from: a */
    public final int mo61a(View view) {
        FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) view.getLayoutParams();
        return view.getMeasuredHeight() + layoutParams.topMargin + layoutParams.bottomMargin;
    }

    /* renamed from: b */
    public final boolean mo62b(View view) {
        return view == null || view.getVisibility() == 8 || view.getMeasuredHeight() == 0;
    }

    public void drawableStateChanged() {
        super.drawableStateChanged();
        Drawable drawable = this.f126i;
        if (drawable != null && drawable.isStateful()) {
            this.f126i.setState(getDrawableState());
        }
        Drawable drawable2 = this.f127j;
        if (drawable2 != null && drawable2.isStateful()) {
            this.f127j.setState(getDrawableState());
        }
        Drawable drawable3 = this.f128k;
        if (drawable3 != null && drawable3.isStateful()) {
            this.f128k.setState(getDrawableState());
        }
    }

    public View getTabContainer() {
        return this.f123f;
    }

    public void jumpDrawablesToCurrentState() {
        super.jumpDrawablesToCurrentState();
        Drawable drawable = this.f126i;
        if (drawable != null) {
            drawable.jumpToCurrentState();
        }
        Drawable drawable2 = this.f127j;
        if (drawable2 != null) {
            drawable2.jumpToCurrentState();
        }
        Drawable drawable3 = this.f128k;
        if (drawable3 != null) {
            drawable3.jumpToCurrentState();
        }
    }

    public void onFinishInflate() {
        super.onFinishInflate();
        this.f124g = findViewById(C4821f.action_bar);
        this.f125h = findViewById(C4821f.action_context_bar);
    }

    public boolean onHoverEvent(MotionEvent motionEvent) {
        super.onHoverEvent(motionEvent);
        return true;
    }

    public boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        return this.f122e || super.onInterceptTouchEvent(motionEvent);
    }

    /* JADX WARNING: Removed duplicated region for block: B:35:0x00b8  */
    /* JADX WARNING: Removed duplicated region for block: B:37:? A[RETURN, SYNTHETIC] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void onLayout(boolean r5, int r6, int r7, int r8, int r9) {
        /*
            r4 = this;
            super.onLayout(r5, r6, r7, r8, r9)
            android.view.View r5 = r4.f123f
            r7 = 8
            r9 = 1
            r0 = 0
            if (r5 == 0) goto L_0x0013
            int r1 = r5.getVisibility()
            if (r1 == r7) goto L_0x0013
            r1 = r9
            goto L_0x0014
        L_0x0013:
            r1 = r0
        L_0x0014:
            if (r5 == 0) goto L_0x0033
            int r2 = r5.getVisibility()
            if (r2 == r7) goto L_0x0033
            int r7 = r4.getMeasuredHeight()
            android.view.ViewGroup$LayoutParams r2 = r5.getLayoutParams()
            android.widget.FrameLayout$LayoutParams r2 = (android.widget.FrameLayout.LayoutParams) r2
            int r3 = r5.getMeasuredHeight()
            int r3 = r7 - r3
            int r2 = r2.bottomMargin
            int r3 = r3 - r2
            int r7 = r7 - r2
            r5.layout(r6, r3, r8, r7)
        L_0x0033:
            boolean r6 = r4.f129l
            if (r6 == 0) goto L_0x004a
            android.graphics.drawable.Drawable r5 = r4.f128k
            if (r5 == 0) goto L_0x0048
            int r6 = r4.getMeasuredWidth()
            int r7 = r4.getMeasuredHeight()
            r5.setBounds(r0, r0, r6, r7)
            goto L_0x00b6
        L_0x0048:
            r9 = r0
            goto L_0x00b6
        L_0x004a:
            android.graphics.drawable.Drawable r6 = r4.f126i
            if (r6 == 0) goto L_0x009b
            android.view.View r6 = r4.f124g
            int r6 = r6.getVisibility()
            if (r6 != 0) goto L_0x0074
            android.graphics.drawable.Drawable r6 = r4.f126i
            android.view.View r7 = r4.f124g
            int r7 = r7.getLeft()
            android.view.View r8 = r4.f124g
            int r8 = r8.getTop()
            android.view.View r0 = r4.f124g
            int r0 = r0.getRight()
            android.view.View r2 = r4.f124g
        L_0x006c:
            int r2 = r2.getBottom()
            r6.setBounds(r7, r8, r0, r2)
            goto L_0x009a
        L_0x0074:
            android.view.View r6 = r4.f125h
            if (r6 == 0) goto L_0x0095
            int r6 = r6.getVisibility()
            if (r6 != 0) goto L_0x0095
            android.graphics.drawable.Drawable r6 = r4.f126i
            android.view.View r7 = r4.f125h
            int r7 = r7.getLeft()
            android.view.View r8 = r4.f125h
            int r8 = r8.getTop()
            android.view.View r0 = r4.f125h
            int r0 = r0.getRight()
            android.view.View r2 = r4.f125h
            goto L_0x006c
        L_0x0095:
            android.graphics.drawable.Drawable r6 = r4.f126i
            r6.setBounds(r0, r0, r0, r0)
        L_0x009a:
            r0 = r9
        L_0x009b:
            r4.f130m = r1
            if (r1 == 0) goto L_0x0048
            android.graphics.drawable.Drawable r6 = r4.f127j
            if (r6 == 0) goto L_0x0048
            int r7 = r5.getLeft()
            int r8 = r5.getTop()
            int r0 = r5.getRight()
            int r5 = r5.getBottom()
            r6.setBounds(r7, r8, r0, r5)
        L_0x00b6:
            if (r9 == 0) goto L_0x00bb
            r4.invalidate()
        L_0x00bb:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.ActionBarContainer.onLayout(boolean, int, int, int, int):void");
    }

    /* JADX WARNING: Removed duplicated region for block: B:25:0x0055  */
    /* JADX WARNING: Removed duplicated region for block: B:26:0x005a  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void onMeasure(int r4, int r5) {
        /*
            r3 = this;
            android.view.View r0 = r3.f124g
            r1 = -2147483648(0xffffffff80000000, float:-0.0)
            if (r0 != 0) goto L_0x001c
            int r0 = android.view.View.MeasureSpec.getMode(r5)
            if (r0 != r1) goto L_0x001c
            int r0 = r3.f131n
            if (r0 < 0) goto L_0x001c
            int r5 = android.view.View.MeasureSpec.getSize(r5)
            int r5 = java.lang.Math.min(r0, r5)
            int r5 = android.view.View.MeasureSpec.makeMeasureSpec(r5, r1)
        L_0x001c:
            super.onMeasure(r4, r5)
            android.view.View r4 = r3.f124g
            if (r4 != 0) goto L_0x0024
            return
        L_0x0024:
            int r4 = android.view.View.MeasureSpec.getMode(r5)
            android.view.View r0 = r3.f123f
            if (r0 == 0) goto L_0x006f
            int r0 = r0.getVisibility()
            r2 = 8
            if (r0 == r2) goto L_0x006f
            r0 = 1073741824(0x40000000, float:2.0)
            if (r4 == r0) goto L_0x006f
            android.view.View r0 = r3.f124g
            boolean r0 = r3.mo62b(r0)
            if (r0 != 0) goto L_0x0047
            android.view.View r0 = r3.f124g
        L_0x0042:
            int r0 = r3.mo61a(r0)
            goto L_0x0053
        L_0x0047:
            android.view.View r0 = r3.f125h
            boolean r0 = r3.mo62b(r0)
            if (r0 != 0) goto L_0x0052
            android.view.View r0 = r3.f125h
            goto L_0x0042
        L_0x0052:
            r0 = 0
        L_0x0053:
            if (r4 != r1) goto L_0x005a
            int r4 = android.view.View.MeasureSpec.getSize(r5)
            goto L_0x005d
        L_0x005a:
            r4 = 2147483647(0x7fffffff, float:NaN)
        L_0x005d:
            int r5 = r3.getMeasuredWidth()
            android.view.View r1 = r3.f123f
            int r1 = r3.mo61a(r1)
            int r1 = r1 + r0
            int r4 = java.lang.Math.min(r1, r4)
            r3.setMeasuredDimension(r5, r4)
        L_0x006f:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.ActionBarContainer.onMeasure(int, int):void");
    }

    public boolean onTouchEvent(MotionEvent motionEvent) {
        super.onTouchEvent(motionEvent);
        return true;
    }

    public void setPrimaryBackground(Drawable drawable) {
        Drawable drawable2 = this.f126i;
        if (drawable2 != null) {
            drawable2.setCallback((Drawable.Callback) null);
            unscheduleDrawable(this.f126i);
        }
        this.f126i = drawable;
        if (drawable != null) {
            drawable.setCallback(this);
            View view = this.f124g;
            if (view != null) {
                this.f126i.setBounds(view.getLeft(), this.f124g.getTop(), this.f124g.getRight(), this.f124g.getBottom());
            }
        }
        boolean z = true;
        if (!this.f129l ? !(this.f126i == null && this.f127j == null) : this.f128k != null) {
            z = false;
        }
        setWillNotDraw(z);
        invalidate();
        invalidateOutline();
    }

    public void setSplitBackground(Drawable drawable) {
        Drawable drawable2;
        Drawable drawable3 = this.f128k;
        if (drawable3 != null) {
            drawable3.setCallback((Drawable.Callback) null);
            unscheduleDrawable(this.f128k);
        }
        this.f128k = drawable;
        boolean z = false;
        if (drawable != null) {
            drawable.setCallback(this);
            if (this.f129l && (drawable2 = this.f128k) != null) {
                drawable2.setBounds(0, 0, getMeasuredWidth(), getMeasuredHeight());
            }
        }
        if (!this.f129l ? this.f126i == null && this.f127j == null : this.f128k == null) {
            z = true;
        }
        setWillNotDraw(z);
        invalidate();
        invalidateOutline();
    }

    public void setStackedBackground(Drawable drawable) {
        Drawable drawable2;
        Drawable drawable3 = this.f127j;
        if (drawable3 != null) {
            drawable3.setCallback((Drawable.Callback) null);
            unscheduleDrawable(this.f127j);
        }
        this.f127j = drawable;
        if (drawable != null) {
            drawable.setCallback(this);
            if (this.f130m && (drawable2 = this.f127j) != null) {
                drawable2.setBounds(this.f123f.getLeft(), this.f123f.getTop(), this.f123f.getRight(), this.f123f.getBottom());
            }
        }
        boolean z = true;
        if (!this.f129l ? !(this.f126i == null && this.f127j == null) : this.f128k != null) {
            z = false;
        }
        setWillNotDraw(z);
        invalidate();
        invalidateOutline();
    }

    public void setTabContainer(C4975k0 k0Var) {
        View view = this.f123f;
        if (view != null) {
            removeView(view);
        }
        this.f123f = k0Var;
        if (k0Var != null) {
            addView(k0Var);
            ViewGroup.LayoutParams layoutParams = k0Var.getLayoutParams();
            layoutParams.width = -1;
            layoutParams.height = -2;
            k0Var.setAllowCollapse(false);
        }
    }

    public void setTransitioning(boolean z) {
        this.f122e = z;
        setDescendantFocusability(z ? 393216 : 262144);
    }

    public void setVisibility(int i) {
        super.setVisibility(i);
        boolean z = i == 0;
        Drawable drawable = this.f126i;
        if (drawable != null) {
            drawable.setVisible(z, false);
        }
        Drawable drawable2 = this.f127j;
        if (drawable2 != null) {
            drawable2.setVisible(z, false);
        }
        Drawable drawable3 = this.f128k;
        if (drawable3 != null) {
            drawable3.setVisible(z, false);
        }
    }

    public ActionMode startActionModeForChild(View view, ActionMode.Callback callback) {
        return null;
    }

    public ActionMode startActionModeForChild(View view, ActionMode.Callback callback, int i) {
        if (i != 0) {
            return super.startActionModeForChild(view, callback, i);
        }
        return null;
    }

    public boolean verifyDrawable(Drawable drawable) {
        return (drawable == this.f126i && !this.f129l) || (drawable == this.f127j && this.f130m) || ((drawable == this.f128k && this.f129l) || super.verifyDrawable(drawable));
    }
}
