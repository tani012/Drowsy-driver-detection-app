package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.RippleDrawable;
import android.net.Uri;
import android.util.AttributeSet;
import android.widget.ImageButton;
import p176d.p178b.C4816a;
import p176d.p178b.p187p.C4952e;
import p176d.p178b.p187p.C4974k;
import p176d.p178b.p187p.C4981m0;
import p176d.p178b.p187p.C4985o0;
import p176d.p178b.p187p.C4987p0;

public class AppCompatImageButton extends ImageButton {

    /* renamed from: e */
    public final C4952e f202e;

    /* renamed from: f */
    public final C4974k f203f;

    public AppCompatImageButton(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, C4816a.imageButtonStyle);
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public AppCompatImageButton(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        C4985o0.m15532a(context);
        C4981m0.m15526a(this, getContext());
        C4952e eVar = new C4952e(this);
        this.f202e = eVar;
        eVar.mo10458d(attributeSet, i);
        C4974k kVar = new C4974k(this);
        this.f203f = kVar;
        kVar.mo10536b(attributeSet, i);
    }

    public void drawableStateChanged() {
        super.drawableStateChanged();
        C4952e eVar = this.f202e;
        if (eVar != null) {
            eVar.mo10455a();
        }
        C4974k kVar = this.f203f;
        if (kVar != null) {
            kVar.mo10535a();
        }
    }

    public ColorStateList getSupportBackgroundTintList() {
        C4952e eVar = this.f202e;
        if (eVar != null) {
            return eVar.mo10456b();
        }
        return null;
    }

    public PorterDuff.Mode getSupportBackgroundTintMode() {
        C4952e eVar = this.f202e;
        if (eVar != null) {
            return eVar.mo10457c();
        }
        return null;
    }

    public ColorStateList getSupportImageTintList() {
        C4987p0 p0Var;
        C4974k kVar = this.f203f;
        if (kVar == null || (p0Var = kVar.f18168b) == null) {
            return null;
        }
        return p0Var.f18214a;
    }

    public PorterDuff.Mode getSupportImageTintMode() {
        C4987p0 p0Var;
        C4974k kVar = this.f203f;
        if (kVar == null || (p0Var = kVar.f18168b) == null) {
            return null;
        }
        return p0Var.f18215b;
    }

    public boolean hasOverlappingRendering() {
        if (!(!(this.f203f.f18167a.getBackground() instanceof RippleDrawable)) || !super.hasOverlappingRendering()) {
            return false;
        }
        return true;
    }

    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        C4952e eVar = this.f202e;
        if (eVar != null) {
            eVar.mo10459e();
        }
    }

    public void setBackgroundResource(int i) {
        super.setBackgroundResource(i);
        C4952e eVar = this.f202e;
        if (eVar != null) {
            eVar.mo10460f(i);
        }
    }

    public void setImageBitmap(Bitmap bitmap) {
        super.setImageBitmap(bitmap);
        C4974k kVar = this.f203f;
        if (kVar != null) {
            kVar.mo10535a();
        }
    }

    public void setImageDrawable(Drawable drawable) {
        super.setImageDrawable(drawable);
        C4974k kVar = this.f203f;
        if (kVar != null) {
            kVar.mo10535a();
        }
    }

    public void setImageResource(int i) {
        this.f203f.mo10537c(i);
    }

    public void setImageURI(Uri uri) {
        super.setImageURI(uri);
        C4974k kVar = this.f203f;
        if (kVar != null) {
            kVar.mo10535a();
        }
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        C4952e eVar = this.f202e;
        if (eVar != null) {
            eVar.mo10462h(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        C4952e eVar = this.f202e;
        if (eVar != null) {
            eVar.mo10463i(mode);
        }
    }

    public void setSupportImageTintList(ColorStateList colorStateList) {
        C4974k kVar = this.f203f;
        if (kVar != null) {
            kVar.mo10538d(colorStateList);
        }
    }

    public void setSupportImageTintMode(PorterDuff.Mode mode) {
        C4974k kVar = this.f203f;
        if (kVar != null) {
            kVar.mo10539e(mode);
        }
    }
}
