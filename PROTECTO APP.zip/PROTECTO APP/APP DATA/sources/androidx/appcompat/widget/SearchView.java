package androidx.appcompat.widget;

import android.annotation.SuppressLint;
import android.app.PendingIntent;
import android.app.SearchableInfo;
import android.content.ActivityNotFoundException;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.database.Cursor;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.Editable;
import android.text.SpannableStringBuilder;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.text.style.ImageSpan;
import android.util.AttributeSet;
import android.util.Log;
import android.util.TypedValue;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.TouchDelegate;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.AutoCompleteTextView;
import android.widget.ImageView;
import android.widget.TextView;
import java.lang.reflect.Method;
import java.util.WeakHashMap;
import p002b.p008b.p009a.p010a.C0131a;
import p176d.p178b.C4816a;
import p176d.p178b.C4819d;
import p176d.p178b.C4821f;
import p176d.p178b.C4822g;
import p176d.p178b.C4823h;
import p176d.p178b.C4825j;
import p176d.p178b.p185o.C4884b;
import p176d.p178b.p187p.C4948c0;
import p176d.p178b.p187p.C4950d;
import p176d.p178b.p187p.C4978l0;
import p176d.p178b.p187p.C4991r0;
import p176d.p178b.p187p.C5004v0;
import p176d.p219i.p231k.C5662k;
import p176d.p234j.p235a.C5697a;
import p176d.p236k.p237a.C5703a;

public class SearchView extends C4948c0 implements C4884b {

    /* renamed from: u0 */
    public static final C0048n f251u0 = (Build.VERSION.SDK_INT < 29 ? new C0048n() : null);

    /* renamed from: A */
    public final ImageView f252A;

    /* renamed from: B */
    public final View f253B;

    /* renamed from: C */
    public C0051p f254C;

    /* renamed from: D */
    public Rect f255D;

    /* renamed from: E */
    public Rect f256E;

    /* renamed from: F */
    public int[] f257F;

    /* renamed from: G */
    public int[] f258G;

    /* renamed from: H */
    public final ImageView f259H;

    /* renamed from: I */
    public final Drawable f260I;

    /* renamed from: J */
    public final int f261J;

    /* renamed from: K */
    public final int f262K;

    /* renamed from: L */
    public final Intent f263L;

    /* renamed from: M */
    public final Intent f264M;

    /* renamed from: N */
    public final CharSequence f265N;

    /* renamed from: O */
    public C0046l f266O;

    /* renamed from: P */
    public C0045k f267P;

    /* renamed from: Q */
    public View.OnFocusChangeListener f268Q;

    /* renamed from: R */
    public C0047m f269R;

    /* renamed from: S */
    public View.OnClickListener f270S;

    /* renamed from: T */
    public boolean f271T;

    /* renamed from: U */
    public boolean f272U;

    /* renamed from: V */
    public C5697a f273V;

    /* renamed from: W */
    public boolean f274W;

    /* renamed from: a0 */
    public CharSequence f275a0;

    /* renamed from: b0 */
    public boolean f276b0;

    /* renamed from: c0 */
    public boolean f277c0;

    /* renamed from: d0 */
    public int f278d0;

    /* renamed from: e0 */
    public boolean f279e0;

    /* renamed from: f0 */
    public CharSequence f280f0;

    /* renamed from: g0 */
    public CharSequence f281g0;

    /* renamed from: h0 */
    public boolean f282h0;

    /* renamed from: i0 */
    public int f283i0;

    /* renamed from: j0 */
    public SearchableInfo f284j0;

    /* renamed from: k0 */
    public Bundle f285k0;

    /* renamed from: l0 */
    public final Runnable f286l0;

    /* renamed from: m0 */
    public Runnable f287m0;

    /* renamed from: n0 */
    public final WeakHashMap<String, Drawable.ConstantState> f288n0;

    /* renamed from: o0 */
    public final View.OnClickListener f289o0;

    /* renamed from: p0 */
    public View.OnKeyListener f290p0;

    /* renamed from: q0 */
    public final TextView.OnEditorActionListener f291q0;

    /* renamed from: r0 */
    public final AdapterView.OnItemClickListener f292r0;

    /* renamed from: s0 */
    public final AdapterView.OnItemSelectedListener f293s0;

    /* renamed from: t */
    public final SearchAutoComplete f294t;

    /* renamed from: t0 */
    public TextWatcher f295t0;

    /* renamed from: u */
    public final View f296u;

    /* renamed from: v */
    public final View f297v;

    /* renamed from: w */
    public final View f298w;

    /* renamed from: x */
    public final ImageView f299x;

    /* renamed from: y */
    public final ImageView f300y;

    /* renamed from: z */
    public final ImageView f301z;

    public static class SearchAutoComplete extends C4950d {

        /* renamed from: h */
        public int f302h = getThreshold();

        /* renamed from: i */
        public SearchView f303i;

        /* renamed from: j */
        public boolean f304j;

        /* renamed from: k */
        public final Runnable f305k = new C0034a();

        /* renamed from: androidx.appcompat.widget.SearchView$SearchAutoComplete$a */
        public class C0034a implements Runnable {
            public C0034a() {
            }

            public void run() {
                SearchAutoComplete searchAutoComplete = SearchAutoComplete.this;
                if (searchAutoComplete.f304j) {
                    ((InputMethodManager) searchAutoComplete.getContext().getSystemService("input_method")).showSoftInput(searchAutoComplete, 0);
                    searchAutoComplete.f304j = false;
                }
            }
        }

        public SearchAutoComplete(Context context, AttributeSet attributeSet) {
            super(context, attributeSet, C4816a.autoCompleteTextViewStyle);
        }

        private int getSearchViewTextMinWidthDp() {
            Configuration configuration = getResources().getConfiguration();
            int i = configuration.screenWidthDp;
            int i2 = configuration.screenHeightDp;
            if (i >= 960 && i2 >= 720 && configuration.orientation == 2) {
                return 256;
            }
            if (i < 600) {
                return (i < 640 || i2 < 480) ? 160 : 192;
            }
            return 192;
        }

        /* renamed from: a */
        public void mo430a() {
            if (Build.VERSION.SDK_INT >= 29) {
                setInputMethodMode(1);
                if (enoughToFilter()) {
                    showDropDown();
                    return;
                }
                return;
            }
            C0048n nVar = SearchView.f251u0;
            if (nVar != null) {
                C0048n.m136a();
                Method method = nVar.f319c;
                if (method != null) {
                    try {
                        method.invoke(this, new Object[]{Boolean.TRUE});
                    } catch (Exception unused) {
                    }
                }
            } else {
                throw null;
            }
        }

        public boolean enoughToFilter() {
            return this.f302h <= 0 || super.enoughToFilter();
        }

        public InputConnection onCreateInputConnection(EditorInfo editorInfo) {
            InputConnection onCreateInputConnection = super.onCreateInputConnection(editorInfo);
            if (this.f304j) {
                removeCallbacks(this.f305k);
                post(this.f305k);
            }
            return onCreateInputConnection;
        }

        public void onFinishInflate() {
            super.onFinishInflate();
            setMinWidth((int) TypedValue.applyDimension(1, (float) getSearchViewTextMinWidthDp(), getResources().getDisplayMetrics()));
        }

        public void onFocusChanged(boolean z, int i, Rect rect) {
            super.onFocusChanged(z, i, rect);
            SearchView searchView = this.f303i;
            searchView.mo386G(searchView.f272U);
            searchView.post(searchView.f286l0);
            if (searchView.f294t.hasFocus()) {
                searchView.mo405r();
            }
        }

        public boolean onKeyPreIme(int i, KeyEvent keyEvent) {
            if (i == 4) {
                if (keyEvent.getAction() == 0 && keyEvent.getRepeatCount() == 0) {
                    KeyEvent.DispatcherState keyDispatcherState = getKeyDispatcherState();
                    if (keyDispatcherState != null) {
                        keyDispatcherState.startTracking(keyEvent, this);
                    }
                    return true;
                } else if (keyEvent.getAction() == 1) {
                    KeyEvent.DispatcherState keyDispatcherState2 = getKeyDispatcherState();
                    if (keyDispatcherState2 != null) {
                        keyDispatcherState2.handleUpEvent(keyEvent);
                    }
                    if (keyEvent.isTracking() && !keyEvent.isCanceled()) {
                        this.f303i.clearFocus();
                        setImeVisibility(false);
                        return true;
                    }
                }
            }
            return super.onKeyPreIme(i, keyEvent);
        }

        public void onWindowFocusChanged(boolean z) {
            super.onWindowFocusChanged(z);
            if (z && this.f303i.hasFocus() && getVisibility() == 0) {
                this.f304j = true;
                if (SearchView.m109s(getContext())) {
                    mo430a();
                }
            }
        }

        public void performCompletion() {
        }

        public void replaceText(CharSequence charSequence) {
        }

        public void setImeVisibility(boolean z) {
            InputMethodManager inputMethodManager = (InputMethodManager) getContext().getSystemService("input_method");
            if (!z) {
                this.f304j = false;
                removeCallbacks(this.f305k);
                inputMethodManager.hideSoftInputFromWindow(getWindowToken(), 0);
            } else if (inputMethodManager.isActive(this)) {
                this.f304j = false;
                removeCallbacks(this.f305k);
                inputMethodManager.showSoftInput(this, 0);
            } else {
                this.f304j = true;
            }
        }

        public void setSearchView(SearchView searchView) {
            this.f303i = searchView;
        }

        public void setThreshold(int i) {
            super.setThreshold(i);
            this.f302h = i;
        }
    }

    /* renamed from: androidx.appcompat.widget.SearchView$a */
    public class C0035a implements TextWatcher {
        public C0035a() {
        }

        public void afterTextChanged(Editable editable) {
        }

        public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {
        }

        public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
            SearchView searchView = SearchView.this;
            Editable text = searchView.f294t.getText();
            searchView.f281g0 = text;
            boolean z = !TextUtils.isEmpty(text);
            searchView.mo385F(z);
            searchView.mo387H(!z);
            searchView.mo381B();
            searchView.mo384E();
            if (searchView.f266O != null && !TextUtils.equals(charSequence, searchView.f280f0)) {
                searchView.f266O.mo457a(charSequence.toString());
            }
            searchView.f280f0 = charSequence.toString();
        }
    }

    /* renamed from: androidx.appcompat.widget.SearchView$b */
    public class C0036b implements Runnable {
        public C0036b() {
        }

        public void run() {
            SearchView.this.mo382C();
        }
    }

    /* renamed from: androidx.appcompat.widget.SearchView$c */
    public class C0037c implements Runnable {
        public C0037c() {
        }

        public void run() {
            C5697a aVar = SearchView.this.f273V;
            if (aVar instanceof C4978l0) {
                aVar.mo10564b((Cursor) null);
            }
        }
    }

    /* renamed from: androidx.appcompat.widget.SearchView$d */
    public class C0038d implements View.OnFocusChangeListener {
        public C0038d() {
        }

        public void onFocusChange(View view, boolean z) {
            SearchView searchView = SearchView.this;
            View.OnFocusChangeListener onFocusChangeListener = searchView.f268Q;
            if (onFocusChangeListener != null) {
                onFocusChangeListener.onFocusChange(searchView, z);
            }
        }
    }

    /* renamed from: androidx.appcompat.widget.SearchView$e */
    public class C0039e implements View.OnLayoutChangeListener {
        public C0039e() {
        }

        public void onLayoutChange(View view, int i, int i2, int i3, int i4, int i5, int i6, int i7, int i8) {
            SearchView searchView = SearchView.this;
            if (searchView.f253B.getWidth() > 1) {
                Resources resources = searchView.getContext().getResources();
                int paddingLeft = searchView.f297v.getPaddingLeft();
                Rect rect = new Rect();
                boolean b = C5004v0.m15611b(searchView);
                int dimensionPixelSize = searchView.f271T ? resources.getDimensionPixelSize(C4819d.abc_dropdownitem_text_padding_left) + resources.getDimensionPixelSize(C4819d.abc_dropdownitem_icon_width) : 0;
                searchView.f294t.getDropDownBackground().getPadding(rect);
                searchView.f294t.setDropDownHorizontalOffset(b ? -rect.left : paddingLeft - (rect.left + dimensionPixelSize));
                searchView.f294t.setDropDownWidth((((searchView.f253B.getWidth() + rect.left) + rect.right) + dimensionPixelSize) - paddingLeft);
            }
        }
    }

    /* renamed from: androidx.appcompat.widget.SearchView$f */
    public class C0040f implements View.OnClickListener {
        public C0040f() {
        }

        public void onClick(View view) {
            SearchView searchView = SearchView.this;
            if (view == searchView.f299x) {
                searchView.mo428y();
            } else if (view == searchView.f301z) {
                searchView.mo424u();
            } else if (view == searchView.f300y) {
                searchView.mo429z();
            } else if (view == searchView.f252A) {
                SearchableInfo searchableInfo = searchView.f284j0;
                if (searchableInfo != null) {
                    try {
                        if (searchableInfo.getVoiceSearchLaunchWebSearch()) {
                            Intent intent = new Intent(searchView.f263L);
                            ComponentName searchActivity = searchableInfo.getSearchActivity();
                            intent.putExtra("calling_package", searchActivity == null ? null : searchActivity.flattenToShortString());
                            searchView.getContext().startActivity(intent);
                        } else if (searchableInfo.getVoiceSearchLaunchRecognizer()) {
                            searchView.getContext().startActivity(searchView.mo404q(searchView.f264M, searchableInfo));
                        }
                    } catch (ActivityNotFoundException unused) {
                        Log.w("SearchView", "Could not find voice search activity");
                    }
                }
            } else if (view == searchView.f294t) {
                searchView.mo405r();
            }
        }
    }

    /* renamed from: androidx.appcompat.widget.SearchView$g */
    public class C0041g implements View.OnKeyListener {
        public C0041g() {
        }

        public boolean onKey(View view, int i, KeyEvent keyEvent) {
            SearchView searchView = SearchView.this;
            if (searchView.f284j0 == null) {
                return false;
            }
            if (searchView.f294t.isPopupShowing() && SearchView.this.f294t.getListSelection() != -1) {
                return SearchView.this.mo380A(i, keyEvent);
            }
            if ((TextUtils.getTrimmedLength(SearchView.this.f294t.getText()) == 0) || !keyEvent.hasNoModifiers() || keyEvent.getAction() != 1 || i != 66) {
                return false;
            }
            view.cancelLongPress();
            SearchView searchView2 = SearchView.this;
            searchView2.mo423t(0, (String) null, searchView2.f294t.getText().toString());
            return true;
        }
    }

    /* renamed from: androidx.appcompat.widget.SearchView$h */
    public class C0042h implements TextView.OnEditorActionListener {
        public C0042h() {
        }

        public boolean onEditorAction(TextView textView, int i, KeyEvent keyEvent) {
            SearchView.this.mo429z();
            return true;
        }
    }

    /* renamed from: androidx.appcompat.widget.SearchView$i */
    public class C0043i implements AdapterView.OnItemClickListener {
        public C0043i() {
        }

        public void onItemClick(AdapterView<?> adapterView, View view, int i, long j) {
            SearchView.this.mo425v(i);
        }
    }

    /* renamed from: androidx.appcompat.widget.SearchView$j */
    public class C0044j implements AdapterView.OnItemSelectedListener {
        public C0044j() {
        }

        public void onItemSelected(AdapterView<?> adapterView, View view, int i, long j) {
            SearchView.this.mo426w(i);
        }

        public void onNothingSelected(AdapterView<?> adapterView) {
        }
    }

    /* renamed from: androidx.appcompat.widget.SearchView$k */
    public interface C0045k {
        /* renamed from: a */
        boolean mo456a();
    }

    /* renamed from: androidx.appcompat.widget.SearchView$l */
    public interface C0046l {
        /* renamed from: a */
        boolean mo457a(String str);

        /* renamed from: b */
        boolean mo458b(String str);
    }

    /* renamed from: androidx.appcompat.widget.SearchView$m */
    public interface C0047m {
        /* renamed from: a */
        boolean mo459a(int i);

        /* renamed from: b */
        boolean mo460b(int i);
    }

    /* renamed from: androidx.appcompat.widget.SearchView$n */
    public static class C0048n {

        /* renamed from: a */
        public Method f317a = null;

        /* renamed from: b */
        public Method f318b = null;

        /* renamed from: c */
        public Method f319c = null;

        @SuppressLint({"DiscouragedPrivateApi", "SoonBlockedPrivateApi"})
        public C0048n() {
            m136a();
            try {
                Method declaredMethod = AutoCompleteTextView.class.getDeclaredMethod("doBeforeTextChanged", new Class[0]);
                this.f317a = declaredMethod;
                declaredMethod.setAccessible(true);
            } catch (NoSuchMethodException unused) {
            }
            try {
                Method declaredMethod2 = AutoCompleteTextView.class.getDeclaredMethod("doAfterTextChanged", new Class[0]);
                this.f318b = declaredMethod2;
                declaredMethod2.setAccessible(true);
            } catch (NoSuchMethodException unused2) {
            }
            Class<AutoCompleteTextView> cls = AutoCompleteTextView.class;
            try {
                Method method = cls.getMethod("ensureImeVisible", new Class[]{Boolean.TYPE});
                this.f319c = method;
                method.setAccessible(true);
            } catch (NoSuchMethodException unused3) {
            }
        }

        /* renamed from: a */
        public static void m136a() {
            if (Build.VERSION.SDK_INT >= 29) {
                throw new UnsupportedClassVersionError("This function can only be used for API Level < 29.");
            }
        }
    }

    /* renamed from: androidx.appcompat.widget.SearchView$o */
    public static class C0049o extends C5703a {
        public static final Parcelable.Creator<C0049o> CREATOR = new C0050a();

        /* renamed from: g */
        public boolean f320g;

        /* renamed from: androidx.appcompat.widget.SearchView$o$a */
        public class C0050a implements Parcelable.ClassLoaderCreator<C0049o> {
            public Object createFromParcel(Parcel parcel) {
                return new C0049o(parcel, (ClassLoader) null);
            }

            public Object[] newArray(int i) {
                return new C0049o[i];
            }

            public Object createFromParcel(Parcel parcel, ClassLoader classLoader) {
                return new C0049o(parcel, classLoader);
            }
        }

        public C0049o(Parcel parcel, ClassLoader classLoader) {
            super(parcel, classLoader);
            this.f320g = ((Boolean) parcel.readValue((ClassLoader) null)).booleanValue();
        }

        public C0049o(Parcelable parcelable) {
            super(parcelable);
        }

        public String toString() {
            StringBuilder m = C0131a.m379m("SearchView.SavedState{");
            m.append(Integer.toHexString(System.identityHashCode(this)));
            m.append(" isIconified=");
            m.append(this.f320g);
            m.append("}");
            return m.toString();
        }

        public void writeToParcel(Parcel parcel, int i) {
            parcel.writeParcelable(this.f20049e, i);
            parcel.writeValue(Boolean.valueOf(this.f320g));
        }
    }

    /* renamed from: androidx.appcompat.widget.SearchView$p */
    public static class C0051p extends TouchDelegate {

        /* renamed from: a */
        public final View f321a;

        /* renamed from: b */
        public final Rect f322b = new Rect();

        /* renamed from: c */
        public final Rect f323c = new Rect();

        /* renamed from: d */
        public final Rect f324d = new Rect();

        /* renamed from: e */
        public final int f325e;

        /* renamed from: f */
        public boolean f326f;

        public C0051p(Rect rect, Rect rect2, View view) {
            super(rect, view);
            this.f325e = ViewConfiguration.get(view.getContext()).getScaledTouchSlop();
            mo466a(rect, rect2);
            this.f321a = view;
        }

        /* renamed from: a */
        public void mo466a(Rect rect, Rect rect2) {
            this.f322b.set(rect);
            this.f324d.set(rect);
            Rect rect3 = this.f324d;
            int i = this.f325e;
            rect3.inset(-i, -i);
            this.f323c.set(rect2);
        }

        /* JADX WARNING: Removed duplicated region for block: B:18:0x0043  */
        /* JADX WARNING: Removed duplicated region for block: B:25:? A[RETURN, SYNTHETIC] */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public boolean onTouchEvent(android.view.MotionEvent r9) {
            /*
                r8 = this;
                float r0 = r9.getX()
                int r0 = (int) r0
                float r1 = r9.getY()
                int r1 = (int) r1
                int r2 = r9.getAction()
                r3 = 2
                r4 = 1
                r5 = 0
                if (r2 == 0) goto L_0x0033
                if (r2 == r4) goto L_0x0020
                if (r2 == r3) goto L_0x0020
                r6 = 3
                if (r2 == r6) goto L_0x001b
                goto L_0x003f
            L_0x001b:
                boolean r2 = r8.f326f
                r8.f326f = r5
                goto L_0x002f
            L_0x0020:
                boolean r2 = r8.f326f
                if (r2 == 0) goto L_0x002f
                android.graphics.Rect r6 = r8.f324d
                boolean r6 = r6.contains(r0, r1)
                if (r6 != 0) goto L_0x002f
                r4 = r2
                r2 = r5
                goto L_0x0041
            L_0x002f:
                r7 = r4
                r4 = r2
                r2 = r7
                goto L_0x0041
            L_0x0033:
                android.graphics.Rect r2 = r8.f322b
                boolean r2 = r2.contains(r0, r1)
                if (r2 == 0) goto L_0x003f
                r8.f326f = r4
                r2 = r4
                goto L_0x0041
            L_0x003f:
                r2 = r4
                r4 = r5
            L_0x0041:
                if (r4 == 0) goto L_0x0070
                if (r2 == 0) goto L_0x005d
                android.graphics.Rect r2 = r8.f323c
                boolean r2 = r2.contains(r0, r1)
                if (r2 != 0) goto L_0x005d
                android.view.View r0 = r8.f321a
                int r0 = r0.getWidth()
                int r0 = r0 / r3
                float r0 = (float) r0
                android.view.View r1 = r8.f321a
                int r1 = r1.getHeight()
                int r1 = r1 / r3
                goto L_0x0066
            L_0x005d:
                android.graphics.Rect r2 = r8.f323c
                int r3 = r2.left
                int r0 = r0 - r3
                float r0 = (float) r0
                int r2 = r2.top
                int r1 = r1 - r2
            L_0x0066:
                float r1 = (float) r1
                r9.setLocation(r0, r1)
                android.view.View r0 = r8.f321a
                boolean r5 = r0.dispatchTouchEvent(r9)
            L_0x0070:
                return r5
            */
            throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.SearchView.C0051p.onTouchEvent(android.view.MotionEvent):boolean");
        }
    }

    public SearchView(Context context) {
        this(context, (AttributeSet) null);
    }

    public SearchView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, C4816a.searchViewStyle);
    }

    public SearchView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.f255D = new Rect();
        this.f256E = new Rect();
        this.f257F = new int[2];
        this.f258G = new int[2];
        this.f286l0 = new C0036b();
        this.f287m0 = new C0037c();
        this.f288n0 = new WeakHashMap<>();
        this.f289o0 = new C0040f();
        this.f290p0 = new C0041g();
        this.f291q0 = new C0042h();
        this.f292r0 = new C0043i();
        this.f293s0 = new C0044j();
        this.f295t0 = new C0035a();
        C4991r0 r0Var = new C4991r0(context, context.obtainStyledAttributes(attributeSet, C4825j.SearchView, i, 0));
        LayoutInflater.from(context).inflate(r0Var.mo10610j(C4825j.SearchView_layout, C4822g.abc_search_view), this, true);
        SearchAutoComplete searchAutoComplete = (SearchAutoComplete) findViewById(C4821f.search_src_text);
        this.f294t = searchAutoComplete;
        searchAutoComplete.setSearchView(this);
        this.f296u = findViewById(C4821f.search_edit_frame);
        this.f297v = findViewById(C4821f.search_plate);
        this.f298w = findViewById(C4821f.submit_area);
        this.f299x = (ImageView) findViewById(C4821f.search_button);
        this.f300y = (ImageView) findViewById(C4821f.search_go_btn);
        this.f301z = (ImageView) findViewById(C4821f.search_close_btn);
        this.f252A = (ImageView) findViewById(C4821f.search_voice_btn);
        this.f259H = (ImageView) findViewById(C4821f.search_mag_icon);
        C5662k.m16845v(this.f297v, r0Var.mo10605e(C4825j.SearchView_queryBackground));
        this.f298w.setBackground(r0Var.mo10605e(C4825j.SearchView_submitBackground));
        this.f299x.setImageDrawable(r0Var.mo10605e(C4825j.SearchView_searchIcon));
        this.f300y.setImageDrawable(r0Var.mo10605e(C4825j.SearchView_goIcon));
        this.f301z.setImageDrawable(r0Var.mo10605e(C4825j.SearchView_closeIcon));
        this.f252A.setImageDrawable(r0Var.mo10605e(C4825j.SearchView_voiceIcon));
        this.f259H.setImageDrawable(r0Var.mo10605e(C4825j.SearchView_searchIcon));
        this.f260I = r0Var.mo10605e(C4825j.SearchView_searchHintIcon);
        this.f299x.setTooltipText(getResources().getString(C4823h.abc_searchview_description_search));
        this.f261J = r0Var.mo10610j(C4825j.SearchView_suggestionRowLayout, C4822g.abc_search_dropdown_item_icons_2line);
        this.f262K = r0Var.mo10610j(C4825j.SearchView_commitIcon, 0);
        this.f299x.setOnClickListener(this.f289o0);
        this.f301z.setOnClickListener(this.f289o0);
        this.f300y.setOnClickListener(this.f289o0);
        this.f252A.setOnClickListener(this.f289o0);
        this.f294t.setOnClickListener(this.f289o0);
        this.f294t.addTextChangedListener(this.f295t0);
        this.f294t.setOnEditorActionListener(this.f291q0);
        this.f294t.setOnItemClickListener(this.f292r0);
        this.f294t.setOnItemSelectedListener(this.f293s0);
        this.f294t.setOnKeyListener(this.f290p0);
        this.f294t.setOnFocusChangeListener(new C0038d());
        setIconifiedByDefault(r0Var.mo10601a(C4825j.SearchView_iconifiedByDefault, true));
        int d = r0Var.mo10604d(C4825j.SearchView_android_maxWidth, -1);
        if (d != -1) {
            setMaxWidth(d);
        }
        this.f265N = r0Var.mo10612l(C4825j.SearchView_defaultQueryHint);
        this.f275a0 = r0Var.mo10612l(C4825j.SearchView_queryHint);
        int h = r0Var.mo10608h(C4825j.SearchView_android_imeOptions, -1);
        if (h != -1) {
            setImeOptions(h);
        }
        int h2 = r0Var.mo10608h(C4825j.SearchView_android_inputType, -1);
        if (h2 != -1) {
            setInputType(h2);
        }
        setFocusable(r0Var.mo10601a(C4825j.SearchView_android_focusable, true));
        r0Var.f18227b.recycle();
        Intent intent = new Intent("android.speech.action.WEB_SEARCH");
        this.f263L = intent;
        intent.addFlags(268435456);
        this.f263L.putExtra("android.speech.extra.LANGUAGE_MODEL", "web_search");
        Intent intent2 = new Intent("android.speech.action.RECOGNIZE_SPEECH");
        this.f264M = intent2;
        intent2.addFlags(268435456);
        View findViewById = findViewById(this.f294t.getDropDownAnchor());
        this.f253B = findViewById;
        if (findViewById != null) {
            findViewById.addOnLayoutChangeListener(new C0039e());
        }
        mo386G(this.f271T);
        mo383D();
    }

    private int getPreferredHeight() {
        return getContext().getResources().getDimensionPixelSize(C4819d.abc_search_view_preferred_height);
    }

    private int getPreferredWidth() {
        return getContext().getResources().getDimensionPixelSize(C4819d.abc_search_view_preferred_width);
    }

    /* renamed from: s */
    public static boolean m109s(Context context) {
        return context.getResources().getConfiguration().orientation == 2;
    }

    private void setQuery(CharSequence charSequence) {
        this.f294t.setText(charSequence);
        this.f294t.setSelection(TextUtils.isEmpty(charSequence) ? 0 : charSequence.length());
    }

    /* renamed from: A */
    public boolean mo380A(int i, KeyEvent keyEvent) {
        if (this.f284j0 != null && this.f273V != null && keyEvent.getAction() == 0 && keyEvent.hasNoModifiers()) {
            if (i == 66 || i == 84 || i == 61) {
                return mo425v(this.f294t.getListSelection());
            }
            if (i == 21 || i == 22) {
                this.f294t.setSelection(i == 21 ? 0 : this.f294t.length());
                this.f294t.setListSelection(0);
                this.f294t.clearListSelection();
                this.f294t.mo430a();
                return true;
            } else if (i != 19 || this.f294t.getListSelection() == 0) {
                return false;
            }
        }
        return false;
    }

    /* renamed from: B */
    public final void mo381B() {
        boolean z = true;
        boolean z2 = !TextUtils.isEmpty(this.f294t.getText());
        int i = 0;
        if (!z2 && (!this.f271T || this.f282h0)) {
            z = false;
        }
        ImageView imageView = this.f301z;
        if (!z) {
            i = 8;
        }
        imageView.setVisibility(i);
        Drawable drawable = this.f301z.getDrawable();
        if (drawable != null) {
            drawable.setState(z2 ? ViewGroup.ENABLED_STATE_SET : ViewGroup.EMPTY_STATE_SET);
        }
    }

    /* renamed from: C */
    public void mo382C() {
        int[] iArr = this.f294t.hasFocus() ? ViewGroup.FOCUSED_STATE_SET : ViewGroup.EMPTY_STATE_SET;
        Drawable background = this.f297v.getBackground();
        if (background != null) {
            background.setState(iArr);
        }
        Drawable background2 = this.f298w.getBackground();
        if (background2 != null) {
            background2.setState(iArr);
        }
        invalidate();
    }

    /* renamed from: D */
    public final void mo383D() {
        SpannableStringBuilder queryHint = getQueryHint();
        SearchAutoComplete searchAutoComplete = this.f294t;
        if (queryHint == null) {
            queryHint = "";
        }
        if (this.f271T && this.f260I != null) {
            int textSize = (int) (((double) this.f294t.getTextSize()) * 1.25d);
            this.f260I.setBounds(0, 0, textSize, textSize);
            SpannableStringBuilder spannableStringBuilder = new SpannableStringBuilder("   ");
            spannableStringBuilder.setSpan(new ImageSpan(this.f260I), 1, 2, 33);
            spannableStringBuilder.append(queryHint);
            queryHint = spannableStringBuilder;
        }
        searchAutoComplete.setHint(queryHint);
    }

    /* renamed from: E */
    public final void mo384E() {
        int i = 0;
        if (!((this.f274W || this.f279e0) && !this.f272U) || !(this.f300y.getVisibility() == 0 || this.f252A.getVisibility() == 0)) {
            i = 8;
        }
        this.f298w.setVisibility(i);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:14:0x001e, code lost:
        if (r2.f279e0 == false) goto L_0x0023;
     */
    /* renamed from: F */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void mo385F(boolean r3) {
        /*
            r2 = this;
            boolean r0 = r2.f274W
            r1 = 0
            if (r0 == 0) goto L_0x0021
            if (r0 != 0) goto L_0x000b
            boolean r0 = r2.f279e0
            if (r0 == 0) goto L_0x0011
        L_0x000b:
            boolean r0 = r2.f272U
            if (r0 != 0) goto L_0x0011
            r0 = 1
            goto L_0x0012
        L_0x0011:
            r0 = r1
        L_0x0012:
            if (r0 == 0) goto L_0x0021
            boolean r0 = r2.hasFocus()
            if (r0 == 0) goto L_0x0021
            if (r3 != 0) goto L_0x0023
            boolean r3 = r2.f279e0
            if (r3 != 0) goto L_0x0021
            goto L_0x0023
        L_0x0021:
            r1 = 8
        L_0x0023:
            android.widget.ImageView r3 = r2.f300y
            r3.setVisibility(r1)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.SearchView.mo385F(boolean):void");
    }

    /* renamed from: G */
    public final void mo386G(boolean z) {
        this.f272U = z;
        int i = 0;
        int i2 = z ? 0 : 8;
        boolean z2 = !TextUtils.isEmpty(this.f294t.getText());
        this.f299x.setVisibility(i2);
        mo385F(z2);
        this.f296u.setVisibility(z ? 8 : 0);
        if (this.f259H.getDrawable() == null || this.f271T) {
            i = 8;
        }
        this.f259H.setVisibility(i);
        mo381B();
        mo387H(!z2);
        mo384E();
    }

    /* renamed from: H */
    public final void mo387H(boolean z) {
        int i = 8;
        if (this.f279e0 && !this.f272U && z) {
            this.f300y.setVisibility(8);
            i = 0;
        }
        this.f252A.setVisibility(i);
    }

    /* renamed from: c */
    public void mo388c() {
        if (!this.f282h0) {
            this.f282h0 = true;
            int imeOptions = this.f294t.getImeOptions();
            this.f283i0 = imeOptions;
            this.f294t.setImeOptions(imeOptions | 33554432);
            this.f294t.setText("");
            setIconified(false);
        }
    }

    public void clearFocus() {
        this.f277c0 = true;
        super.clearFocus();
        this.f294t.clearFocus();
        this.f294t.setImeVisibility(false);
        this.f277c0 = false;
    }

    /* renamed from: d */
    public void mo390d() {
        this.f294t.setText("");
        SearchAutoComplete searchAutoComplete = this.f294t;
        searchAutoComplete.setSelection(searchAutoComplete.length());
        this.f281g0 = "";
        clearFocus();
        mo386G(true);
        this.f294t.setImeOptions(this.f283i0);
        this.f282h0 = false;
    }

    public int getImeOptions() {
        return this.f294t.getImeOptions();
    }

    public int getInputType() {
        return this.f294t.getInputType();
    }

    public int getMaxWidth() {
        return this.f278d0;
    }

    public CharSequence getQuery() {
        return this.f294t.getText();
    }

    public CharSequence getQueryHint() {
        CharSequence charSequence = this.f275a0;
        if (charSequence != null) {
            return charSequence;
        }
        SearchableInfo searchableInfo = this.f284j0;
        return (searchableInfo == null || searchableInfo.getHintId() == 0) ? this.f265N : getContext().getText(this.f284j0.getHintId());
    }

    public int getSuggestionCommitIconResId() {
        return this.f262K;
    }

    public int getSuggestionRowLayout() {
        return this.f261J;
    }

    public C5697a getSuggestionsAdapter() {
        return this.f273V;
    }

    public void onDetachedFromWindow() {
        removeCallbacks(this.f286l0);
        post(this.f287m0);
        super.onDetachedFromWindow();
    }

    public void onLayout(boolean z, int i, int i2, int i3, int i4) {
        super.onLayout(z, i, i2, i3, i4);
        if (z) {
            SearchAutoComplete searchAutoComplete = this.f294t;
            Rect rect = this.f255D;
            searchAutoComplete.getLocationInWindow(this.f257F);
            getLocationInWindow(this.f258G);
            int[] iArr = this.f257F;
            int i5 = iArr[1];
            int[] iArr2 = this.f258G;
            int i6 = i5 - iArr2[1];
            int i7 = iArr[0] - iArr2[0];
            rect.set(i7, i6, searchAutoComplete.getWidth() + i7, searchAutoComplete.getHeight() + i6);
            Rect rect2 = this.f256E;
            Rect rect3 = this.f255D;
            rect2.set(rect3.left, 0, rect3.right, i4 - i2);
            C0051p pVar = this.f254C;
            if (pVar == null) {
                C0051p pVar2 = new C0051p(this.f256E, this.f255D, this.f294t);
                this.f254C = pVar2;
                setTouchDelegate(pVar2);
                return;
            }
            pVar.mo466a(this.f256E, this.f255D);
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:9:0x001d, code lost:
        if (r0 <= 0) goto L_0x0037;
     */
    /* JADX WARNING: Removed duplicated region for block: B:19:0x0041  */
    /* JADX WARNING: Removed duplicated region for block: B:21:0x0049  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void onMeasure(int r4, int r5) {
        /*
            r3 = this;
            boolean r0 = r3.f272U
            if (r0 == 0) goto L_0x0008
            super.onMeasure(r4, r5)
            return
        L_0x0008:
            int r0 = android.view.View.MeasureSpec.getMode(r4)
            int r4 = android.view.View.MeasureSpec.getSize(r4)
            r1 = -2147483648(0xffffffff80000000, float:-0.0)
            r2 = 1073741824(0x40000000, float:2.0)
            if (r0 == r1) goto L_0x002a
            if (r0 == 0) goto L_0x0020
            if (r0 == r2) goto L_0x001b
            goto L_0x0037
        L_0x001b:
            int r0 = r3.f278d0
            if (r0 <= 0) goto L_0x0037
            goto L_0x002e
        L_0x0020:
            int r4 = r3.f278d0
            if (r4 <= 0) goto L_0x0025
            goto L_0x0037
        L_0x0025:
            int r4 = r3.getPreferredWidth()
            goto L_0x0037
        L_0x002a:
            int r0 = r3.f278d0
            if (r0 <= 0) goto L_0x002f
        L_0x002e:
            goto L_0x0033
        L_0x002f:
            int r0 = r3.getPreferredWidth()
        L_0x0033:
            int r4 = java.lang.Math.min(r0, r4)
        L_0x0037:
            int r0 = android.view.View.MeasureSpec.getMode(r5)
            int r5 = android.view.View.MeasureSpec.getSize(r5)
            if (r0 == r1) goto L_0x0049
            if (r0 == 0) goto L_0x0044
            goto L_0x0051
        L_0x0044:
            int r5 = r3.getPreferredHeight()
            goto L_0x0051
        L_0x0049:
            int r0 = r3.getPreferredHeight()
            int r5 = java.lang.Math.min(r0, r5)
        L_0x0051:
            int r4 = android.view.View.MeasureSpec.makeMeasureSpec(r4, r2)
            int r5 = android.view.View.MeasureSpec.makeMeasureSpec(r5, r2)
            super.onMeasure(r4, r5)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.SearchView.onMeasure(int, int):void");
    }

    public void onRestoreInstanceState(Parcelable parcelable) {
        if (!(parcelable instanceof C0049o)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        C0049o oVar = (C0049o) parcelable;
        super.onRestoreInstanceState(oVar.f20049e);
        mo386G(oVar.f320g);
        requestLayout();
    }

    public Parcelable onSaveInstanceState() {
        C0049o oVar = new C0049o(super.onSaveInstanceState());
        oVar.f320g = this.f272U;
        return oVar;
    }

    public void onWindowFocusChanged(boolean z) {
        super.onWindowFocusChanged(z);
        post(this.f286l0);
    }

    /* renamed from: p */
    public final Intent mo403p(String str, Uri uri, String str2, String str3, int i, String str4) {
        Intent intent = new Intent(str);
        intent.addFlags(268435456);
        if (uri != null) {
            intent.setData(uri);
        }
        intent.putExtra("user_query", this.f281g0);
        if (str3 != null) {
            intent.putExtra("query", str3);
        }
        if (str2 != null) {
            intent.putExtra("intent_extra_data_key", str2);
        }
        Bundle bundle = this.f285k0;
        if (bundle != null) {
            intent.putExtra("app_data", bundle);
        }
        if (i != 0) {
            intent.putExtra("action_key", i);
            intent.putExtra("action_msg", str4);
        }
        intent.setComponent(this.f284j0.getSearchActivity());
        return intent;
    }

    /* renamed from: q */
    public final Intent mo404q(Intent intent, SearchableInfo searchableInfo) {
        ComponentName searchActivity = searchableInfo.getSearchActivity();
        Intent intent2 = new Intent("android.intent.action.SEARCH");
        intent2.setComponent(searchActivity);
        PendingIntent activity = PendingIntent.getActivity(getContext(), 0, intent2, 1073741824);
        Bundle bundle = new Bundle();
        Bundle bundle2 = this.f285k0;
        if (bundle2 != null) {
            bundle.putParcelable("app_data", bundle2);
        }
        Intent intent3 = new Intent(intent);
        int i = 1;
        Resources resources = getResources();
        String string = searchableInfo.getVoiceLanguageModeId() != 0 ? resources.getString(searchableInfo.getVoiceLanguageModeId()) : "free_form";
        String str = null;
        String string2 = searchableInfo.getVoicePromptTextId() != 0 ? resources.getString(searchableInfo.getVoicePromptTextId()) : null;
        String string3 = searchableInfo.getVoiceLanguageId() != 0 ? resources.getString(searchableInfo.getVoiceLanguageId()) : null;
        if (searchableInfo.getVoiceMaxResults() != 0) {
            i = searchableInfo.getVoiceMaxResults();
        }
        intent3.putExtra("android.speech.extra.LANGUAGE_MODEL", string);
        intent3.putExtra("android.speech.extra.PROMPT", string2);
        intent3.putExtra("android.speech.extra.LANGUAGE", string3);
        intent3.putExtra("android.speech.extra.MAX_RESULTS", i);
        if (searchActivity != null) {
            str = searchActivity.flattenToShortString();
        }
        intent3.putExtra("calling_package", str);
        intent3.putExtra("android.speech.extra.RESULTS_PENDINGINTENT", activity);
        intent3.putExtra("android.speech.extra.RESULTS_PENDINGINTENT_BUNDLE", bundle);
        return intent3;
    }

    /* renamed from: r */
    public void mo405r() {
        if (Build.VERSION.SDK_INT >= 29) {
            this.f294t.refreshAutoCompleteResults();
            return;
        }
        C0048n nVar = f251u0;
        SearchAutoComplete searchAutoComplete = this.f294t;
        if (nVar != null) {
            C0048n.m136a();
            Method method = nVar.f317a;
            if (method != null) {
                try {
                    method.invoke(searchAutoComplete, new Object[0]);
                } catch (Exception unused) {
                }
            }
            C0048n nVar2 = f251u0;
            SearchAutoComplete searchAutoComplete2 = this.f294t;
            if (nVar2 != null) {
                C0048n.m136a();
                Method method2 = nVar2.f318b;
                if (method2 != null) {
                    try {
                        method2.invoke(searchAutoComplete2, new Object[0]);
                    } catch (Exception unused2) {
                    }
                }
            } else {
                throw null;
            }
        } else {
            throw null;
        }
    }

    public boolean requestFocus(int i, Rect rect) {
        if (this.f277c0 || !isFocusable()) {
            return false;
        }
        if (this.f272U) {
            return super.requestFocus(i, rect);
        }
        boolean requestFocus = this.f294t.requestFocus(i, rect);
        if (requestFocus) {
            mo386G(false);
        }
        return requestFocus;
    }

    public void setAppSearchData(Bundle bundle) {
        this.f285k0 = bundle;
    }

    public void setIconified(boolean z) {
        if (z) {
            mo424u();
        } else {
            mo428y();
        }
    }

    public void setIconifiedByDefault(boolean z) {
        if (this.f271T != z) {
            this.f271T = z;
            mo386G(z);
            mo383D();
        }
    }

    public void setImeOptions(int i) {
        this.f294t.setImeOptions(i);
    }

    public void setInputType(int i) {
        this.f294t.setInputType(i);
    }

    public void setMaxWidth(int i) {
        this.f278d0 = i;
        requestLayout();
    }

    public void setOnCloseListener(C0045k kVar) {
        this.f267P = kVar;
    }

    public void setOnQueryTextFocusChangeListener(View.OnFocusChangeListener onFocusChangeListener) {
        this.f268Q = onFocusChangeListener;
    }

    public void setOnQueryTextListener(C0046l lVar) {
        this.f266O = lVar;
    }

    public void setOnSearchClickListener(View.OnClickListener onClickListener) {
        this.f270S = onClickListener;
    }

    public void setOnSuggestionListener(C0047m mVar) {
        this.f269R = mVar;
    }

    public void setQueryHint(CharSequence charSequence) {
        this.f275a0 = charSequence;
        mo383D();
    }

    public void setQueryRefinementEnabled(boolean z) {
        this.f276b0 = z;
        C5697a aVar = this.f273V;
        if (aVar instanceof C4978l0) {
            ((C4978l0) aVar).f18189v = z ? 2 : 1;
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:30:0x009c, code lost:
        if (getContext().getPackageManager().resolveActivity(r2, 65536) != null) goto L_0x00a0;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void setSearchableInfo(android.app.SearchableInfo r7) {
        /*
            r6 = this;
            r6.f284j0 = r7
            r0 = 1
            r1 = 65536(0x10000, float:9.18355E-41)
            r2 = 0
            if (r7 == 0) goto L_0x006e
            androidx.appcompat.widget.SearchView$SearchAutoComplete r3 = r6.f294t
            int r7 = r7.getSuggestThreshold()
            r3.setThreshold(r7)
            androidx.appcompat.widget.SearchView$SearchAutoComplete r7 = r6.f294t
            android.app.SearchableInfo r3 = r6.f284j0
            int r3 = r3.getImeOptions()
            r7.setImeOptions(r3)
            android.app.SearchableInfo r7 = r6.f284j0
            int r7 = r7.getInputType()
            r3 = r7 & 15
            if (r3 != r0) goto L_0x0036
            r3 = -65537(0xfffffffffffeffff, float:NaN)
            r7 = r7 & r3
            android.app.SearchableInfo r3 = r6.f284j0
            java.lang.String r3 = r3.getSuggestAuthority()
            if (r3 == 0) goto L_0x0036
            r7 = r7 | r1
            r3 = 524288(0x80000, float:7.34684E-40)
            r7 = r7 | r3
        L_0x0036:
            androidx.appcompat.widget.SearchView$SearchAutoComplete r3 = r6.f294t
            r3.setInputType(r7)
            d.j.a.a r7 = r6.f273V
            if (r7 == 0) goto L_0x0042
            r7.mo10564b(r2)
        L_0x0042:
            android.app.SearchableInfo r7 = r6.f284j0
            java.lang.String r7 = r7.getSuggestAuthority()
            if (r7 == 0) goto L_0x006b
            d.b.p.l0 r7 = new d.b.p.l0
            android.content.Context r3 = r6.getContext()
            android.app.SearchableInfo r4 = r6.f284j0
            java.util.WeakHashMap<java.lang.String, android.graphics.drawable.Drawable$ConstantState> r5 = r6.f288n0
            r7.<init>(r3, r6, r4, r5)
            r6.f273V = r7
            androidx.appcompat.widget.SearchView$SearchAutoComplete r3 = r6.f294t
            r3.setAdapter(r7)
            d.j.a.a r7 = r6.f273V
            d.b.p.l0 r7 = (p176d.p178b.p187p.C4978l0) r7
            boolean r3 = r6.f276b0
            if (r3 == 0) goto L_0x0068
            r3 = 2
            goto L_0x0069
        L_0x0068:
            r3 = r0
        L_0x0069:
            r7.f18189v = r3
        L_0x006b:
            r6.mo383D()
        L_0x006e:
            android.app.SearchableInfo r7 = r6.f284j0
            r3 = 0
            if (r7 == 0) goto L_0x009f
            boolean r7 = r7.getVoiceSearchEnabled()
            if (r7 == 0) goto L_0x009f
            android.app.SearchableInfo r7 = r6.f284j0
            boolean r7 = r7.getVoiceSearchLaunchWebSearch()
            if (r7 == 0) goto L_0x0084
            android.content.Intent r2 = r6.f263L
            goto L_0x008e
        L_0x0084:
            android.app.SearchableInfo r7 = r6.f284j0
            boolean r7 = r7.getVoiceSearchLaunchRecognizer()
            if (r7 == 0) goto L_0x008e
            android.content.Intent r2 = r6.f264M
        L_0x008e:
            if (r2 == 0) goto L_0x009f
            android.content.Context r7 = r6.getContext()
            android.content.pm.PackageManager r7 = r7.getPackageManager()
            android.content.pm.ResolveInfo r7 = r7.resolveActivity(r2, r1)
            if (r7 == 0) goto L_0x009f
            goto L_0x00a0
        L_0x009f:
            r0 = r3
        L_0x00a0:
            r6.f279e0 = r0
            if (r0 == 0) goto L_0x00ab
            androidx.appcompat.widget.SearchView$SearchAutoComplete r7 = r6.f294t
            java.lang.String r0 = "nm"
            r7.setPrivateImeOptions(r0)
        L_0x00ab:
            boolean r7 = r6.f272U
            r6.mo386G(r7)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.SearchView.setSearchableInfo(android.app.SearchableInfo):void");
    }

    public void setSubmitButtonEnabled(boolean z) {
        this.f274W = z;
        mo386G(this.f272U);
    }

    public void setSuggestionsAdapter(C5697a aVar) {
        this.f273V = aVar;
        this.f294t.setAdapter(aVar);
    }

    /* renamed from: t */
    public void mo423t(int i, String str, String str2) {
        getContext().startActivity(mo403p("android.intent.action.SEARCH", (Uri) null, (String) null, str2, i, (String) null));
    }

    /* renamed from: u */
    public void mo424u() {
        if (!TextUtils.isEmpty(this.f294t.getText())) {
            this.f294t.setText("");
            this.f294t.requestFocus();
            this.f294t.setImeVisibility(true);
        } else if (this.f271T) {
            C0045k kVar = this.f267P;
            if (kVar == null || !kVar.mo456a()) {
                clearFocus();
                mo386G(true);
            }
        }
    }

    /* renamed from: v */
    public boolean mo425v(int i) {
        int i2;
        String i3;
        C0047m mVar = this.f269R;
        if (mVar != null && mVar.mo460b(i)) {
            return false;
        }
        Cursor cursor = this.f273V.f20036g;
        if (cursor != null && cursor.moveToPosition(i)) {
            Intent intent = null;
            try {
                String e = C4978l0.m15516e(cursor, "suggest_intent_action");
                if (e == null) {
                    e = this.f284j0.getSuggestIntentAction();
                }
                if (e == null) {
                    e = "android.intent.action.SEARCH";
                }
                String str = e;
                String i4 = C4978l0.m15517i(cursor, cursor.getColumnIndex("suggest_intent_data"));
                if (i4 == null) {
                    i4 = this.f284j0.getSuggestIntentData();
                }
                if (!(i4 == null || (i3 = C4978l0.m15517i(cursor, cursor.getColumnIndex("suggest_intent_data_id"))) == null)) {
                    i4 = i4 + "/" + Uri.encode(i3);
                }
                intent = mo403p(str, i4 == null ? null : Uri.parse(i4), C4978l0.m15517i(cursor, cursor.getColumnIndex("suggest_intent_extra_data")), C4978l0.m15517i(cursor, cursor.getColumnIndex("suggest_intent_query")), 0, (String) null);
            } catch (RuntimeException e2) {
                try {
                    i2 = cursor.getPosition();
                } catch (RuntimeException unused) {
                    i2 = -1;
                }
                Log.w("SearchView", "Search suggestions cursor at row " + i2 + " returned exception.", e2);
            }
            if (intent != null) {
                try {
                    getContext().startActivity(intent);
                } catch (RuntimeException e3) {
                    Log.e("SearchView", "Failed launch activity: " + intent, e3);
                }
            }
        }
        this.f294t.setImeVisibility(false);
        this.f294t.dismissDropDown();
        return true;
    }

    /* renamed from: w */
    public boolean mo426w(int i) {
        CharSequence c;
        C0047m mVar = this.f269R;
        if (mVar != null && mVar.mo459a(i)) {
            return false;
        }
        Editable text = this.f294t.getText();
        Cursor cursor = this.f273V.f20036g;
        if (cursor == null) {
            return true;
        }
        if (!cursor.moveToPosition(i) || (c = this.f273V.mo10565c(cursor)) == null) {
            setQuery(text);
            return true;
        }
        setQuery(c);
        return true;
    }

    /* renamed from: x */
    public void mo427x(CharSequence charSequence) {
        setQuery(charSequence);
    }

    /* renamed from: y */
    public void mo428y() {
        mo386G(false);
        this.f294t.requestFocus();
        this.f294t.setImeVisibility(true);
        View.OnClickListener onClickListener = this.f270S;
        if (onClickListener != null) {
            onClickListener.onClick(this);
        }
    }

    /* renamed from: z */
    public void mo429z() {
        Editable text = this.f294t.getText();
        if (text != null && TextUtils.getTrimmedLength(text) > 0) {
            C0046l lVar = this.f266O;
            if (lVar == null || !lVar.mo458b(text.toString())) {
                if (this.f284j0 != null) {
                    mo423t(0, (String) null, text.toString());
                }
                this.f294t.setImeVisibility(false);
                this.f294t.dismissDropDown();
            }
        }
    }
}
