package androidx.appcompat.widget;

import android.content.Context;
import android.content.DialogInterface;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.database.DataSetObserver;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.AdapterView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.ThemedSpinnerAdapter;
import androidx.appcompat.app.AlertController;
import p176d.p178b.C4816a;
import p176d.p178b.p179k.C4846m;
import p176d.p178b.p180l.p181a.C4879a;
import p176d.p178b.p187p.C4937b0;
import p176d.p178b.p187p.C4952e;
import p176d.p178b.p187p.C4953e0;
import p176d.p178b.p187p.C4983n0;
import p176d.p178b.p187p.C5009z;
import p176d.p219i.p231k.C5662k;

public class AppCompatSpinner extends Spinner {

    /* renamed from: m */
    public static final int[] f207m = {16843505};

    /* renamed from: e */
    public final C4952e f208e;

    /* renamed from: f */
    public final Context f209f;

    /* renamed from: g */
    public C4937b0 f210g;

    /* renamed from: h */
    public SpinnerAdapter f211h;

    /* renamed from: i */
    public final boolean f212i;

    /* renamed from: j */
    public C0032f f213j;

    /* renamed from: k */
    public int f214k;

    /* renamed from: l */
    public final Rect f215l;

    /* renamed from: androidx.appcompat.widget.AppCompatSpinner$a */
    public class C0023a implements ViewTreeObserver.OnGlobalLayoutListener {
        public C0023a() {
        }

        public void onGlobalLayout() {
            if (!AppCompatSpinner.this.getInternalPopup().mo284b0()) {
                AppCompatSpinner.this.mo253b();
            }
            ViewTreeObserver viewTreeObserver = AppCompatSpinner.this.getViewTreeObserver();
            if (viewTreeObserver != null) {
                viewTreeObserver.removeOnGlobalLayoutListener(this);
            }
        }
    }

    /* renamed from: androidx.appcompat.widget.AppCompatSpinner$b */
    public class C0024b implements C0032f, DialogInterface.OnClickListener {

        /* renamed from: e */
        public C4846m f217e;

        /* renamed from: f */
        public ListAdapter f218f;

        /* renamed from: g */
        public CharSequence f219g;

        public C0024b() {
        }

        /* renamed from: a */
        public int mo283a() {
            return 0;
        }

        /* renamed from: b0 */
        public boolean mo284b0() {
            C4846m mVar = this.f217e;
            if (mVar != null) {
                return mVar.isShowing();
            }
            return false;
        }

        /* renamed from: d */
        public Drawable mo285d() {
            return null;
        }

        public void dismiss() {
            C4846m mVar = this.f217e;
            if (mVar != null) {
                mVar.dismiss();
                this.f217e = null;
            }
        }

        /* renamed from: e */
        public void mo287e(CharSequence charSequence) {
            this.f219g = charSequence;
        }

        /* renamed from: f */
        public void mo288f(Drawable drawable) {
            Log.e("AppCompatSpinner", "Cannot set popup background for MODE_DIALOG, ignoring");
        }

        /* renamed from: g */
        public void mo289g(int i) {
            Log.e("AppCompatSpinner", "Cannot set vertical offset for MODE_DIALOG, ignoring");
        }

        /* renamed from: h */
        public void mo290h(int i) {
            Log.e("AppCompatSpinner", "Cannot set horizontal (original) offset for MODE_DIALOG, ignoring");
        }

        /* renamed from: i */
        public void mo291i(int i) {
            Log.e("AppCompatSpinner", "Cannot set horizontal offset for MODE_DIALOG, ignoring");
        }

        /* renamed from: j */
        public void mo292j(int i, int i2) {
            if (this.f218f != null) {
                Context popupContext = AppCompatSpinner.this.getPopupContext();
                C4846m.C4847a aVar = new C4846m.C4847a(popupContext, C4846m.m14978c(popupContext, 0));
                CharSequence charSequence = this.f219g;
                if (charSequence != null) {
                    aVar.f17614a.f74f = charSequence;
                }
                ListAdapter listAdapter = this.f218f;
                int selectedItemPosition = AppCompatSpinner.this.getSelectedItemPosition();
                AlertController.C0007b bVar = aVar.f17614a;
                bVar.f85q = listAdapter;
                bVar.f86r = this;
                bVar.f89u = selectedItemPosition;
                bVar.f88t = true;
                C4846m a = aVar.mo9868a();
                this.f217e = a;
                ListView listView = a.f17613g.f46g;
                listView.setTextDirection(i);
                listView.setTextAlignment(i2);
                this.f217e.show();
            }
        }

        /* renamed from: k */
        public int mo293k() {
            return 0;
        }

        /* renamed from: l */
        public CharSequence mo294l() {
            return this.f219g;
        }

        /* renamed from: m */
        public void mo295m(ListAdapter listAdapter) {
            this.f218f = listAdapter;
        }

        public void onClick(DialogInterface dialogInterface, int i) {
            AppCompatSpinner.this.setSelection(i);
            if (AppCompatSpinner.this.getOnItemClickListener() != null) {
                AppCompatSpinner.this.performItemClick((View) null, i, this.f218f.getItemId(i));
            }
            C4846m mVar = this.f217e;
            if (mVar != null) {
                mVar.dismiss();
                this.f217e = null;
            }
        }
    }

    /* renamed from: androidx.appcompat.widget.AppCompatSpinner$c */
    public static class C0025c implements ListAdapter, SpinnerAdapter {

        /* renamed from: e */
        public SpinnerAdapter f221e;

        /* renamed from: f */
        public ListAdapter f222f;

        public C0025c(SpinnerAdapter spinnerAdapter, Resources.Theme theme) {
            this.f221e = spinnerAdapter;
            if (spinnerAdapter instanceof ListAdapter) {
                this.f222f = (ListAdapter) spinnerAdapter;
            }
            if (theme == null) {
                return;
            }
            if (spinnerAdapter instanceof ThemedSpinnerAdapter) {
                ThemedSpinnerAdapter themedSpinnerAdapter = (ThemedSpinnerAdapter) spinnerAdapter;
                if (themedSpinnerAdapter.getDropDownViewTheme() != theme) {
                    themedSpinnerAdapter.setDropDownViewTheme(theme);
                }
            } else if (spinnerAdapter instanceof C4983n0) {
                C4983n0 n0Var = (C4983n0) spinnerAdapter;
                if (n0Var.getDropDownViewTheme() == null) {
                    n0Var.setDropDownViewTheme(theme);
                }
            }
        }

        public boolean areAllItemsEnabled() {
            ListAdapter listAdapter = this.f222f;
            if (listAdapter != null) {
                return listAdapter.areAllItemsEnabled();
            }
            return true;
        }

        public int getCount() {
            SpinnerAdapter spinnerAdapter = this.f221e;
            if (spinnerAdapter == null) {
                return 0;
            }
            return spinnerAdapter.getCount();
        }

        public View getDropDownView(int i, View view, ViewGroup viewGroup) {
            SpinnerAdapter spinnerAdapter = this.f221e;
            if (spinnerAdapter == null) {
                return null;
            }
            return spinnerAdapter.getDropDownView(i, view, viewGroup);
        }

        public Object getItem(int i) {
            SpinnerAdapter spinnerAdapter = this.f221e;
            if (spinnerAdapter == null) {
                return null;
            }
            return spinnerAdapter.getItem(i);
        }

        public long getItemId(int i) {
            SpinnerAdapter spinnerAdapter = this.f221e;
            if (spinnerAdapter == null) {
                return -1;
            }
            return spinnerAdapter.getItemId(i);
        }

        public int getItemViewType(int i) {
            return 0;
        }

        public View getView(int i, View view, ViewGroup viewGroup) {
            SpinnerAdapter spinnerAdapter = this.f221e;
            if (spinnerAdapter == null) {
                return null;
            }
            return spinnerAdapter.getDropDownView(i, view, viewGroup);
        }

        public int getViewTypeCount() {
            return 1;
        }

        public boolean hasStableIds() {
            SpinnerAdapter spinnerAdapter = this.f221e;
            return spinnerAdapter != null && spinnerAdapter.hasStableIds();
        }

        public boolean isEmpty() {
            return getCount() == 0;
        }

        public boolean isEnabled(int i) {
            ListAdapter listAdapter = this.f222f;
            if (listAdapter != null) {
                return listAdapter.isEnabled(i);
            }
            return true;
        }

        public void registerDataSetObserver(DataSetObserver dataSetObserver) {
            SpinnerAdapter spinnerAdapter = this.f221e;
            if (spinnerAdapter != null) {
                spinnerAdapter.registerDataSetObserver(dataSetObserver);
            }
        }

        public void unregisterDataSetObserver(DataSetObserver dataSetObserver) {
            SpinnerAdapter spinnerAdapter = this.f221e;
            if (spinnerAdapter != null) {
                spinnerAdapter.unregisterDataSetObserver(dataSetObserver);
            }
        }
    }

    /* renamed from: androidx.appcompat.widget.AppCompatSpinner$d */
    public class C0026d extends C4953e0 implements C0032f {

        /* renamed from: I */
        public CharSequence f223I;

        /* renamed from: J */
        public ListAdapter f224J;

        /* renamed from: K */
        public final Rect f225K = new Rect();

        /* renamed from: L */
        public int f226L;

        /* renamed from: androidx.appcompat.widget.AppCompatSpinner$d$a */
        public class C0027a implements AdapterView.OnItemClickListener {

            /* renamed from: e */
            public final /* synthetic */ AppCompatSpinner f228e;

            public C0027a(AppCompatSpinner appCompatSpinner) {
                this.f228e = appCompatSpinner;
            }

            public void onItemClick(AdapterView<?> adapterView, View view, int i, long j) {
                AppCompatSpinner.this.setSelection(i);
                if (AppCompatSpinner.this.getOnItemClickListener() != null) {
                    C0026d dVar = C0026d.this;
                    AppCompatSpinner.this.performItemClick(view, i, dVar.f224J.getItemId(i));
                }
                C0026d.this.dismiss();
            }
        }

        /* renamed from: androidx.appcompat.widget.AppCompatSpinner$d$b */
        public class C0028b implements ViewTreeObserver.OnGlobalLayoutListener {
            public C0028b() {
            }

            public void onGlobalLayout() {
                C0026d dVar = C0026d.this;
                AppCompatSpinner appCompatSpinner = AppCompatSpinner.this;
                if (dVar != null) {
                    if (!(C5662k.m16835l(appCompatSpinner) && appCompatSpinner.getGlobalVisibleRect(dVar.f225K))) {
                        C0026d.this.dismiss();
                        return;
                    }
                    C0026d.this.mo310r();
                    C0026d.super.mo10130a0();
                    return;
                }
                throw null;
            }
        }

        /* renamed from: androidx.appcompat.widget.AppCompatSpinner$d$c */
        public class C0029c implements PopupWindow.OnDismissListener {

            /* renamed from: e */
            public final /* synthetic */ ViewTreeObserver.OnGlobalLayoutListener f231e;

            public C0029c(ViewTreeObserver.OnGlobalLayoutListener onGlobalLayoutListener) {
                this.f231e = onGlobalLayoutListener;
            }

            public void onDismiss() {
                ViewTreeObserver viewTreeObserver = AppCompatSpinner.this.getViewTreeObserver();
                if (viewTreeObserver != null) {
                    viewTreeObserver.removeGlobalOnLayoutListener(this.f231e);
                }
            }
        }

        public C0026d(Context context, AttributeSet attributeSet, int i) {
            super(context, attributeSet, i, 0);
            this.f18110v = AppCompatSpinner.this;
            mo10472p(true);
            this.f18108t = 0;
            this.f18111w = new C0027a(AppCompatSpinner.this);
        }

        /* renamed from: e */
        public void mo287e(CharSequence charSequence) {
            this.f223I = charSequence;
        }

        /* renamed from: h */
        public void mo290h(int i) {
            this.f226L = i;
        }

        /* renamed from: j */
        public void mo292j(int i, int i2) {
            ViewTreeObserver viewTreeObserver;
            boolean b0 = mo10131b0();
            mo310r();
            this.f18092F.setInputMethodMode(2);
            super.mo10130a0();
            C5009z zVar = this.f18095g;
            zVar.setChoiceMode(1);
            zVar.setTextDirection(i);
            zVar.setTextAlignment(i2);
            int selectedItemPosition = AppCompatSpinner.this.getSelectedItemPosition();
            C5009z zVar2 = this.f18095g;
            if (mo10131b0() && zVar2 != null) {
                zVar2.setListSelectionHidden(false);
                zVar2.setSelection(selectedItemPosition);
                if (zVar2.getChoiceMode() != 0) {
                    zVar2.setItemChecked(selectedItemPosition, true);
                }
            }
            if (!b0 && (viewTreeObserver = AppCompatSpinner.this.getViewTreeObserver()) != null) {
                C0028b bVar = new C0028b();
                viewTreeObserver.addOnGlobalLayoutListener(bVar);
                this.f18092F.setOnDismissListener(new C0029c(bVar));
            }
        }

        /* renamed from: l */
        public CharSequence mo294l() {
            return this.f223I;
        }

        /* renamed from: m */
        public void mo295m(ListAdapter listAdapter) {
            super.mo295m(listAdapter);
            this.f224J = listAdapter;
        }

        /* JADX WARNING: Removed duplicated region for block: B:21:0x008d  */
        /* JADX WARNING: Removed duplicated region for block: B:22:0x0096  */
        /* renamed from: r */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public void mo310r() {
            /*
                r8 = this;
                android.graphics.drawable.Drawable r0 = r8.mo10465d()
                r1 = 0
                if (r0 == 0) goto L_0x0026
                androidx.appcompat.widget.AppCompatSpinner r1 = androidx.appcompat.widget.AppCompatSpinner.this
                android.graphics.Rect r1 = r1.f215l
                r0.getPadding(r1)
                androidx.appcompat.widget.AppCompatSpinner r0 = androidx.appcompat.widget.AppCompatSpinner.this
                boolean r0 = p176d.p178b.p187p.C5004v0.m15611b(r0)
                if (r0 == 0) goto L_0x001d
                androidx.appcompat.widget.AppCompatSpinner r0 = androidx.appcompat.widget.AppCompatSpinner.this
                android.graphics.Rect r0 = r0.f215l
                int r0 = r0.right
                goto L_0x0024
            L_0x001d:
                androidx.appcompat.widget.AppCompatSpinner r0 = androidx.appcompat.widget.AppCompatSpinner.this
                android.graphics.Rect r0 = r0.f215l
                int r0 = r0.left
                int r0 = -r0
            L_0x0024:
                r1 = r0
                goto L_0x002e
            L_0x0026:
                androidx.appcompat.widget.AppCompatSpinner r0 = androidx.appcompat.widget.AppCompatSpinner.this
                android.graphics.Rect r0 = r0.f215l
                r0.right = r1
                r0.left = r1
            L_0x002e:
                androidx.appcompat.widget.AppCompatSpinner r0 = androidx.appcompat.widget.AppCompatSpinner.this
                int r0 = r0.getPaddingLeft()
                androidx.appcompat.widget.AppCompatSpinner r2 = androidx.appcompat.widget.AppCompatSpinner.this
                int r2 = r2.getPaddingRight()
                androidx.appcompat.widget.AppCompatSpinner r3 = androidx.appcompat.widget.AppCompatSpinner.this
                int r3 = r3.getWidth()
                androidx.appcompat.widget.AppCompatSpinner r4 = androidx.appcompat.widget.AppCompatSpinner.this
                int r5 = r4.f214k
                r6 = -2
                if (r5 != r6) goto L_0x0078
                android.widget.ListAdapter r5 = r8.f224J
                android.widget.SpinnerAdapter r5 = (android.widget.SpinnerAdapter) r5
                android.graphics.drawable.Drawable r6 = r8.mo10465d()
                int r4 = r4.mo252a(r5, r6)
                androidx.appcompat.widget.AppCompatSpinner r5 = androidx.appcompat.widget.AppCompatSpinner.this
                android.content.Context r5 = r5.getContext()
                android.content.res.Resources r5 = r5.getResources()
                android.util.DisplayMetrics r5 = r5.getDisplayMetrics()
                int r5 = r5.widthPixels
                androidx.appcompat.widget.AppCompatSpinner r6 = androidx.appcompat.widget.AppCompatSpinner.this
                android.graphics.Rect r6 = r6.f215l
                int r7 = r6.left
                int r5 = r5 - r7
                int r6 = r6.right
                int r5 = r5 - r6
                if (r4 <= r5) goto L_0x0070
                r4 = r5
            L_0x0070:
                int r5 = r3 - r0
                int r5 = r5 - r2
                int r4 = java.lang.Math.max(r4, r5)
                goto L_0x007e
            L_0x0078:
                r4 = -1
                if (r5 != r4) goto L_0x0082
                int r4 = r3 - r0
                int r4 = r4 - r2
            L_0x007e:
                r8.mo10471o(r4)
                goto L_0x0085
            L_0x0082:
                r8.mo10471o(r5)
            L_0x0085:
                androidx.appcompat.widget.AppCompatSpinner r4 = androidx.appcompat.widget.AppCompatSpinner.this
                boolean r4 = p176d.p178b.p187p.C5004v0.m15611b(r4)
                if (r4 == 0) goto L_0x0096
                int r3 = r3 - r2
                int r0 = r8.f18097i
                int r3 = r3 - r0
                int r0 = r8.f226L
                int r3 = r3 - r0
                int r3 = r3 + r1
                goto L_0x009b
            L_0x0096:
                int r2 = r8.f226L
                int r0 = r0 + r2
                int r3 = r0 + r1
            L_0x009b:
                r8.f18098j = r3
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.AppCompatSpinner.C0026d.mo310r():void");
        }
    }

    /* renamed from: androidx.appcompat.widget.AppCompatSpinner$e */
    public static class C0030e extends View.BaseSavedState {
        public static final Parcelable.Creator<C0030e> CREATOR = new C0031a();

        /* renamed from: e */
        public boolean f233e;

        /* renamed from: androidx.appcompat.widget.AppCompatSpinner$e$a */
        public class C0031a implements Parcelable.Creator<C0030e> {
            public Object createFromParcel(Parcel parcel) {
                return new C0030e(parcel);
            }

            public Object[] newArray(int i) {
                return new C0030e[i];
            }
        }

        public C0030e(Parcel parcel) {
            super(parcel);
            this.f233e = parcel.readByte() != 0;
        }

        public C0030e(Parcelable parcelable) {
            super(parcelable);
        }

        public void writeToParcel(Parcel parcel, int i) {
            super.writeToParcel(parcel, i);
            parcel.writeByte(this.f233e ? (byte) 1 : 0);
        }
    }

    /* renamed from: androidx.appcompat.widget.AppCompatSpinner$f */
    public interface C0032f {
        /* renamed from: a */
        int mo283a();

        /* renamed from: b0 */
        boolean mo284b0();

        /* renamed from: d */
        Drawable mo285d();

        void dismiss();

        /* renamed from: e */
        void mo287e(CharSequence charSequence);

        /* renamed from: f */
        void mo288f(Drawable drawable);

        /* renamed from: g */
        void mo289g(int i);

        /* renamed from: h */
        void mo290h(int i);

        /* renamed from: i */
        void mo291i(int i);

        /* renamed from: j */
        void mo292j(int i, int i2);

        /* renamed from: k */
        int mo293k();

        /* renamed from: l */
        CharSequence mo294l();

        /* renamed from: m */
        void mo295m(ListAdapter listAdapter);
    }

    public AppCompatSpinner(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, C4816a.spinnerStyle);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:20:0x0057, code lost:
        if (r4 != null) goto L_0x0059;
     */
    /* JADX WARNING: Removed duplicated region for block: B:36:0x00da  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public AppCompatSpinner(android.content.Context r9, android.util.AttributeSet r10, int r11) {
        /*
            r8 = this;
            r8.<init>(r9, r10, r11)
            android.graphics.Rect r0 = new android.graphics.Rect
            r0.<init>()
            r8.f215l = r0
            android.content.Context r0 = r8.getContext()
            p176d.p178b.p187p.C4981m0.m15526a(r8, r0)
            int[] r0 = p176d.p178b.C4825j.Spinner
            r1 = 0
            android.content.res.TypedArray r0 = r9.obtainStyledAttributes(r10, r0, r11, r1)
            d.b.p.e r2 = new d.b.p.e
            r2.<init>(r8)
            r8.f208e = r2
            int r2 = p176d.p178b.C4825j.Spinner_popupTheme
            int r2 = r0.getResourceId(r2, r1)
            if (r2 == 0) goto L_0x002f
            d.b.o.c r3 = new d.b.o.c
            r3.<init>(r9, r2)
            r8.f209f = r3
            goto L_0x0031
        L_0x002f:
            r8.f209f = r9
        L_0x0031:
            r2 = 0
            r3 = -1
            int[] r4 = f207m     // Catch:{ Exception -> 0x004d, all -> 0x004a }
            android.content.res.TypedArray r4 = r9.obtainStyledAttributes(r10, r4, r11, r1)     // Catch:{ Exception -> 0x004d, all -> 0x004a }
            boolean r5 = r4.hasValue(r1)     // Catch:{ Exception -> 0x0048 }
            if (r5 == 0) goto L_0x0059
            int r3 = r4.getInt(r1, r1)     // Catch:{ Exception -> 0x0048 }
            goto L_0x0059
        L_0x0044:
            r9 = move-exception
            r2 = r4
            goto L_0x00d8
        L_0x0048:
            r5 = move-exception
            goto L_0x0050
        L_0x004a:
            r9 = move-exception
            goto L_0x00d8
        L_0x004d:
            r4 = move-exception
            r5 = r4
            r4 = r2
        L_0x0050:
            java.lang.String r6 = "AppCompatSpinner"
            java.lang.String r7 = "Could not read android:spinnerMode"
            android.util.Log.i(r6, r7, r5)     // Catch:{ all -> 0x0044 }
            if (r4 == 0) goto L_0x005c
        L_0x0059:
            r4.recycle()
        L_0x005c:
            r4 = 1
            if (r3 == 0) goto L_0x009c
            if (r3 == r4) goto L_0x0062
            goto L_0x00ac
        L_0x0062:
            androidx.appcompat.widget.AppCompatSpinner$d r3 = new androidx.appcompat.widget.AppCompatSpinner$d
            android.content.Context r5 = r8.f209f
            r3.<init>(r5, r10, r11)
            android.content.Context r5 = r8.f209f
            int[] r6 = p176d.p178b.C4825j.Spinner
            d.b.p.r0 r1 = p176d.p178b.p187p.C4991r0.m15539o(r5, r10, r6, r11, r1)
            int r5 = p176d.p178b.C4825j.Spinner_android_dropDownWidth
            r6 = -2
            int r5 = r1.mo10609i(r5, r6)
            r8.f214k = r5
            int r5 = p176d.p178b.C4825j.Spinner_android_popupBackground
            android.graphics.drawable.Drawable r5 = r1.mo10605e(r5)
            android.widget.PopupWindow r6 = r3.f18092F
            r6.setBackgroundDrawable(r5)
            int r5 = p176d.p178b.C4825j.Spinner_android_prompt
            java.lang.String r5 = r0.getString(r5)
            r3.f223I = r5
            android.content.res.TypedArray r1 = r1.f18227b
            r1.recycle()
            r8.f213j = r3
            d.b.p.r r1 = new d.b.p.r
            r1.<init>(r8, r8, r3)
            r8.f210g = r1
            goto L_0x00ac
        L_0x009c:
            androidx.appcompat.widget.AppCompatSpinner$b r1 = new androidx.appcompat.widget.AppCompatSpinner$b
            r1.<init>()
            r8.f213j = r1
            int r3 = p176d.p178b.C4825j.Spinner_android_prompt
            java.lang.String r3 = r0.getString(r3)
            r1.mo287e(r3)
        L_0x00ac:
            int r1 = p176d.p178b.C4825j.Spinner_android_entries
            java.lang.CharSequence[] r1 = r0.getTextArray(r1)
            if (r1 == 0) goto L_0x00c4
            android.widget.ArrayAdapter r3 = new android.widget.ArrayAdapter
            r5 = 17367048(0x1090008, float:2.5162948E-38)
            r3.<init>(r9, r5, r1)
            int r9 = p176d.p178b.C4822g.support_simple_spinner_dropdown_item
            r3.setDropDownViewResource(r9)
            r8.setAdapter((android.widget.SpinnerAdapter) r3)
        L_0x00c4:
            r0.recycle()
            r8.f212i = r4
            android.widget.SpinnerAdapter r9 = r8.f211h
            if (r9 == 0) goto L_0x00d2
            r8.setAdapter((android.widget.SpinnerAdapter) r9)
            r8.f211h = r2
        L_0x00d2:
            d.b.p.e r9 = r8.f208e
            r9.mo10458d(r10, r11)
            return
        L_0x00d8:
            if (r2 == 0) goto L_0x00dd
            r2.recycle()
        L_0x00dd:
            throw r9
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.AppCompatSpinner.<init>(android.content.Context, android.util.AttributeSet, int):void");
    }

    /* renamed from: a */
    public int mo252a(SpinnerAdapter spinnerAdapter, Drawable drawable) {
        int i = 0;
        if (spinnerAdapter == null) {
            return 0;
        }
        int makeMeasureSpec = View.MeasureSpec.makeMeasureSpec(getMeasuredWidth(), 0);
        int makeMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(getMeasuredHeight(), 0);
        int max = Math.max(0, getSelectedItemPosition());
        int min = Math.min(spinnerAdapter.getCount(), max + 15);
        View view = null;
        int i2 = 0;
        for (int max2 = Math.max(0, max - (15 - (min - max))); max2 < min; max2++) {
            int itemViewType = spinnerAdapter.getItemViewType(max2);
            if (itemViewType != i) {
                view = null;
                i = itemViewType;
            }
            view = spinnerAdapter.getView(max2, view, this);
            if (view.getLayoutParams() == null) {
                view.setLayoutParams(new ViewGroup.LayoutParams(-2, -2));
            }
            view.measure(makeMeasureSpec, makeMeasureSpec2);
            i2 = Math.max(i2, view.getMeasuredWidth());
        }
        if (drawable == null) {
            return i2;
        }
        drawable.getPadding(this.f215l);
        Rect rect = this.f215l;
        return i2 + rect.left + rect.right;
    }

    /* renamed from: b */
    public void mo253b() {
        this.f213j.mo292j(getTextDirection(), getTextAlignment());
    }

    public void drawableStateChanged() {
        super.drawableStateChanged();
        C4952e eVar = this.f208e;
        if (eVar != null) {
            eVar.mo10455a();
        }
    }

    public int getDropDownHorizontalOffset() {
        C0032f fVar = this.f213j;
        return fVar != null ? fVar.mo283a() : super.getDropDownHorizontalOffset();
    }

    public int getDropDownVerticalOffset() {
        C0032f fVar = this.f213j;
        return fVar != null ? fVar.mo293k() : super.getDropDownVerticalOffset();
    }

    public int getDropDownWidth() {
        return this.f213j != null ? this.f214k : super.getDropDownWidth();
    }

    public final C0032f getInternalPopup() {
        return this.f213j;
    }

    public Drawable getPopupBackground() {
        C0032f fVar = this.f213j;
        return fVar != null ? fVar.mo285d() : super.getPopupBackground();
    }

    public Context getPopupContext() {
        return this.f209f;
    }

    public CharSequence getPrompt() {
        C0032f fVar = this.f213j;
        return fVar != null ? fVar.mo294l() : super.getPrompt();
    }

    public ColorStateList getSupportBackgroundTintList() {
        C4952e eVar = this.f208e;
        if (eVar != null) {
            return eVar.mo10456b();
        }
        return null;
    }

    public PorterDuff.Mode getSupportBackgroundTintMode() {
        C4952e eVar = this.f208e;
        if (eVar != null) {
            return eVar.mo10457c();
        }
        return null;
    }

    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        C0032f fVar = this.f213j;
        if (fVar != null && fVar.mo284b0()) {
            this.f213j.dismiss();
        }
    }

    public void onMeasure(int i, int i2) {
        super.onMeasure(i, i2);
        if (this.f213j != null && View.MeasureSpec.getMode(i) == Integer.MIN_VALUE) {
            setMeasuredDimension(Math.min(Math.max(getMeasuredWidth(), mo252a(getAdapter(), getBackground())), View.MeasureSpec.getSize(i)), getMeasuredHeight());
        }
    }

    public void onRestoreInstanceState(Parcelable parcelable) {
        ViewTreeObserver viewTreeObserver;
        C0030e eVar = (C0030e) parcelable;
        super.onRestoreInstanceState(eVar.getSuperState());
        if (eVar.f233e && (viewTreeObserver = getViewTreeObserver()) != null) {
            viewTreeObserver.addOnGlobalLayoutListener(new C0023a());
        }
    }

    public Parcelable onSaveInstanceState() {
        C0030e eVar = new C0030e(super.onSaveInstanceState());
        C0032f fVar = this.f213j;
        eVar.f233e = fVar != null && fVar.mo284b0();
        return eVar;
    }

    public boolean onTouchEvent(MotionEvent motionEvent) {
        C4937b0 b0Var = this.f210g;
        if (b0Var == null || !b0Var.onTouch(this, motionEvent)) {
            return super.onTouchEvent(motionEvent);
        }
        return true;
    }

    public boolean performClick() {
        C0032f fVar = this.f213j;
        if (fVar == null) {
            return super.performClick();
        }
        if (fVar.mo284b0()) {
            return true;
        }
        mo253b();
        return true;
    }

    public void setAdapter(SpinnerAdapter spinnerAdapter) {
        if (!this.f212i) {
            this.f211h = spinnerAdapter;
            return;
        }
        super.setAdapter(spinnerAdapter);
        if (this.f213j != null) {
            Context context = this.f209f;
            if (context == null) {
                context = getContext();
            }
            this.f213j.mo295m(new C0025c(spinnerAdapter, context.getTheme()));
        }
    }

    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        C4952e eVar = this.f208e;
        if (eVar != null) {
            eVar.mo10459e();
        }
    }

    public void setBackgroundResource(int i) {
        super.setBackgroundResource(i);
        C4952e eVar = this.f208e;
        if (eVar != null) {
            eVar.mo10460f(i);
        }
    }

    public void setDropDownHorizontalOffset(int i) {
        C0032f fVar = this.f213j;
        if (fVar != null) {
            fVar.mo290h(i);
            this.f213j.mo291i(i);
            return;
        }
        super.setDropDownHorizontalOffset(i);
    }

    public void setDropDownVerticalOffset(int i) {
        C0032f fVar = this.f213j;
        if (fVar != null) {
            fVar.mo289g(i);
        } else {
            super.setDropDownVerticalOffset(i);
        }
    }

    public void setDropDownWidth(int i) {
        if (this.f213j != null) {
            this.f214k = i;
        } else {
            super.setDropDownWidth(i);
        }
    }

    public void setPopupBackgroundDrawable(Drawable drawable) {
        C0032f fVar = this.f213j;
        if (fVar != null) {
            fVar.mo288f(drawable);
        } else {
            super.setPopupBackgroundDrawable(drawable);
        }
    }

    public void setPopupBackgroundResource(int i) {
        setPopupBackgroundDrawable(C4879a.m15208b(getPopupContext(), i));
    }

    public void setPrompt(CharSequence charSequence) {
        C0032f fVar = this.f213j;
        if (fVar != null) {
            fVar.mo287e(charSequence);
        } else {
            super.setPrompt(charSequence);
        }
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        C4952e eVar = this.f208e;
        if (eVar != null) {
            eVar.mo10462h(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        C4952e eVar = this.f208e;
        if (eVar != null) {
            eVar.mo10463i(mode);
        }
    }
}
