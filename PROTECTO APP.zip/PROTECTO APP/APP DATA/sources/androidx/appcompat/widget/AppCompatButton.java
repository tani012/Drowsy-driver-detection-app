package androidx.appcompat.widget;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.view.ActionMode;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.Button;
import p176d.p178b.p179k.C4851q;
import p176d.p178b.p187p.C4952e;
import p176d.p178b.p187p.C4987p0;
import p176d.p178b.p187p.C4994t;
import p176d.p219i.p233l.C5694b;

public class AppCompatButton extends Button implements C5694b {

    /* renamed from: e */
    public final C4952e f200e;

    /* renamed from: f */
    public final C4994t f201f;

    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public AppCompatButton(android.content.Context r2, android.util.AttributeSet r3) {
        /*
            r1 = this;
            int r0 = p176d.p178b.C4816a.buttonStyle
            p176d.p178b.p187p.C4985o0.m15532a(r2)
            r1.<init>(r2, r3, r0)
            android.content.Context r2 = r1.getContext()
            p176d.p178b.p187p.C4981m0.m15526a(r1, r2)
            d.b.p.e r2 = new d.b.p.e
            r2.<init>(r1)
            r1.f200e = r2
            r2.mo10458d(r3, r0)
            d.b.p.t r2 = new d.b.p.t
            r2.<init>(r1)
            r1.f201f = r2
            r2.mo10619e(r3, r0)
            d.b.p.t r2 = r1.f201f
            r2.mo10617b()
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.AppCompatButton.<init>(android.content.Context, android.util.AttributeSet):void");
    }

    public void drawableStateChanged() {
        super.drawableStateChanged();
        C4952e eVar = this.f200e;
        if (eVar != null) {
            eVar.mo10455a();
        }
        C4994t tVar = this.f201f;
        if (tVar != null) {
            tVar.mo10617b();
        }
    }

    public int getAutoSizeMaxTextSize() {
        if (C5694b.f20026a) {
            return super.getAutoSizeMaxTextSize();
        }
        C4994t tVar = this.f201f;
        if (tVar != null) {
            return Math.round(tVar.f18241i.f18277e);
        }
        return -1;
    }

    public int getAutoSizeMinTextSize() {
        if (C5694b.f20026a) {
            return super.getAutoSizeMinTextSize();
        }
        C4994t tVar = this.f201f;
        if (tVar != null) {
            return Math.round(tVar.f18241i.f18276d);
        }
        return -1;
    }

    public int getAutoSizeStepGranularity() {
        if (C5694b.f20026a) {
            return super.getAutoSizeStepGranularity();
        }
        C4994t tVar = this.f201f;
        if (tVar != null) {
            return Math.round(tVar.f18241i.f18275c);
        }
        return -1;
    }

    public int[] getAutoSizeTextAvailableSizes() {
        if (C5694b.f20026a) {
            return super.getAutoSizeTextAvailableSizes();
        }
        C4994t tVar = this.f201f;
        return tVar != null ? tVar.f18241i.f18278f : new int[0];
    }

    @SuppressLint({"WrongConstant"})
    public int getAutoSizeTextType() {
        if (C5694b.f20026a) {
            return super.getAutoSizeTextType() == 1 ? 1 : 0;
        }
        C4994t tVar = this.f201f;
        if (tVar != null) {
            return tVar.f18241i.f18273a;
        }
        return 0;
    }

    public ColorStateList getSupportBackgroundTintList() {
        C4952e eVar = this.f200e;
        if (eVar != null) {
            return eVar.mo10456b();
        }
        return null;
    }

    public PorterDuff.Mode getSupportBackgroundTintMode() {
        C4952e eVar = this.f200e;
        if (eVar != null) {
            return eVar.mo10457c();
        }
        return null;
    }

    public ColorStateList getSupportCompoundDrawablesTintList() {
        C4987p0 p0Var = this.f201f.f18240h;
        if (p0Var != null) {
            return p0Var.f18214a;
        }
        return null;
    }

    public PorterDuff.Mode getSupportCompoundDrawablesTintMode() {
        C4987p0 p0Var = this.f201f.f18240h;
        if (p0Var != null) {
            return p0Var.f18215b;
        }
        return null;
    }

    public void onInitializeAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        super.onInitializeAccessibilityEvent(accessibilityEvent);
        accessibilityEvent.setClassName(Button.class.getName());
    }

    public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo accessibilityNodeInfo) {
        super.onInitializeAccessibilityNodeInfo(accessibilityNodeInfo);
        accessibilityNodeInfo.setClassName(Button.class.getName());
    }

    public void onLayout(boolean z, int i, int i2, int i3, int i4) {
        super.onLayout(z, i, i2, i3, i4);
        C4994t tVar = this.f201f;
        if (tVar != null && !C5694b.f20026a) {
            tVar.f18241i.mo10659a();
        }
    }

    public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
        super.onTextChanged(charSequence, i, i2, i3);
        C4994t tVar = this.f201f;
        if (tVar != null && !C5694b.f20026a && tVar.mo10618d()) {
            this.f201f.f18241i.mo10659a();
        }
    }

    public void setAutoSizeTextTypeUniformWithConfiguration(int i, int i2, int i3, int i4) {
        if (C5694b.f20026a) {
            super.setAutoSizeTextTypeUniformWithConfiguration(i, i2, i3, i4);
            return;
        }
        C4994t tVar = this.f201f;
        if (tVar != null) {
            tVar.mo10621g(i, i2, i3, i4);
        }
    }

    public void setAutoSizeTextTypeUniformWithPresetSizes(int[] iArr, int i) {
        if (C5694b.f20026a) {
            super.setAutoSizeTextTypeUniformWithPresetSizes(iArr, i);
            return;
        }
        C4994t tVar = this.f201f;
        if (tVar != null) {
            tVar.mo10622h(iArr, i);
        }
    }

    public void setAutoSizeTextTypeWithDefaults(int i) {
        if (C5694b.f20026a) {
            super.setAutoSizeTextTypeWithDefaults(i);
            return;
        }
        C4994t tVar = this.f201f;
        if (tVar != null) {
            tVar.mo10623i(i);
        }
    }

    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        C4952e eVar = this.f200e;
        if (eVar != null) {
            eVar.mo10459e();
        }
    }

    public void setBackgroundResource(int i) {
        super.setBackgroundResource(i);
        C4952e eVar = this.f200e;
        if (eVar != null) {
            eVar.mo10460f(i);
        }
    }

    public void setCustomSelectionActionModeCallback(ActionMode.Callback callback) {
        super.setCustomSelectionActionModeCallback(C4851q.C4862i.m15115a1(this, callback));
    }

    public void setSupportAllCaps(boolean z) {
        C4994t tVar = this.f201f;
        if (tVar != null) {
            tVar.f18233a.setAllCaps(z);
        }
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        C4952e eVar = this.f200e;
        if (eVar != null) {
            eVar.mo10462h(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        C4952e eVar = this.f200e;
        if (eVar != null) {
            eVar.mo10463i(mode);
        }
    }

    public void setSupportCompoundDrawablesTintList(ColorStateList colorStateList) {
        this.f201f.mo10624j(colorStateList);
        this.f201f.mo10617b();
    }

    public void setSupportCompoundDrawablesTintMode(PorterDuff.Mode mode) {
        this.f201f.mo10625k(mode);
        this.f201f.mo10617b();
    }

    public void setTextAppearance(Context context, int i) {
        super.setTextAppearance(context, i);
        C4994t tVar = this.f201f;
        if (tVar != null) {
            tVar.mo10620f(context, i);
        }
    }

    public void setTextSize(int i, float f) {
        boolean z = C5694b.f20026a;
        if (z) {
            super.setTextSize(i, f);
            return;
        }
        C4994t tVar = this.f201f;
        if (tVar != null && !z && !tVar.mo10618d()) {
            tVar.f18241i.mo10662f(i, f);
        }
    }
}
