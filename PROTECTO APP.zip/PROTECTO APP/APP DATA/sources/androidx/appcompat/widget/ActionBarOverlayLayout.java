package androidx.appcompat.widget;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.AttributeSet;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewPropertyAnimator;
import android.view.Window;
import android.view.WindowInsets;
import android.widget.OverScroller;
import p002b.p008b.p009a.p010a.C0131a;
import p176d.p178b.C4816a;
import p176d.p178b.C4821f;
import p176d.p178b.p179k.C4827a0;
import p176d.p178b.p185o.p186i.C4922m;
import p176d.p178b.p187p.C5005w;
import p176d.p178b.p187p.C5007x;
import p176d.p219i.p223e.C5611b;
import p176d.p219i.p231k.C5657f;
import p176d.p219i.p231k.C5658g;
import p176d.p219i.p231k.C5659h;
import p176d.p219i.p231k.C5662k;
import p176d.p219i.p231k.C5676s;

@SuppressLint({"UnknownNullness"})
public class ActionBarOverlayLayout extends ViewGroup implements C5005w, C5657f, C5658g {

    /* renamed from: J */
    public static final int[] f145J = {C4816a.actionBarSize, 16842841};

    /* renamed from: A */
    public C5676s f146A;

    /* renamed from: B */
    public C5676s f147B;

    /* renamed from: C */
    public C0016d f148C;

    /* renamed from: D */
    public OverScroller f149D;

    /* renamed from: E */
    public ViewPropertyAnimator f150E;

    /* renamed from: F */
    public final AnimatorListenerAdapter f151F;

    /* renamed from: G */
    public final Runnable f152G;

    /* renamed from: H */
    public final Runnable f153H;

    /* renamed from: I */
    public final C5659h f154I;

    /* renamed from: e */
    public int f155e;

    /* renamed from: f */
    public int f156f = 0;

    /* renamed from: g */
    public ContentFrameLayout f157g;

    /* renamed from: h */
    public ActionBarContainer f158h;

    /* renamed from: i */
    public C5007x f159i;

    /* renamed from: j */
    public Drawable f160j;

    /* renamed from: k */
    public boolean f161k;

    /* renamed from: l */
    public boolean f162l;

    /* renamed from: m */
    public boolean f163m;

    /* renamed from: n */
    public boolean f164n;

    /* renamed from: o */
    public boolean f165o;

    /* renamed from: p */
    public int f166p;

    /* renamed from: q */
    public int f167q;

    /* renamed from: r */
    public final Rect f168r = new Rect();

    /* renamed from: s */
    public final Rect f169s = new Rect();

    /* renamed from: t */
    public final Rect f170t = new Rect();

    /* renamed from: u */
    public final Rect f171u = new Rect();

    /* renamed from: v */
    public final Rect f172v = new Rect();

    /* renamed from: w */
    public final Rect f173w = new Rect();

    /* renamed from: x */
    public final Rect f174x = new Rect();

    /* renamed from: y */
    public C5676s f175y;

    /* renamed from: z */
    public C5676s f176z;

    /* renamed from: androidx.appcompat.widget.ActionBarOverlayLayout$a */
    public class C0013a extends AnimatorListenerAdapter {
        public C0013a() {
        }

        public void onAnimationCancel(Animator animator) {
            ActionBarOverlayLayout actionBarOverlayLayout = ActionBarOverlayLayout.this;
            actionBarOverlayLayout.f150E = null;
            actionBarOverlayLayout.f165o = false;
        }

        public void onAnimationEnd(Animator animator) {
            ActionBarOverlayLayout actionBarOverlayLayout = ActionBarOverlayLayout.this;
            actionBarOverlayLayout.f150E = null;
            actionBarOverlayLayout.f165o = false;
        }
    }

    /* renamed from: androidx.appcompat.widget.ActionBarOverlayLayout$b */
    public class C0014b implements Runnable {
        public C0014b() {
        }

        public void run() {
            ActionBarOverlayLayout.this.mo141q();
            ActionBarOverlayLayout actionBarOverlayLayout = ActionBarOverlayLayout.this;
            actionBarOverlayLayout.f150E = actionBarOverlayLayout.f158h.animate().translationY(0.0f).setListener(ActionBarOverlayLayout.this.f151F);
        }
    }

    /* renamed from: androidx.appcompat.widget.ActionBarOverlayLayout$c */
    public class C0015c implements Runnable {
        public C0015c() {
        }

        public void run() {
            ActionBarOverlayLayout.this.mo141q();
            ActionBarOverlayLayout actionBarOverlayLayout = ActionBarOverlayLayout.this;
            actionBarOverlayLayout.f150E = actionBarOverlayLayout.f158h.animate().translationY((float) (-ActionBarOverlayLayout.this.f158h.getHeight())).setListener(ActionBarOverlayLayout.this.f151F);
        }
    }

    /* renamed from: androidx.appcompat.widget.ActionBarOverlayLayout$d */
    public interface C0016d {
    }

    /* renamed from: androidx.appcompat.widget.ActionBarOverlayLayout$e */
    public static class C0017e extends ViewGroup.MarginLayoutParams {
        public C0017e(int i, int i2) {
            super(i, i2);
        }

        public C0017e(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
        }

        public C0017e(ViewGroup.LayoutParams layoutParams) {
            super(layoutParams);
        }
    }

    public ActionBarOverlayLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        C5676s sVar = C5676s.f19969b;
        this.f175y = sVar;
        this.f176z = sVar;
        this.f146A = sVar;
        this.f147B = sVar;
        this.f151F = new C0013a();
        this.f152G = new C0014b();
        this.f153H = new C0015c();
        mo142r(context);
        this.f154I = new C5659h();
    }

    /* renamed from: a */
    public void mo102a(Menu menu, C4922m.C4923a aVar) {
        mo143s();
        this.f159i.mo10628a(menu, aVar);
    }

    /* renamed from: b */
    public boolean mo103b() {
        mo143s();
        return this.f159i.mo10629b();
    }

    /* renamed from: c */
    public void mo104c() {
        mo143s();
        this.f159i.mo10630c();
    }

    public boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof C0017e;
    }

    /* renamed from: d */
    public boolean mo106d() {
        mo143s();
        return this.f159i.mo10632d();
    }

    public void draw(Canvas canvas) {
        int i;
        super.draw(canvas);
        if (this.f160j != null && !this.f161k) {
            if (this.f158h.getVisibility() == 0) {
                i = (int) (this.f158h.getTranslationY() + ((float) this.f158h.getBottom()) + 0.5f);
            } else {
                i = 0;
            }
            this.f160j.setBounds(0, i, getWidth(), this.f160j.getIntrinsicHeight() + i);
            this.f160j.draw(canvas);
        }
    }

    /* renamed from: e */
    public boolean mo108e() {
        mo143s();
        return this.f159i.mo10633e();
    }

    /* renamed from: f */
    public boolean mo109f() {
        mo143s();
        return this.f159i.mo10634f();
    }

    public boolean fitSystemWindows(Rect rect) {
        return super.fitSystemWindows(rect);
    }

    /* renamed from: g */
    public boolean mo111g() {
        mo143s();
        return this.f159i.mo10635g();
    }

    public ViewGroup.LayoutParams generateDefaultLayoutParams() {
        return new C0017e(-1, -1);
    }

    public ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new C0017e(getContext(), attributeSet);
    }

    public ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return new C0017e(layoutParams);
    }

    public int getActionBarHideOffset() {
        ActionBarContainer actionBarContainer = this.f158h;
        if (actionBarContainer != null) {
            return -((int) actionBarContainer.getTranslationY());
        }
        return 0;
    }

    public int getNestedScrollAxes() {
        C5659h hVar = this.f154I;
        return hVar.f19946b | hVar.f19945a;
    }

    public CharSequence getTitle() {
        mo143s();
        return this.f159i.getTitle();
    }

    /* renamed from: h */
    public void mo118h(View view, View view2, int i, int i2) {
        if (i2 == 0) {
            onNestedScrollAccepted(view, view2, i);
        }
    }

    /* renamed from: i */
    public void mo119i(View view, int i) {
        if (i == 0) {
            onStopNestedScroll(view);
        }
    }

    /* renamed from: j */
    public void mo120j(View view, int i, int i2, int[] iArr, int i3) {
        if (i3 == 0) {
            onNestedPreScroll(view, i, i2, iArr);
        }
    }

    /* renamed from: k */
    public void mo121k(int i) {
        mo143s();
        if (i == 2) {
            this.f159i.mo10649s();
        } else if (i == 5) {
            this.f159i.mo10654t();
        } else if (i == 109) {
            setOverlayMode(true);
        }
    }

    /* renamed from: l */
    public void mo122l() {
        mo143s();
        this.f159i.mo10638h();
    }

    /* renamed from: m */
    public void mo123m(View view, int i, int i2, int i3, int i4, int i5, int[] iArr) {
        if (i5 == 0) {
            onNestedScroll(view, i, i2, i3, i4);
        }
    }

    /* renamed from: n */
    public void mo124n(View view, int i, int i2, int i3, int i4, int i5) {
        if (i5 == 0) {
            onNestedScroll(view, i, i2, i3, i4);
        }
    }

    /* renamed from: o */
    public boolean mo125o(View view, View view2, int i, int i2) {
        return i2 == 0 && onStartNestedScroll(view, view2, i);
    }

    public WindowInsets onApplyWindowInsets(WindowInsets windowInsets) {
        mo143s();
        if (windowInsets != null) {
            C5676s sVar = new C5676s(windowInsets);
            boolean p = mo140p(this.f158h, new Rect(sVar.mo11833b(), sVar.mo11835d(), sVar.mo11834c(), sVar.mo11832a()), true, true, false, true);
            C5662k.m16825b(this, sVar, this.f168r);
            Rect rect = this.f168r;
            C5676s g = sVar.f19970a.mo11844g(rect.left, rect.top, rect.right, rect.bottom);
            this.f175y = g;
            boolean z = true;
            if (!this.f176z.equals(g)) {
                this.f176z = this.f175y;
                p = true;
            }
            if (!this.f169s.equals(this.f168r)) {
                this.f169s.set(this.f168r);
            } else {
                z = p;
            }
            if (z) {
                requestLayout();
            }
            return sVar.f19970a.mo11850a().f19970a.mo11847c().f19970a.mo11846b().mo11838g();
        }
        throw null;
    }

    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        mo142r(getContext());
        C5662k.m16842s(this);
    }

    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        mo141q();
    }

    public void onLayout(boolean z, int i, int i2, int i3, int i4) {
        int childCount = getChildCount();
        int paddingLeft = getPaddingLeft();
        int paddingTop = getPaddingTop();
        for (int i5 = 0; i5 < childCount; i5++) {
            View childAt = getChildAt(i5);
            if (childAt.getVisibility() != 8) {
                C0017e eVar = (C0017e) childAt.getLayoutParams();
                int measuredWidth = childAt.getMeasuredWidth();
                int measuredHeight = childAt.getMeasuredHeight();
                int i6 = eVar.leftMargin + paddingLeft;
                int i7 = eVar.topMargin + paddingTop;
                childAt.layout(i6, i7, measuredWidth + i6, measuredHeight + i7);
            }
        }
    }

    public void onMeasure(int i, int i2) {
        int i3;
        C5676s sVar;
        mo143s();
        measureChildWithMargins(this.f158h, i, 0, i2, 0);
        C0017e eVar = (C0017e) this.f158h.getLayoutParams();
        int max = Math.max(0, this.f158h.getMeasuredWidth() + eVar.leftMargin + eVar.rightMargin);
        int max2 = Math.max(0, this.f158h.getMeasuredHeight() + eVar.topMargin + eVar.bottomMargin);
        int combineMeasuredStates = View.combineMeasuredStates(0, this.f158h.getMeasuredState());
        boolean z = (C5662k.m16833j(this) & 256) != 0;
        if (z) {
            i3 = this.f155e;
            if (this.f163m && this.f158h.getTabContainer() != null) {
                i3 += this.f155e;
            }
        } else {
            i3 = this.f158h.getVisibility() != 8 ? this.f158h.getMeasuredHeight() : 0;
        }
        this.f170t.set(this.f168r);
        C5676s sVar2 = this.f175y;
        this.f146A = sVar2;
        if (this.f162l || z) {
            C5611b a = C5611b.m16750a(this.f146A.mo11833b(), this.f146A.mo11835d() + i3, this.f146A.mo11834c(), this.f146A.mo11832a() + 0);
            C5676s sVar3 = this.f146A;
            C5676s.C5679c bVar = Build.VERSION.SDK_INT >= 29 ? new C5676s.C5678b(sVar3) : new C5676s.C5677a(sVar3);
            bVar.mo11841c(a);
            sVar = bVar.mo11840a();
        } else {
            Rect rect = this.f170t;
            rect.top += i3;
            rect.bottom += 0;
            sVar = sVar2.f19970a.mo11844g(0, i3, 0, 0);
        }
        this.f146A = sVar;
        mo140p(this.f157g, this.f170t, true, true, true, true);
        if (!this.f147B.equals(this.f146A)) {
            C5676s sVar4 = this.f146A;
            this.f147B = sVar4;
            ContentFrameLayout contentFrameLayout = this.f157g;
            WindowInsets g = sVar4.mo11838g();
            if (g != null && !contentFrameLayout.dispatchApplyWindowInsets(g).equals(g)) {
                new C5676s(g);
            }
        }
        measureChildWithMargins(this.f157g, i, 0, i2, 0);
        C0017e eVar2 = (C0017e) this.f157g.getLayoutParams();
        int max3 = Math.max(max, this.f157g.getMeasuredWidth() + eVar2.leftMargin + eVar2.rightMargin);
        int max4 = Math.max(max2, this.f157g.getMeasuredHeight() + eVar2.topMargin + eVar2.bottomMargin);
        int combineMeasuredStates2 = View.combineMeasuredStates(combineMeasuredStates, this.f157g.getMeasuredState());
        setMeasuredDimension(View.resolveSizeAndState(Math.max(getPaddingRight() + getPaddingLeft() + max3, getSuggestedMinimumWidth()), i, combineMeasuredStates2), View.resolveSizeAndState(Math.max(getPaddingBottom() + getPaddingTop() + max4, getSuggestedMinimumHeight()), i2, combineMeasuredStates2 << 16));
    }

    public boolean onNestedFling(View view, float f, float f2, boolean z) {
        boolean z2 = false;
        if (!this.f164n || !z) {
            return false;
        }
        this.f149D.fling(0, 0, 0, (int) f2, 0, 0, Integer.MIN_VALUE, Integer.MAX_VALUE);
        if (this.f149D.getFinalY() > this.f158h.getHeight()) {
            z2 = true;
        }
        if (z2) {
            mo141q();
            this.f153H.run();
        } else {
            mo141q();
            this.f152G.run();
        }
        this.f165o = true;
        return true;
    }

    public boolean onNestedPreFling(View view, float f, float f2) {
        return false;
    }

    public void onNestedPreScroll(View view, int i, int i2, int[] iArr) {
    }

    public void onNestedScroll(View view, int i, int i2, int i3, int i4) {
        int i5 = this.f166p + i2;
        this.f166p = i5;
        setActionBarHideOffset(i5);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:2:0x0011, code lost:
        r1 = (p176d.p178b.p179k.C4827a0) r1;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void onNestedScrollAccepted(android.view.View r1, android.view.View r2, int r3) {
        /*
            r0 = this;
            d.i.k.h r1 = r0.f154I
            r1.f19945a = r3
            int r1 = r0.getActionBarHideOffset()
            r0.f166p = r1
            r0.mo141q()
            androidx.appcompat.widget.ActionBarOverlayLayout$d r1 = r0.f148C
            if (r1 == 0) goto L_0x001d
            d.b.k.a0 r1 = (p176d.p178b.p179k.C4827a0) r1
            d.b.o.g r2 = r1.f17581v
            if (r2 == 0) goto L_0x001d
            r2.mo10053a()
            r2 = 0
            r1.f17581v = r2
        L_0x001d:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.ActionBarOverlayLayout.onNestedScrollAccepted(android.view.View, android.view.View, int):void");
    }

    public boolean onStartNestedScroll(View view, View view2, int i) {
        if ((i & 2) == 0 || this.f158h.getVisibility() != 0) {
            return false;
        }
        return this.f164n;
    }

    public void onStopNestedScroll(View view) {
        if (this.f164n && !this.f165o) {
            if (this.f166p <= this.f158h.getHeight()) {
                mo141q();
                postDelayed(this.f152G, 600);
            } else {
                mo141q();
                postDelayed(this.f153H, 600);
            }
        }
        C0016d dVar = this.f148C;
        if (dVar != null && ((C4827a0) dVar) == null) {
            throw null;
        }
    }

    public void onWindowSystemUiVisibilityChanged(int i) {
        super.onWindowSystemUiVisibilityChanged(i);
        mo143s();
        int i2 = this.f167q ^ i;
        this.f167q = i;
        boolean z = (i & 4) == 0;
        boolean z2 = (i & 256) != 0;
        C0016d dVar = this.f148C;
        if (dVar != null) {
            ((C4827a0) dVar).f17576q = !z2;
            if (z || !z2) {
                C4827a0 a0Var = (C4827a0) this.f148C;
                if (a0Var.f17578s) {
                    a0Var.f17578s = false;
                    a0Var.mo9838n(true);
                }
            } else {
                C4827a0 a0Var2 = (C4827a0) dVar;
                if (!a0Var2.f17578s) {
                    a0Var2.f17578s = true;
                    a0Var2.mo9838n(true);
                }
            }
        }
        if ((i2 & 256) != 0 && this.f148C != null) {
            C5662k.m16842s(this);
        }
    }

    public void onWindowVisibilityChanged(int i) {
        super.onWindowVisibilityChanged(i);
        this.f156f = i;
        C0016d dVar = this.f148C;
        if (dVar != null) {
            ((C4827a0) dVar).f17575p = i;
        }
    }

    /* renamed from: p */
    public final boolean mo140p(View view, Rect rect, boolean z, boolean z2, boolean z3, boolean z4) {
        boolean z5;
        int i;
        int i2;
        int i3;
        int i4;
        C0017e eVar = (C0017e) view.getLayoutParams();
        if (!z || eVar.leftMargin == (i4 = rect.left)) {
            z5 = false;
        } else {
            eVar.leftMargin = i4;
            z5 = true;
        }
        if (z2 && eVar.topMargin != (i3 = rect.top)) {
            eVar.topMargin = i3;
            z5 = true;
        }
        if (z4 && eVar.rightMargin != (i2 = rect.right)) {
            eVar.rightMargin = i2;
            z5 = true;
        }
        if (!z3 || eVar.bottomMargin == (i = rect.bottom)) {
            return z5;
        }
        eVar.bottomMargin = i;
        return true;
    }

    /* renamed from: q */
    public void mo141q() {
        removeCallbacks(this.f152G);
        removeCallbacks(this.f153H);
        ViewPropertyAnimator viewPropertyAnimator = this.f150E;
        if (viewPropertyAnimator != null) {
            viewPropertyAnimator.cancel();
        }
    }

    /* renamed from: r */
    public final void mo142r(Context context) {
        TypedArray obtainStyledAttributes = getContext().getTheme().obtainStyledAttributes(f145J);
        boolean z = false;
        this.f155e = obtainStyledAttributes.getDimensionPixelSize(0, 0);
        Drawable drawable = obtainStyledAttributes.getDrawable(1);
        this.f160j = drawable;
        setWillNotDraw(drawable == null);
        obtainStyledAttributes.recycle();
        if (context.getApplicationInfo().targetSdkVersion < 19) {
            z = true;
        }
        this.f161k = z;
        this.f149D = new OverScroller(context);
    }

    /* renamed from: s */
    public void mo143s() {
        C5007x xVar;
        if (this.f157g == null) {
            this.f157g = (ContentFrameLayout) findViewById(C4821f.action_bar_activity_content);
            this.f158h = (ActionBarContainer) findViewById(C4821f.action_bar_container);
            View findViewById = findViewById(C4821f.action_bar);
            if (findViewById instanceof C5007x) {
                xVar = (C5007x) findViewById;
            } else if (findViewById instanceof Toolbar) {
                xVar = ((Toolbar) findViewById).getWrapper();
            } else {
                StringBuilder m = C0131a.m379m("Can't make a decor toolbar out of ");
                m.append(findViewById.getClass().getSimpleName());
                throw new IllegalStateException(m.toString());
            }
            this.f159i = xVar;
        }
    }

    public void setActionBarHideOffset(int i) {
        mo141q();
        this.f158h.setTranslationY((float) (-Math.max(0, Math.min(i, this.f158h.getHeight()))));
    }

    public void setActionBarVisibilityCallback(C0016d dVar) {
        this.f148C = dVar;
        if (getWindowToken() != null) {
            ((C4827a0) this.f148C).f17575p = this.f156f;
            int i = this.f167q;
            if (i != 0) {
                onWindowSystemUiVisibilityChanged(i);
                C5662k.m16842s(this);
            }
        }
    }

    public void setHasNonEmbeddedTabs(boolean z) {
        this.f163m = z;
    }

    public void setHideOnContentScrollEnabled(boolean z) {
        if (z != this.f164n) {
            this.f164n = z;
            if (!z) {
                mo141q();
                setActionBarHideOffset(0);
            }
        }
    }

    public void setIcon(int i) {
        mo143s();
        this.f159i.setIcon(i);
    }

    public void setIcon(Drawable drawable) {
        mo143s();
        this.f159i.setIcon(drawable);
    }

    public void setLogo(int i) {
        mo143s();
        this.f159i.mo10646p(i);
    }

    public void setOverlayMode(boolean z) {
        this.f162l = z;
        this.f161k = z && getContext().getApplicationInfo().targetSdkVersion < 19;
    }

    public void setShowingForActionMode(boolean z) {
    }

    public void setUiOptions(int i) {
    }

    public void setWindowCallback(Window.Callback callback) {
        mo143s();
        this.f159i.setWindowCallback(callback);
    }

    public void setWindowTitle(CharSequence charSequence) {
        mo143s();
        this.f159i.setWindowTitle(charSequence);
    }

    public boolean shouldDelayChildPressedState() {
        return false;
    }
}
