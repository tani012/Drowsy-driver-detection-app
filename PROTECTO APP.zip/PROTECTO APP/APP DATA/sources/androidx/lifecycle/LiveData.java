package androidx.lifecycle;

import java.util.Map;
import p002b.p008b.p009a.p010a.C0131a;
import p176d.p188c.p189a.p190a.C5012a;
import p176d.p188c.p189a.p191b.C5017b;
import p176d.p242n.C5781e;
import p176d.p242n.C5784f;
import p176d.p242n.C5786h;
import p176d.p242n.C5787i;
import p176d.p242n.C5793n;

public abstract class LiveData<T> {

    /* renamed from: j */
    public static final Object f609j = new Object();

    /* renamed from: a */
    public final Object f610a;

    /* renamed from: b */
    public C5017b<C5793n<? super T>, LiveData<T>.c> f611b;

    /* renamed from: c */
    public int f612c;

    /* renamed from: d */
    public volatile Object f613d;

    /* renamed from: e */
    public volatile Object f614e;

    /* renamed from: f */
    public int f615f;

    /* renamed from: g */
    public boolean f616g;

    /* renamed from: h */
    public boolean f617h;

    /* renamed from: i */
    public final Runnable f618i;

    public class LifecycleBoundObserver extends LiveData<T>.c implements C5784f {

        /* renamed from: e */
        public final C5786h f619e;

        public LifecycleBoundObserver(C5786h hVar, C5793n<? super T> nVar) {
            super(nVar);
            this.f619e = hVar;
        }

        /* renamed from: d */
        public void mo9d(C5786h hVar, C5781e.C5782a aVar) {
            if (((C5787i) this.f619e.mo1a()).f20306b == C5781e.C5783b.DESTROYED) {
                LiveData.this.mo816g(this.f622a);
            } else {
                mo822a(mo820h());
            }
        }

        /* renamed from: f */
        public void mo818f() {
            ((C5787i) this.f619e.mo1a()).f20305a.mo10689r(this);
        }

        /* renamed from: g */
        public boolean mo819g(C5786h hVar) {
            return this.f619e == hVar;
        }

        /* renamed from: h */
        public boolean mo820h() {
            return ((C5787i) this.f619e.mo1a()).f20306b.compareTo(C5781e.C5783b.STARTED) >= 0;
        }
    }

    /* renamed from: androidx.lifecycle.LiveData$a */
    public class C0078a implements Runnable {
        public C0078a() {
        }

        public void run() {
            Object obj;
            synchronized (LiveData.this.f610a) {
                obj = LiveData.this.f614e;
                LiveData.this.f614e = LiveData.f609j;
            }
            LiveData.this.mo817h(obj);
        }
    }

    /* renamed from: androidx.lifecycle.LiveData$b */
    public class C0079b extends LiveData<T>.c {
        public C0079b(LiveData liveData, C5793n<? super T> nVar) {
            super(nVar);
        }

        /* renamed from: h */
        public boolean mo820h() {
            return true;
        }
    }

    /* renamed from: androidx.lifecycle.LiveData$c */
    public abstract class C0080c {

        /* renamed from: a */
        public final C5793n<? super T> f622a;

        /* renamed from: b */
        public boolean f623b;

        /* renamed from: c */
        public int f624c = -1;

        public C0080c(C5793n<? super T> nVar) {
            this.f622a = nVar;
        }

        /* renamed from: a */
        public void mo822a(boolean z) {
            if (z != this.f623b) {
                this.f623b = z;
                int i = 1;
                boolean z2 = LiveData.this.f612c == 0;
                LiveData liveData = LiveData.this;
                int i2 = liveData.f612c;
                if (!this.f623b) {
                    i = -1;
                }
                liveData.f612c = i2 + i;
                if (z2 && this.f623b) {
                    LiveData.this.mo814e();
                }
                LiveData liveData2 = LiveData.this;
                if (liveData2.f612c == 0 && !this.f623b) {
                    liveData2.mo815f();
                }
                if (this.f623b) {
                    LiveData.this.mo812c(this);
                }
            }
        }

        /* renamed from: f */
        public void mo818f() {
        }

        /* renamed from: g */
        public boolean mo819g(C5786h hVar) {
            return false;
        }

        /* renamed from: h */
        public abstract boolean mo820h();
    }

    public LiveData() {
        this.f610a = new Object();
        this.f611b = new C5017b<>();
        this.f612c = 0;
        this.f614e = f609j;
        this.f618i = new C0078a();
        this.f613d = f609j;
        this.f615f = -1;
    }

    public LiveData(T t) {
        this.f610a = new Object();
        this.f611b = new C5017b<>();
        this.f612c = 0;
        this.f614e = f609j;
        this.f618i = new C0078a();
        this.f613d = t;
        this.f615f = 0;
    }

    /* renamed from: a */
    public static void m289a(String str) {
        if (!C5012a.m15650c().f18305a.mo10683a()) {
            throw new IllegalStateException(C0131a.m374h("Cannot invoke ", str, " on a background thread"));
        }
    }

    /* renamed from: b */
    public final void mo811b(LiveData<T>.c cVar) {
        if (cVar.f623b) {
            if (!cVar.mo820h()) {
                cVar.mo822a(false);
                return;
            }
            int i = cVar.f624c;
            int i2 = this.f615f;
            if (i < i2) {
                cVar.f624c = i2;
                cVar.f622a.mo837a(this.f613d);
            }
        }
    }

    /* renamed from: c */
    public void mo812c(LiveData<T>.c cVar) {
        if (this.f616g) {
            this.f617h = true;
            return;
        }
        this.f616g = true;
        do {
            this.f617h = false;
            if (cVar == null) {
                C5017b<K, V>.d g = this.f611b.mo10691g();
                while (g.hasNext()) {
                    mo811b((C0080c) ((Map.Entry) g.next()).getValue());
                    if (this.f617h) {
                        break;
                    }
                }
            } else {
                mo811b(cVar);
                cVar = null;
            }
        } while (this.f617h);
        this.f616g = false;
    }

    /* renamed from: d */
    public void mo813d(C5786h hVar, C5793n<? super T> nVar) {
        m289a("observe");
        if (((C5787i) hVar.mo1a()).f20306b != C5781e.C5783b.DESTROYED) {
            LifecycleBoundObserver lifecycleBoundObserver = new LifecycleBoundObserver(hVar, nVar);
            C0080c p = this.f611b.mo10688p(nVar, lifecycleBoundObserver);
            if (p != null && !p.mo819g(hVar)) {
                throw new IllegalArgumentException("Cannot add the same observer with different lifecycles");
            } else if (p == null) {
                hVar.mo1a().mo12114a(lifecycleBoundObserver);
            }
        }
    }

    /* renamed from: e */
    public void mo814e() {
    }

    /* renamed from: f */
    public void mo815f() {
    }

    /* renamed from: g */
    public void mo816g(C5793n<? super T> nVar) {
        m289a("removeObserver");
        C0080c r = this.f611b.mo10689r(nVar);
        if (r != null) {
            r.mo818f();
            r.mo822a(false);
        }
    }

    /* renamed from: h */
    public abstract void mo817h(T t);
}
