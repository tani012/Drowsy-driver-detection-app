package androidx.lifecycle;

import p176d.p242n.C5780d;
import p176d.p242n.C5781e;
import p176d.p242n.C5784f;
import p176d.p242n.C5786h;
import p176d.p242n.C5791l;

public class SingleGeneratedAdapterObserver implements C5784f {

    /* renamed from: a */
    public final C5780d f633a;

    public SingleGeneratedAdapterObserver(C5780d dVar) {
        this.f633a = dVar;
    }

    /* renamed from: d */
    public void mo9d(C5786h hVar, C5781e.C5782a aVar) {
        this.f633a.mo12113a(hVar, aVar, false, (C5791l) null);
        this.f633a.mo12113a(hVar, aVar, true, (C5791l) null);
    }
}
