package androidx.lifecycle;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import p176d.p242n.C5781e;
import p176d.p242n.C5784f;
import p176d.p242n.C5786h;
import p176d.p242n.C5787i;
import p176d.p242n.C5798q;
import p176d.p242n.C5800r;
import p176d.p242n.C5805t;
import p176d.p242n.C5806u;
import p176d.p245p.C5813a;
import p176d.p245p.C5817c;

public final class SavedStateHandleController implements C5784f {

    /* renamed from: a */
    public final String f628a;

    /* renamed from: b */
    public boolean f629b = false;

    /* renamed from: c */
    public final C5798q f630c;

    /* renamed from: androidx.lifecycle.SavedStateHandleController$a */
    public static final class C0082a implements C5813a.C5814a {
        /* renamed from: a */
        public void mo824a(C5817c cVar) {
            if (cVar instanceof C5806u) {
                C5805t i = ((C5806u) cVar).mo4i();
                C5813a d = cVar.mo3d();
                if (i != null) {
                    Iterator it = new HashSet(i.f20324a.keySet()).iterator();
                    while (it.hasNext()) {
                        SavedStateHandleController.m307a(i.f20324a.get((String) it.next()), d, cVar.mo1a());
                    }
                    if (!new HashSet(i.f20324a.keySet()).isEmpty()) {
                        d.mo12153b(C0082a.class);
                        return;
                    }
                    return;
                }
                throw null;
            }
            throw new IllegalStateException("Internal error: OnRecreation should be registered only on componentsthat implement ViewModelStoreOwner");
        }
    }

    public SavedStateHandleController(String str, C5798q qVar) {
        this.f628a = str;
        this.f630c = qVar;
    }

    /* renamed from: a */
    public static void m307a(C5800r rVar, C5813a aVar, C5781e eVar) {
        Object obj;
        Map<String, Object> map = rVar.f20320a;
        if (map == null) {
            obj = null;
        } else {
            synchronized (map) {
                obj = rVar.f20320a.get("androidx.lifecycle.savedstate.vm.tag");
            }
        }
        SavedStateHandleController savedStateHandleController = (SavedStateHandleController) obj;
        if (savedStateHandleController != null && !savedStateHandleController.f629b) {
            savedStateHandleController.mo823f(aVar, eVar);
            m308g(aVar, eVar);
        }
    }

    /* renamed from: g */
    public static void m308g(final C5813a aVar, final C5781e eVar) {
        C5781e.C5783b bVar = ((C5787i) eVar).f20306b;
        if (bVar != C5781e.C5783b.INITIALIZED) {
            if (!(bVar.compareTo(C5781e.C5783b.STARTED) >= 0)) {
                eVar.mo12114a(new C5784f() {
                    /* renamed from: d */
                    public void mo9d(C5786h hVar, C5781e.C5782a aVar) {
                        if (aVar == C5781e.C5782a.ON_START) {
                            ((C5787i) eVar).f20305a.mo10689r(this);
                            aVar.mo12153b(C0082a.class);
                        }
                    }
                });
                return;
            }
        }
        aVar.mo12153b(C0082a.class);
    }

    /* renamed from: d */
    public void mo9d(C5786h hVar, C5781e.C5782a aVar) {
        if (aVar == C5781e.C5782a.ON_DESTROY) {
            this.f629b = false;
            ((C5787i) hVar.mo1a()).f20305a.mo10689r(this);
        }
    }

    /* renamed from: f */
    public void mo823f(C5813a aVar, C5781e eVar) {
        if (!this.f629b) {
            this.f629b = true;
            eVar.mo12114a(this);
            if (aVar.f20331a.mo10688p(this.f628a, this.f630c.f20318b) != null) {
                throw new IllegalArgumentException("SavedStateProvider with the given key is already registered");
            }
            return;
        }
        throw new IllegalStateException("Already attached to lifecycleOwner");
    }
}
