package androidx.lifecycle;

import p176d.p242n.C5776b;
import p176d.p242n.C5781e;
import p176d.p242n.C5784f;
import p176d.p242n.C5786h;

public class ReflectiveGenericLifecycleObserver implements C5784f {

    /* renamed from: a */
    public final Object f626a;

    /* renamed from: b */
    public final C5776b.C5777a f627b;

    public ReflectiveGenericLifecycleObserver(Object obj) {
        this.f626a = obj;
        this.f627b = C5776b.f20292c.mo12103b(obj.getClass());
    }

    /* renamed from: d */
    public void mo9d(C5786h hVar, C5781e.C5782a aVar) {
        C5776b.C5777a aVar2 = this.f627b;
        Object obj = this.f626a;
        C5776b.C5777a.m17103a(aVar2.f20295a.get(aVar), hVar, aVar, obj);
        C5776b.C5777a.m17103a(aVar2.f20295a.get(C5781e.C5782a.ON_ANY), hVar, aVar, obj);
    }
}
