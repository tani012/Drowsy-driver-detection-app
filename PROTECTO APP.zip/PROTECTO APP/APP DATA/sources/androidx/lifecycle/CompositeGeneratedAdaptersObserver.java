package androidx.lifecycle;

import p176d.p242n.C5780d;
import p176d.p242n.C5781e;
import p176d.p242n.C5784f;
import p176d.p242n.C5786h;
import p176d.p242n.C5791l;

public class CompositeGeneratedAdaptersObserver implements C5784f {

    /* renamed from: a */
    public final C5780d[] f606a;

    public CompositeGeneratedAdaptersObserver(C5780d[] dVarArr) {
        this.f606a = dVarArr;
    }

    /* renamed from: d */
    public void mo9d(C5786h hVar, C5781e.C5782a aVar) {
        C5791l lVar = new C5791l();
        for (C5780d a : this.f606a) {
            a.mo12113a(hVar, aVar, false, lVar);
        }
        for (C5780d a2 : this.f606a) {
            a2.mo12113a(hVar, aVar, true, lVar);
        }
    }
}
