package androidx.lifecycle;

import p176d.p242n.C5779c;
import p176d.p242n.C5781e;
import p176d.p242n.C5784f;
import p176d.p242n.C5786h;

public class FullLifecycleObserverAdapter implements C5784f {

    /* renamed from: a */
    public final C5779c f607a;

    /* renamed from: b */
    public final C5784f f608b;

    public FullLifecycleObserverAdapter(C5779c cVar, C5784f fVar) {
        this.f607a = cVar;
        this.f608b = fVar;
    }

    /* renamed from: d */
    public void mo9d(C5786h hVar, C5781e.C5782a aVar) {
        switch (aVar.ordinal()) {
            case 0:
                this.f607a.mo12108c(hVar);
                break;
            case 1:
                this.f607a.onStart(hVar);
                break;
            case 2:
                this.f607a.mo12107b(hVar);
                break;
            case 3:
                this.f607a.mo12109e(hVar);
                break;
            case 4:
                this.f607a.onStop(hVar);
                break;
            case 5:
                this.f607a.onDestroy(hVar);
                break;
            case 6:
                throw new IllegalArgumentException("ON_ANY must not been send by anybody");
        }
        C5784f fVar = this.f608b;
        if (fVar != null) {
            fVar.mo9d(hVar, aVar);
        }
    }
}
