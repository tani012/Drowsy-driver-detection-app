package androidx.lifecycle;

import p176d.p242n.C5781e;
import p176d.p242n.C5784f;
import p176d.p242n.C5786h;

public final class Lifecycling$1 implements C5784f {
    /* renamed from: d */
    public void mo9d(C5786h hVar, C5781e.C5782a aVar) {
        throw null;
    }
}
