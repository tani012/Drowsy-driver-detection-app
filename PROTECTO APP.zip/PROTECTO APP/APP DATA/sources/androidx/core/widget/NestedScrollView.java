package androidx.core.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.Log;
import android.util.TypedValue;
import android.view.FocusFinder;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.accessibility.AccessibilityEvent;
import android.view.animation.AnimationUtils;
import android.widget.EdgeEffect;
import android.widget.FrameLayout;
import android.widget.OverScroller;
import android.widget.ScrollView;
import androidx.appcompat.app.AlertController;
import java.util.ArrayList;
import p002b.p008b.p009a.p010a.C0131a;
import p176d.p178b.p179k.C4844k;
import p176d.p178b.p179k.C4851q;
import p176d.p219i.p231k.C5649a;
import p176d.p219i.p231k.C5656e;
import p176d.p219i.p231k.C5657f;
import p176d.p219i.p231k.C5658g;
import p176d.p219i.p231k.C5659h;
import p176d.p219i.p231k.C5662k;
import p176d.p219i.p231k.p232t.C5686b;

public class NestedScrollView extends FrameLayout implements C5658g {

    /* renamed from: E */
    public static final C0069a f511E = new C0069a();

    /* renamed from: F */
    public static final int[] f512F = {16843130};

    /* renamed from: A */
    public final C5659h f513A;

    /* renamed from: B */
    public final C5656e f514B;

    /* renamed from: C */
    public float f515C;

    /* renamed from: D */
    public C0070b f516D;

    /* renamed from: e */
    public long f517e;

    /* renamed from: f */
    public final Rect f518f = new Rect();

    /* renamed from: g */
    public OverScroller f519g = new OverScroller(getContext());

    /* renamed from: h */
    public EdgeEffect f520h;

    /* renamed from: i */
    public EdgeEffect f521i;

    /* renamed from: j */
    public int f522j;

    /* renamed from: k */
    public boolean f523k = true;

    /* renamed from: l */
    public boolean f524l = false;

    /* renamed from: m */
    public View f525m = null;

    /* renamed from: n */
    public boolean f526n = false;

    /* renamed from: o */
    public VelocityTracker f527o;

    /* renamed from: p */
    public boolean f528p;

    /* renamed from: q */
    public boolean f529q = true;

    /* renamed from: r */
    public int f530r;

    /* renamed from: s */
    public int f531s;

    /* renamed from: t */
    public int f532t;

    /* renamed from: u */
    public int f533u = -1;

    /* renamed from: v */
    public final int[] f534v = new int[2];

    /* renamed from: w */
    public final int[] f535w = new int[2];

    /* renamed from: x */
    public int f536x;

    /* renamed from: y */
    public int f537y;

    /* renamed from: z */
    public C0071c f538z;

    /* renamed from: androidx.core.widget.NestedScrollView$a */
    public static class C0069a extends C5649a {
        /* renamed from: a */
        public void mo752a(View view, AccessibilityEvent accessibilityEvent) {
            this.f19931a.onInitializeAccessibilityEvent(view, accessibilityEvent);
            NestedScrollView nestedScrollView = (NestedScrollView) view;
            accessibilityEvent.setClassName(ScrollView.class.getName());
            accessibilityEvent.setScrollable(nestedScrollView.getScrollRange() > 0);
            accessibilityEvent.setScrollX(nestedScrollView.getScrollX());
            accessibilityEvent.setScrollY(nestedScrollView.getScrollY());
            accessibilityEvent.setMaxScrollX(nestedScrollView.getScrollX());
            accessibilityEvent.setMaxScrollY(nestedScrollView.getScrollRange());
        }

        /* renamed from: b */
        public void mo753b(View view, C5686b bVar) {
            int scrollRange;
            this.f19931a.onInitializeAccessibilityNodeInfo(view, bVar.f19985a);
            NestedScrollView nestedScrollView = (NestedScrollView) view;
            bVar.f19985a.setClassName(ScrollView.class.getName());
            if (nestedScrollView.isEnabled() && (scrollRange = nestedScrollView.getScrollRange()) > 0) {
                bVar.f19985a.setScrollable(true);
                if (nestedScrollView.getScrollY() > 0) {
                    bVar.mo11855a(C5686b.C5687a.f19989e);
                    bVar.mo11855a(C5686b.C5687a.f19990f);
                }
                if (nestedScrollView.getScrollY() < scrollRange) {
                    bVar.mo11855a(C5686b.C5687a.f19988d);
                    bVar.mo11855a(C5686b.C5687a.f19991g);
                }
            }
        }

        /* renamed from: c */
        public boolean mo754c(View view, int i, Bundle bundle) {
            int min;
            if (super.mo754c(view, i, bundle)) {
                return true;
            }
            NestedScrollView nestedScrollView = (NestedScrollView) view;
            if (!nestedScrollView.isEnabled()) {
                return false;
            }
            if (i != 4096) {
                if (i == 8192 || i == 16908344) {
                    min = Math.max(nestedScrollView.getScrollY() - ((nestedScrollView.getHeight() - nestedScrollView.getPaddingBottom()) - nestedScrollView.getPaddingTop()), 0);
                    if (min == nestedScrollView.getScrollY()) {
                        return false;
                    }
                    nestedScrollView.mo674A(0 - nestedScrollView.getScrollX(), min - nestedScrollView.getScrollY(), 250, true);
                    return true;
                } else if (i != 16908346) {
                    return false;
                }
            }
            min = Math.min(nestedScrollView.getScrollY() + ((nestedScrollView.getHeight() - nestedScrollView.getPaddingBottom()) - nestedScrollView.getPaddingTop()), nestedScrollView.getScrollRange());
            if (min == nestedScrollView.getScrollY()) {
                return false;
            }
            nestedScrollView.mo674A(0 - nestedScrollView.getScrollX(), min - nestedScrollView.getScrollY(), 250, true);
            return true;
        }
    }

    /* renamed from: androidx.core.widget.NestedScrollView$b */
    public interface C0070b {
    }

    /* renamed from: androidx.core.widget.NestedScrollView$c */
    public static class C0071c extends View.BaseSavedState {
        public static final Parcelable.Creator<C0071c> CREATOR = new C0072a();

        /* renamed from: e */
        public int f539e;

        /* renamed from: androidx.core.widget.NestedScrollView$c$a */
        public class C0072a implements Parcelable.Creator<C0071c> {
            public Object createFromParcel(Parcel parcel) {
                return new C0071c(parcel);
            }

            public Object[] newArray(int i) {
                return new C0071c[i];
            }
        }

        public C0071c(Parcel parcel) {
            super(parcel);
            this.f539e = parcel.readInt();
        }

        public C0071c(Parcelable parcelable) {
            super(parcelable);
        }

        public String toString() {
            StringBuilder m = C0131a.m379m("HorizontalScrollView.SavedState{");
            m.append(Integer.toHexString(System.identityHashCode(this)));
            m.append(" scrollPosition=");
            m.append(this.f539e);
            m.append("}");
            return m.toString();
        }

        public void writeToParcel(Parcel parcel, int i) {
            super.writeToParcel(parcel, i);
            parcel.writeInt(this.f539e);
        }
    }

    public NestedScrollView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, 0);
        setFocusable(true);
        setDescendantFocusability(262144);
        setWillNotDraw(false);
        ViewConfiguration viewConfiguration = ViewConfiguration.get(getContext());
        this.f530r = viewConfiguration.getScaledTouchSlop();
        this.f531s = viewConfiguration.getScaledMinimumFlingVelocity();
        this.f532t = viewConfiguration.getScaledMaximumFlingVelocity();
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, f512F, 0, 0);
        setFillViewport(obtainStyledAttributes.getBoolean(0, false));
        obtainStyledAttributes.recycle();
        this.f513A = new C5659h();
        this.f514B = new C5656e(this);
        setNestedScrollingEnabled(true);
        C5662k.m16844u(this, f511E);
    }

    /* renamed from: c */
    public static int m204c(int i, int i2, int i3) {
        if (i2 >= i3 || i < 0) {
            return 0;
        }
        return i2 + i > i3 ? i3 - i2 : i;
    }

    private float getVerticalScrollFactorCompat() {
        if (this.f515C == 0.0f) {
            TypedValue typedValue = new TypedValue();
            Context context = getContext();
            if (context.getTheme().resolveAttribute(16842829, typedValue, true)) {
                this.f515C = typedValue.getDimension(context.getResources().getDisplayMetrics());
            } else {
                throw new IllegalStateException("Expected theme to define listPreferredItemHeight.");
            }
        }
        return this.f515C;
    }

    /* renamed from: r */
    public static boolean m205r(View view, View view2) {
        if (view == view2) {
            return true;
        }
        ViewParent parent = view.getParent();
        return (parent instanceof ViewGroup) && m205r((View) parent, view2);
    }

    /* renamed from: A */
    public final void mo674A(int i, int i2, int i3, boolean z) {
        if (getChildCount() != 0) {
            if (AnimationUtils.currentAnimationTimeMillis() - this.f517e > 250) {
                View childAt = getChildAt(0);
                FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
                int scrollY = getScrollY();
                OverScroller overScroller = this.f519g;
                int scrollX = getScrollX();
                overScroller.startScroll(scrollX, scrollY, 0, Math.max(0, Math.min(i2 + scrollY, Math.max(0, ((childAt.getHeight() + layoutParams.topMargin) + layoutParams.bottomMargin) - ((getHeight() - getPaddingTop()) - getPaddingBottom())))) - scrollY, i3);
                mo749x(z);
            } else {
                if (!this.f519g.isFinished()) {
                    mo677a();
                }
                scrollBy(i, i2);
            }
            this.f517e = AnimationUtils.currentAnimationTimeMillis();
        }
    }

    /* renamed from: B */
    public boolean mo675B(int i, int i2) {
        boolean z;
        C5656e eVar = this.f514B;
        if (!(eVar.mo11810b(i2) != null)) {
            if (!eVar.f19943d) {
                return false;
            }
            ViewParent parent = eVar.f19942c.getParent();
            View view = eVar.f19942c;
            while (parent != null) {
                View view2 = eVar.f19942c;
                boolean z2 = parent instanceof C5657f;
                if (z2) {
                    z = ((C5657f) parent).mo125o(view, view2, i, i2);
                } else {
                    if (i2 == 0) {
                        try {
                            z = parent.onStartNestedScroll(view, view2, i);
                        } catch (AbstractMethodError e) {
                            Log.e("ViewParentCompat", "ViewParent " + parent + " does not implement interface method onStartNestedScroll", e);
                        }
                    }
                    z = false;
                }
                if (z) {
                    if (i2 == 0) {
                        eVar.f19940a = parent;
                    } else if (i2 == 1) {
                        eVar.f19941b = parent;
                    }
                    View view3 = eVar.f19942c;
                    if (z2) {
                        ((C5657f) parent).mo118h(view, view3, i, i2);
                    } else if (i2 == 0) {
                        try {
                            parent.onNestedScrollAccepted(view, view3, i);
                        } catch (AbstractMethodError e2) {
                            Log.e("ViewParentCompat", "ViewParent " + parent + " does not implement interface method onNestedScrollAccepted", e2);
                        }
                    }
                } else {
                    if (parent instanceof View) {
                        view = (View) parent;
                    }
                    parent = parent.getParent();
                }
            }
            return false;
        }
        return true;
    }

    /* renamed from: C */
    public void mo676C(int i) {
        C5656e eVar = this.f514B;
        ViewParent b = eVar.mo11810b(i);
        if (b != null) {
            View view = eVar.f19942c;
            if (b instanceof C5657f) {
                ((C5657f) b).mo119i(view, i);
            } else if (i == 0) {
                try {
                    b.onStopNestedScroll(view);
                } catch (AbstractMethodError e) {
                    Log.e("ViewParentCompat", "ViewParent " + b + " does not implement interface method onStopNestedScroll", e);
                }
            }
            if (i == 0) {
                eVar.f19940a = null;
            } else if (i == 1) {
                eVar.f19941b = null;
            }
        }
    }

    /* renamed from: a */
    public final void mo677a() {
        this.f519g.abortAnimation();
        mo676C(1);
    }

    public void addView(View view) {
        if (getChildCount() <= 0) {
            super.addView(view);
            return;
        }
        throw new IllegalStateException("ScrollView can host only one direct child");
    }

    public void addView(View view, int i) {
        if (getChildCount() <= 0) {
            super.addView(view, i);
            return;
        }
        throw new IllegalStateException("ScrollView can host only one direct child");
    }

    public void addView(View view, int i, ViewGroup.LayoutParams layoutParams) {
        if (getChildCount() <= 0) {
            super.addView(view, i, layoutParams);
            return;
        }
        throw new IllegalStateException("ScrollView can host only one direct child");
    }

    public void addView(View view, ViewGroup.LayoutParams layoutParams) {
        if (getChildCount() <= 0) {
            super.addView(view, layoutParams);
            return;
        }
        throw new IllegalStateException("ScrollView can host only one direct child");
    }

    /* renamed from: b */
    public boolean mo682b(int i) {
        View findFocus = findFocus();
        if (findFocus == this) {
            findFocus = null;
        }
        View findNextFocus = FocusFinder.getInstance().findNextFocus(this, findFocus, i);
        int maxScrollAmount = getMaxScrollAmount();
        if (findNextFocus == null || !mo736s(findNextFocus, maxScrollAmount, getHeight())) {
            if (i == 33 && getScrollY() < maxScrollAmount) {
                maxScrollAmount = getScrollY();
            } else if (i == 130 && getChildCount() > 0) {
                View childAt = getChildAt(0);
                maxScrollAmount = Math.min((childAt.getBottom() + ((FrameLayout.LayoutParams) childAt.getLayoutParams()).bottomMargin) - ((getHeight() + getScrollY()) - getPaddingBottom()), maxScrollAmount);
            }
            if (maxScrollAmount == 0) {
                return false;
            }
            if (i != 130) {
                maxScrollAmount = -maxScrollAmount;
            }
            mo698f(maxScrollAmount);
        } else {
            findNextFocus.getDrawingRect(this.f518f);
            offsetDescendantRectToMyCoords(findNextFocus, this.f518f);
            mo698f(mo690d(this.f518f));
            findNextFocus.requestFocus(i);
        }
        if (findFocus != null && findFocus.isFocused() && (!mo736s(findFocus, 0, getHeight()))) {
            int descendantFocusability = getDescendantFocusability();
            setDescendantFocusability(131072);
            requestFocus();
            setDescendantFocusability(descendantFocusability);
        }
        return true;
    }

    public int computeHorizontalScrollExtent() {
        return super.computeHorizontalScrollExtent();
    }

    public int computeHorizontalScrollOffset() {
        return super.computeHorizontalScrollOffset();
    }

    public int computeHorizontalScrollRange() {
        return super.computeHorizontalScrollRange();
    }

    public void computeScroll() {
        EdgeEffect edgeEffect;
        if (!this.f519g.isFinished()) {
            this.f519g.computeScrollOffset();
            int currY = this.f519g.getCurrY();
            int i = currY - this.f537y;
            this.f537y = currY;
            int[] iArr = this.f535w;
            boolean z = false;
            iArr[1] = 0;
            mo697e(0, i, iArr, (int[]) null, 1);
            int i2 = i - this.f535w[1];
            int scrollRange = getScrollRange();
            if (i2 != 0) {
                int scrollY = getScrollY();
                mo747v(0, i2, getScrollX(), scrollY, 0, scrollRange, 0, 0);
                int scrollY2 = getScrollY() - scrollY;
                int i3 = i2 - scrollY2;
                int[] iArr2 = this.f535w;
                iArr2[1] = 0;
                this.f514B.mo11809a(0, scrollY2, 0, i3, this.f534v, 1, iArr2);
                i2 = i3 - this.f535w[1];
            }
            if (i2 != 0) {
                int overScrollMode = getOverScrollMode();
                if (overScrollMode == 0 || (overScrollMode == 1 && scrollRange > 0)) {
                    z = true;
                }
                if (z) {
                    mo699g();
                    if (i2 < 0) {
                        if (this.f520h.isFinished()) {
                            edgeEffect = this.f520h;
                        }
                    } else if (this.f521i.isFinished()) {
                        edgeEffect = this.f521i;
                    }
                    edgeEffect.onAbsorb((int) this.f519g.getCurrVelocity());
                }
                mo677a();
            }
            if (!this.f519g.isFinished()) {
                C5662k.m16839p(this);
            } else {
                mo676C(1);
            }
        }
    }

    public int computeVerticalScrollExtent() {
        return super.computeVerticalScrollExtent();
    }

    public int computeVerticalScrollOffset() {
        return Math.max(0, super.computeVerticalScrollOffset());
    }

    public int computeVerticalScrollRange() {
        int childCount = getChildCount();
        int height = (getHeight() - getPaddingBottom()) - getPaddingTop();
        if (childCount == 0) {
            return height;
        }
        View childAt = getChildAt(0);
        int bottom = childAt.getBottom() + ((FrameLayout.LayoutParams) childAt.getLayoutParams()).bottomMargin;
        int scrollY = getScrollY();
        int max = Math.max(0, bottom - height);
        return scrollY < 0 ? bottom - scrollY : scrollY > max ? bottom + (scrollY - max) : bottom;
    }

    /* renamed from: d */
    public int mo690d(Rect rect) {
        if (getChildCount() == 0) {
            return 0;
        }
        int height = getHeight();
        int scrollY = getScrollY();
        int i = scrollY + height;
        int verticalFadingEdgeLength = getVerticalFadingEdgeLength();
        if (rect.top > 0) {
            scrollY += verticalFadingEdgeLength;
        }
        View childAt = getChildAt(0);
        FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
        int i2 = rect.bottom < (childAt.getHeight() + layoutParams.topMargin) + layoutParams.bottomMargin ? i - verticalFadingEdgeLength : i;
        if (rect.bottom > i2 && rect.top > scrollY) {
            return Math.min((rect.height() > height ? rect.top - scrollY : rect.bottom - i2) + 0, (childAt.getBottom() + layoutParams.bottomMargin) - i);
        } else if (rect.top >= scrollY || rect.bottom >= i2) {
            return 0;
        } else {
            return Math.max(rect.height() > height ? 0 - (i2 - rect.bottom) : 0 - (scrollY - rect.top), -getScrollY());
        }
    }

    public boolean dispatchKeyEvent(KeyEvent keyEvent) {
        return super.dispatchKeyEvent(keyEvent) || mo707k(keyEvent);
    }

    public boolean dispatchNestedFling(float f, float f2, boolean z) {
        ViewParent b;
        C5656e eVar = this.f514B;
        if (!eVar.f19943d || (b = eVar.mo11810b(0)) == null) {
            return false;
        }
        return C4851q.C4862i.m15183x0(b, eVar.f19942c, f, f2, z);
    }

    public boolean dispatchNestedPreFling(float f, float f2) {
        ViewParent b;
        C5656e eVar = this.f514B;
        if (!eVar.f19943d || (b = eVar.mo11810b(0)) == null) {
            return false;
        }
        return C4851q.C4862i.m15186y0(b, eVar.f19942c, f, f2);
    }

    public boolean dispatchNestedPreScroll(int i, int i2, int[] iArr, int[] iArr2) {
        return mo697e(i, i2, iArr, iArr2, 0);
    }

    public boolean dispatchNestedScroll(int i, int i2, int i3, int i4, int[] iArr) {
        return this.f514B.mo11809a(i, i2, i3, i4, iArr, 0, (int[]) null);
    }

    public void draw(Canvas canvas) {
        int i;
        super.draw(canvas);
        if (this.f520h != null) {
            int scrollY = getScrollY();
            int i2 = 0;
            if (!this.f520h.isFinished()) {
                int save = canvas.save();
                int width = getWidth();
                int height = getHeight();
                int min = Math.min(0, scrollY);
                if (getClipToPadding()) {
                    width -= getPaddingRight() + getPaddingLeft();
                    i = getPaddingLeft() + 0;
                } else {
                    i = 0;
                }
                if (getClipToPadding()) {
                    height -= getPaddingBottom() + getPaddingTop();
                    min += getPaddingTop();
                }
                canvas.translate((float) i, (float) min);
                this.f520h.setSize(width, height);
                if (this.f520h.draw(canvas)) {
                    C5662k.m16839p(this);
                }
                canvas.restoreToCount(save);
            }
            if (!this.f521i.isFinished()) {
                int save2 = canvas.save();
                int width2 = getWidth();
                int height2 = getHeight();
                int max = Math.max(getScrollRange(), scrollY) + height2;
                if (getClipToPadding()) {
                    width2 -= getPaddingRight() + getPaddingLeft();
                    i2 = 0 + getPaddingLeft();
                }
                if (getClipToPadding()) {
                    height2 -= getPaddingBottom() + getPaddingTop();
                    max -= getPaddingBottom();
                }
                canvas.translate((float) (i2 - width2), (float) max);
                canvas.rotate(180.0f, (float) width2, 0.0f);
                this.f521i.setSize(width2, height2);
                if (this.f521i.draw(canvas)) {
                    C5662k.m16839p(this);
                }
                canvas.restoreToCount(save2);
            }
        }
    }

    /* renamed from: e */
    public boolean mo697e(int i, int i2, int[] iArr, int[] iArr2, int i3) {
        ViewParent b;
        int i4;
        int i5;
        int[] iArr3;
        int[] iArr4 = iArr2;
        C5656e eVar = this.f514B;
        if (!eVar.f19943d || (b = eVar.mo11810b(i3)) == null) {
            return false;
        }
        if (i != 0 || i2 != 0) {
            if (iArr4 != null) {
                eVar.f19942c.getLocationInWindow(iArr4);
                i5 = iArr4[0];
                i4 = iArr4[1];
            } else {
                i5 = 0;
                i4 = 0;
            }
            if (iArr == null) {
                if (eVar.f19944e == null) {
                    eVar.f19944e = new int[2];
                }
                iArr3 = eVar.f19944e;
            } else {
                iArr3 = iArr;
            }
            iArr3[0] = 0;
            iArr3[1] = 0;
            C4851q.C4862i.m15189z0(b, eVar.f19942c, i, i2, iArr3, i3);
            if (iArr4 != null) {
                eVar.f19942c.getLocationInWindow(iArr4);
                iArr4[0] = iArr4[0] - i5;
                iArr4[1] = iArr4[1] - i4;
            }
            if (iArr3[0] == 0 && iArr3[1] == 0) {
                return false;
            }
            return true;
        } else if (iArr4 == null) {
            return false;
        } else {
            iArr4[0] = 0;
            iArr4[1] = 0;
            return false;
        }
    }

    /* renamed from: f */
    public final void mo698f(int i) {
        if (i == 0) {
            return;
        }
        if (this.f529q) {
            mo674A(0, i, 250, false);
        } else {
            scrollBy(0, i);
        }
    }

    /* renamed from: g */
    public final void mo699g() {
        if (getOverScrollMode() == 2) {
            this.f520h = null;
            this.f521i = null;
        } else if (this.f520h == null) {
            Context context = getContext();
            this.f520h = new EdgeEffect(context);
            this.f521i = new EdgeEffect(context);
        }
    }

    public float getBottomFadingEdgeStrength() {
        if (getChildCount() == 0) {
            return 0.0f;
        }
        View childAt = getChildAt(0);
        int verticalFadingEdgeLength = getVerticalFadingEdgeLength();
        int bottom = ((childAt.getBottom() + ((FrameLayout.LayoutParams) childAt.getLayoutParams()).bottomMargin) - getScrollY()) - (getHeight() - getPaddingBottom());
        if (bottom < verticalFadingEdgeLength) {
            return ((float) bottom) / ((float) verticalFadingEdgeLength);
        }
        return 1.0f;
    }

    public int getMaxScrollAmount() {
        return (int) (((float) getHeight()) * 0.5f);
    }

    public int getNestedScrollAxes() {
        C5659h hVar = this.f513A;
        return hVar.f19946b | hVar.f19945a;
    }

    public int getScrollRange() {
        if (getChildCount() <= 0) {
            return 0;
        }
        View childAt = getChildAt(0);
        FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
        return Math.max(0, ((childAt.getHeight() + layoutParams.topMargin) + layoutParams.bottomMargin) - ((getHeight() - getPaddingTop()) - getPaddingBottom()));
    }

    public float getTopFadingEdgeStrength() {
        if (getChildCount() == 0) {
            return 0.0f;
        }
        int verticalFadingEdgeLength = getVerticalFadingEdgeLength();
        int scrollY = getScrollY();
        if (scrollY < verticalFadingEdgeLength) {
            return ((float) scrollY) / ((float) verticalFadingEdgeLength);
        }
        return 1.0f;
    }

    /* renamed from: h */
    public void mo118h(View view, View view2, int i, int i2) {
        C5659h hVar = this.f513A;
        if (i2 == 1) {
            hVar.f19946b = i;
        } else {
            hVar.f19945a = i;
        }
        mo675B(2, i2);
    }

    public boolean hasNestedScrollingParent() {
        return mo731q(0);
    }

    /* renamed from: i */
    public void mo119i(View view, int i) {
        C5659h hVar = this.f513A;
        if (i == 1) {
            hVar.f19946b = 0;
        } else {
            hVar.f19945a = 0;
        }
        mo676C(i);
    }

    public boolean isNestedScrollingEnabled() {
        return this.f514B.f19943d;
    }

    /* renamed from: j */
    public void mo120j(View view, int i, int i2, int[] iArr, int i3) {
        mo697e(i, i2, iArr, (int[]) null, i3);
    }

    /* JADX WARNING: Removed duplicated region for block: B:22:0x0062  */
    /* JADX WARNING: Removed duplicated region for block: B:8:0x0038  */
    /* renamed from: k */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean mo707k(android.view.KeyEvent r7) {
        /*
            r6 = this;
            android.graphics.Rect r0 = r6.f518f
            r0.setEmpty()
            int r0 = r6.getChildCount()
            r1 = 1
            r2 = 0
            if (r0 <= 0) goto L_0x0033
            android.view.View r0 = r6.getChildAt(r2)
            android.view.ViewGroup$LayoutParams r3 = r0.getLayoutParams()
            android.widget.FrameLayout$LayoutParams r3 = (android.widget.FrameLayout.LayoutParams) r3
            int r0 = r0.getHeight()
            int r4 = r3.topMargin
            int r0 = r0 + r4
            int r3 = r3.bottomMargin
            int r0 = r0 + r3
            int r3 = r6.getHeight()
            int r4 = r6.getPaddingTop()
            int r3 = r3 - r4
            int r4 = r6.getPaddingBottom()
            int r3 = r3 - r4
            if (r0 <= r3) goto L_0x0033
            r0 = r1
            goto L_0x0034
        L_0x0033:
            r0 = r2
        L_0x0034:
            r3 = 130(0x82, float:1.82E-43)
            if (r0 != 0) goto L_0x0062
            boolean r0 = r6.isFocused()
            if (r0 == 0) goto L_0x0061
            int r7 = r7.getKeyCode()
            r0 = 4
            if (r7 == r0) goto L_0x0061
            android.view.View r7 = r6.findFocus()
            if (r7 != r6) goto L_0x004c
            r7 = 0
        L_0x004c:
            android.view.FocusFinder r0 = android.view.FocusFinder.getInstance()
            android.view.View r7 = r0.findNextFocus(r6, r7, r3)
            if (r7 == 0) goto L_0x005f
            if (r7 == r6) goto L_0x005f
            boolean r7 = r7.requestFocus(r3)
            if (r7 == 0) goto L_0x005f
            goto L_0x0060
        L_0x005f:
            r1 = r2
        L_0x0060:
            return r1
        L_0x0061:
            return r2
        L_0x0062:
            int r0 = r7.getAction()
            if (r0 != 0) goto L_0x00fa
            int r0 = r7.getKeyCode()
            r4 = 19
            r5 = 33
            if (r0 == r4) goto L_0x00eb
            r4 = 20
            if (r0 == r4) goto L_0x00db
            r4 = 62
            if (r0 == r4) goto L_0x007c
            goto L_0x00fa
        L_0x007c:
            boolean r7 = r7.isShiftPressed()
            if (r7 == 0) goto L_0x0083
            goto L_0x0084
        L_0x0083:
            r5 = r3
        L_0x0084:
            if (r5 != r3) goto L_0x0088
            r7 = r1
            goto L_0x0089
        L_0x0088:
            r7 = r2
        L_0x0089:
            int r0 = r6.getHeight()
            if (r7 == 0) goto L_0x00be
            android.graphics.Rect r7 = r6.f518f
            int r3 = r6.getScrollY()
            int r3 = r3 + r0
            r7.top = r3
            int r7 = r6.getChildCount()
            if (r7 <= 0) goto L_0x00d0
            int r7 = r7 - r1
            android.view.View r7 = r6.getChildAt(r7)
            android.view.ViewGroup$LayoutParams r1 = r7.getLayoutParams()
            android.widget.FrameLayout$LayoutParams r1 = (android.widget.FrameLayout.LayoutParams) r1
            int r7 = r7.getBottom()
            int r1 = r1.bottomMargin
            int r7 = r7 + r1
            int r1 = r6.getPaddingBottom()
            int r1 = r1 + r7
            android.graphics.Rect r7 = r6.f518f
            int r3 = r7.top
            int r3 = r3 + r0
            if (r3 <= r1) goto L_0x00d0
            int r1 = r1 - r0
            goto L_0x00ce
        L_0x00be:
            android.graphics.Rect r7 = r6.f518f
            int r1 = r6.getScrollY()
            int r1 = r1 - r0
            r7.top = r1
            android.graphics.Rect r7 = r6.f518f
            int r1 = r7.top
            if (r1 >= 0) goto L_0x00d0
            r1 = r2
        L_0x00ce:
            r7.top = r1
        L_0x00d0:
            android.graphics.Rect r7 = r6.f518f
            int r1 = r7.top
            int r0 = r0 + r1
            r7.bottom = r0
            r6.mo750y(r5, r1, r0)
            goto L_0x00fa
        L_0x00db:
            boolean r7 = r7.isAltPressed()
            if (r7 != 0) goto L_0x00e6
            boolean r2 = r6.mo682b(r3)
            goto L_0x00fa
        L_0x00e6:
            boolean r2 = r6.mo730p(r3)
            goto L_0x00fa
        L_0x00eb:
            boolean r7 = r7.isAltPressed()
            if (r7 != 0) goto L_0x00f6
            boolean r2 = r6.mo682b(r5)
            goto L_0x00fa
        L_0x00f6:
            boolean r2 = r6.mo730p(r5)
        L_0x00fa:
            return r2
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.core.widget.NestedScrollView.mo707k(android.view.KeyEvent):boolean");
    }

    /* renamed from: l */
    public void mo708l(int i) {
        if (getChildCount() > 0) {
            this.f519g.fling(getScrollX(), getScrollY(), 0, i, 0, 0, Integer.MIN_VALUE, Integer.MAX_VALUE, 0, 0);
            mo749x(true);
        }
    }

    /* renamed from: m */
    public void mo123m(View view, int i, int i2, int i3, int i4, int i5, int[] iArr) {
        mo745t(i4, i5, iArr);
    }

    public void measureChild(View view, int i, int i2) {
        ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
        view.measure(FrameLayout.getChildMeasureSpec(i, getPaddingRight() + getPaddingLeft(), layoutParams.width), View.MeasureSpec.makeMeasureSpec(0, 0));
    }

    public void measureChildWithMargins(View view, int i, int i2, int i3, int i4) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        view.measure(FrameLayout.getChildMeasureSpec(i, getPaddingRight() + getPaddingLeft() + marginLayoutParams.leftMargin + marginLayoutParams.rightMargin + i2, marginLayoutParams.width), View.MeasureSpec.makeMeasureSpec(marginLayoutParams.topMargin + marginLayoutParams.bottomMargin, 0));
    }

    /* renamed from: n */
    public void mo124n(View view, int i, int i2, int i3, int i4, int i5) {
        mo745t(i4, i5, (int[]) null);
    }

    /* renamed from: o */
    public boolean mo125o(View view, View view2, int i, int i2) {
        return (i & 2) != 0;
    }

    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        this.f524l = false;
    }

    public boolean onGenericMotionEvent(MotionEvent motionEvent) {
        if ((motionEvent.getSource() & 2) != 0 && motionEvent.getAction() == 8 && !this.f526n) {
            float axisValue = motionEvent.getAxisValue(9);
            if (axisValue != 0.0f) {
                int scrollRange = getScrollRange();
                int scrollY = getScrollY();
                int verticalScrollFactorCompat = scrollY - ((int) (axisValue * getVerticalScrollFactorCompat()));
                if (verticalScrollFactorCompat < 0) {
                    scrollRange = 0;
                } else if (verticalScrollFactorCompat <= scrollRange) {
                    scrollRange = verticalScrollFactorCompat;
                }
                if (scrollRange != scrollY) {
                    super.scrollTo(getScrollX(), scrollRange);
                    return true;
                }
            }
        }
        return false;
    }

    /* JADX WARNING: Removed duplicated region for block: B:47:0x00e1  */
    /* JADX WARNING: Removed duplicated region for block: B:48:0x00e7  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean onInterceptTouchEvent(android.view.MotionEvent r12) {
        /*
            r11 = this;
            int r0 = r12.getAction()
            r1 = 2
            r2 = 1
            if (r0 != r1) goto L_0x000d
            boolean r3 = r11.f526n
            if (r3 == 0) goto L_0x000d
            return r2
        L_0x000d:
            r0 = r0 & 255(0xff, float:3.57E-43)
            r3 = 0
            if (r0 == 0) goto L_0x00aa
            r4 = -1
            if (r0 == r2) goto L_0x0085
            if (r0 == r1) goto L_0x0024
            r1 = 3
            if (r0 == r1) goto L_0x0085
            r1 = 6
            if (r0 == r1) goto L_0x001f
            goto L_0x0113
        L_0x001f:
            r11.mo746u(r12)
            goto L_0x0113
        L_0x0024:
            int r0 = r11.f533u
            if (r0 != r4) goto L_0x002a
            goto L_0x0113
        L_0x002a:
            int r5 = r12.findPointerIndex(r0)
            if (r5 != r4) goto L_0x004d
            java.lang.StringBuilder r12 = new java.lang.StringBuilder
            r12.<init>()
            java.lang.String r1 = "Invalid pointerId="
            r12.append(r1)
            r12.append(r0)
            java.lang.String r0 = " in onInterceptTouchEvent"
            r12.append(r0)
            java.lang.String r12 = r12.toString()
            java.lang.String r0 = "NestedScrollView"
            android.util.Log.e(r0, r12)
            goto L_0x0113
        L_0x004d:
            float r0 = r12.getY(r5)
            int r0 = (int) r0
            int r4 = r11.f522j
            int r4 = r0 - r4
            int r4 = java.lang.Math.abs(r4)
            int r5 = r11.f530r
            if (r4 <= r5) goto L_0x0113
            int r4 = r11.getNestedScrollAxes()
            r1 = r1 & r4
            if (r1 != 0) goto L_0x0113
            r11.f526n = r2
            r11.f522j = r0
            android.view.VelocityTracker r0 = r11.f527o
            if (r0 != 0) goto L_0x0073
            android.view.VelocityTracker r0 = android.view.VelocityTracker.obtain()
            r11.f527o = r0
        L_0x0073:
            android.view.VelocityTracker r0 = r11.f527o
            r0.addMovement(r12)
            r11.f536x = r3
            android.view.ViewParent r12 = r11.getParent()
            if (r12 == 0) goto L_0x0113
            r12.requestDisallowInterceptTouchEvent(r2)
            goto L_0x0113
        L_0x0085:
            r11.f526n = r3
            r11.f533u = r4
            r11.mo748w()
            android.widget.OverScroller r4 = r11.f519g
            int r5 = r11.getScrollX()
            int r6 = r11.getScrollY()
            r7 = 0
            r8 = 0
            r9 = 0
            int r10 = r11.getScrollRange()
            boolean r12 = r4.springBack(r5, r6, r7, r8, r9, r10)
            if (r12 == 0) goto L_0x00a6
            p176d.p219i.p231k.C5662k.m16839p(r11)
        L_0x00a6:
            r11.mo676C(r3)
            goto L_0x0113
        L_0x00aa:
            float r0 = r12.getY()
            int r0 = (int) r0
            float r4 = r12.getX()
            int r4 = (int) r4
            int r5 = r11.getChildCount()
            if (r5 <= 0) goto L_0x00de
            int r5 = r11.getScrollY()
            android.view.View r6 = r11.getChildAt(r3)
            int r7 = r6.getTop()
            int r7 = r7 - r5
            if (r0 < r7) goto L_0x00de
            int r7 = r6.getBottom()
            int r7 = r7 - r5
            if (r0 >= r7) goto L_0x00de
            int r5 = r6.getLeft()
            if (r4 < r5) goto L_0x00de
            int r5 = r6.getRight()
            if (r4 >= r5) goto L_0x00de
            r4 = r2
            goto L_0x00df
        L_0x00de:
            r4 = r3
        L_0x00df:
            if (r4 != 0) goto L_0x00e7
            r11.f526n = r3
            r11.mo748w()
            goto L_0x0113
        L_0x00e7:
            r11.f522j = r0
            int r0 = r12.getPointerId(r3)
            r11.f533u = r0
            android.view.VelocityTracker r0 = r11.f527o
            if (r0 != 0) goto L_0x00fa
            android.view.VelocityTracker r0 = android.view.VelocityTracker.obtain()
            r11.f527o = r0
            goto L_0x00fd
        L_0x00fa:
            r0.clear()
        L_0x00fd:
            android.view.VelocityTracker r0 = r11.f527o
            r0.addMovement(r12)
            android.widget.OverScroller r12 = r11.f519g
            r12.computeScrollOffset()
            android.widget.OverScroller r12 = r11.f519g
            boolean r12 = r12.isFinished()
            r12 = r12 ^ r2
            r11.f526n = r12
            r11.mo675B(r1, r3)
        L_0x0113:
            boolean r12 = r11.f526n
            return r12
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.core.widget.NestedScrollView.onInterceptTouchEvent(android.view.MotionEvent):boolean");
    }

    public void onLayout(boolean z, int i, int i2, int i3, int i4) {
        super.onLayout(z, i, i2, i3, i4);
        int i5 = 0;
        this.f523k = false;
        View view = this.f525m;
        if (view != null && m205r(view, this)) {
            mo751z(this.f525m);
        }
        this.f525m = null;
        if (!this.f524l) {
            if (this.f538z != null) {
                scrollTo(getScrollX(), this.f538z.f539e);
                this.f538z = null;
            }
            if (getChildCount() > 0) {
                View childAt = getChildAt(0);
                FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
                i5 = childAt.getMeasuredHeight() + layoutParams.topMargin + layoutParams.bottomMargin;
            }
            int paddingTop = ((i4 - i2) - getPaddingTop()) - getPaddingBottom();
            int scrollY = getScrollY();
            int c = m204c(scrollY, paddingTop, i5);
            if (c != scrollY) {
                scrollTo(getScrollX(), c);
            }
        }
        scrollTo(getScrollX(), getScrollY());
        this.f524l = true;
    }

    public void onMeasure(int i, int i2) {
        super.onMeasure(i, i2);
        if (this.f528p && View.MeasureSpec.getMode(i2) != 0 && getChildCount() > 0) {
            View childAt = getChildAt(0);
            FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
            int measuredHeight = childAt.getMeasuredHeight();
            int measuredHeight2 = (((getMeasuredHeight() - getPaddingTop()) - getPaddingBottom()) - layoutParams.topMargin) - layoutParams.bottomMargin;
            if (measuredHeight < measuredHeight2) {
                childAt.measure(FrameLayout.getChildMeasureSpec(i, getPaddingRight() + getPaddingLeft() + layoutParams.leftMargin + layoutParams.rightMargin, layoutParams.width), View.MeasureSpec.makeMeasureSpec(measuredHeight2, 1073741824));
            }
        }
    }

    public boolean onNestedFling(View view, float f, float f2, boolean z) {
        if (z) {
            return false;
        }
        dispatchNestedFling(0.0f, f2, true);
        mo708l((int) f2);
        return true;
    }

    public boolean onNestedPreFling(View view, float f, float f2) {
        return dispatchNestedPreFling(f, f2);
    }

    public void onNestedPreScroll(View view, int i, int i2, int[] iArr) {
        mo697e(i, i2, iArr, (int[]) null, 0);
    }

    public void onNestedScroll(View view, int i, int i2, int i3, int i4) {
        mo745t(i4, 0, (int[]) null);
    }

    public void onNestedScrollAccepted(View view, View view2, int i) {
        this.f513A.f19945a = i;
        mo675B(2, 0);
    }

    public void onOverScrolled(int i, int i2, boolean z, boolean z2) {
        super.scrollTo(i, i2);
    }

    public boolean onRequestFocusInDescendants(int i, Rect rect) {
        if (i == 2) {
            i = 130;
        } else if (i == 1) {
            i = 33;
        }
        FocusFinder instance = FocusFinder.getInstance();
        View findNextFocus = rect == null ? instance.findNextFocus(this, (View) null, i) : instance.findNextFocusFromRect(this, rect, i);
        if (findNextFocus != null && !(true ^ mo736s(findNextFocus, 0, getHeight()))) {
            return findNextFocus.requestFocus(i, rect);
        }
        return false;
    }

    public void onRestoreInstanceState(Parcelable parcelable) {
        if (!(parcelable instanceof C0071c)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        C0071c cVar = (C0071c) parcelable;
        super.onRestoreInstanceState(cVar.getSuperState());
        this.f538z = cVar;
        requestLayout();
    }

    public Parcelable onSaveInstanceState() {
        C0071c cVar = new C0071c(super.onSaveInstanceState());
        cVar.f539e = getScrollY();
        return cVar;
    }

    public void onScrollChanged(int i, int i2, int i3, int i4) {
        super.onScrollChanged(i, i2, i3, i4);
        C0070b bVar = this.f516D;
        if (bVar != null) {
            C4844k kVar = (C4844k) bVar;
            AlertController.m13c(this, kVar.f17609a, kVar.f17610b);
        }
    }

    public void onSizeChanged(int i, int i2, int i3, int i4) {
        super.onSizeChanged(i, i2, i3, i4);
        View findFocus = findFocus();
        if (findFocus != null && this != findFocus && mo736s(findFocus, 0, i4)) {
            findFocus.getDrawingRect(this.f518f);
            offsetDescendantRectToMyCoords(findFocus, this.f518f);
            mo698f(mo690d(this.f518f));
        }
    }

    public boolean onStartNestedScroll(View view, View view2, int i) {
        return (i & 2) != 0;
    }

    public void onStopNestedScroll(View view) {
        this.f513A.f19945a = 0;
        mo676C(0);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:27:0x008e, code lost:
        if (r0 != null) goto L_0x0229;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:87:0x0227, code lost:
        if (r0 != null) goto L_0x0229;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean onTouchEvent(android.view.MotionEvent r23) {
        /*
            r22 = this;
            r9 = r22
            r10 = r23
            android.view.VelocityTracker r0 = r9.f527o
            if (r0 != 0) goto L_0x000e
            android.view.VelocityTracker r0 = android.view.VelocityTracker.obtain()
            r9.f527o = r0
        L_0x000e:
            int r0 = r23.getActionMasked()
            r11 = 0
            if (r0 != 0) goto L_0x0017
            r9.f536x = r11
        L_0x0017:
            android.view.MotionEvent r12 = android.view.MotionEvent.obtain(r23)
            int r1 = r9.f536x
            float r1 = (float) r1
            r2 = 0
            r12.offsetLocation(r2, r1)
            r1 = 2
            r13 = 1
            if (r0 == 0) goto L_0x0232
            r3 = -1
            if (r0 == r13) goto L_0x01d6
            if (r0 == r1) goto L_0x0092
            r1 = 3
            if (r0 == r1) goto L_0x005b
            r1 = 5
            if (r0 == r1) goto L_0x0048
            r1 = 6
            if (r0 == r1) goto L_0x0036
            goto L_0x0268
        L_0x0036:
            r22.mo746u(r23)
            int r0 = r9.f533u
            int r0 = r10.findPointerIndex(r0)
            float r0 = r10.getY(r0)
            int r0 = (int) r0
            r9.f522j = r0
            goto L_0x0268
        L_0x0048:
            int r0 = r23.getActionIndex()
            float r1 = r10.getY(r0)
            int r1 = (int) r1
            r9.f522j = r1
            int r0 = r10.getPointerId(r0)
            r9.f533u = r0
            goto L_0x0268
        L_0x005b:
            boolean r0 = r9.f526n
            if (r0 == 0) goto L_0x0082
            int r0 = r22.getChildCount()
            if (r0 <= 0) goto L_0x0082
            android.widget.OverScroller r14 = r9.f519g
            int r15 = r22.getScrollX()
            int r16 = r22.getScrollY()
            r17 = 0
            r18 = 0
            r19 = 0
            int r20 = r22.getScrollRange()
            boolean r0 = r14.springBack(r15, r16, r17, r18, r19, r20)
            if (r0 == 0) goto L_0x0082
            p176d.p219i.p231k.C5662k.m16839p(r22)
        L_0x0082:
            r9.f533u = r3
            r9.f526n = r11
            r22.mo748w()
            r9.mo676C(r11)
            android.widget.EdgeEffect r0 = r9.f520h
            if (r0 == 0) goto L_0x0268
            goto L_0x0229
        L_0x0092:
            int r0 = r9.f533u
            int r14 = r10.findPointerIndex(r0)
            if (r14 != r3) goto L_0x00b5
            java.lang.String r0 = "Invalid pointerId="
            java.lang.StringBuilder r0 = p002b.p008b.p009a.p010a.C0131a.m379m(r0)
            int r1 = r9.f533u
            r0.append(r1)
            java.lang.String r1 = " in onTouchEvent"
            r0.append(r1)
            java.lang.String r0 = r0.toString()
            java.lang.String r1 = "NestedScrollView"
            android.util.Log.e(r1, r0)
            goto L_0x0268
        L_0x00b5:
            float r0 = r10.getY(r14)
            int r6 = (int) r0
            int r0 = r9.f522j
            int r0 = r0 - r6
            boolean r1 = r9.f526n
            if (r1 != 0) goto L_0x00db
            int r1 = java.lang.Math.abs(r0)
            int r2 = r9.f530r
            if (r1 <= r2) goto L_0x00db
            android.view.ViewParent r1 = r22.getParent()
            if (r1 == 0) goto L_0x00d2
            r1.requestDisallowInterceptTouchEvent(r13)
        L_0x00d2:
            r9.f526n = r13
            int r1 = r9.f530r
            if (r0 <= 0) goto L_0x00da
            int r0 = r0 - r1
            goto L_0x00db
        L_0x00da:
            int r0 = r0 + r1
        L_0x00db:
            r7 = r0
            boolean r0 = r9.f526n
            if (r0 == 0) goto L_0x0268
            r1 = 0
            int[] r3 = r9.f535w
            int[] r4 = r9.f534v
            r5 = 0
            r0 = r22
            r2 = r7
            boolean r0 = r0.mo697e(r1, r2, r3, r4, r5)
            if (r0 == 0) goto L_0x00fd
            int[] r0 = r9.f535w
            r0 = r0[r13]
            int r7 = r7 - r0
            int r0 = r9.f536x
            int[] r1 = r9.f534v
            r1 = r1[r13]
            int r0 = r0 + r1
            r9.f536x = r0
        L_0x00fd:
            r15 = r7
            int[] r0 = r9.f534v
            r0 = r0[r13]
            int r6 = r6 - r0
            r9.f522j = r6
            int r16 = r22.getScrollY()
            int r8 = r22.getScrollRange()
            int r0 = r22.getOverScrollMode()
            if (r0 == 0) goto L_0x011b
            if (r0 != r13) goto L_0x0118
            if (r8 <= 0) goto L_0x0118
            goto L_0x011b
        L_0x0118:
            r17 = r11
            goto L_0x011d
        L_0x011b:
            r17 = r13
        L_0x011d:
            r1 = 0
            r3 = 0
            int r4 = r22.getScrollY()
            r5 = 0
            r7 = 0
            r18 = 0
            r0 = r22
            r2 = r15
            r6 = r8
            r21 = r8
            r8 = r18
            boolean r0 = r0.mo747v(r1, r2, r3, r4, r5, r6, r7, r8)
            if (r0 == 0) goto L_0x0140
            boolean r0 = r9.mo731q(r11)
            if (r0 != 0) goto L_0x0140
            android.view.VelocityTracker r0 = r9.f527o
            r0.clear()
        L_0x0140:
            int r0 = r22.getScrollY()
            int r3 = r0 - r16
            int r5 = r15 - r3
            int[] r8 = r9.f535w
            r8[r13] = r11
            r2 = 0
            r4 = 0
            int[] r6 = r9.f534v
            r7 = 0
            d.i.k.e r1 = r9.f514B
            r1.mo11809a(r2, r3, r4, r5, r6, r7, r8)
            int r0 = r9.f522j
            int[] r1 = r9.f534v
            r2 = r1[r13]
            int r0 = r0 - r2
            r9.f522j = r0
            int r0 = r9.f536x
            r1 = r1[r13]
            int r0 = r0 + r1
            r9.f536x = r0
            if (r17 == 0) goto L_0x0268
            int[] r0 = r9.f535w
            r0 = r0[r13]
            int r15 = r15 - r0
            r22.mo699g()
            int r0 = r16 + r15
            if (r0 >= 0) goto L_0x0195
            android.widget.EdgeEffect r0 = r9.f520h
            float r1 = (float) r15
            int r2 = r22.getHeight()
            float r2 = (float) r2
            float r1 = r1 / r2
            float r2 = r10.getX(r14)
            int r3 = r22.getWidth()
            float r3 = (float) r3
            float r2 = r2 / r3
            r0.onPull(r1, r2)
            android.widget.EdgeEffect r0 = r9.f521i
            boolean r0 = r0.isFinished()
            if (r0 != 0) goto L_0x01bf
            android.widget.EdgeEffect r0 = r9.f521i
            goto L_0x01bc
        L_0x0195:
            r1 = r21
            if (r0 <= r1) goto L_0x01bf
            android.widget.EdgeEffect r0 = r9.f521i
            float r1 = (float) r15
            int r2 = r22.getHeight()
            float r2 = (float) r2
            float r1 = r1 / r2
            r2 = 1065353216(0x3f800000, float:1.0)
            float r3 = r10.getX(r14)
            int r4 = r22.getWidth()
            float r4 = (float) r4
            float r3 = r3 / r4
            float r2 = r2 - r3
            r0.onPull(r1, r2)
            android.widget.EdgeEffect r0 = r9.f520h
            boolean r0 = r0.isFinished()
            if (r0 != 0) goto L_0x01bf
            android.widget.EdgeEffect r0 = r9.f520h
        L_0x01bc:
            r0.onRelease()
        L_0x01bf:
            android.widget.EdgeEffect r0 = r9.f520h
            if (r0 == 0) goto L_0x0268
            boolean r0 = r0.isFinished()
            if (r0 == 0) goto L_0x01d1
            android.widget.EdgeEffect r0 = r9.f521i
            boolean r0 = r0.isFinished()
            if (r0 != 0) goto L_0x0268
        L_0x01d1:
            p176d.p219i.p231k.C5662k.m16839p(r22)
            goto L_0x0268
        L_0x01d6:
            android.view.VelocityTracker r0 = r9.f527o
            r1 = 1000(0x3e8, float:1.401E-42)
            int r4 = r9.f532t
            float r4 = (float) r4
            r0.computeCurrentVelocity(r1, r4)
            int r1 = r9.f533u
            float r0 = r0.getYVelocity(r1)
            int r0 = (int) r0
            int r1 = java.lang.Math.abs(r0)
            int r4 = r9.f531s
            if (r1 < r4) goto L_0x01fe
            int r0 = -r0
            float r1 = (float) r0
            boolean r4 = r9.dispatchNestedPreFling(r2, r1)
            if (r4 != 0) goto L_0x021b
            r9.dispatchNestedFling(r2, r1, r13)
            r9.mo708l(r0)
            goto L_0x021b
        L_0x01fe:
            android.widget.OverScroller r14 = r9.f519g
            int r15 = r22.getScrollX()
            int r16 = r22.getScrollY()
            r17 = 0
            r18 = 0
            r19 = 0
            int r20 = r22.getScrollRange()
            boolean r0 = r14.springBack(r15, r16, r17, r18, r19, r20)
            if (r0 == 0) goto L_0x021b
            p176d.p219i.p231k.C5662k.m16839p(r22)
        L_0x021b:
            r9.f533u = r3
            r9.f526n = r11
            r22.mo748w()
            r9.mo676C(r11)
            android.widget.EdgeEffect r0 = r9.f520h
            if (r0 == 0) goto L_0x0268
        L_0x0229:
            r0.onRelease()
            android.widget.EdgeEffect r0 = r9.f521i
            r0.onRelease()
            goto L_0x0268
        L_0x0232:
            int r0 = r22.getChildCount()
            if (r0 != 0) goto L_0x0239
            return r11
        L_0x0239:
            android.widget.OverScroller r0 = r9.f519g
            boolean r0 = r0.isFinished()
            r0 = r0 ^ r13
            r9.f526n = r0
            if (r0 == 0) goto L_0x024d
            android.view.ViewParent r0 = r22.getParent()
            if (r0 == 0) goto L_0x024d
            r0.requestDisallowInterceptTouchEvent(r13)
        L_0x024d:
            android.widget.OverScroller r0 = r9.f519g
            boolean r0 = r0.isFinished()
            if (r0 != 0) goto L_0x0258
            r22.mo677a()
        L_0x0258:
            float r0 = r23.getY()
            int r0 = (int) r0
            r9.f522j = r0
            int r0 = r10.getPointerId(r11)
            r9.f533u = r0
            r9.mo675B(r1, r11)
        L_0x0268:
            android.view.VelocityTracker r0 = r9.f527o
            if (r0 == 0) goto L_0x026f
            r0.addMovement(r12)
        L_0x026f:
            r12.recycle()
            return r13
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.core.widget.NestedScrollView.onTouchEvent(android.view.MotionEvent):boolean");
    }

    /* renamed from: p */
    public boolean mo730p(int i) {
        int childCount;
        boolean z = i == 130;
        int height = getHeight();
        Rect rect = this.f518f;
        rect.top = 0;
        rect.bottom = height;
        if (z && (childCount = getChildCount()) > 0) {
            View childAt = getChildAt(childCount - 1);
            this.f518f.bottom = getPaddingBottom() + childAt.getBottom() + ((FrameLayout.LayoutParams) childAt.getLayoutParams()).bottomMargin;
            Rect rect2 = this.f518f;
            rect2.top = rect2.bottom - height;
        }
        Rect rect3 = this.f518f;
        return mo750y(i, rect3.top, rect3.bottom);
    }

    /* renamed from: q */
    public boolean mo731q(int i) {
        return this.f514B.mo11810b(i) != null;
    }

    public void requestChildFocus(View view, View view2) {
        if (!this.f523k) {
            mo751z(view2);
        } else {
            this.f525m = view2;
        }
        super.requestChildFocus(view, view2);
    }

    public boolean requestChildRectangleOnScreen(View view, Rect rect, boolean z) {
        rect.offset(view.getLeft() - view.getScrollX(), view.getTop() - view.getScrollY());
        int d = mo690d(rect);
        boolean z2 = d != 0;
        if (z2) {
            if (z) {
                scrollBy(0, d);
            } else {
                mo674A(0, d, 250, false);
            }
        }
        return z2;
    }

    public void requestDisallowInterceptTouchEvent(boolean z) {
        if (z) {
            mo748w();
        }
        super.requestDisallowInterceptTouchEvent(z);
    }

    public void requestLayout() {
        this.f523k = true;
        super.requestLayout();
    }

    /* renamed from: s */
    public final boolean mo736s(View view, int i, int i2) {
        view.getDrawingRect(this.f518f);
        offsetDescendantRectToMyCoords(view, this.f518f);
        return this.f518f.bottom + i >= getScrollY() && this.f518f.top - i <= getScrollY() + i2;
    }

    public void scrollTo(int i, int i2) {
        if (getChildCount() > 0) {
            View childAt = getChildAt(0);
            FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
            int c = m204c(i, (getWidth() - getPaddingLeft()) - getPaddingRight(), childAt.getWidth() + layoutParams.leftMargin + layoutParams.rightMargin);
            int c2 = m204c(i2, (getHeight() - getPaddingTop()) - getPaddingBottom(), childAt.getHeight() + layoutParams.topMargin + layoutParams.bottomMargin);
            if (c != getScrollX() || c2 != getScrollY()) {
                super.scrollTo(c, c2);
            }
        }
    }

    public void setFillViewport(boolean z) {
        if (z != this.f528p) {
            this.f528p = z;
            requestLayout();
        }
    }

    public void setNestedScrollingEnabled(boolean z) {
        C5656e eVar = this.f514B;
        if (eVar.f19943d) {
            C5662k.m16823A(eVar.f19942c);
        }
        eVar.f19943d = z;
    }

    public void setOnScrollChangeListener(C0070b bVar) {
        this.f516D = bVar;
    }

    public void setSmoothScrollingEnabled(boolean z) {
        this.f529q = z;
    }

    public boolean shouldDelayChildPressedState() {
        return true;
    }

    public boolean startNestedScroll(int i) {
        return mo675B(i, 0);
    }

    public void stopNestedScroll() {
        mo676C(0);
    }

    /* renamed from: t */
    public final void mo745t(int i, int i2, int[] iArr) {
        int scrollY = getScrollY();
        scrollBy(0, i);
        int scrollY2 = getScrollY() - scrollY;
        if (iArr != null) {
            iArr[1] = iArr[1] + scrollY2;
        }
        this.f514B.mo11809a(0, scrollY2, 0, i - scrollY2, (int[]) null, i2, iArr);
    }

    /* renamed from: u */
    public final void mo746u(MotionEvent motionEvent) {
        int actionIndex = motionEvent.getActionIndex();
        if (motionEvent.getPointerId(actionIndex) == this.f533u) {
            int i = actionIndex == 0 ? 1 : 0;
            this.f522j = (int) motionEvent.getY(i);
            this.f533u = motionEvent.getPointerId(i);
            VelocityTracker velocityTracker = this.f527o;
            if (velocityTracker != null) {
                velocityTracker.clear();
            }
        }
    }

    /* renamed from: v */
    public boolean mo747v(int i, int i2, int i3, int i4, int i5, int i6, int i7, int i8) {
        boolean z;
        boolean z2;
        int overScrollMode = getOverScrollMode();
        boolean z3 = computeHorizontalScrollRange() > computeHorizontalScrollExtent();
        boolean z4 = computeVerticalScrollRange() > computeVerticalScrollExtent();
        boolean z5 = overScrollMode == 0 || (overScrollMode == 1 && z3);
        boolean z6 = overScrollMode == 0 || (overScrollMode == 1 && z4);
        int i9 = i3 + i;
        int i10 = !z5 ? 0 : i7;
        int i11 = i4 + i2;
        int i12 = !z6 ? 0 : i8;
        int i13 = -i10;
        int i14 = i10 + i5;
        int i15 = -i12;
        int i16 = i12 + i6;
        if (i9 > i14) {
            i9 = i14;
            z = true;
        } else if (i9 < i13) {
            z = true;
            i9 = i13;
        } else {
            z = false;
        }
        if (i11 > i16) {
            i11 = i16;
            z2 = true;
        } else if (i11 < i15) {
            z2 = true;
            i11 = i15;
        } else {
            z2 = false;
        }
        if (z2 && !mo731q(1)) {
            this.f519g.springBack(i9, i11, 0, 0, 0, getScrollRange());
        }
        onOverScrolled(i9, i11, z, z2);
        return z || z2;
    }

    /* renamed from: w */
    public final void mo748w() {
        VelocityTracker velocityTracker = this.f527o;
        if (velocityTracker != null) {
            velocityTracker.recycle();
            this.f527o = null;
        }
    }

    /* renamed from: x */
    public final void mo749x(boolean z) {
        if (z) {
            mo675B(2, 1);
        } else {
            mo676C(1);
        }
        this.f537y = getScrollY();
        C5662k.m16839p(this);
    }

    /* renamed from: y */
    public final boolean mo750y(int i, int i2, int i3) {
        boolean z;
        int i4 = i;
        int i5 = i2;
        int i6 = i3;
        int height = getHeight();
        int scrollY = getScrollY();
        int i7 = height + scrollY;
        boolean z2 = i4 == 33;
        ArrayList focusables = getFocusables(2);
        int size = focusables.size();
        View view = null;
        boolean z3 = false;
        for (int i8 = 0; i8 < size; i8++) {
            View view2 = (View) focusables.get(i8);
            int top = view2.getTop();
            int bottom = view2.getBottom();
            if (i5 < bottom && top < i6) {
                boolean z4 = i5 < top && bottom < i6;
                if (view == null) {
                    view = view2;
                    z3 = z4;
                } else {
                    boolean z5 = (z2 && top < view.getTop()) || (!z2 && bottom > view.getBottom());
                    if (z3) {
                        if (z4) {
                            if (!z5) {
                            }
                        }
                    } else if (z4) {
                        view = view2;
                        z3 = true;
                    } else if (!z5) {
                    }
                    view = view2;
                }
            }
        }
        if (view == null) {
            view = this;
        }
        if (i5 < scrollY || i6 > i7) {
            mo698f(z2 ? i5 - scrollY : i6 - i7);
            z = true;
        } else {
            z = false;
        }
        if (view != findFocus()) {
            view.requestFocus(i4);
        }
        return z;
    }

    /* renamed from: z */
    public final void mo751z(View view) {
        view.getDrawingRect(this.f518f);
        offsetDescendantRectToMyCoords(view, this.f518f);
        int d = mo690d(this.f518f);
        if (d != 0) {
            scrollBy(0, d);
        }
    }
}
