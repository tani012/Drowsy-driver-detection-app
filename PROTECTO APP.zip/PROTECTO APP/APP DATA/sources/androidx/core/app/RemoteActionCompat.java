package androidx.core.app;

import android.app.PendingIntent;
import androidx.core.graphics.drawable.IconCompat;
import p176d.p249r.C5822c;

public final class RemoteActionCompat implements C5822c {

    /* renamed from: a */
    public IconCompat f495a;

    /* renamed from: b */
    public CharSequence f496b;

    /* renamed from: c */
    public CharSequence f497c;

    /* renamed from: d */
    public PendingIntent f498d;

    /* renamed from: e */
    public boolean f499e;

    /* renamed from: f */
    public boolean f500f;
}
