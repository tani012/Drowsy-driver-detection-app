package androidx.core.app;

import android.app.PendingIntent;
import android.text.TextUtils;
import androidx.core.graphics.drawable.IconCompat;
import p176d.p249r.C5820a;
import p176d.p249r.C5821b;

public class RemoteActionCompatParcelizer {
    public static RemoteActionCompat read(C5820a aVar) {
        RemoteActionCompat remoteActionCompat = new RemoteActionCompat();
        Object obj = remoteActionCompat.f495a;
        if (aVar.mo12163h(1)) {
            obj = aVar.mo12166k();
        }
        remoteActionCompat.f495a = (IconCompat) obj;
        remoteActionCompat.f496b = aVar.mo12162g(remoteActionCompat.f496b, 2);
        remoteActionCompat.f497c = aVar.mo12162g(remoteActionCompat.f497c, 3);
        remoteActionCompat.f498d = (PendingIntent) aVar.mo12165j(remoteActionCompat.f498d, 4);
        remoteActionCompat.f499e = aVar.mo12161f(remoteActionCompat.f499e, 5);
        remoteActionCompat.f500f = aVar.mo12161f(remoteActionCompat.f500f, 6);
        return remoteActionCompat;
    }

    public static void write(RemoteActionCompat remoteActionCompat, C5820a aVar) {
        if (aVar != null) {
            IconCompat iconCompat = remoteActionCompat.f495a;
            aVar.mo12167l(1);
            aVar.mo12170o(iconCompat);
            CharSequence charSequence = remoteActionCompat.f496b;
            aVar.mo12167l(2);
            C5821b bVar = (C5821b) aVar;
            TextUtils.writeToParcel(charSequence, bVar.f20342e, 0);
            CharSequence charSequence2 = remoteActionCompat.f497c;
            aVar.mo12167l(3);
            TextUtils.writeToParcel(charSequence2, bVar.f20342e, 0);
            aVar.mo12169n(remoteActionCompat.f498d, 4);
            boolean z = remoteActionCompat.f499e;
            aVar.mo12167l(5);
            bVar.f20342e.writeInt(z ? 1 : 0);
            boolean z2 = remoteActionCompat.f500f;
            aVar.mo12167l(6);
            bVar.f20342e.writeInt(z2 ? 1 : 0);
            return;
        }
        throw null;
    }
}
