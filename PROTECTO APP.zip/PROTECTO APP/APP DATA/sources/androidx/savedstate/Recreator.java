package androidx.savedstate;

import android.annotation.SuppressLint;
import android.os.Bundle;
import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import p002b.p008b.p009a.p010a.C0131a;
import p176d.p242n.C5781e;
import p176d.p242n.C5784f;
import p176d.p242n.C5786h;
import p176d.p242n.C5787i;
import p176d.p245p.C5813a;
import p176d.p245p.C5817c;

@SuppressLint({"RestrictedApi"})
public final class Recreator implements C5784f {

    /* renamed from: a */
    public final C5817c f634a;

    /* renamed from: androidx.savedstate.Recreator$a */
    public static final class C0083a implements C5813a.C5815b {

        /* renamed from: a */
        public final Set<String> f635a = new HashSet();

        public C0083a(C5813a aVar) {
            if (aVar.f20331a.mo10688p("androidx.savedstate.Restarter", this) != null) {
                throw new IllegalArgumentException("SavedStateProvider with the given key is already registered");
            }
        }

        /* renamed from: a */
        public Bundle mo825a() {
            Bundle bundle = new Bundle();
            bundle.putStringArrayList("classes_to_restore", new ArrayList(this.f635a));
            return bundle;
        }
    }

    public Recreator(C5817c cVar) {
        this.f634a = cVar;
    }

    /* renamed from: d */
    public void mo9d(C5786h hVar, C5781e.C5782a aVar) {
        if (aVar == C5781e.C5782a.ON_CREATE) {
            ((C5787i) hVar.mo1a()).f20305a.mo10689r(this);
            Bundle a = this.f634a.mo3d().mo12152a("androidx.savedstate.Restarter");
            if (a != null) {
                ArrayList<String> stringArrayList = a.getStringArrayList("classes_to_restore");
                if (stringArrayList != null) {
                    Iterator<String> it = stringArrayList.iterator();
                    while (it.hasNext()) {
                        String next = it.next();
                        try {
                            Class<? extends U> asSubclass = Class.forName(next, false, Recreator.class.getClassLoader()).asSubclass(C5813a.C5814a.class);
                            try {
                                Constructor<? extends U> declaredConstructor = asSubclass.getDeclaredConstructor(new Class[0]);
                                declaredConstructor.setAccessible(true);
                                try {
                                    ((C5813a.C5814a) declaredConstructor.newInstance(new Object[0])).mo824a(this.f634a);
                                } catch (Exception e) {
                                    throw new RuntimeException(C0131a.m373g("Failed to instantiate ", next), e);
                                }
                            } catch (NoSuchMethodException e2) {
                                StringBuilder m = C0131a.m379m("Class");
                                m.append(asSubclass.getSimpleName());
                                m.append(" must have default constructor in order to be automatically recreated");
                                throw new IllegalStateException(m.toString(), e2);
                            }
                        } catch (ClassNotFoundException e3) {
                            throw new RuntimeException(C0131a.m374h("Class ", next, " wasn't found"), e3);
                        }
                    }
                    return;
                }
                throw new IllegalStateException("Bundle with restored state for the component \"androidx.savedstate.Restarter\" must contain list of strings by the key \"classes_to_restore\"");
            }
            return;
        }
        throw new AssertionError("Next event must be ON_CREATE");
    }
}
