package androidx.savedstate;

import p176d.p242n.C5781e;
import p176d.p242n.C5784f;
import p176d.p242n.C5786h;
import p176d.p245p.C5813a;

public class SavedStateRegistry$1 implements C5784f {

    /* renamed from: a */
    public final /* synthetic */ C5813a f636a;

    public SavedStateRegistry$1(C5813a aVar) {
        this.f636a = aVar;
    }

    /* renamed from: d */
    public void mo9d(C5786h hVar, C5781e.C5782a aVar) {
        boolean z;
        C5813a aVar2;
        if (aVar == C5781e.C5782a.ON_START) {
            aVar2 = this.f636a;
            z = true;
        } else if (aVar == C5781e.C5782a.ON_STOP) {
            aVar2 = this.f636a;
            z = false;
        } else {
            return;
        }
        aVar2.f20335e = z;
    }
}
