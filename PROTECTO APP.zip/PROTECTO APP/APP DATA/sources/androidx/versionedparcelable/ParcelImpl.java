package androidx.versionedparcelable;

import android.annotation.SuppressLint;
import android.os.Parcel;
import android.os.Parcelable;
import p176d.p249r.C5821b;
import p176d.p249r.C5822c;

@SuppressLint({"BanParcelableUsage"})
public class ParcelImpl implements Parcelable {
    public static final Parcelable.Creator<ParcelImpl> CREATOR = new C0084a();

    /* renamed from: e */
    public final C5822c f637e;

    /* renamed from: androidx.versionedparcelable.ParcelImpl$a */
    public static class C0084a implements Parcelable.Creator<ParcelImpl> {
        public Object createFromParcel(Parcel parcel) {
            return new ParcelImpl(parcel);
        }

        public Object[] newArray(int i) {
            return new ParcelImpl[i];
        }
    }

    public ParcelImpl(Parcel parcel) {
        this.f637e = new C5821b(parcel).mo12166k();
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int i) {
        new C5821b(parcel).mo12170o(this.f637e);
    }
}
