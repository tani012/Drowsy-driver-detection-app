package androidx.versionedparcelable;

import p176d.p249r.C5822c;

public abstract class CustomVersionedParcelable implements C5822c {
}
