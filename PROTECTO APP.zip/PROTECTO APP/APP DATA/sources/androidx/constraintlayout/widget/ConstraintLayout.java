package androidx.constraintlayout.widget;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.util.SparseArray;
import android.util.SparseIntArray;
import android.view.View;
import android.view.ViewGroup;
import java.util.ArrayList;
import java.util.HashMap;
import p176d.p215h.p216a.p217h.C5553d;
import p176d.p215h.p216a.p217h.C5555e;
import p176d.p215h.p216a.p217h.C5557g;
import p176d.p215h.p218b.C5567b;
import p176d.p215h.p218b.C5568c;
import p176d.p215h.p218b.C5572e;
import p176d.p215h.p218b.C5573f;
import p176d.p215h.p218b.C5575h;

public class ConstraintLayout extends ViewGroup {

    /* renamed from: e */
    public SparseArray<View> f415e = new SparseArray<>();

    /* renamed from: f */
    public ArrayList<C5567b> f416f = new ArrayList<>(4);

    /* renamed from: g */
    public final ArrayList<C5553d> f417g = new ArrayList<>(100);

    /* renamed from: h */
    public C5555e f418h = new C5555e();

    /* renamed from: i */
    public int f419i = 0;

    /* renamed from: j */
    public int f420j = 0;

    /* renamed from: k */
    public int f421k = Integer.MAX_VALUE;

    /* renamed from: l */
    public int f422l = Integer.MAX_VALUE;

    /* renamed from: m */
    public boolean f423m = true;

    /* renamed from: n */
    public int f424n = 7;

    /* renamed from: o */
    public C5568c f425o = null;

    /* renamed from: p */
    public int f426p = -1;

    /* renamed from: q */
    public HashMap<String, Integer> f427q = new HashMap<>();

    /* renamed from: r */
    public int f428r = -1;

    /* renamed from: s */
    public int f429s = -1;

    /* renamed from: androidx.constraintlayout.widget.ConstraintLayout$a */
    public static class C0066a extends ViewGroup.MarginLayoutParams {

        /* renamed from: A */
        public float f430A = 0.5f;

        /* renamed from: B */
        public String f431B = null;

        /* renamed from: C */
        public int f432C = 1;

        /* renamed from: D */
        public float f433D = -1.0f;

        /* renamed from: E */
        public float f434E = -1.0f;

        /* renamed from: F */
        public int f435F = 0;

        /* renamed from: G */
        public int f436G = 0;

        /* renamed from: H */
        public int f437H = 0;

        /* renamed from: I */
        public int f438I = 0;

        /* renamed from: J */
        public int f439J = 0;

        /* renamed from: K */
        public int f440K = 0;

        /* renamed from: L */
        public int f441L = 0;

        /* renamed from: M */
        public int f442M = 0;

        /* renamed from: N */
        public float f443N = 1.0f;

        /* renamed from: O */
        public float f444O = 1.0f;

        /* renamed from: P */
        public int f445P = -1;

        /* renamed from: Q */
        public int f446Q = -1;

        /* renamed from: R */
        public int f447R = -1;

        /* renamed from: S */
        public boolean f448S = false;

        /* renamed from: T */
        public boolean f449T = false;

        /* renamed from: U */
        public boolean f450U = true;

        /* renamed from: V */
        public boolean f451V = true;

        /* renamed from: W */
        public boolean f452W = false;

        /* renamed from: X */
        public boolean f453X = false;

        /* renamed from: Y */
        public boolean f454Y = false;

        /* renamed from: Z */
        public boolean f455Z = false;

        /* renamed from: a */
        public int f456a = -1;

        /* renamed from: a0 */
        public int f457a0 = -1;

        /* renamed from: b */
        public int f458b = -1;

        /* renamed from: b0 */
        public int f459b0 = -1;

        /* renamed from: c */
        public float f460c = -1.0f;

        /* renamed from: c0 */
        public int f461c0 = -1;

        /* renamed from: d */
        public int f462d = -1;

        /* renamed from: d0 */
        public int f463d0 = -1;

        /* renamed from: e */
        public int f464e = -1;

        /* renamed from: e0 */
        public int f465e0 = -1;

        /* renamed from: f */
        public int f466f = -1;

        /* renamed from: f0 */
        public int f467f0 = -1;

        /* renamed from: g */
        public int f468g = -1;

        /* renamed from: g0 */
        public float f469g0 = 0.5f;

        /* renamed from: h */
        public int f470h = -1;

        /* renamed from: h0 */
        public int f471h0;

        /* renamed from: i */
        public int f472i = -1;

        /* renamed from: i0 */
        public int f473i0;

        /* renamed from: j */
        public int f474j = -1;

        /* renamed from: j0 */
        public float f475j0;

        /* renamed from: k */
        public int f476k = -1;

        /* renamed from: k0 */
        public C5553d f477k0 = new C5553d();

        /* renamed from: l */
        public int f478l = -1;

        /* renamed from: l0 */
        public boolean f479l0 = false;

        /* renamed from: m */
        public int f480m = -1;

        /* renamed from: n */
        public int f481n = 0;

        /* renamed from: o */
        public float f482o = 0.0f;

        /* renamed from: p */
        public int f483p = -1;

        /* renamed from: q */
        public int f484q = -1;

        /* renamed from: r */
        public int f485r = -1;

        /* renamed from: s */
        public int f486s = -1;

        /* renamed from: t */
        public int f487t = -1;

        /* renamed from: u */
        public int f488u = -1;

        /* renamed from: v */
        public int f489v = -1;

        /* renamed from: w */
        public int f490w = -1;

        /* renamed from: x */
        public int f491x = -1;

        /* renamed from: y */
        public int f492y = -1;

        /* renamed from: z */
        public float f493z = 0.5f;

        /* renamed from: androidx.constraintlayout.widget.ConstraintLayout$a$a */
        public static class C0067a {

            /* renamed from: a */
            public static final SparseIntArray f494a;

            static {
                SparseIntArray sparseIntArray = new SparseIntArray();
                f494a = sparseIntArray;
                sparseIntArray.append(C5575h.ConstraintLayout_Layout_layout_constraintLeft_toLeftOf, 8);
                f494a.append(C5575h.ConstraintLayout_Layout_layout_constraintLeft_toRightOf, 9);
                f494a.append(C5575h.ConstraintLayout_Layout_layout_constraintRight_toLeftOf, 10);
                f494a.append(C5575h.ConstraintLayout_Layout_layout_constraintRight_toRightOf, 11);
                f494a.append(C5575h.ConstraintLayout_Layout_layout_constraintTop_toTopOf, 12);
                f494a.append(C5575h.ConstraintLayout_Layout_layout_constraintTop_toBottomOf, 13);
                f494a.append(C5575h.ConstraintLayout_Layout_layout_constraintBottom_toTopOf, 14);
                f494a.append(C5575h.ConstraintLayout_Layout_layout_constraintBottom_toBottomOf, 15);
                f494a.append(C5575h.ConstraintLayout_Layout_layout_constraintBaseline_toBaselineOf, 16);
                f494a.append(C5575h.ConstraintLayout_Layout_layout_constraintCircle, 2);
                f494a.append(C5575h.ConstraintLayout_Layout_layout_constraintCircleRadius, 3);
                f494a.append(C5575h.ConstraintLayout_Layout_layout_constraintCircleAngle, 4);
                f494a.append(C5575h.ConstraintLayout_Layout_layout_editor_absoluteX, 49);
                f494a.append(C5575h.ConstraintLayout_Layout_layout_editor_absoluteY, 50);
                f494a.append(C5575h.ConstraintLayout_Layout_layout_constraintGuide_begin, 5);
                f494a.append(C5575h.ConstraintLayout_Layout_layout_constraintGuide_end, 6);
                f494a.append(C5575h.ConstraintLayout_Layout_layout_constraintGuide_percent, 7);
                f494a.append(C5575h.ConstraintLayout_Layout_android_orientation, 1);
                f494a.append(C5575h.ConstraintLayout_Layout_layout_constraintStart_toEndOf, 17);
                f494a.append(C5575h.ConstraintLayout_Layout_layout_constraintStart_toStartOf, 18);
                f494a.append(C5575h.ConstraintLayout_Layout_layout_constraintEnd_toStartOf, 19);
                f494a.append(C5575h.ConstraintLayout_Layout_layout_constraintEnd_toEndOf, 20);
                f494a.append(C5575h.ConstraintLayout_Layout_layout_goneMarginLeft, 21);
                f494a.append(C5575h.ConstraintLayout_Layout_layout_goneMarginTop, 22);
                f494a.append(C5575h.ConstraintLayout_Layout_layout_goneMarginRight, 23);
                f494a.append(C5575h.ConstraintLayout_Layout_layout_goneMarginBottom, 24);
                f494a.append(C5575h.ConstraintLayout_Layout_layout_goneMarginStart, 25);
                f494a.append(C5575h.ConstraintLayout_Layout_layout_goneMarginEnd, 26);
                f494a.append(C5575h.ConstraintLayout_Layout_layout_constraintHorizontal_bias, 29);
                f494a.append(C5575h.ConstraintLayout_Layout_layout_constraintVertical_bias, 30);
                f494a.append(C5575h.ConstraintLayout_Layout_layout_constraintDimensionRatio, 44);
                f494a.append(C5575h.ConstraintLayout_Layout_layout_constraintHorizontal_weight, 45);
                f494a.append(C5575h.ConstraintLayout_Layout_layout_constraintVertical_weight, 46);
                f494a.append(C5575h.ConstraintLayout_Layout_layout_constraintHorizontal_chainStyle, 47);
                f494a.append(C5575h.ConstraintLayout_Layout_layout_constraintVertical_chainStyle, 48);
                f494a.append(C5575h.ConstraintLayout_Layout_layout_constrainedWidth, 27);
                f494a.append(C5575h.ConstraintLayout_Layout_layout_constrainedHeight, 28);
                f494a.append(C5575h.ConstraintLayout_Layout_layout_constraintWidth_default, 31);
                f494a.append(C5575h.ConstraintLayout_Layout_layout_constraintHeight_default, 32);
                f494a.append(C5575h.ConstraintLayout_Layout_layout_constraintWidth_min, 33);
                f494a.append(C5575h.ConstraintLayout_Layout_layout_constraintWidth_max, 34);
                f494a.append(C5575h.ConstraintLayout_Layout_layout_constraintWidth_percent, 35);
                f494a.append(C5575h.ConstraintLayout_Layout_layout_constraintHeight_min, 36);
                f494a.append(C5575h.ConstraintLayout_Layout_layout_constraintHeight_max, 37);
                f494a.append(C5575h.ConstraintLayout_Layout_layout_constraintHeight_percent, 38);
                f494a.append(C5575h.ConstraintLayout_Layout_layout_constraintLeft_creator, 39);
                f494a.append(C5575h.ConstraintLayout_Layout_layout_constraintTop_creator, 40);
                f494a.append(C5575h.ConstraintLayout_Layout_layout_constraintRight_creator, 41);
                f494a.append(C5575h.ConstraintLayout_Layout_layout_constraintBottom_creator, 42);
                f494a.append(C5575h.ConstraintLayout_Layout_layout_constraintBaseline_creator, 43);
            }
        }

        public C0066a(int i, int i2) {
            super(i, i2);
        }

        /* JADX WARNING: Can't fix incorrect switch cases order */
        /* JADX WARNING: Code restructure failed: missing block: B:78:0x0204, code lost:
            android.util.Log.e("ConstraintLayout", r4);
         */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public C0066a(android.content.Context r10, android.util.AttributeSet r11) {
            /*
                r9 = this;
                r9.<init>(r10, r11)
                r0 = -1
                r9.f456a = r0
                r9.f458b = r0
                r1 = -1082130432(0xffffffffbf800000, float:-1.0)
                r9.f460c = r1
                r9.f462d = r0
                r9.f464e = r0
                r9.f466f = r0
                r9.f468g = r0
                r9.f470h = r0
                r9.f472i = r0
                r9.f474j = r0
                r9.f476k = r0
                r9.f478l = r0
                r9.f480m = r0
                r2 = 0
                r9.f481n = r2
                r3 = 0
                r9.f482o = r3
                r9.f483p = r0
                r9.f484q = r0
                r9.f485r = r0
                r9.f486s = r0
                r9.f487t = r0
                r9.f488u = r0
                r9.f489v = r0
                r9.f490w = r0
                r9.f491x = r0
                r9.f492y = r0
                r4 = 1056964608(0x3f000000, float:0.5)
                r9.f493z = r4
                r9.f430A = r4
                r5 = 0
                r9.f431B = r5
                r5 = 1
                r9.f432C = r5
                r9.f433D = r1
                r9.f434E = r1
                r9.f435F = r2
                r9.f436G = r2
                r9.f437H = r2
                r9.f438I = r2
                r9.f439J = r2
                r9.f440K = r2
                r9.f441L = r2
                r9.f442M = r2
                r1 = 1065353216(0x3f800000, float:1.0)
                r9.f443N = r1
                r9.f444O = r1
                r9.f445P = r0
                r9.f446Q = r0
                r9.f447R = r0
                r9.f448S = r2
                r9.f449T = r2
                r9.f450U = r5
                r9.f451V = r5
                r9.f452W = r2
                r9.f453X = r2
                r9.f454Y = r2
                r9.f455Z = r2
                r9.f457a0 = r0
                r9.f459b0 = r0
                r9.f461c0 = r0
                r9.f463d0 = r0
                r9.f465e0 = r0
                r9.f467f0 = r0
                r9.f469g0 = r4
                d.h.a.h.d r1 = new d.h.a.h.d
                r1.<init>()
                r9.f477k0 = r1
                r9.f479l0 = r2
                int[] r1 = p176d.p215h.p218b.C5575h.ConstraintLayout_Layout
                android.content.res.TypedArray r10 = r10.obtainStyledAttributes(r11, r1)
                int r11 = r10.getIndexCount()
                r1 = r2
            L_0x0098:
                if (r1 >= r11) goto L_0x03ab
                int r4 = r10.getIndex(r1)
                android.util.SparseIntArray r6 = androidx.constraintlayout.widget.ConstraintLayout.C0066a.C0067a.f494a
                int r6 = r6.get(r4)
                java.lang.String r7 = "ConstraintLayout"
                r8 = -2
                switch(r6) {
                    case 1: goto L_0x039f;
                    case 2: goto L_0x038e;
                    case 3: goto L_0x0385;
                    case 4: goto L_0x0370;
                    case 5: goto L_0x0367;
                    case 6: goto L_0x035e;
                    case 7: goto L_0x0355;
                    case 8: goto L_0x0344;
                    case 9: goto L_0x0333;
                    case 10: goto L_0x0321;
                    case 11: goto L_0x030f;
                    case 12: goto L_0x02fd;
                    case 13: goto L_0x02eb;
                    case 14: goto L_0x02d9;
                    case 15: goto L_0x02c7;
                    case 16: goto L_0x02b5;
                    case 17: goto L_0x02a3;
                    case 18: goto L_0x0291;
                    case 19: goto L_0x027f;
                    case 20: goto L_0x026d;
                    case 21: goto L_0x0263;
                    case 22: goto L_0x0259;
                    case 23: goto L_0x024f;
                    case 24: goto L_0x0245;
                    case 25: goto L_0x023b;
                    case 26: goto L_0x0231;
                    case 27: goto L_0x0227;
                    case 28: goto L_0x021d;
                    case 29: goto L_0x0213;
                    case 30: goto L_0x0209;
                    case 31: goto L_0x01fa;
                    case 32: goto L_0x01ef;
                    case 33: goto L_0x01d9;
                    case 34: goto L_0x01c3;
                    case 35: goto L_0x01b5;
                    case 36: goto L_0x019f;
                    case 37: goto L_0x0189;
                    case 38: goto L_0x017b;
                    default: goto L_0x00aa;
                }
            L_0x00aa:
                switch(r6) {
                    case 44: goto L_0x00e7;
                    case 45: goto L_0x00dd;
                    case 46: goto L_0x00d3;
                    case 47: goto L_0x00cb;
                    case 48: goto L_0x00c3;
                    case 49: goto L_0x00b9;
                    case 50: goto L_0x00af;
                    default: goto L_0x00ad;
                }
            L_0x00ad:
                goto L_0x03a7
            L_0x00af:
                int r6 = r9.f446Q
                int r4 = r10.getDimensionPixelOffset(r4, r6)
                r9.f446Q = r4
                goto L_0x03a7
            L_0x00b9:
                int r6 = r9.f445P
                int r4 = r10.getDimensionPixelOffset(r4, r6)
                r9.f445P = r4
                goto L_0x03a7
            L_0x00c3:
                int r4 = r10.getInt(r4, r2)
                r9.f436G = r4
                goto L_0x03a7
            L_0x00cb:
                int r4 = r10.getInt(r4, r2)
                r9.f435F = r4
                goto L_0x03a7
            L_0x00d3:
                float r6 = r9.f434E
                float r4 = r10.getFloat(r4, r6)
                r9.f434E = r4
                goto L_0x03a7
            L_0x00dd:
                float r6 = r9.f433D
                float r4 = r10.getFloat(r4, r6)
                r9.f433D = r4
                goto L_0x03a7
            L_0x00e7:
                java.lang.String r4 = r10.getString(r4)
                r9.f431B = r4
                r9.f432C = r0
                if (r4 == 0) goto L_0x03a7
                int r4 = r4.length()
                java.lang.String r6 = r9.f431B
                r7 = 44
                int r6 = r6.indexOf(r7)
                if (r6 <= 0) goto L_0x0121
                int r7 = r4 + -1
                if (r6 >= r7) goto L_0x0121
                java.lang.String r7 = r9.f431B
                java.lang.String r7 = r7.substring(r2, r6)
                java.lang.String r8 = "W"
                boolean r8 = r7.equalsIgnoreCase(r8)
                if (r8 == 0) goto L_0x0114
                r9.f432C = r2
                goto L_0x011e
            L_0x0114:
                java.lang.String r8 = "H"
                boolean r7 = r7.equalsIgnoreCase(r8)
                if (r7 == 0) goto L_0x011e
                r9.f432C = r5
            L_0x011e:
                int r6 = r6 + 1
                goto L_0x0122
            L_0x0121:
                r6 = r2
            L_0x0122:
                java.lang.String r7 = r9.f431B
                r8 = 58
                int r7 = r7.indexOf(r8)
                if (r7 < 0) goto L_0x016a
                int r4 = r4 + -1
                if (r7 >= r4) goto L_0x016a
                java.lang.String r4 = r9.f431B
                java.lang.String r4 = r4.substring(r6, r7)
                java.lang.String r6 = r9.f431B
                int r7 = r7 + 1
                java.lang.String r6 = r6.substring(r7)
                int r7 = r4.length()
                if (r7 <= 0) goto L_0x03a7
                int r7 = r6.length()
                if (r7 <= 0) goto L_0x03a7
                float r4 = java.lang.Float.parseFloat(r4)     // Catch:{ NumberFormatException -> 0x03a7 }
                float r6 = java.lang.Float.parseFloat(r6)     // Catch:{ NumberFormatException -> 0x03a7 }
                int r7 = (r4 > r3 ? 1 : (r4 == r3 ? 0 : -1))
                if (r7 <= 0) goto L_0x03a7
                int r7 = (r6 > r3 ? 1 : (r6 == r3 ? 0 : -1))
                if (r7 <= 0) goto L_0x03a7
                int r7 = r9.f432C     // Catch:{ NumberFormatException -> 0x03a7 }
                if (r7 != r5) goto L_0x0164
                float r6 = r6 / r4
                java.lang.Math.abs(r6)     // Catch:{ NumberFormatException -> 0x03a7 }
                goto L_0x03a7
            L_0x0164:
                float r4 = r4 / r6
                java.lang.Math.abs(r4)     // Catch:{ NumberFormatException -> 0x03a7 }
                goto L_0x03a7
            L_0x016a:
                java.lang.String r4 = r9.f431B
                java.lang.String r4 = r4.substring(r6)
                int r6 = r4.length()
                if (r6 <= 0) goto L_0x03a7
                java.lang.Float.parseFloat(r4)     // Catch:{ NumberFormatException -> 0x03a7 }
                goto L_0x03a7
            L_0x017b:
                float r6 = r9.f444O
                float r4 = r10.getFloat(r4, r6)
                float r4 = java.lang.Math.max(r3, r4)
                r9.f444O = r4
                goto L_0x03a7
            L_0x0189:
                int r6 = r9.f442M     // Catch:{ Exception -> 0x0193 }
                int r6 = r10.getDimensionPixelSize(r4, r6)     // Catch:{ Exception -> 0x0193 }
                r9.f442M = r6     // Catch:{ Exception -> 0x0193 }
                goto L_0x03a7
            L_0x0193:
                int r6 = r9.f442M
                int r4 = r10.getInt(r4, r6)
                if (r4 != r8) goto L_0x03a7
                r9.f442M = r8
                goto L_0x03a7
            L_0x019f:
                int r6 = r9.f440K     // Catch:{ Exception -> 0x01a9 }
                int r6 = r10.getDimensionPixelSize(r4, r6)     // Catch:{ Exception -> 0x01a9 }
                r9.f440K = r6     // Catch:{ Exception -> 0x01a9 }
                goto L_0x03a7
            L_0x01a9:
                int r6 = r9.f440K
                int r4 = r10.getInt(r4, r6)
                if (r4 != r8) goto L_0x03a7
                r9.f440K = r8
                goto L_0x03a7
            L_0x01b5:
                float r6 = r9.f443N
                float r4 = r10.getFloat(r4, r6)
                float r4 = java.lang.Math.max(r3, r4)
                r9.f443N = r4
                goto L_0x03a7
            L_0x01c3:
                int r6 = r9.f441L     // Catch:{ Exception -> 0x01cd }
                int r6 = r10.getDimensionPixelSize(r4, r6)     // Catch:{ Exception -> 0x01cd }
                r9.f441L = r6     // Catch:{ Exception -> 0x01cd }
                goto L_0x03a7
            L_0x01cd:
                int r6 = r9.f441L
                int r4 = r10.getInt(r4, r6)
                if (r4 != r8) goto L_0x03a7
                r9.f441L = r8
                goto L_0x03a7
            L_0x01d9:
                int r6 = r9.f439J     // Catch:{ Exception -> 0x01e3 }
                int r6 = r10.getDimensionPixelSize(r4, r6)     // Catch:{ Exception -> 0x01e3 }
                r9.f439J = r6     // Catch:{ Exception -> 0x01e3 }
                goto L_0x03a7
            L_0x01e3:
                int r6 = r9.f439J
                int r4 = r10.getInt(r4, r6)
                if (r4 != r8) goto L_0x03a7
                r9.f439J = r8
                goto L_0x03a7
            L_0x01ef:
                int r4 = r10.getInt(r4, r2)
                r9.f438I = r4
                if (r4 != r5) goto L_0x03a7
                java.lang.String r4 = "layout_constraintHeight_default=\"wrap\" is deprecated.\nUse layout_height=\"WRAP_CONTENT\" and layout_constrainedHeight=\"true\" instead."
                goto L_0x0204
            L_0x01fa:
                int r4 = r10.getInt(r4, r2)
                r9.f437H = r4
                if (r4 != r5) goto L_0x03a7
                java.lang.String r4 = "layout_constraintWidth_default=\"wrap\" is deprecated.\nUse layout_width=\"WRAP_CONTENT\" and layout_constrainedWidth=\"true\" instead."
            L_0x0204:
                android.util.Log.e(r7, r4)
                goto L_0x03a7
            L_0x0209:
                float r6 = r9.f430A
                float r4 = r10.getFloat(r4, r6)
                r9.f430A = r4
                goto L_0x03a7
            L_0x0213:
                float r6 = r9.f493z
                float r4 = r10.getFloat(r4, r6)
                r9.f493z = r4
                goto L_0x03a7
            L_0x021d:
                boolean r6 = r9.f449T
                boolean r4 = r10.getBoolean(r4, r6)
                r9.f449T = r4
                goto L_0x03a7
            L_0x0227:
                boolean r6 = r9.f448S
                boolean r4 = r10.getBoolean(r4, r6)
                r9.f448S = r4
                goto L_0x03a7
            L_0x0231:
                int r6 = r9.f492y
                int r4 = r10.getDimensionPixelSize(r4, r6)
                r9.f492y = r4
                goto L_0x03a7
            L_0x023b:
                int r6 = r9.f491x
                int r4 = r10.getDimensionPixelSize(r4, r6)
                r9.f491x = r4
                goto L_0x03a7
            L_0x0245:
                int r6 = r9.f490w
                int r4 = r10.getDimensionPixelSize(r4, r6)
                r9.f490w = r4
                goto L_0x03a7
            L_0x024f:
                int r6 = r9.f489v
                int r4 = r10.getDimensionPixelSize(r4, r6)
                r9.f489v = r4
                goto L_0x03a7
            L_0x0259:
                int r6 = r9.f488u
                int r4 = r10.getDimensionPixelSize(r4, r6)
                r9.f488u = r4
                goto L_0x03a7
            L_0x0263:
                int r6 = r9.f487t
                int r4 = r10.getDimensionPixelSize(r4, r6)
                r9.f487t = r4
                goto L_0x03a7
            L_0x026d:
                int r6 = r9.f486s
                int r6 = r10.getResourceId(r4, r6)
                r9.f486s = r6
                if (r6 != r0) goto L_0x03a7
                int r4 = r10.getInt(r4, r0)
                r9.f486s = r4
                goto L_0x03a7
            L_0x027f:
                int r6 = r9.f485r
                int r6 = r10.getResourceId(r4, r6)
                r9.f485r = r6
                if (r6 != r0) goto L_0x03a7
                int r4 = r10.getInt(r4, r0)
                r9.f485r = r4
                goto L_0x03a7
            L_0x0291:
                int r6 = r9.f484q
                int r6 = r10.getResourceId(r4, r6)
                r9.f484q = r6
                if (r6 != r0) goto L_0x03a7
                int r4 = r10.getInt(r4, r0)
                r9.f484q = r4
                goto L_0x03a7
            L_0x02a3:
                int r6 = r9.f483p
                int r6 = r10.getResourceId(r4, r6)
                r9.f483p = r6
                if (r6 != r0) goto L_0x03a7
                int r4 = r10.getInt(r4, r0)
                r9.f483p = r4
                goto L_0x03a7
            L_0x02b5:
                int r6 = r9.f478l
                int r6 = r10.getResourceId(r4, r6)
                r9.f478l = r6
                if (r6 != r0) goto L_0x03a7
                int r4 = r10.getInt(r4, r0)
                r9.f478l = r4
                goto L_0x03a7
            L_0x02c7:
                int r6 = r9.f476k
                int r6 = r10.getResourceId(r4, r6)
                r9.f476k = r6
                if (r6 != r0) goto L_0x03a7
                int r4 = r10.getInt(r4, r0)
                r9.f476k = r4
                goto L_0x03a7
            L_0x02d9:
                int r6 = r9.f474j
                int r6 = r10.getResourceId(r4, r6)
                r9.f474j = r6
                if (r6 != r0) goto L_0x03a7
                int r4 = r10.getInt(r4, r0)
                r9.f474j = r4
                goto L_0x03a7
            L_0x02eb:
                int r6 = r9.f472i
                int r6 = r10.getResourceId(r4, r6)
                r9.f472i = r6
                if (r6 != r0) goto L_0x03a7
                int r4 = r10.getInt(r4, r0)
                r9.f472i = r4
                goto L_0x03a7
            L_0x02fd:
                int r6 = r9.f470h
                int r6 = r10.getResourceId(r4, r6)
                r9.f470h = r6
                if (r6 != r0) goto L_0x03a7
                int r4 = r10.getInt(r4, r0)
                r9.f470h = r4
                goto L_0x03a7
            L_0x030f:
                int r6 = r9.f468g
                int r6 = r10.getResourceId(r4, r6)
                r9.f468g = r6
                if (r6 != r0) goto L_0x03a7
                int r4 = r10.getInt(r4, r0)
                r9.f468g = r4
                goto L_0x03a7
            L_0x0321:
                int r6 = r9.f466f
                int r6 = r10.getResourceId(r4, r6)
                r9.f466f = r6
                if (r6 != r0) goto L_0x03a7
                int r4 = r10.getInt(r4, r0)
                r9.f466f = r4
                goto L_0x03a7
            L_0x0333:
                int r6 = r9.f464e
                int r6 = r10.getResourceId(r4, r6)
                r9.f464e = r6
                if (r6 != r0) goto L_0x03a7
                int r4 = r10.getInt(r4, r0)
                r9.f464e = r4
                goto L_0x03a7
            L_0x0344:
                int r6 = r9.f462d
                int r6 = r10.getResourceId(r4, r6)
                r9.f462d = r6
                if (r6 != r0) goto L_0x03a7
                int r4 = r10.getInt(r4, r0)
                r9.f462d = r4
                goto L_0x03a7
            L_0x0355:
                float r6 = r9.f460c
                float r4 = r10.getFloat(r4, r6)
                r9.f460c = r4
                goto L_0x03a7
            L_0x035e:
                int r6 = r9.f458b
                int r4 = r10.getDimensionPixelOffset(r4, r6)
                r9.f458b = r4
                goto L_0x03a7
            L_0x0367:
                int r6 = r9.f456a
                int r4 = r10.getDimensionPixelOffset(r4, r6)
                r9.f456a = r4
                goto L_0x03a7
            L_0x0370:
                float r6 = r9.f482o
                float r4 = r10.getFloat(r4, r6)
                r6 = 1135869952(0x43b40000, float:360.0)
                float r4 = r4 % r6
                r9.f482o = r4
                int r7 = (r4 > r3 ? 1 : (r4 == r3 ? 0 : -1))
                if (r7 >= 0) goto L_0x03a7
                float r4 = r6 - r4
                float r4 = r4 % r6
                r9.f482o = r4
                goto L_0x03a7
            L_0x0385:
                int r6 = r9.f481n
                int r4 = r10.getDimensionPixelSize(r4, r6)
                r9.f481n = r4
                goto L_0x03a7
            L_0x038e:
                int r6 = r9.f480m
                int r6 = r10.getResourceId(r4, r6)
                r9.f480m = r6
                if (r6 != r0) goto L_0x03a7
                int r4 = r10.getInt(r4, r0)
                r9.f480m = r4
                goto L_0x03a7
            L_0x039f:
                int r6 = r9.f447R
                int r4 = r10.getInt(r4, r6)
                r9.f447R = r4
            L_0x03a7:
                int r1 = r1 + 1
                goto L_0x0098
            L_0x03ab:
                r10.recycle()
                r9.mo661a()
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: androidx.constraintlayout.widget.ConstraintLayout.C0066a.<init>(android.content.Context, android.util.AttributeSet):void");
        }

        public C0066a(ViewGroup.LayoutParams layoutParams) {
            super(layoutParams);
        }

        /* renamed from: a */
        public void mo661a() {
            this.f453X = false;
            this.f450U = true;
            this.f451V = true;
            if (this.width == -2 && this.f448S) {
                this.f450U = false;
                this.f437H = 1;
            }
            if (this.height == -2 && this.f449T) {
                this.f451V = false;
                this.f438I = 1;
            }
            int i = this.width;
            if (i == 0 || i == -1) {
                this.f450U = false;
                if (this.width == 0 && this.f437H == 1) {
                    this.width = -2;
                    this.f448S = true;
                }
            }
            int i2 = this.height;
            if (i2 == 0 || i2 == -1) {
                this.f451V = false;
                if (this.height == 0 && this.f438I == 1) {
                    this.height = -2;
                    this.f449T = true;
                }
            }
            if (this.f460c != -1.0f || this.f456a != -1 || this.f458b != -1) {
                this.f453X = true;
                this.f450U = true;
                this.f451V = true;
                if (!(this.f477k0 instanceof C5557g)) {
                    this.f477k0 = new C5557g();
                }
                ((C5557g) this.f477k0).mo11665F(this.f447R);
            }
        }

        /* JADX WARNING: Code restructure failed: missing block: B:71:0x00d6, code lost:
            if (r1 > 0) goto L_0x00d8;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:77:0x00e5, code lost:
            if (r1 > 0) goto L_0x00d8;
         */
        /* JADX WARNING: Removed duplicated region for block: B:14:0x004c  */
        /* JADX WARNING: Removed duplicated region for block: B:17:0x0053  */
        /* JADX WARNING: Removed duplicated region for block: B:20:0x005a  */
        /* JADX WARNING: Removed duplicated region for block: B:23:0x0060  */
        /* JADX WARNING: Removed duplicated region for block: B:26:0x0066  */
        /* JADX WARNING: Removed duplicated region for block: B:33:0x007c  */
        /* JADX WARNING: Removed duplicated region for block: B:34:0x0084  */
        /* JADX WARNING: Removed duplicated region for block: B:80:0x00ec  */
        /* JADX WARNING: Removed duplicated region for block: B:84:0x00f7  */
        @android.annotation.TargetApi(17)
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public void resolveLayoutDirection(int r7) {
            /*
                r6 = this;
                int r0 = r6.leftMargin
                int r1 = r6.rightMargin
                super.resolveLayoutDirection(r7)
                r7 = -1
                r6.f461c0 = r7
                r6.f463d0 = r7
                r6.f457a0 = r7
                r6.f459b0 = r7
                r6.f465e0 = r7
                r6.f467f0 = r7
                int r2 = r6.f487t
                r6.f465e0 = r2
                int r2 = r6.f489v
                r6.f467f0 = r2
                float r2 = r6.f493z
                r6.f469g0 = r2
                int r2 = r6.f456a
                r6.f471h0 = r2
                int r2 = r6.f458b
                r6.f473i0 = r2
                float r2 = r6.f460c
                r6.f475j0 = r2
                int r2 = r6.getLayoutDirection()
                r3 = 0
                r4 = 1
                if (r4 != r2) goto L_0x0036
                r2 = r4
                goto L_0x0037
            L_0x0036:
                r2 = r3
            L_0x0037:
                if (r2 == 0) goto L_0x0098
                int r2 = r6.f483p
                if (r2 == r7) goto L_0x0041
                r6.f461c0 = r2
            L_0x003f:
                r3 = r4
                goto L_0x0048
            L_0x0041:
                int r2 = r6.f484q
                if (r2 == r7) goto L_0x0048
                r6.f463d0 = r2
                goto L_0x003f
            L_0x0048:
                int r2 = r6.f485r
                if (r2 == r7) goto L_0x004f
                r6.f459b0 = r2
                r3 = r4
            L_0x004f:
                int r2 = r6.f486s
                if (r2 == r7) goto L_0x0056
                r6.f457a0 = r2
                r3 = r4
            L_0x0056:
                int r2 = r6.f491x
                if (r2 == r7) goto L_0x005c
                r6.f467f0 = r2
            L_0x005c:
                int r2 = r6.f492y
                if (r2 == r7) goto L_0x0062
                r6.f465e0 = r2
            L_0x0062:
                r2 = 1065353216(0x3f800000, float:1.0)
                if (r3 == 0) goto L_0x006c
                float r3 = r6.f493z
                float r3 = r2 - r3
                r6.f469g0 = r3
            L_0x006c:
                boolean r3 = r6.f453X
                if (r3 == 0) goto L_0x00bc
                int r3 = r6.f447R
                if (r3 != r4) goto L_0x00bc
                float r3 = r6.f460c
                r4 = -1082130432(0xffffffffbf800000, float:-1.0)
                int r5 = (r3 > r4 ? 1 : (r3 == r4 ? 0 : -1))
                if (r5 == 0) goto L_0x0084
                float r2 = r2 - r3
                r6.f475j0 = r2
                r6.f471h0 = r7
                r6.f473i0 = r7
                goto L_0x00bc
            L_0x0084:
                int r2 = r6.f456a
                if (r2 == r7) goto L_0x008f
                r6.f473i0 = r2
                r6.f471h0 = r7
            L_0x008c:
                r6.f475j0 = r4
                goto L_0x00bc
            L_0x008f:
                int r2 = r6.f458b
                if (r2 == r7) goto L_0x00bc
                r6.f471h0 = r2
                r6.f473i0 = r7
                goto L_0x008c
            L_0x0098:
                int r2 = r6.f483p
                if (r2 == r7) goto L_0x009e
                r6.f459b0 = r2
            L_0x009e:
                int r2 = r6.f484q
                if (r2 == r7) goto L_0x00a4
                r6.f457a0 = r2
            L_0x00a4:
                int r2 = r6.f485r
                if (r2 == r7) goto L_0x00aa
                r6.f461c0 = r2
            L_0x00aa:
                int r2 = r6.f486s
                if (r2 == r7) goto L_0x00b0
                r6.f463d0 = r2
            L_0x00b0:
                int r2 = r6.f491x
                if (r2 == r7) goto L_0x00b6
                r6.f465e0 = r2
            L_0x00b6:
                int r2 = r6.f492y
                if (r2 == r7) goto L_0x00bc
                r6.f467f0 = r2
            L_0x00bc:
                int r2 = r6.f485r
                if (r2 != r7) goto L_0x0104
                int r2 = r6.f486s
                if (r2 != r7) goto L_0x0104
                int r2 = r6.f484q
                if (r2 != r7) goto L_0x0104
                int r2 = r6.f483p
                if (r2 != r7) goto L_0x0104
                int r2 = r6.f466f
                if (r2 == r7) goto L_0x00db
                r6.f461c0 = r2
                int r2 = r6.rightMargin
                if (r2 > 0) goto L_0x00e8
                if (r1 <= 0) goto L_0x00e8
            L_0x00d8:
                r6.rightMargin = r1
                goto L_0x00e8
            L_0x00db:
                int r2 = r6.f468g
                if (r2 == r7) goto L_0x00e8
                r6.f463d0 = r2
                int r2 = r6.rightMargin
                if (r2 > 0) goto L_0x00e8
                if (r1 <= 0) goto L_0x00e8
                goto L_0x00d8
            L_0x00e8:
                int r1 = r6.f462d
                if (r1 == r7) goto L_0x00f7
                r6.f457a0 = r1
                int r7 = r6.leftMargin
                if (r7 > 0) goto L_0x0104
                if (r0 <= 0) goto L_0x0104
            L_0x00f4:
                r6.leftMargin = r0
                goto L_0x0104
            L_0x00f7:
                int r1 = r6.f464e
                if (r1 == r7) goto L_0x0104
                r6.f459b0 = r1
                int r7 = r6.leftMargin
                if (r7 > 0) goto L_0x0104
                if (r0 <= 0) goto L_0x0104
                goto L_0x00f4
            L_0x0104:
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: androidx.constraintlayout.widget.ConstraintLayout.C0066a.resolveLayoutDirection(int):void");
        }
    }

    public ConstraintLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f418h.f19553X = this;
        this.f415e.put(getId(), this);
        this.f425o = null;
        if (attributeSet != null) {
            TypedArray obtainStyledAttributes = getContext().obtainStyledAttributes(attributeSet, C5575h.ConstraintLayout_Layout);
            int indexCount = obtainStyledAttributes.getIndexCount();
            for (int i = 0; i < indexCount; i++) {
                int index = obtainStyledAttributes.getIndex(i);
                if (index == C5575h.ConstraintLayout_Layout_android_minWidth) {
                    this.f419i = obtainStyledAttributes.getDimensionPixelOffset(index, this.f419i);
                } else if (index == C5575h.ConstraintLayout_Layout_android_minHeight) {
                    this.f420j = obtainStyledAttributes.getDimensionPixelOffset(index, this.f420j);
                } else if (index == C5575h.ConstraintLayout_Layout_android_maxWidth) {
                    this.f421k = obtainStyledAttributes.getDimensionPixelOffset(index, this.f421k);
                } else if (index == C5575h.ConstraintLayout_Layout_android_maxHeight) {
                    this.f422l = obtainStyledAttributes.getDimensionPixelOffset(index, this.f422l);
                } else if (index == C5575h.ConstraintLayout_Layout_layout_optimizationLevel) {
                    this.f424n = obtainStyledAttributes.getInt(index, this.f424n);
                } else if (index == C5575h.ConstraintLayout_Layout_constraintSet) {
                    int resourceId = obtainStyledAttributes.getResourceId(index, 0);
                    try {
                        C5568c cVar = new C5568c();
                        this.f425o = cVar;
                        cVar.mo11695c(getContext(), resourceId);
                    } catch (Resources.NotFoundException unused) {
                        this.f425o = null;
                    }
                    this.f426p = resourceId;
                }
            }
            obtainStyledAttributes.recycle();
        }
        this.f418h.f19597B0 = this.f424n;
    }

    /* renamed from: a */
    public C0066a generateDefaultLayoutParams() {
        return new C0066a(-2, -2);
    }

    public void addView(View view, int i, ViewGroup.LayoutParams layoutParams) {
        super.addView(view, i, layoutParams);
    }

    /* renamed from: b */
    public Object mo630b(int i, Object obj) {
        if (i != 0 || !(obj instanceof String)) {
            return null;
        }
        String str = (String) obj;
        HashMap<String, Integer> hashMap = this.f427q;
        if (hashMap == null || !hashMap.containsKey(str)) {
            return null;
        }
        return this.f427q.get(str);
    }

    /* renamed from: c */
    public final C5553d mo631c(int i) {
        if (i == 0) {
            return this.f418h;
        }
        View view = this.f415e.get(i);
        if (view == null && (view = findViewById(i)) != null && view != this && view.getParent() == this) {
            onViewAdded(view);
        }
        if (view == this) {
            return this.f418h;
        }
        if (view == null) {
            return null;
        }
        return ((C0066a) view.getLayoutParams()).f477k0;
    }

    public boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof C0066a;
    }

    /* renamed from: d */
    public final C5553d mo633d(View view) {
        if (view == this) {
            return this.f418h;
        }
        if (view == null) {
            return null;
        }
        return ((C0066a) view.getLayoutParams()).f477k0;
    }

    public void dispatchDraw(Canvas canvas) {
        Object tag;
        super.dispatchDraw(canvas);
        if (isInEditMode()) {
            int childCount = getChildCount();
            float width = (float) getWidth();
            float height = (float) getHeight();
            for (int i = 0; i < childCount; i++) {
                View childAt = getChildAt(i);
                if (!(childAt.getVisibility() == 8 || (tag = childAt.getTag()) == null || !(tag instanceof String))) {
                    String[] split = ((String) tag).split(",");
                    if (split.length == 4) {
                        int parseInt = Integer.parseInt(split[0]);
                        int parseInt2 = Integer.parseInt(split[1]);
                        int parseInt3 = Integer.parseInt(split[2]);
                        int i2 = (int) ((((float) parseInt) / 1080.0f) * width);
                        int i3 = (int) ((((float) parseInt2) / 1920.0f) * height);
                        Paint paint = new Paint();
                        paint.setColor(-65536);
                        float f = (float) i2;
                        float f2 = (float) (i2 + ((int) ((((float) parseInt3) / 1080.0f) * width)));
                        Canvas canvas2 = canvas;
                        float f3 = (float) i3;
                        float f4 = f;
                        float f5 = f;
                        float f6 = f3;
                        Paint paint2 = paint;
                        float f7 = f2;
                        Paint paint3 = paint2;
                        canvas2.drawLine(f4, f6, f7, f3, paint3);
                        float parseInt4 = (float) (i3 + ((int) ((((float) Integer.parseInt(split[3])) / 1920.0f) * height)));
                        float f8 = f2;
                        float f9 = parseInt4;
                        canvas2.drawLine(f8, f6, f7, f9, paint3);
                        float f10 = parseInt4;
                        float f11 = f5;
                        canvas2.drawLine(f8, f10, f11, f9, paint3);
                        float f12 = f5;
                        canvas2.drawLine(f12, f10, f11, f3, paint3);
                        Paint paint4 = paint2;
                        paint4.setColor(-16711936);
                        Paint paint5 = paint4;
                        float f13 = f2;
                        Paint paint6 = paint5;
                        canvas2.drawLine(f12, f3, f13, parseInt4, paint6);
                        canvas2.drawLine(f12, parseInt4, f13, f3, paint6);
                    }
                }
            }
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:113:0x021d  */
    /* JADX WARNING: Removed duplicated region for block: B:137:0x0277  */
    /* JADX WARNING: Removed duplicated region for block: B:147:0x02a4  */
    /* JADX WARNING: Removed duplicated region for block: B:149:0x02a8  */
    /* JADX WARNING: Removed duplicated region for block: B:152:0x02ad  */
    /* JADX WARNING: Removed duplicated region for block: B:153:0x02b5  */
    /* JADX WARNING: Removed duplicated region for block: B:156:0x02c1  */
    /* JADX WARNING: Removed duplicated region for block: B:157:0x02c5  */
    /* JADX WARNING: Removed duplicated region for block: B:160:0x02cd  */
    /* JADX WARNING: Removed duplicated region for block: B:163:0x02d7  */
    /* renamed from: e */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void mo635e(int r31, int r32) {
        /*
            r30 = this;
            r0 = r30
            r1 = r31
            r2 = r32
            d.h.a.h.d$a r3 = p176d.p215h.p216a.p217h.C5553d.C5554a.MATCH_CONSTRAINT
            d.h.a.h.d$a r4 = p176d.p215h.p216a.p217h.C5553d.C5554a.WRAP_CONTENT
            d.h.a.h.c$b r5 = p176d.p215h.p216a.p217h.C5550c.C5552b.BOTTOM
            d.h.a.h.c$b r6 = p176d.p215h.p216a.p217h.C5550c.C5552b.TOP
            d.h.a.h.c$b r7 = p176d.p215h.p216a.p217h.C5550c.C5552b.RIGHT
            d.h.a.h.c$b r8 = p176d.p215h.p216a.p217h.C5550c.C5552b.LEFT
            int r9 = r30.getPaddingTop()
            int r10 = r30.getPaddingBottom()
            int r10 = r10 + r9
            int r9 = r30.getPaddingLeft()
            int r11 = r30.getPaddingRight()
            int r11 = r11 + r9
            int r9 = r30.getChildCount()
            r13 = 0
        L_0x0029:
            r14 = 8
            if (r13 >= r9) goto L_0x00d5
            android.view.View r15 = r0.getChildAt(r13)
            int r12 = r15.getVisibility()
            if (r12 != r14) goto L_0x003b
            r19 = r3
            goto L_0x00c7
        L_0x003b:
            android.view.ViewGroup$LayoutParams r12 = r15.getLayoutParams()
            androidx.constraintlayout.widget.ConstraintLayout$a r12 = (androidx.constraintlayout.widget.ConstraintLayout.C0066a) r12
            d.h.a.h.d r14 = r12.f477k0
            r19 = r3
            boolean r3 = r12.f453X
            if (r3 != 0) goto L_0x00c7
            boolean r3 = r12.f454Y
            if (r3 == 0) goto L_0x004f
            goto L_0x00c7
        L_0x004f:
            int r3 = r15.getVisibility()
            r14.f19554Y = r3
            int r3 = r12.width
            r20 = r4
            int r4 = r12.height
            if (r3 == 0) goto L_0x00b6
            if (r4 != 0) goto L_0x0060
            goto L_0x00b6
        L_0x0060:
            r21 = r5
            r5 = -2
            if (r3 != r5) goto L_0x0068
            r18 = 1
            goto L_0x006a
        L_0x0068:
            r18 = 0
        L_0x006a:
            int r3 = android.view.ViewGroup.getChildMeasureSpec(r1, r11, r3)
            if (r4 != r5) goto L_0x0073
            r16 = 1
            goto L_0x0075
        L_0x0073:
            r16 = 0
        L_0x0075:
            int r4 = android.view.ViewGroup.getChildMeasureSpec(r2, r10, r4)
            r15.measure(r3, r4)
            int r3 = r15.getMeasuredWidth()
            int r4 = r15.getMeasuredHeight()
            r14.mo11628C(r3)
            r14.mo11649w(r4)
            if (r18 == 0) goto L_0x008e
            r14.f19549T = r3
        L_0x008e:
            if (r16 == 0) goto L_0x0092
            r14.f19550U = r4
        L_0x0092:
            boolean r5 = r12.f452W
            if (r5 == 0) goto L_0x009f
            int r5 = r15.getBaseline()
            r15 = -1
            if (r5 == r15) goto L_0x009f
            r14.f19546Q = r5
        L_0x009f:
            boolean r5 = r12.f450U
            if (r5 == 0) goto L_0x00cb
            boolean r5 = r12.f451V
            if (r5 == 0) goto L_0x00cb
            d.h.a.h.k r5 = r14.mo11639l()
            r5.mo11675e(r3)
            d.h.a.h.k r3 = r14.mo11638k()
            r3.mo11675e(r4)
            goto L_0x00cb
        L_0x00b6:
            r21 = r5
            d.h.a.h.k r3 = r14.mo11639l()
            r3.mo11677b()
            d.h.a.h.k r3 = r14.mo11638k()
            r3.mo11677b()
            goto L_0x00cb
        L_0x00c7:
            r20 = r4
            r21 = r5
        L_0x00cb:
            int r13 = r13 + 1
            r3 = r19
            r4 = r20
            r5 = r21
            goto L_0x0029
        L_0x00d5:
            r19 = r3
            r20 = r4
            r21 = r5
            d.h.a.h.e r3 = r0.f418h
            r3.mo11661N()
            r3 = 0
        L_0x00e1:
            if (r3 >= r9) goto L_0x0307
            android.view.View r4 = r0.getChildAt(r3)
            int r5 = r4.getVisibility()
            if (r5 != r14) goto L_0x00ef
            goto L_0x02d9
        L_0x00ef:
            android.view.ViewGroup$LayoutParams r5 = r4.getLayoutParams()
            androidx.constraintlayout.widget.ConstraintLayout$a r5 = (androidx.constraintlayout.widget.ConstraintLayout.C0066a) r5
            d.h.a.h.d r12 = r5.f477k0
            boolean r13 = r5.f453X
            if (r13 != 0) goto L_0x02d9
            boolean r13 = r5.f454Y
            if (r13 == 0) goto L_0x0101
            goto L_0x02d9
        L_0x0101:
            int r13 = r4.getVisibility()
            r12.f19554Y = r13
            int r13 = r5.width
            int r15 = r5.height
            if (r13 == 0) goto L_0x0111
            if (r15 == 0) goto L_0x0111
            goto L_0x02d9
        L_0x0111:
            d.h.a.h.c r14 = r12.mo11633f(r8)
            d.h.a.h.j r14 = r14.f19507a
            r22 = r9
            d.h.a.h.c r9 = r12.mo11633f(r7)
            d.h.a.h.j r9 = r9.f19507a
            r23 = r3
            d.h.a.h.c r3 = r12.mo11633f(r8)
            d.h.a.h.c r3 = r3.f19510d
            if (r3 == 0) goto L_0x0135
            d.h.a.h.c r3 = r12.mo11633f(r7)
            d.h.a.h.c r3 = r3.f19510d
            if (r3 == 0) goto L_0x0135
            r24 = r7
            r3 = 1
            goto L_0x0138
        L_0x0135:
            r24 = r7
            r3 = 0
        L_0x0138:
            d.h.a.h.c r7 = r12.mo11633f(r6)
            d.h.a.h.j r7 = r7.f19507a
            r25 = r8
            r8 = r21
            r21 = r5
            d.h.a.h.c r5 = r12.mo11633f(r8)
            d.h.a.h.j r5 = r5.f19507a
            r26 = r4
            d.h.a.h.c r4 = r12.mo11633f(r6)
            d.h.a.h.c r4 = r4.f19510d
            if (r4 == 0) goto L_0x015e
            d.h.a.h.c r4 = r12.mo11633f(r8)
            d.h.a.h.c r4 = r4.f19510d
            if (r4 == 0) goto L_0x015e
            r4 = 1
            goto L_0x015f
        L_0x015e:
            r4 = 0
        L_0x015f:
            if (r13 != 0) goto L_0x0172
            if (r15 != 0) goto L_0x0172
            if (r3 == 0) goto L_0x0172
            if (r4 == 0) goto L_0x0172
            r5 = r2
            r27 = r6
            r28 = r8
            r0 = r19
            r8 = r20
            goto L_0x02ea
        L_0x0172:
            r27 = r6
            d.h.a.h.e r6 = r0.f418h
            d.h.a.h.d$a r6 = r6.mo11636i()
            r28 = r8
            r8 = r20
            if (r6 == r8) goto L_0x0182
            r6 = 1
            goto L_0x0183
        L_0x0182:
            r6 = 0
        L_0x0183:
            d.h.a.h.e r2 = r0.f418h
            d.h.a.h.d$a r2 = r2.mo11640m()
            if (r2 == r8) goto L_0x018d
            r2 = 1
            goto L_0x018e
        L_0x018d:
            r2 = 0
        L_0x018e:
            if (r6 != 0) goto L_0x0197
            d.h.a.h.k r20 = r12.mo11639l()
            r20.mo11677b()
        L_0x0197:
            if (r2 != 0) goto L_0x01a0
            d.h.a.h.k r20 = r12.mo11638k()
            r20.mo11677b()
        L_0x01a0:
            r20 = 0
            if (r13 != 0) goto L_0x01fb
            if (r6 == 0) goto L_0x01ee
            int r13 = r12.f19564e
            if (r13 != 0) goto L_0x01c4
            float r13 = r12.f19536G
            int r13 = (r13 > r20 ? 1 : (r13 == r20 ? 0 : -1))
            if (r13 != 0) goto L_0x01c4
            int r13 = r12.f19570h
            if (r13 != 0) goto L_0x01c4
            int r13 = r12.f19572i
            if (r13 != 0) goto L_0x01c4
            d.h.a.h.d$a[] r13 = r12.f19532C
            r17 = 0
            r13 = r13[r17]
            r0 = r19
            if (r13 != r0) goto L_0x01c8
            r13 = 1
            goto L_0x01ca
        L_0x01c4:
            r0 = r19
            r17 = 0
        L_0x01c8:
            r13 = r17
        L_0x01ca:
            if (r13 == 0) goto L_0x01f2
            if (r3 == 0) goto L_0x01f2
            boolean r3 = r14.mo11678c()
            if (r3 == 0) goto L_0x01f2
            boolean r3 = r9.mo11678c()
            if (r3 == 0) goto L_0x01f2
            float r3 = r9.f19641g
            float r9 = r14.f19641g
            float r3 = r3 - r9
            int r3 = (int) r3
            d.h.a.h.k r9 = r12.mo11639l()
            r9.mo11675e(r3)
            int r3 = android.view.ViewGroup.getChildMeasureSpec(r1, r11, r3)
            r13 = r3
            r3 = -2
            goto L_0x0207
        L_0x01ee:
            r0 = r19
            r17 = 0
        L_0x01f2:
            r3 = -2
            int r6 = android.view.ViewGroup.getChildMeasureSpec(r1, r11, r3)
            r9 = r17
            r3 = 1
            goto L_0x021b
        L_0x01fb:
            r0 = r19
            r3 = -2
            r9 = -1
            r17 = 0
            if (r13 != r9) goto L_0x020c
            int r13 = android.view.ViewGroup.getChildMeasureSpec(r1, r11, r9)
        L_0x0207:
            r9 = r6
            r6 = r13
            r3 = r17
            goto L_0x021b
        L_0x020c:
            if (r13 != r3) goto L_0x0210
            r3 = 1
            goto L_0x0212
        L_0x0210:
            r3 = r17
        L_0x0212:
            int r9 = android.view.ViewGroup.getChildMeasureSpec(r1, r11, r13)
            r29 = r9
            r9 = r6
            r6 = r29
        L_0x021b:
            if (r15 != 0) goto L_0x0277
            if (r2 == 0) goto L_0x026a
            int r13 = r12.f19566f
            if (r13 != 0) goto L_0x023a
            float r13 = r12.f19536G
            int r13 = (r13 > r20 ? 1 : (r13 == r20 ? 0 : -1))
            if (r13 != 0) goto L_0x023a
            int r13 = r12.f19575k
            if (r13 != 0) goto L_0x023a
            int r13 = r12.f19576l
            if (r13 != 0) goto L_0x023a
            d.h.a.h.d$a[] r13 = r12.f19532C
            r14 = 1
            r13 = r13[r14]
            if (r13 != r0) goto L_0x023b
            r13 = r14
            goto L_0x023d
        L_0x023a:
            r14 = 1
        L_0x023b:
            r13 = r17
        L_0x023d:
            if (r13 == 0) goto L_0x0267
            if (r4 == 0) goto L_0x0267
            boolean r4 = r7.mo11678c()
            if (r4 == 0) goto L_0x0267
            boolean r4 = r5.mo11678c()
            if (r4 == 0) goto L_0x0267
            float r4 = r5.f19641g
            float r5 = r7.f19641g
            float r4 = r4 - r5
            int r4 = (int) r4
            d.h.a.h.k r5 = r12.mo11638k()
            r5.mo11675e(r4)
            r5 = r32
            int r4 = android.view.ViewGroup.getChildMeasureSpec(r5, r10, r4)
            r13 = r4
            r7 = r17
            r15 = r26
            r4 = -2
            goto L_0x0291
        L_0x0267:
            r5 = r32
            goto L_0x026d
        L_0x026a:
            r5 = r32
            r14 = 1
        L_0x026d:
            r4 = -2
            int r2 = android.view.ViewGroup.getChildMeasureSpec(r5, r10, r4)
            r13 = r2
            r7 = r14
            r2 = r17
            goto L_0x028f
        L_0x0277:
            r5 = r32
            r4 = -2
            r7 = -1
            r14 = 1
            if (r15 != r7) goto L_0x0285
            int r13 = android.view.ViewGroup.getChildMeasureSpec(r5, r10, r7)
            r7 = r17
            goto L_0x028f
        L_0x0285:
            if (r15 != r4) goto L_0x0289
            r7 = r14
            goto L_0x028b
        L_0x0289:
            r7 = r17
        L_0x028b:
            int r13 = android.view.ViewGroup.getChildMeasureSpec(r5, r10, r15)
        L_0x028f:
            r15 = r26
        L_0x0291:
            r15.measure(r6, r13)
            int r6 = r15.getMeasuredWidth()
            int r13 = r15.getMeasuredHeight()
            r12.mo11628C(r6)
            r12.mo11649w(r13)
            if (r3 == 0) goto L_0x02a6
            r12.f19549T = r6
        L_0x02a6:
            if (r7 == 0) goto L_0x02aa
            r12.f19550U = r13
        L_0x02aa:
            r3 = 2
            if (r9 == 0) goto L_0x02b5
            d.h.a.h.k r7 = r12.mo11639l()
            r7.mo11675e(r6)
            goto L_0x02bb
        L_0x02b5:
            d.h.a.h.k r6 = r12.mo11639l()
            r6.f19650b = r3
        L_0x02bb:
            d.h.a.h.k r6 = r12.mo11638k()
            if (r2 == 0) goto L_0x02c5
            r6.mo11675e(r13)
            goto L_0x02c7
        L_0x02c5:
            r6.f19650b = r3
        L_0x02c7:
            r2 = r21
            boolean r2 = r2.f452W
            if (r2 == 0) goto L_0x02d7
            int r2 = r15.getBaseline()
            r3 = -1
            if (r2 == r3) goto L_0x02ef
            r12.f19546Q = r2
            goto L_0x02ef
        L_0x02d7:
            r3 = -1
            goto L_0x02ef
        L_0x02d9:
            r5 = r2
            r23 = r3
            r27 = r6
            r24 = r7
            r25 = r8
            r22 = r9
            r0 = r19
            r8 = r20
            r28 = r21
        L_0x02ea:
            r3 = -1
            r4 = -2
            r14 = 1
            r17 = 0
        L_0x02ef:
            int r2 = r23 + 1
            r19 = r0
            r3 = r2
            r2 = r5
            r20 = r8
            r9 = r22
            r7 = r24
            r8 = r25
            r6 = r27
            r21 = r28
            r14 = 8
            r0 = r30
            goto L_0x00e1
        L_0x0307:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.constraintlayout.widget.ConstraintLayout.mo635e(int, int):void");
    }

    /* renamed from: f */
    public void mo636f(int i, Object obj, Object obj2) {
        if (i == 0 && (obj instanceof String) && (obj2 instanceof Integer)) {
            if (this.f427q == null) {
                this.f427q = new HashMap<>();
            }
            String str = (String) obj;
            int indexOf = str.indexOf("/");
            if (indexOf != -1) {
                str = str.substring(indexOf + 1);
            }
            this.f427q.put(str, Integer.valueOf(((Integer) obj2).intValue()));
        }
    }

    /* renamed from: g */
    public void mo637g() {
        this.f418h.mo11653F();
    }

    public ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new C0066a(getContext(), attributeSet);
    }

    public ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return new C0066a(layoutParams);
    }

    public int getMaxHeight() {
        return this.f422l;
    }

    public int getMaxWidth() {
        return this.f421k;
    }

    public int getMinHeight() {
        return this.f420j;
    }

    public int getMinWidth() {
        return this.f419i;
    }

    public int getOptimizationLevel() {
        return this.f418h.f19597B0;
    }

    /* renamed from: h */
    public final void mo646h() {
        int childCount = getChildCount();
        for (int i = 0; i < childCount; i++) {
            View childAt = getChildAt(i);
            if (childAt instanceof C5573f) {
                ((C5573f) childAt).mo11710a();
            }
        }
        int size = this.f416f.size();
        if (size > 0) {
            for (int i2 = 0; i2 < size; i2++) {
                this.f416f.get(i2).mo11685d();
            }
        }
    }

    public void onLayout(boolean z, int i, int i2, int i3, int i4) {
        View content;
        int childCount = getChildCount();
        boolean isInEditMode = isInEditMode();
        for (int i5 = 0; i5 < childCount; i5++) {
            View childAt = getChildAt(i5);
            C0066a aVar = (C0066a) childAt.getLayoutParams();
            C5553d dVar = aVar.f477k0;
            if ((childAt.getVisibility() != 8 || aVar.f453X || aVar.f454Y || isInEditMode) && !aVar.f455Z) {
                int i6 = dVar.f19542M + dVar.f19544O;
                int i7 = dVar.f19543N + dVar.f19545P;
                int n = dVar.mo11641n() + i6;
                int h = dVar.mo11635h() + i7;
                childAt.layout(i6, i7, n, h);
                if ((childAt instanceof C5573f) && (content = ((C5573f) childAt).getContent()) != null) {
                    content.setVisibility(0);
                    content.layout(i6, i7, n, h);
                }
            }
        }
        int size = this.f416f.size();
        if (size > 0) {
            for (int i8 = 0; i8 < size; i8++) {
                this.f416f.get(i8).mo11684c();
            }
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:384:0x0843, code lost:
        if (r13.f437H != 1) goto L_0x0847;
     */
    /* JADX WARNING: Removed duplicated region for block: B:235:0x0524  */
    /* JADX WARNING: Removed duplicated region for block: B:238:0x0530 A[ADDED_TO_REGION] */
    /* JADX WARNING: Removed duplicated region for block: B:246:0x0569  */
    /* JADX WARNING: Removed duplicated region for block: B:249:0x057c  */
    /* JADX WARNING: Removed duplicated region for block: B:257:0x059d  */
    /* JADX WARNING: Removed duplicated region for block: B:261:0x05ac  */
    /* JADX WARNING: Removed duplicated region for block: B:269:0x05c7  */
    /* JADX WARNING: Removed duplicated region for block: B:308:0x06ab  */
    /* JADX WARNING: Removed duplicated region for block: B:349:0x073c  */
    /* JADX WARNING: Removed duplicated region for block: B:397:0x0860  */
    /* JADX WARNING: Removed duplicated region for block: B:420:0x08b2  */
    /* JADX WARNING: Removed duplicated region for block: B:423:0x08c3  */
    /* JADX WARNING: Removed duplicated region for block: B:425:0x08c7  */
    /* JADX WARNING: Removed duplicated region for block: B:463:0x095a  */
    /* JADX WARNING: Removed duplicated region for block: B:485:0x09ac  */
    /* JADX WARNING: Removed duplicated region for block: B:488:0x09b4  */
    /* JADX WARNING: Removed duplicated region for block: B:491:0x09cb  */
    /* JADX WARNING: Removed duplicated region for block: B:593:0x0bb4  */
    /* JADX WARNING: Removed duplicated region for block: B:596:0x0be8  */
    /* JADX WARNING: Removed duplicated region for block: B:599:0x0bef  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void onMeasure(int r52, int r53) {
        /*
            r51 = this;
            r0 = r51
            r1 = r52
            r2 = r53
            d.h.a.h.c$b r9 = p176d.p215h.p216a.p217h.C5550c.C5552b.BOTTOM
            d.h.a.h.c$b r10 = p176d.p215h.p216a.p217h.C5550c.C5552b.RIGHT
            d.h.a.h.d$a r11 = p176d.p215h.p216a.p217h.C5553d.C5554a.WRAP_CONTENT
            d.h.a.h.d$a r12 = p176d.p215h.p216a.p217h.C5553d.C5554a.FIXED
            java.lang.System.currentTimeMillis()
            int r13 = android.view.View.MeasureSpec.getMode(r52)
            int r14 = android.view.View.MeasureSpec.getSize(r52)
            int r15 = android.view.View.MeasureSpec.getMode(r53)
            int r8 = android.view.View.MeasureSpec.getSize(r53)
            int r7 = r51.getPaddingLeft()
            int r6 = r51.getPaddingTop()
            d.h.a.h.e r3 = r0.f418h
            r3.f19538I = r7
            r3.f19539J = r6
            int r4 = r0.f421k
            int[] r5 = r3.f19581q
            r16 = r11
            r11 = 0
            r5[r11] = r4
            int r4 = r0.f422l
            r11 = 1
            r5[r11] = r4
            int r4 = r51.getLayoutDirection()
            if (r4 != r11) goto L_0x0045
            r4 = r11
            goto L_0x0046
        L_0x0045:
            r4 = 0
        L_0x0046:
            r3.f19601k0 = r4
            int r3 = android.view.View.MeasureSpec.getMode(r52)
            int r4 = android.view.View.MeasureSpec.getSize(r52)
            int r5 = android.view.View.MeasureSpec.getMode(r53)
            int r11 = android.view.View.MeasureSpec.getSize(r53)
            int r17 = r51.getPaddingTop()
            int r18 = r51.getPaddingBottom()
            int r18 = r18 + r17
            int r17 = r51.getPaddingLeft()
            int r19 = r51.getPaddingRight()
            int r19 = r19 + r17
            r51.getLayoutParams()
            r17 = r15
            r15 = -2147483648(0xffffffff80000000, float:-0.0)
            r20 = r14
            r14 = 1073741824(0x40000000, float:2.0)
            if (r3 == r15) goto L_0x008e
            if (r3 == 0) goto L_0x008a
            if (r3 == r14) goto L_0x007f
            r3 = r12
            goto L_0x008c
        L_0x007f:
            int r3 = r0.f421k
            int r3 = java.lang.Math.min(r3, r4)
            int r3 = r3 - r19
            r4 = r3
            r3 = r12
            goto L_0x0090
        L_0x008a:
            r3 = r16
        L_0x008c:
            r4 = 0
            goto L_0x0090
        L_0x008e:
            r3 = r16
        L_0x0090:
            if (r5 == r15) goto L_0x00a7
            if (r5 == 0) goto L_0x00a3
            if (r5 == r14) goto L_0x0098
            r5 = r12
            goto L_0x00a5
        L_0x0098:
            int r5 = r0.f422l
            int r5 = java.lang.Math.min(r5, r11)
            int r5 = r5 - r18
            r11 = r5
            r5 = r12
            goto L_0x00a9
        L_0x00a3:
            r5 = r16
        L_0x00a5:
            r11 = 0
            goto L_0x00a9
        L_0x00a7:
            r5 = r16
        L_0x00a9:
            d.h.a.h.e r14 = r0.f418h
            r15 = 0
            r14.f19547R = r15
            r14.f19548S = r15
            r14.mo11651y(r3)
            d.h.a.h.e r3 = r0.f418h
            r3.mo11628C(r4)
            d.h.a.h.e r3 = r0.f418h
            r3.mo11627B(r5)
            d.h.a.h.e r3 = r0.f418h
            r3.mo11649w(r11)
            d.h.a.h.e r3 = r0.f418h
            int r4 = r0.f419i
            int r5 = r51.getPaddingLeft()
            int r4 = r4 - r5
            int r5 = r51.getPaddingRight()
            int r4 = r4 - r5
            if (r4 >= 0) goto L_0x00d3
            r4 = 0
        L_0x00d3:
            r3.f19547R = r4
            d.h.a.h.e r3 = r0.f418h
            int r4 = r0.f420j
            int r5 = r51.getPaddingTop()
            int r4 = r4 - r5
            int r5 = r51.getPaddingBottom()
            int r4 = r4 - r5
            if (r4 >= 0) goto L_0x00e6
            r4 = 0
        L_0x00e6:
            r3.f19548S = r4
            d.h.a.h.e r3 = r0.f418h
            int r11 = r3.mo11641n()
            d.h.a.h.e r3 = r0.f418h
            int r14 = r3.mo11635h()
            boolean r3 = r0.f423m
            if (r3 == 0) goto L_0x07b7
            r3 = 0
            r0.f423m = r3
            int r3 = r51.getChildCount()
            r4 = 0
        L_0x0100:
            if (r4 >= r3) goto L_0x0111
            android.view.View r21 = r0.getChildAt(r4)
            boolean r21 = r21.isLayoutRequested()
            if (r21 == 0) goto L_0x010e
            r3 = 1
            goto L_0x0112
        L_0x010e:
            int r4 = r4 + 1
            goto L_0x0100
        L_0x0111:
            r3 = 0
        L_0x0112:
            if (r3 == 0) goto L_0x07a7
            java.util.ArrayList<d.h.a.h.d> r3 = r0.f417g
            r3.clear()
            d.h.a.h.c$b r4 = p176d.p215h.p216a.p217h.C5550c.C5552b.BASELINE
            d.h.a.h.d$a r3 = p176d.p215h.p216a.p217h.C5553d.C5554a.MATCH_PARENT
            d.h.a.h.d$a r15 = p176d.p215h.p216a.p217h.C5553d.C5554a.MATCH_CONSTRAINT
            d.h.a.h.c$b r5 = p176d.p215h.p216a.p217h.C5550c.C5552b.LEFT
            r29 = r13
            d.h.a.h.c$b r13 = p176d.p215h.p216a.p217h.C5550c.C5552b.TOP
            boolean r30 = r51.isInEditMode()
            int r2 = r51.getChildCount()
            r31 = r3
            if (r30 == 0) goto L_0x017d
            r3 = 0
        L_0x0132:
            if (r3 >= r2) goto L_0x017d
            android.view.View r22 = r0.getChildAt(r3)
            r32 = r4
            android.content.res.Resources r4 = r51.getResources()     // Catch:{ NotFoundException -> 0x0170 }
            r33 = r6
            int r6 = r22.getId()     // Catch:{ NotFoundException -> 0x0172 }
            java.lang.String r4 = r4.getResourceName(r6)     // Catch:{ NotFoundException -> 0x0172 }
            int r6 = r22.getId()     // Catch:{ NotFoundException -> 0x0172 }
            java.lang.Integer r6 = java.lang.Integer.valueOf(r6)     // Catch:{ NotFoundException -> 0x0172 }
            r34 = r7
            r7 = 0
            r0.mo636f(r7, r4, r6)     // Catch:{ NotFoundException -> 0x0174 }
            r6 = 47
            int r6 = r4.indexOf(r6)     // Catch:{ NotFoundException -> 0x0174 }
            r7 = -1
            if (r6 == r7) goto L_0x0165
            int r6 = r6 + 1
            java.lang.String r4 = r4.substring(r6)     // Catch:{ NotFoundException -> 0x0174 }
        L_0x0165:
            int r6 = r22.getId()     // Catch:{ NotFoundException -> 0x0174 }
            d.h.a.h.d r6 = r0.mo631c(r6)     // Catch:{ NotFoundException -> 0x0174 }
            r6.f19555Z = r4     // Catch:{ NotFoundException -> 0x0174 }
            goto L_0x0174
        L_0x0170:
            r33 = r6
        L_0x0172:
            r34 = r7
        L_0x0174:
            int r3 = r3 + 1
            r4 = r32
            r6 = r33
            r7 = r34
            goto L_0x0132
        L_0x017d:
            r32 = r4
            r33 = r6
            r34 = r7
            r3 = 0
        L_0x0184:
            if (r3 >= r2) goto L_0x0197
            android.view.View r4 = r0.getChildAt(r3)
            d.h.a.h.d r4 = r0.mo633d(r4)
            if (r4 != 0) goto L_0x0191
            goto L_0x0194
        L_0x0191:
            r4.mo11645r()
        L_0x0194:
            int r3 = r3 + 1
            goto L_0x0184
        L_0x0197:
            int r3 = r0.f426p
            r4 = -1
            if (r3 == r4) goto L_0x01ba
            r3 = 0
        L_0x019d:
            if (r3 >= r2) goto L_0x01ba
            android.view.View r4 = r0.getChildAt(r3)
            int r6 = r4.getId()
            int r7 = r0.f426p
            if (r6 != r7) goto L_0x01b7
            boolean r6 = r4 instanceof p176d.p215h.p218b.C5570d
            if (r6 == 0) goto L_0x01b7
            d.h.b.d r4 = (p176d.p215h.p218b.C5570d) r4
            d.h.b.c r4 = r4.getConstraintSet()
            r0.f425o = r4
        L_0x01b7:
            int r3 = r3 + 1
            goto L_0x019d
        L_0x01ba:
            d.h.b.c r3 = r0.f425o
            if (r3 == 0) goto L_0x0337
            int r4 = r51.getChildCount()
            java.util.HashSet r6 = new java.util.HashSet
            java.util.HashMap<java.lang.Integer, d.h.b.c$a> r7 = r3.f19673a
            java.util.Set r7 = r7.keySet()
            r6.<init>(r7)
            r7 = 0
        L_0x01ce:
            if (r7 >= r4) goto L_0x02b8
            r22 = r4
            android.view.View r4 = r0.getChildAt(r7)
            r35 = r8
            int r8 = r4.getId()
            r1 = -1
            if (r8 == r1) goto L_0x02b0
            java.util.HashMap<java.lang.Integer, d.h.b.c$a> r1 = r3.f19673a
            r36 = r11
            java.lang.Integer r11 = java.lang.Integer.valueOf(r8)
            boolean r1 = r1.containsKey(r11)
            if (r1 == 0) goto L_0x029c
            java.lang.Integer r1 = java.lang.Integer.valueOf(r8)
            r6.remove(r1)
            java.util.HashMap<java.lang.Integer, d.h.b.c$a> r1 = r3.f19673a
            java.lang.Integer r11 = java.lang.Integer.valueOf(r8)
            java.lang.Object r1 = r1.get(r11)
            d.h.b.c$a r1 = (p176d.p215h.p218b.C5568c.C5569a) r1
            boolean r11 = r4 instanceof p176d.p215h.p218b.C5566a
            if (r11 == 0) goto L_0x0208
            r11 = 1
            r1.f19739t0 = r11
            goto L_0x0209
        L_0x0208:
            r11 = 1
        L_0x0209:
            r37 = r14
            int r14 = r1.f19739t0
            r38 = r12
            r12 = -1
            if (r14 == r12) goto L_0x023a
            if (r14 == r11) goto L_0x0215
            goto L_0x023a
        L_0x0215:
            r11 = r4
            d.h.b.a r11 = (p176d.p215h.p218b.C5566a) r11
            r11.setId(r8)
            int r8 = r1.f19737s0
            r11.setType(r8)
            boolean r8 = r1.f19735r0
            r11.setAllowsGoneWidget(r8)
            int[] r8 = r1.f19741u0
            if (r8 == 0) goto L_0x022d
            r11.setReferencedIds(r8)
            goto L_0x023a
        L_0x022d:
            java.lang.String r8 = r1.f19743v0
            if (r8 == 0) goto L_0x023a
            int[] r8 = r3.mo11693a(r11, r8)
            r1.f19741u0 = r8
            r11.setReferencedIds(r8)
        L_0x023a:
            android.view.ViewGroup$LayoutParams r8 = r4.getLayoutParams()
            androidx.constraintlayout.widget.ConstraintLayout$a r8 = (androidx.constraintlayout.widget.ConstraintLayout.C0066a) r8
            r1.mo11696a(r8)
            r4.setLayoutParams(r8)
            int r8 = r1.f19683J
            r4.setVisibility(r8)
            float r8 = r1.f19694U
            r4.setAlpha(r8)
            float r8 = r1.f19697X
            r4.setRotation(r8)
            float r8 = r1.f19698Y
            r4.setRotationX(r8)
            float r8 = r1.f19699Z
            r4.setRotationY(r8)
            float r8 = r1.f19701a0
            r4.setScaleX(r8)
            float r8 = r1.f19703b0
            r4.setScaleY(r8)
            float r8 = r1.f19705c0
            boolean r8 = java.lang.Float.isNaN(r8)
            if (r8 != 0) goto L_0x0276
            float r8 = r1.f19705c0
            r4.setPivotX(r8)
        L_0x0276:
            float r8 = r1.f19707d0
            boolean r8 = java.lang.Float.isNaN(r8)
            if (r8 != 0) goto L_0x0283
            float r8 = r1.f19707d0
            r4.setPivotY(r8)
        L_0x0283:
            float r8 = r1.f19709e0
            r4.setTranslationX(r8)
            float r8 = r1.f19711f0
            r4.setTranslationY(r8)
            float r8 = r1.f19713g0
            r4.setTranslationZ(r8)
            boolean r8 = r1.f19695V
            if (r8 == 0) goto L_0x02a0
            float r1 = r1.f19696W
            r4.setElevation(r1)
            goto L_0x02a0
        L_0x029c:
            r38 = r12
            r37 = r14
        L_0x02a0:
            int r7 = r7 + 1
            r1 = r52
            r4 = r22
            r8 = r35
            r11 = r36
            r14 = r37
            r12 = r38
            goto L_0x01ce
        L_0x02b0:
            java.lang.RuntimeException r1 = new java.lang.RuntimeException
            java.lang.String r2 = "All children of ConstraintLayout must have ids to use ConstraintSet"
            r1.<init>(r2)
            throw r1
        L_0x02b8:
            r35 = r8
            r36 = r11
            r38 = r12
            r37 = r14
            java.util.Iterator r1 = r6.iterator()
        L_0x02c4:
            boolean r4 = r1.hasNext()
            if (r4 == 0) goto L_0x033f
            java.lang.Object r4 = r1.next()
            java.lang.Integer r4 = (java.lang.Integer) r4
            java.util.HashMap<java.lang.Integer, d.h.b.c$a> r6 = r3.f19673a
            java.lang.Object r6 = r6.get(r4)
            d.h.b.c$a r6 = (p176d.p215h.p218b.C5568c.C5569a) r6
            int r7 = r6.f19739t0
            r8 = -1
            if (r7 == r8) goto L_0x0318
            r8 = 1
            if (r7 == r8) goto L_0x02e1
            goto L_0x0318
        L_0x02e1:
            d.h.b.a r7 = new d.h.b.a
            android.content.Context r8 = r51.getContext()
            r7.<init>(r8)
            int r8 = r4.intValue()
            r7.setId(r8)
            int[] r8 = r6.f19741u0
            if (r8 == 0) goto L_0x02f9
            r7.setReferencedIds(r8)
            goto L_0x0306
        L_0x02f9:
            java.lang.String r8 = r6.f19743v0
            if (r8 == 0) goto L_0x0306
            int[] r8 = r3.mo11693a(r7, r8)
            r6.f19741u0 = r8
            r7.setReferencedIds(r8)
        L_0x0306:
            int r8 = r6.f19737s0
            r7.setType(r8)
            androidx.constraintlayout.widget.ConstraintLayout$a r8 = r51.generateDefaultLayoutParams()
            r7.mo11687f()
            r6.mo11696a(r8)
            r0.addView(r7, r8)
        L_0x0318:
            boolean r7 = r6.f19700a
            if (r7 == 0) goto L_0x02c4
            d.h.b.e r7 = new d.h.b.e
            android.content.Context r8 = r51.getContext()
            r7.<init>(r8)
            int r4 = r4.intValue()
            r7.setId(r4)
            androidx.constraintlayout.widget.ConstraintLayout$a r4 = r51.generateDefaultLayoutParams()
            r6.mo11696a(r4)
            r0.addView(r7, r4)
            goto L_0x02c4
        L_0x0337:
            r35 = r8
            r36 = r11
            r38 = r12
            r37 = r14
        L_0x033f:
            d.h.a.h.e r1 = r0.f418h
            java.util.ArrayList<d.h.a.h.d> r1 = r1.f19661j0
            r1.clear()
            java.util.ArrayList<d.h.b.b> r1 = r0.f416f
            int r1 = r1.size()
            if (r1 <= 0) goto L_0x035f
            r3 = 0
        L_0x034f:
            if (r3 >= r1) goto L_0x035f
            java.util.ArrayList<d.h.b.b> r4 = r0.f416f
            java.lang.Object r4 = r4.get(r3)
            d.h.b.b r4 = (p176d.p215h.p218b.C5567b) r4
            r4.mo11686e(r0)
            int r3 = r3 + 1
            goto L_0x034f
        L_0x035f:
            r1 = 0
        L_0x0360:
            if (r1 >= r2) goto L_0x039b
            android.view.View r3 = r0.getChildAt(r1)
            boolean r4 = r3 instanceof p176d.p215h.p218b.C5573f
            if (r4 == 0) goto L_0x0398
            d.h.b.f r3 = (p176d.p215h.p218b.C5573f) r3
            int r4 = r3.f19762e
            r6 = -1
            if (r4 != r6) goto L_0x037c
            boolean r4 = r3.isInEditMode()
            if (r4 != 0) goto L_0x037c
            int r4 = r3.f19764g
            r3.setVisibility(r4)
        L_0x037c:
            int r4 = r3.f19762e
            android.view.View r4 = r0.findViewById(r4)
            r3.f19763f = r4
            if (r4 == 0) goto L_0x0398
            android.view.ViewGroup$LayoutParams r4 = r4.getLayoutParams()
            androidx.constraintlayout.widget.ConstraintLayout$a r4 = (androidx.constraintlayout.widget.ConstraintLayout.C0066a) r4
            r6 = 1
            r4.f455Z = r6
            android.view.View r4 = r3.f19763f
            r6 = 0
            r4.setVisibility(r6)
            r3.setVisibility(r6)
        L_0x0398:
            int r1 = r1 + 1
            goto L_0x0360
        L_0x039b:
            r1 = 0
        L_0x039c:
            if (r1 >= r2) goto L_0x079d
            android.view.View r3 = r0.getChildAt(r1)
            d.h.a.h.d r11 = r0.mo633d(r3)
            if (r11 != 0) goto L_0x03aa
            goto L_0x049e
        L_0x03aa:
            android.view.ViewGroup$LayoutParams r4 = r3.getLayoutParams()
            r12 = r4
            androidx.constraintlayout.widget.ConstraintLayout$a r12 = (androidx.constraintlayout.widget.ConstraintLayout.C0066a) r12
            r12.mo661a()
            boolean r4 = r12.f479l0
            if (r4 == 0) goto L_0x03bc
            r4 = 0
            r12.f479l0 = r4
            goto L_0x03ec
        L_0x03bc:
            if (r30 == 0) goto L_0x03ec
            android.content.res.Resources r4 = r51.getResources()     // Catch:{ NotFoundException -> 0x03ec }
            int r6 = r3.getId()     // Catch:{ NotFoundException -> 0x03ec }
            java.lang.String r4 = r4.getResourceName(r6)     // Catch:{ NotFoundException -> 0x03ec }
            int r6 = r3.getId()     // Catch:{ NotFoundException -> 0x03ec }
            java.lang.Integer r6 = java.lang.Integer.valueOf(r6)     // Catch:{ NotFoundException -> 0x03ec }
            r7 = 0
            r0.mo636f(r7, r4, r6)     // Catch:{ NotFoundException -> 0x03ec }
            java.lang.String r6 = "id/"
            int r6 = r4.indexOf(r6)     // Catch:{ NotFoundException -> 0x03ec }
            int r6 = r6 + 3
            java.lang.String r4 = r4.substring(r6)     // Catch:{ NotFoundException -> 0x03ec }
            int r6 = r3.getId()     // Catch:{ NotFoundException -> 0x03ec }
            d.h.a.h.d r6 = r0.mo631c(r6)     // Catch:{ NotFoundException -> 0x03ec }
            r6.f19555Z = r4     // Catch:{ NotFoundException -> 0x03ec }
        L_0x03ec:
            int r4 = r3.getVisibility()
            r11.f19554Y = r4
            boolean r4 = r12.f455Z
            if (r4 == 0) goto L_0x03fa
            r4 = 8
            r11.f19554Y = r4
        L_0x03fa:
            r11.f19553X = r3
            d.h.a.h.e r3 = r0.f418h
            java.util.ArrayList<d.h.a.h.d> r4 = r3.f19661j0
            r4.add(r11)
            d.h.a.h.d r4 = r11.f19533D
            if (r4 == 0) goto L_0x0411
            d.h.a.h.n r4 = (p176d.p215h.p216a.p217h.C5565n) r4
            java.util.ArrayList<d.h.a.h.d> r4 = r4.f19661j0
            r4.remove(r11)
            r4 = 0
            r11.f19533D = r4
        L_0x0411:
            r11.f19533D = r3
            boolean r3 = r12.f451V
            if (r3 == 0) goto L_0x041b
            boolean r3 = r12.f450U
            if (r3 != 0) goto L_0x0420
        L_0x041b:
            java.util.ArrayList<d.h.a.h.d> r3 = r0.f417g
            r3.add(r11)
        L_0x0420:
            boolean r3 = r12.f453X
            if (r3 == 0) goto L_0x0454
            d.h.a.h.g r11 = (p176d.p215h.p216a.p217h.C5557g) r11
            int r3 = r12.f471h0
            int r4 = r12.f473i0
            float r6 = r12.f475j0
            r7 = -1082130432(0xffffffffbf800000, float:-1.0)
            int r8 = (r6 > r7 ? 1 : (r6 == r7 ? 0 : -1))
            if (r8 == 0) goto L_0x043d
            if (r8 <= 0) goto L_0x049e
            r11.f19628j0 = r6
            r6 = -1
            r11.f19629k0 = r6
            r11.f19630l0 = r6
            goto L_0x049e
        L_0x043d:
            r6 = -1
            if (r3 == r6) goto L_0x0449
            if (r3 <= r6) goto L_0x049e
            r11.f19628j0 = r7
            r11.f19629k0 = r3
            r11.f19630l0 = r6
            goto L_0x049e
        L_0x0449:
            if (r4 == r6) goto L_0x049e
            if (r4 <= r6) goto L_0x049e
            r11.f19628j0 = r7
            r11.f19629k0 = r6
            r11.f19630l0 = r4
            goto L_0x049e
        L_0x0454:
            r6 = -1
            int r3 = r12.f462d
            if (r3 != r6) goto L_0x04b3
            int r3 = r12.f464e
            if (r3 != r6) goto L_0x04b3
            int r3 = r12.f466f
            if (r3 != r6) goto L_0x04b3
            int r3 = r12.f468g
            if (r3 != r6) goto L_0x04b3
            int r3 = r12.f484q
            if (r3 != r6) goto L_0x04b3
            int r3 = r12.f483p
            if (r3 != r6) goto L_0x04b3
            int r3 = r12.f485r
            if (r3 != r6) goto L_0x04b3
            int r3 = r12.f486s
            if (r3 != r6) goto L_0x04b3
            int r3 = r12.f470h
            if (r3 != r6) goto L_0x04b3
            int r3 = r12.f472i
            if (r3 != r6) goto L_0x04b3
            int r3 = r12.f474j
            if (r3 != r6) goto L_0x04b3
            int r3 = r12.f476k
            if (r3 != r6) goto L_0x04b3
            int r3 = r12.f478l
            if (r3 != r6) goto L_0x04b3
            int r3 = r12.f445P
            if (r3 != r6) goto L_0x04b3
            int r3 = r12.f446Q
            if (r3 != r6) goto L_0x04b3
            int r3 = r12.f480m
            if (r3 != r6) goto L_0x04b3
            int r3 = r12.width
            if (r3 == r6) goto L_0x04b3
            int r3 = r12.height
            if (r3 != r6) goto L_0x049e
            goto L_0x04b3
        L_0x049e:
            r40 = r1
            r39 = r2
            r2 = r5
            r3 = r10
            r4 = r15
            r15 = r31
            r1 = r32
            r28 = r33
            r32 = r34
            r43 = r35
            r5 = r38
            goto L_0x0787
        L_0x04b3:
            int r3 = r12.f457a0
            int r4 = r12.f459b0
            int r6 = r12.f461c0
            int r7 = r12.f463d0
            int r8 = r12.f465e0
            int r14 = r12.f467f0
            r39 = r2
            float r2 = r12.f469g0
            r40 = r1
            int r1 = r12.f480m
            r41 = r15
            r15 = -1
            if (r1 == r15) goto L_0x04f6
            d.h.a.h.d r24 = r0.mo631c(r1)
            if (r24 == 0) goto L_0x04e5
            float r1 = r12.f482o
            int r2 = r12.f481n
            d.h.a.h.c$b r25 = p176d.p215h.p216a.p217h.C5550c.C5552b.CENTER
            r27 = 0
            r22 = r11
            r23 = r25
            r26 = r2
            r22.mo11642o(r23, r24, r25, r26, r27)
            r11.f19582r = r1
        L_0x04e5:
            r42 = r5
            r15 = r31
            r1 = r32
            r28 = r33
            r32 = r34
            r43 = r35
            r31 = r10
            r10 = -1
            goto L_0x0628
        L_0x04f6:
            r1 = r15
            if (r3 == r1) goto L_0x0508
            d.h.a.h.d r3 = r0.mo631c(r3)
            if (r3 == 0) goto L_0x0521
            int r4 = r12.leftMargin
            r24 = r3
            r26 = r4
            r25 = r5
            goto L_0x0518
        L_0x0508:
            if (r4 == r1) goto L_0x0521
            d.h.a.h.d r1 = r0.mo631c(r4)
            if (r1 == 0) goto L_0x0521
            int r3 = r12.leftMargin
            r24 = r1
            r26 = r3
            r25 = r10
        L_0x0518:
            r22 = r11
            r23 = r5
            r27 = r8
            r22.mo11642o(r23, r24, r25, r26, r27)
        L_0x0521:
            r1 = -1
            if (r6 == r1) goto L_0x0530
            d.h.a.h.d r3 = r0.mo631c(r6)
            if (r3 == 0) goto L_0x0556
            int r4 = r12.rightMargin
            r6 = r3
            r8 = r4
            r7 = r5
            goto L_0x053d
        L_0x0530:
            if (r7 == r1) goto L_0x0556
            d.h.a.h.d r3 = r0.mo631c(r7)
            if (r3 == 0) goto L_0x0556
            int r4 = r12.rightMargin
            r6 = r3
            r8 = r4
            r7 = r10
        L_0x053d:
            r15 = r31
            r3 = r11
            r1 = r32
            r4 = r10
            r42 = r5
            r31 = r10
            r10 = -1
            r5 = r6
            r28 = r33
            r6 = r7
            r32 = r34
            r7 = r8
            r43 = r35
            r8 = r14
            r3.mo11642o(r4, r5, r6, r7, r8)
            goto L_0x0565
        L_0x0556:
            r42 = r5
            r15 = r31
            r28 = r33
            r43 = r35
            r31 = r10
            r10 = r1
            r1 = r32
            r32 = r34
        L_0x0565:
            int r3 = r12.f470h
            if (r3 == r10) goto L_0x057c
            d.h.a.h.d r3 = r0.mo631c(r3)
            if (r3 == 0) goto L_0x0599
            int r4 = r12.topMargin
            int r5 = r12.f488u
            r24 = r3
            r26 = r4
            r27 = r5
            r25 = r13
            goto L_0x0592
        L_0x057c:
            int r3 = r12.f472i
            if (r3 == r10) goto L_0x0599
            d.h.a.h.d r3 = r0.mo631c(r3)
            if (r3 == 0) goto L_0x0599
            int r4 = r12.topMargin
            int r5 = r12.f488u
            r24 = r3
            r26 = r4
            r27 = r5
            r25 = r9
        L_0x0592:
            r22 = r11
            r23 = r13
            r22.mo11642o(r23, r24, r25, r26, r27)
        L_0x0599:
            int r3 = r12.f474j
            if (r3 == r10) goto L_0x05ac
            d.h.a.h.d r3 = r0.mo631c(r3)
            if (r3 == 0) goto L_0x05c3
            int r4 = r12.bottomMargin
            int r5 = r12.f490w
            r7 = r4
            r8 = r5
            r6 = r13
        L_0x05aa:
            r5 = r3
            goto L_0x05be
        L_0x05ac:
            int r3 = r12.f476k
            if (r3 == r10) goto L_0x05c3
            d.h.a.h.d r3 = r0.mo631c(r3)
            if (r3 == 0) goto L_0x05c3
            int r4 = r12.bottomMargin
            int r5 = r12.f490w
            r7 = r4
            r8 = r5
            r6 = r9
            goto L_0x05aa
        L_0x05be:
            r3 = r11
            r4 = r9
            r3.mo11642o(r4, r5, r6, r7, r8)
        L_0x05c3:
            int r3 = r12.f478l
            if (r3 == r10) goto L_0x060f
            android.util.SparseArray<android.view.View> r4 = r0.f415e
            java.lang.Object r3 = r4.get(r3)
            android.view.View r3 = (android.view.View) r3
            int r4 = r12.f478l
            d.h.a.h.d r4 = r0.mo631c(r4)
            if (r4 == 0) goto L_0x060f
            if (r3 == 0) goto L_0x060f
            android.view.ViewGroup$LayoutParams r5 = r3.getLayoutParams()
            boolean r5 = r5 instanceof androidx.constraintlayout.widget.ConstraintLayout.C0066a
            if (r5 == 0) goto L_0x060f
            android.view.ViewGroup$LayoutParams r3 = r3.getLayoutParams()
            androidx.constraintlayout.widget.ConstraintLayout$a r3 = (androidx.constraintlayout.widget.ConstraintLayout.C0066a) r3
            r5 = 1
            r12.f452W = r5
            r3.f452W = r5
            d.h.a.h.c r44 = r11.mo11633f(r1)
            d.h.a.h.c r45 = r4.mo11633f(r1)
            r46 = 0
            r47 = -1
            d.h.a.h.c$a r48 = p176d.p215h.p216a.p217h.C5550c.C5551a.STRONG
            r49 = 0
            r50 = 1
            r44.mo11620a(r45, r46, r47, r48, r49, r50)
            d.h.a.h.c r3 = r11.mo11633f(r13)
            r3.mo11623d()
            d.h.a.h.c r3 = r11.mo11633f(r9)
            r3.mo11623d()
        L_0x060f:
            r3 = 0
            int r4 = (r2 > r3 ? 1 : (r2 == r3 ? 0 : -1))
            r5 = 1056964608(0x3f000000, float:0.5)
            if (r4 < 0) goto L_0x061c
            int r4 = (r2 > r5 ? 1 : (r2 == r5 ? 0 : -1))
            if (r4 == 0) goto L_0x061c
            r11.f19551V = r2
        L_0x061c:
            float r2 = r12.f430A
            int r4 = (r2 > r3 ? 1 : (r2 == r3 ? 0 : -1))
            if (r4 < 0) goto L_0x0628
            int r3 = (r2 > r5 ? 1 : (r2 == r5 ? 0 : -1))
            if (r3 == 0) goto L_0x0628
            r11.f19552W = r2
        L_0x0628:
            if (r30 == 0) goto L_0x063a
            int r2 = r12.f445P
            if (r2 != r10) goto L_0x0632
            int r2 = r12.f446Q
            if (r2 == r10) goto L_0x063a
        L_0x0632:
            int r2 = r12.f445P
            int r3 = r12.f446Q
            r11.f19538I = r2
            r11.f19539J = r3
        L_0x063a:
            boolean r2 = r12.f450U
            if (r2 != 0) goto L_0x066e
            int r2 = r12.width
            if (r2 != r10) goto L_0x065e
            r11.mo11651y(r15)
            r2 = r42
            d.h.a.h.c r3 = r11.mo11633f(r2)
            int r4 = r12.leftMargin
            r3.f19511e = r4
            r3 = r31
            d.h.a.h.c r4 = r11.mo11633f(r3)
            int r5 = r12.rightMargin
            r4.f19511e = r5
            r5 = r38
            r4 = r41
            goto L_0x067e
        L_0x065e:
            r3 = r31
            r4 = r41
            r2 = r42
            r11.mo11651y(r4)
            r5 = 0
            r11.mo11628C(r5)
            r5 = r38
            goto L_0x067e
        L_0x066e:
            r3 = r31
            r5 = r38
            r4 = r41
            r2 = r42
            r11.mo11651y(r5)
            int r6 = r12.width
            r11.mo11628C(r6)
        L_0x067e:
            boolean r6 = r12.f451V
            if (r6 != 0) goto L_0x069f
            int r6 = r12.height
            if (r6 != r10) goto L_0x069a
            r11.mo11627B(r15)
            d.h.a.h.c r6 = r11.mo11633f(r13)
            int r7 = r12.topMargin
            r6.f19511e = r7
            d.h.a.h.c r6 = r11.mo11633f(r9)
            int r7 = r12.bottomMargin
            r6.f19511e = r7
            goto L_0x06a7
        L_0x069a:
            r11.mo11627B(r4)
            r6 = 0
            goto L_0x06a4
        L_0x069f:
            r11.mo11627B(r5)
            int r6 = r12.height
        L_0x06a4:
            r11.mo11649w(r6)
        L_0x06a7:
            java.lang.String r6 = r12.f431B
            if (r6 == 0) goto L_0x0740
            int r7 = r6.length()
            if (r7 != 0) goto L_0x06b6
            r7 = 0
            r11.f19536G = r7
            goto L_0x0740
        L_0x06b6:
            int r7 = r6.length()
            r8 = 44
            int r8 = r6.indexOf(r8)
            if (r8 <= 0) goto L_0x06e3
            int r14 = r7 + -1
            if (r8 >= r14) goto L_0x06e3
            r14 = 0
            java.lang.String r10 = r6.substring(r14, r8)
            java.lang.String r14 = "W"
            boolean r14 = r10.equalsIgnoreCase(r14)
            if (r14 == 0) goto L_0x06d5
            r10 = 0
            goto L_0x06e0
        L_0x06d5:
            java.lang.String r14 = "H"
            boolean r10 = r10.equalsIgnoreCase(r14)
            if (r10 == 0) goto L_0x06df
            r10 = 1
            goto L_0x06e0
        L_0x06df:
            r10 = -1
        L_0x06e0:
            int r8 = r8 + 1
            goto L_0x06e5
        L_0x06e3:
            r8 = 0
            r10 = -1
        L_0x06e5:
            r14 = 58
            int r14 = r6.indexOf(r14)
            if (r14 < 0) goto L_0x0727
            int r7 = r7 + -1
            if (r14 >= r7) goto L_0x0727
            java.lang.String r7 = r6.substring(r8, r14)
            int r14 = r14 + 1
            java.lang.String r6 = r6.substring(r14)
            int r8 = r7.length()
            if (r8 <= 0) goto L_0x0736
            int r8 = r6.length()
            if (r8 <= 0) goto L_0x0736
            float r7 = java.lang.Float.parseFloat(r7)     // Catch:{ NumberFormatException -> 0x0736 }
            float r6 = java.lang.Float.parseFloat(r6)     // Catch:{ NumberFormatException -> 0x0736 }
            r8 = 0
            int r14 = (r7 > r8 ? 1 : (r7 == r8 ? 0 : -1))
            if (r14 <= 0) goto L_0x0736
            int r14 = (r6 > r8 ? 1 : (r6 == r8 ? 0 : -1))
            if (r14 <= 0) goto L_0x0736
            r8 = 1
            if (r10 != r8) goto L_0x0721
            float r6 = r6 / r7
            float r6 = java.lang.Math.abs(r6)     // Catch:{ NumberFormatException -> 0x0736 }
            goto L_0x0737
        L_0x0721:
            float r7 = r7 / r6
            float r6 = java.lang.Math.abs(r7)     // Catch:{ NumberFormatException -> 0x0736 }
            goto L_0x0737
        L_0x0727:
            java.lang.String r6 = r6.substring(r8)
            int r7 = r6.length()
            if (r7 <= 0) goto L_0x0736
            float r6 = java.lang.Float.parseFloat(r6)     // Catch:{ NumberFormatException -> 0x0736 }
            goto L_0x0737
        L_0x0736:
            r6 = 0
        L_0x0737:
            r7 = 0
            int r7 = (r6 > r7 ? 1 : (r6 == r7 ? 0 : -1))
            if (r7 <= 0) goto L_0x0740
            r11.f19536G = r6
            r11.f19537H = r10
        L_0x0740:
            float r6 = r12.f433D
            float[] r7 = r11.f19569g0
            r8 = 0
            r7[r8] = r6
            float r6 = r12.f434E
            r8 = 1
            r7[r8] = r6
            int r6 = r12.f435F
            r11.f19565e0 = r6
            int r6 = r12.f436G
            r11.f19567f0 = r6
            int r6 = r12.f437H
            int r7 = r12.f439J
            int r8 = r12.f441L
            float r10 = r12.f443N
            r11.f19564e = r6
            r11.f19570h = r7
            r11.f19572i = r8
            r11.f19574j = r10
            r7 = 1065353216(0x3f800000, float:1.0)
            int r8 = (r10 > r7 ? 1 : (r10 == r7 ? 0 : -1))
            r10 = 2
            if (r8 >= 0) goto L_0x076f
            if (r6 != 0) goto L_0x076f
            r11.f19564e = r10
        L_0x076f:
            int r6 = r12.f438I
            int r8 = r12.f440K
            int r14 = r12.f442M
            float r12 = r12.f444O
            r11.f19566f = r6
            r11.f19575k = r8
            r11.f19576l = r14
            r11.f19577m = r12
            int r7 = (r12 > r7 ? 1 : (r12 == r7 ? 0 : -1))
            if (r7 >= 0) goto L_0x0787
            if (r6 != 0) goto L_0x0787
            r11.f19566f = r10
        L_0x0787:
            int r6 = r40 + 1
            r10 = r3
            r38 = r5
            r31 = r15
            r33 = r28
            r34 = r32
            r35 = r43
            r32 = r1
            r5 = r2
            r15 = r4
            r1 = r6
            r2 = r39
            goto L_0x039c
        L_0x079d:
            r3 = r10
            r28 = r33
            r32 = r34
            r43 = r35
            r5 = r38
            goto L_0x07b5
        L_0x07a7:
            r28 = r6
            r32 = r7
            r43 = r8
            r3 = r10
            r36 = r11
            r5 = r12
            r29 = r13
            r37 = r14
        L_0x07b5:
            r1 = 1
            goto L_0x07c6
        L_0x07b7:
            r28 = r6
            r32 = r7
            r43 = r8
            r3 = r10
            r36 = r11
            r5 = r12
            r29 = r13
            r37 = r14
            r1 = 0
        L_0x07c6:
            int r2 = r0.f424n
            r4 = 8
            r2 = r2 & r4
            if (r2 != r4) goto L_0x07cf
            r15 = 1
            goto L_0x07d0
        L_0x07cf:
            r15 = 0
        L_0x07d0:
            if (r15 == 0) goto L_0x07e9
            d.h.a.h.e r4 = r0.f418h
            r4.mo11659L()
            d.h.a.h.e r4 = r0.f418h
            r6 = r36
            r7 = r37
            r4.mo11657J(r6, r7)
            r51.mo635e(r52, r53)
            r10 = r53
        L_0x07e5:
            r6 = r52
            goto L_0x08f7
        L_0x07e9:
            r6 = r36
            r7 = r37
            int r4 = r51.getPaddingTop()
            int r8 = r51.getPaddingBottom()
            int r8 = r8 + r4
            int r4 = r51.getPaddingLeft()
            int r10 = r51.getPaddingRight()
            int r10 = r10 + r4
            int r4 = r51.getChildCount()
            r11 = 0
        L_0x0804:
            if (r11 >= r4) goto L_0x08ef
            android.view.View r12 = r0.getChildAt(r11)
            int r13 = r12.getVisibility()
            r14 = 8
            if (r13 != r14) goto L_0x0814
            goto L_0x08d7
        L_0x0814:
            android.view.ViewGroup$LayoutParams r13 = r12.getLayoutParams()
            androidx.constraintlayout.widget.ConstraintLayout$a r13 = (androidx.constraintlayout.widget.ConstraintLayout.C0066a) r13
            d.h.a.h.d r14 = r13.f477k0
            boolean r2 = r13.f453X
            if (r2 != 0) goto L_0x08d7
            boolean r2 = r13.f454Y
            if (r2 == 0) goto L_0x0826
            goto L_0x08d7
        L_0x0826:
            int r2 = r12.getVisibility()
            r14.f19554Y = r2
            int r2 = r13.width
            r24 = r4
            int r4 = r13.height
            r37 = r7
            boolean r7 = r13.f450U
            r36 = r6
            if (r7 != 0) goto L_0x085d
            boolean r6 = r13.f451V
            if (r6 != 0) goto L_0x085d
            if (r7 != 0) goto L_0x0846
            int r6 = r13.f437H
            r7 = 1
            if (r6 == r7) goto L_0x085d
            goto L_0x0847
        L_0x0846:
            r7 = 1
        L_0x0847:
            int r6 = r13.width
            r7 = -1
            if (r6 == r7) goto L_0x085d
            boolean r6 = r13.f451V
            if (r6 != 0) goto L_0x085b
            int r6 = r13.f438I
            r7 = 1
            if (r6 == r7) goto L_0x085d
            int r6 = r13.height
            r7 = -1
            if (r6 != r7) goto L_0x085b
            goto L_0x085d
        L_0x085b:
            r6 = 0
            goto L_0x085e
        L_0x085d:
            r6 = 1
        L_0x085e:
            if (r6 == 0) goto L_0x08b2
            r6 = r52
            if (r2 != 0) goto L_0x086c
            r7 = -2
            int r2 = android.view.ViewGroup.getChildMeasureSpec(r6, r10, r7)
            r25 = 1
            goto L_0x0885
        L_0x086c:
            r7 = -1
            if (r2 != r7) goto L_0x0877
            int r2 = android.view.ViewGroup.getChildMeasureSpec(r6, r10, r7)
            r7 = -2
            r25 = 0
            goto L_0x0885
        L_0x0877:
            r7 = -2
            if (r2 != r7) goto L_0x087d
            r23 = 1
            goto L_0x087f
        L_0x087d:
            r23 = 0
        L_0x087f:
            int r2 = android.view.ViewGroup.getChildMeasureSpec(r6, r10, r2)
            r25 = r23
        L_0x0885:
            r26 = r10
            if (r4 != 0) goto L_0x0891
            r10 = r53
            int r4 = android.view.ViewGroup.getChildMeasureSpec(r10, r8, r7)
            r7 = 1
            goto L_0x08a6
        L_0x0891:
            r7 = -1
            r10 = r53
            if (r4 != r7) goto L_0x089c
            int r4 = android.view.ViewGroup.getChildMeasureSpec(r10, r8, r7)
            r7 = 0
            goto L_0x08a6
        L_0x089c:
            r7 = -2
            if (r4 != r7) goto L_0x08a1
            r7 = 1
            goto L_0x08a2
        L_0x08a1:
            r7 = 0
        L_0x08a2:
            int r4 = android.view.ViewGroup.getChildMeasureSpec(r10, r8, r4)
        L_0x08a6:
            r12.measure(r2, r4)
            int r2 = r12.getMeasuredWidth()
            int r4 = r12.getMeasuredHeight()
            goto L_0x08bb
        L_0x08b2:
            r6 = r52
            r26 = r10
            r10 = r53
            r7 = 0
            r25 = 0
        L_0x08bb:
            r14.mo11628C(r2)
            r14.mo11649w(r4)
            if (r25 == 0) goto L_0x08c5
            r14.f19549T = r2
        L_0x08c5:
            if (r7 == 0) goto L_0x08c9
            r14.f19550U = r4
        L_0x08c9:
            boolean r2 = r13.f452W
            if (r2 == 0) goto L_0x08e3
            int r2 = r12.getBaseline()
            r4 = -1
            if (r2 == r4) goto L_0x08e3
            r14.f19546Q = r2
            goto L_0x08e3
        L_0x08d7:
            r24 = r4
            r36 = r6
            r37 = r7
            r26 = r10
            r6 = r52
            r10 = r53
        L_0x08e3:
            int r11 = r11 + 1
            r4 = r24
            r10 = r26
            r6 = r36
            r7 = r37
            goto L_0x0804
        L_0x08ef:
            r10 = r53
            r36 = r6
            r37 = r7
            goto L_0x07e5
        L_0x08f7:
            r51.mo646h()
            int r2 = r51.getChildCount()
            if (r2 <= 0) goto L_0x0907
            if (r1 == 0) goto L_0x0907
            d.h.a.h.e r1 = r0.f418h
            p176d.p178b.p179k.C4851q.C4862i.m15095R(r1)
        L_0x0907:
            d.h.a.h.e r1 = r0.f418h
            boolean r2 = r1.f19613w0
            if (r2 == 0) goto L_0x094b
            boolean r2 = r1.f19614x0
            if (r2 == 0) goto L_0x0929
            r2 = r29
            r4 = -2147483648(0xffffffff80000000, float:-0.0)
            if (r2 != r4) goto L_0x0926
            int r4 = r1.f19616z0
            r7 = r20
            if (r4 >= r7) goto L_0x0920
            r1.mo11628C(r4)
        L_0x0920:
            d.h.a.h.e r1 = r0.f418h
            r1.mo11651y(r5)
            goto L_0x092d
        L_0x0926:
            r7 = r20
            goto L_0x092d
        L_0x0929:
            r7 = r20
            r2 = r29
        L_0x092d:
            d.h.a.h.e r1 = r0.f418h
            boolean r4 = r1.f19615y0
            if (r4 == 0) goto L_0x0948
            r4 = r17
            r8 = -2147483648(0xffffffff80000000, float:-0.0)
            if (r4 != r8) goto L_0x0951
            int r8 = r1.f19596A0
            r11 = r43
            if (r8 >= r11) goto L_0x0942
            r1.mo11649w(r8)
        L_0x0942:
            d.h.a.h.e r1 = r0.f418h
            r1.mo11627B(r5)
            goto L_0x0953
        L_0x0948:
            r4 = r17
            goto L_0x0951
        L_0x094b:
            r4 = r17
            r7 = r20
            r2 = r29
        L_0x0951:
            r11 = r43
        L_0x0953:
            int r1 = r0.f424n
            r5 = 32
            r1 = r1 & r5
            if (r1 != r5) goto L_0x09ac
            d.h.a.h.e r1 = r0.f418h
            int r1 = r1.mo11641n()
            d.h.a.h.e r5 = r0.f418h
            int r5 = r5.mo11635h()
            int r8 = r0.f428r
            if (r8 == r1) goto L_0x0977
            r8 = 1073741824(0x40000000, float:2.0)
            if (r2 != r8) goto L_0x0979
            d.h.a.h.e r2 = r0.f418h
            java.util.List<d.h.a.h.f> r2 = r2.f19612v0
            r12 = 0
            p176d.p178b.p179k.C4851q.C4862i.m15094Q0(r2, r12, r1)
            goto L_0x0979
        L_0x0977:
            r8 = 1073741824(0x40000000, float:2.0)
        L_0x0979:
            int r1 = r0.f429s
            if (r1 == r5) goto L_0x0987
            if (r4 != r8) goto L_0x0987
            d.h.a.h.e r1 = r0.f418h
            java.util.List<d.h.a.h.f> r1 = r1.f19612v0
            r2 = 1
            p176d.p178b.p179k.C4851q.C4862i.m15094Q0(r1, r2, r5)
        L_0x0987:
            d.h.a.h.e r1 = r0.f418h
            boolean r2 = r1.f19614x0
            if (r2 == 0) goto L_0x0998
            int r2 = r1.f19616z0
            if (r2 <= r7) goto L_0x0998
            java.util.List<d.h.a.h.f> r1 = r1.f19612v0
            r2 = 0
            p176d.p178b.p179k.C4851q.C4862i.m15094Q0(r1, r2, r7)
            goto L_0x0999
        L_0x0998:
            r2 = 0
        L_0x0999:
            d.h.a.h.e r1 = r0.f418h
            boolean r4 = r1.f19615y0
            if (r4 == 0) goto L_0x09aa
            int r4 = r1.f19596A0
            if (r4 <= r11) goto L_0x09aa
            java.util.List<d.h.a.h.f> r1 = r1.f19612v0
            r4 = 1
            p176d.p178b.p179k.C4851q.C4862i.m15094Q0(r1, r4, r11)
            goto L_0x09ae
        L_0x09aa:
            r4 = 1
            goto L_0x09ae
        L_0x09ac:
            r2 = 0
            goto L_0x09aa
        L_0x09ae:
            int r1 = r51.getChildCount()
            if (r1 <= 0) goto L_0x09b7
            r51.mo637g()
        L_0x09b7:
            java.util.ArrayList<d.h.a.h.d> r1 = r0.f417g
            int r1 = r1.size()
            int r5 = r51.getPaddingBottom()
            int r5 = r5 + r28
            int r7 = r51.getPaddingRight()
            int r7 = r7 + r32
            if (r1 <= 0) goto L_0x0bb4
            d.h.a.h.e r8 = r0.f418h
            d.h.a.h.d$a r8 = r8.mo11636i()
            r11 = r16
            if (r8 != r11) goto L_0x09d7
            r8 = r4
            goto L_0x09d8
        L_0x09d7:
            r8 = r2
        L_0x09d8:
            d.h.a.h.e r12 = r0.f418h
            d.h.a.h.d$a r12 = r12.mo11640m()
            if (r12 != r11) goto L_0x09e2
            r11 = r4
            goto L_0x09e3
        L_0x09e2:
            r11 = r2
        L_0x09e3:
            d.h.a.h.e r12 = r0.f418h
            int r12 = r12.mo11641n()
            int r13 = r0.f419i
            int r12 = java.lang.Math.max(r12, r13)
            d.h.a.h.e r13 = r0.f418h
            int r13 = r13.mo11635h()
            int r14 = r0.f420j
            int r13 = java.lang.Math.max(r13, r14)
            r14 = r2
            r16 = r14
        L_0x09fe:
            if (r14 >= r1) goto L_0x0b22
            java.util.ArrayList<d.h.a.h.d> r4 = r0.f417g
            java.lang.Object r4 = r4.get(r14)
            d.h.a.h.d r4 = (p176d.p215h.p216a.p217h.C5553d) r4
            r17 = r1
            java.lang.Object r1 = r4.f19553X
            android.view.View r1 = (android.view.View) r1
            if (r1 != 0) goto L_0x0a18
            r1 = r2
            r24 = r8
            r19 = r14
        L_0x0a15:
            r2 = -1
            goto L_0x0b13
        L_0x0a18:
            android.view.ViewGroup$LayoutParams r19 = r1.getLayoutParams()
            r0 = r19
            androidx.constraintlayout.widget.ConstraintLayout$a r0 = (androidx.constraintlayout.widget.ConstraintLayout.C0066a) r0
            r19 = r14
            boolean r14 = r0.f454Y
            if (r14 != 0) goto L_0x0b0e
            boolean r14 = r0.f453X
            if (r14 == 0) goto L_0x0a2c
            goto L_0x0b0e
        L_0x0a2c:
            int r14 = r1.getVisibility()
            r20 = r2
            r2 = 8
            if (r14 != r2) goto L_0x0a37
            goto L_0x0a4d
        L_0x0a37:
            if (r15 == 0) goto L_0x0a52
            d.h.a.h.k r2 = r4.mo11639l()
            boolean r2 = r2.mo11678c()
            if (r2 == 0) goto L_0x0a52
            d.h.a.h.k r2 = r4.mo11638k()
            boolean r2 = r2.mo11678c()
            if (r2 == 0) goto L_0x0a52
        L_0x0a4d:
            r24 = r8
            r1 = r20
            goto L_0x0a15
        L_0x0a52:
            int r2 = r0.width
            r14 = -2
            if (r2 != r14) goto L_0x0a60
            boolean r14 = r0.f450U
            if (r14 == 0) goto L_0x0a60
            int r2 = android.view.ViewGroup.getChildMeasureSpec(r6, r7, r2)
            goto L_0x0a6a
        L_0x0a60:
            int r2 = r4.mo11641n()
            r14 = 1073741824(0x40000000, float:2.0)
            int r2 = android.view.View.MeasureSpec.makeMeasureSpec(r2, r14)
        L_0x0a6a:
            int r14 = r0.height
            r6 = -2
            if (r14 != r6) goto L_0x0a78
            boolean r6 = r0.f451V
            if (r6 == 0) goto L_0x0a78
            int r6 = android.view.ViewGroup.getChildMeasureSpec(r10, r5, r14)
            goto L_0x0a82
        L_0x0a78:
            int r6 = r4.mo11635h()
            r14 = 1073741824(0x40000000, float:2.0)
            int r6 = android.view.View.MeasureSpec.makeMeasureSpec(r6, r14)
        L_0x0a82:
            r1.measure(r2, r6)
            int r2 = r1.getMeasuredWidth()
            int r6 = r1.getMeasuredHeight()
            int r14 = r4.mo11641n()
            if (r2 == r14) goto L_0x0abf
            r4.mo11628C(r2)
            if (r15 == 0) goto L_0x0a9f
            d.h.a.h.k r14 = r4.mo11639l()
            r14.mo11675e(r2)
        L_0x0a9f:
            if (r8 == 0) goto L_0x0aba
            int r2 = r4.f19538I
            int r14 = r4.f19534E
            r24 = r8
            int r8 = r2 + r14
            if (r8 <= r12) goto L_0x0abc
            int r2 = r2 + r14
            d.h.a.h.c r8 = r4.mo11633f(r3)
            int r8 = r8.mo11621b()
            int r8 = r8 + r2
            int r12 = java.lang.Math.max(r12, r8)
            goto L_0x0abc
        L_0x0aba:
            r24 = r8
        L_0x0abc:
            r16 = 1
            goto L_0x0ac1
        L_0x0abf:
            r24 = r8
        L_0x0ac1:
            int r2 = r4.mo11635h()
            if (r6 == r2) goto L_0x0aee
            r4.mo11649w(r6)
            if (r15 == 0) goto L_0x0ad3
            d.h.a.h.k r2 = r4.mo11638k()
            r2.mo11675e(r6)
        L_0x0ad3:
            if (r11 == 0) goto L_0x0aec
            int r2 = r4.f19539J
            int r6 = r4.f19535F
            int r8 = r2 + r6
            if (r8 <= r13) goto L_0x0aec
            int r2 = r2 + r6
            d.h.a.h.c r6 = r4.mo11633f(r9)
            int r6 = r6.mo11621b()
            int r6 = r6 + r2
            int r2 = java.lang.Math.max(r13, r6)
            r13 = r2
        L_0x0aec:
            r16 = 1
        L_0x0aee:
            boolean r0 = r0.f452W
            if (r0 == 0) goto L_0x0b02
            int r0 = r1.getBaseline()
            r2 = -1
            if (r0 == r2) goto L_0x0b03
            int r6 = r4.f19546Q
            if (r0 == r6) goto L_0x0b03
            r4.f19546Q = r0
            r16 = 1
            goto L_0x0b03
        L_0x0b02:
            r2 = -1
        L_0x0b03:
            int r0 = r1.getMeasuredState()
            r1 = r20
            int r0 = android.view.ViewGroup.combineMeasuredStates(r1, r0)
            goto L_0x0b14
        L_0x0b0e:
            r1 = r2
            r24 = r8
            goto L_0x0a15
        L_0x0b13:
            r0 = r1
        L_0x0b14:
            int r14 = r19 + 1
            r6 = r52
            r2 = r0
            r1 = r17
            r8 = r24
            r4 = 1
            r0 = r51
            goto L_0x09fe
        L_0x0b22:
            r17 = r1
            r1 = r2
            r0 = r51
            if (r16 == 0) goto L_0x0b66
            d.h.a.h.e r2 = r0.f418h
            r3 = r36
            r2.mo11628C(r3)
            d.h.a.h.e r2 = r0.f418h
            r3 = r37
            r2.mo11649w(r3)
            if (r15 == 0) goto L_0x0b3e
            d.h.a.h.e r2 = r0.f418h
            r2.mo11661N()
        L_0x0b3e:
            r51.mo637g()
            d.h.a.h.e r2 = r0.f418h
            int r2 = r2.mo11641n()
            if (r2 >= r12) goto L_0x0b50
            d.h.a.h.e r2 = r0.f418h
            r2.mo11628C(r12)
            r15 = 1
            goto L_0x0b51
        L_0x0b50:
            r15 = 0
        L_0x0b51:
            d.h.a.h.e r2 = r0.f418h
            int r2 = r2.mo11635h()
            if (r2 >= r13) goto L_0x0b60
            d.h.a.h.e r2 = r0.f418h
            r2.mo11649w(r13)
            r11 = 1
            goto L_0x0b61
        L_0x0b60:
            r11 = r15
        L_0x0b61:
            if (r11 == 0) goto L_0x0b66
            r51.mo637g()
        L_0x0b66:
            r2 = r17
            r11 = 0
        L_0x0b69:
            if (r11 >= r2) goto L_0x0bb2
            java.util.ArrayList<d.h.a.h.d> r3 = r0.f417g
            java.lang.Object r3 = r3.get(r11)
            d.h.a.h.d r3 = (p176d.p215h.p216a.p217h.C5553d) r3
            java.lang.Object r4 = r3.f19553X
            android.view.View r4 = (android.view.View) r4
            if (r4 != 0) goto L_0x0b7a
            goto L_0x0b8f
        L_0x0b7a:
            int r6 = r4.getMeasuredWidth()
            int r8 = r3.mo11641n()
            if (r6 != r8) goto L_0x0b94
            int r6 = r4.getMeasuredHeight()
            int r8 = r3.mo11635h()
            if (r6 == r8) goto L_0x0b8f
            goto L_0x0b94
        L_0x0b8f:
            r8 = 8
        L_0x0b91:
            r9 = 1073741824(0x40000000, float:2.0)
            goto L_0x0baf
        L_0x0b94:
            int r6 = r3.f19554Y
            r8 = 8
            if (r6 == r8) goto L_0x0b91
            int r6 = r3.mo11641n()
            r9 = 1073741824(0x40000000, float:2.0)
            int r6 = android.view.View.MeasureSpec.makeMeasureSpec(r6, r9)
            int r3 = r3.mo11635h()
            int r3 = android.view.View.MeasureSpec.makeMeasureSpec(r3, r9)
            r4.measure(r6, r3)
        L_0x0baf:
            int r11 = r11 + 1
            goto L_0x0b69
        L_0x0bb2:
            r11 = r1
            goto L_0x0bb5
        L_0x0bb4:
            r11 = 0
        L_0x0bb5:
            d.h.a.h.e r1 = r0.f418h
            int r1 = r1.mo11641n()
            int r1 = r1 + r7
            d.h.a.h.e r2 = r0.f418h
            int r2 = r2.mo11635h()
            int r2 = r2 + r5
            r3 = r52
            int r1 = android.view.ViewGroup.resolveSizeAndState(r1, r3, r11)
            int r3 = r11 << 16
            int r2 = android.view.ViewGroup.resolveSizeAndState(r2, r10, r3)
            r3 = 16777215(0xffffff, float:2.3509886E-38)
            r1 = r1 & r3
            r2 = r2 & r3
            int r3 = r0.f421k
            int r1 = java.lang.Math.min(r3, r1)
            int r3 = r0.f422l
            int r2 = java.lang.Math.min(r3, r2)
            d.h.a.h.e r3 = r0.f418h
            boolean r3 = r3.f19599D0
            r4 = 16777216(0x1000000, float:2.3509887E-38)
            if (r3 == 0) goto L_0x0be9
            r1 = r1 | r4
        L_0x0be9:
            d.h.a.h.e r3 = r0.f418h
            boolean r3 = r3.f19600E0
            if (r3 == 0) goto L_0x0bf0
            r2 = r2 | r4
        L_0x0bf0:
            r0.setMeasuredDimension(r1, r2)
            r0.f428r = r1
            r0.f429s = r2
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.constraintlayout.widget.ConstraintLayout.onMeasure(int, int):void");
    }

    public void onViewAdded(View view) {
        super.onViewAdded(view);
        C5553d d = mo633d(view);
        if ((view instanceof C5572e) && !(d instanceof C5557g)) {
            C0066a aVar = (C0066a) view.getLayoutParams();
            C5557g gVar = new C5557g();
            aVar.f477k0 = gVar;
            aVar.f453X = true;
            gVar.mo11665F(aVar.f447R);
        }
        if (view instanceof C5567b) {
            C5567b bVar = (C5567b) view;
            bVar.mo11687f();
            ((C0066a) view.getLayoutParams()).f454Y = true;
            if (!this.f416f.contains(bVar)) {
                this.f416f.add(bVar);
            }
        }
        this.f415e.put(view.getId(), view);
        this.f423m = true;
    }

    public void onViewRemoved(View view) {
        super.onViewRemoved(view);
        this.f415e.remove(view.getId());
        C5553d d = mo633d(view);
        this.f418h.f19661j0.remove(d);
        d.f19533D = null;
        this.f416f.remove(view);
        this.f417g.remove(d);
        this.f423m = true;
    }

    public void removeView(View view) {
        super.removeView(view);
    }

    public void requestLayout() {
        super.requestLayout();
        this.f423m = true;
        this.f428r = -1;
        this.f429s = -1;
    }

    public void setConstraintSet(C5568c cVar) {
        this.f425o = cVar;
    }

    public void setId(int i) {
        this.f415e.remove(getId());
        super.setId(i);
        this.f415e.put(getId(), this);
    }

    public void setMaxHeight(int i) {
        if (i != this.f422l) {
            this.f422l = i;
            requestLayout();
        }
    }

    public void setMaxWidth(int i) {
        if (i != this.f421k) {
            this.f421k = i;
            requestLayout();
        }
    }

    public void setMinHeight(int i) {
        if (i != this.f420j) {
            this.f420j = i;
            requestLayout();
        }
    }

    public void setMinWidth(int i) {
        if (i != this.f419i) {
            this.f419i = i;
            requestLayout();
        }
    }

    public void setOptimizationLevel(int i) {
        this.f418h.f19597B0 = i;
    }

    public boolean shouldDelayChildPressedState() {
        return false;
    }
}
