package androidx.camera.view;

import android.content.Context;
import android.content.res.TypedArray;
import android.hardware.display.DisplayManager;
import android.os.Build;
import android.util.AttributeSet;
import android.util.Log;
import android.view.Display;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import androidx.lifecycle.LiveData;
import java.util.concurrent.atomic.AtomicReference;
import p002b.p011c.p107c.p108a.p109a.C3973a;
import p176d.p195e.p201b.C5217c2;
import p176d.p195e.p201b.p202h2.C5349q0;
import p176d.p195e.p201b.p202h2.C5360t;
import p176d.p195e.p201b.p202h2.C5362u;
import p176d.p195e.p208d.C5479e;
import p176d.p195e.p208d.C5491q;
import p176d.p195e.p208d.C5492r;
import p176d.p195e.p208d.C5495t;
import p176d.p195e.p208d.C5496u;
import p176d.p195e.p208d.C5500w;
import p176d.p195e.p208d.p209x.p210a.C5501a;
import p176d.p219i.p221d.C5600a;
import p176d.p242n.C5792m;

public class PreviewView extends FrameLayout {

    /* renamed from: k */
    public static final C0063b f393k = C0063b.SURFACE_VIEW;

    /* renamed from: e */
    public C0063b f394e = C0063b.SURFACE_VIEW;

    /* renamed from: f */
    public C5492r f395f;

    /* renamed from: g */
    public C5501a f396g = new C5501a();

    /* renamed from: h */
    public C5792m<C0065d> f397h = new C5792m<>(C0065d.IDLE);

    /* renamed from: i */
    public AtomicReference<C5491q> f398i = new AtomicReference<>();

    /* renamed from: j */
    public final View.OnLayoutChangeListener f399j = new C0062a();

    /* renamed from: androidx.camera.view.PreviewView$a */
    public class C0062a implements View.OnLayoutChangeListener {
        public C0062a() {
        }

        public void onLayoutChange(View view, int i, int i2, int i3, int i4, int i5, int i6, int i7, int i8) {
            C5492r rVar = PreviewView.this.f395f;
            if (rVar != null) {
                rVar.mo11371a();
            }
        }
    }

    /* renamed from: androidx.camera.view.PreviewView$b */
    public enum C0063b {
        SURFACE_VIEW,
        TEXTURE_VIEW
    }

    /* renamed from: androidx.camera.view.PreviewView$c */
    public enum C0064c {
        FILL_START(0),
        FILL_CENTER(1),
        FILL_END(2),
        FIT_START(3),
        FIT_CENTER(4),
        FIT_END(5);
        

        /* renamed from: e */
        public final int f411e;

        /* access modifiers changed from: public */
        C0064c(int i) {
            this.f411e = i;
        }
    }

    /* renamed from: androidx.camera.view.PreviewView$d */
    public enum C0065d {
        IDLE,
        STREAMING
    }

    /* JADX INFO: finally extract failed */
    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public PreviewView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, 0, 0);
        TypedArray obtainStyledAttributes = context.getTheme().obtainStyledAttributes(attributeSet, C5495t.PreviewView, 0, 0);
        if (Build.VERSION.SDK_INT >= 29) {
            saveAttributeDataForStyleable(context, C5495t.PreviewView, attributeSet, obtainStyledAttributes, 0, 0);
        }
        try {
            int integer = obtainStyledAttributes.getInteger(C5495t.PreviewView_scaleType, this.f396g.f19336a.f411e);
            for (C0064c cVar : C0064c.values()) {
                if (cVar.f411e == integer) {
                    setScaleType(cVar);
                    obtainStyledAttributes.recycle();
                    if (getBackground() == null) {
                        setBackgroundColor(C5600a.m16738b(getContext(), 17170444));
                        return;
                    }
                    return;
                }
            }
            throw new IllegalArgumentException("Unknown scale type id " + integer);
        } catch (Throwable th) {
            obtainStyledAttributes.recycle();
            throw th;
        }
    }

    /* renamed from: a */
    public final C5492r mo611a(C0063b bVar) {
        int ordinal = bVar.ordinal();
        if (ordinal == 0) {
            return new C5496u();
        }
        if (ordinal == 1) {
            return new C5500w();
        }
        throw new IllegalStateException("Unsupported implementation mode " + bVar);
    }

    /* renamed from: b */
    public final C0063b mo612b(C5360t tVar, C0063b bVar) {
        return (tVar.mo11008d().equals("androidx.camera.camera2.legacy") || mo613c()) ? C0063b.TEXTURE_VIEW : bVar;
    }

    /* renamed from: c */
    public final boolean mo613c() {
        Display defaultDisplay = ((WindowManager) getContext().getSystemService("window")).getDefaultDisplay();
        return (((DisplayManager) getContext().getSystemService("display")).getDisplays().length <= 1 || defaultDisplay == null || defaultDisplay.getDisplayId() == 0) ? false : true;
    }

    /* renamed from: d */
    public final boolean mo614d(C5360t tVar) {
        return tVar.mo11005a() % 180 == 90;
    }

    /* renamed from: e */
    public void mo615e(C5491q qVar, C5362u uVar) {
        if (this.f398i.compareAndSet(qVar, (Object) null)) {
            qVar.mo11370d(C0065d.IDLE);
        }
        C3973a<Void> aVar = qVar.f19306e;
        if (aVar != null) {
            aVar.cancel(false);
            qVar.f19306e = null;
        }
        ((C5349q0) uVar.mo10973j()).mo11239b(qVar);
    }

    /* renamed from: f */
    public void mo616f(C5217c2 c2Var) {
        Log.d("PreviewView", "Surface requested by Preview.");
        C5362u uVar = (C5362u) c2Var.f18792b;
        C0063b b = mo612b(uVar.mo591f(), this.f394e);
        this.f396g.f19338c = mo614d(uVar.mo591f());
        C5492r a = mo611a(b);
        this.f395f = a;
        C5501a aVar = this.f396g;
        a.f19309b = this;
        a.f19310c = aVar;
        C5491q qVar = new C5491q(uVar.mo591f(), this.f397h, this.f395f);
        this.f398i.set(qVar);
        ((C5349q0) uVar.mo10973j()).mo11238a(C5600a.m16740d(getContext()), qVar);
        this.f395f.mo11376f(c2Var, new C5479e(this, qVar, uVar));
    }

    /* JADX WARNING: Code restructure failed: missing block: B:18:0x0059, code lost:
        if (r2 != 5) goto L_0x008e;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public android.graphics.Bitmap getBitmap() {
        /*
            r8 = this;
            d.e.d.r r0 = r8.f395f
            if (r0 != 0) goto L_0x0007
            r0 = 0
            goto L_0x009f
        L_0x0007:
            android.graphics.Bitmap r1 = r0.mo11373c()
            if (r1 != 0) goto L_0x0010
        L_0x000d:
            r0 = r1
            goto L_0x009f
        L_0x0010:
            d.e.d.x.a.a r2 = r0.f19310c
            p176d.p178b.p179k.C4851q.C4862i.m15164r(r2)
            d.e.d.x.a.a r2 = r0.f19310c
            d.e.d.x.a.c.c r2 = r2.f19337b
            if (r2 != 0) goto L_0x001c
            goto L_0x000d
        L_0x001c:
            android.graphics.Matrix r6 = new android.graphics.Matrix
            r6.<init>()
            float r3 = r2.f19340a
            float r4 = r2.f19341b
            r6.setScale(r3, r4)
            float r2 = r2.f19344e
            r6.postRotate(r2)
            r2 = 0
            r3 = 0
            int r4 = r1.getWidth()
            int r5 = r1.getHeight()
            r7 = 1
            android.graphics.Bitmap r1 = android.graphics.Bitmap.createBitmap(r1, r2, r3, r4, r5, r6, r7)
            d.e.d.x.a.a r2 = r0.f19310c
            androidx.camera.view.PreviewView$c r2 = r2.f19336a
            android.widget.FrameLayout r3 = r0.f19309b
            p176d.p178b.p179k.C4851q.C4862i.m15164r(r3)
            int r2 = r2.ordinal()
            r3 = 0
            if (r2 == 0) goto L_0x008e
            r4 = 1
            r5 = 2
            if (r2 == r4) goto L_0x0074
            if (r2 == r5) goto L_0x005c
            r4 = 3
            if (r2 == r4) goto L_0x000d
            r4 = 4
            if (r2 == r4) goto L_0x000d
            r4 = 5
            if (r2 == r4) goto L_0x000d
            goto L_0x008e
        L_0x005c:
            int r2 = r1.getWidth()
            android.widget.FrameLayout r3 = r0.f19309b
            int r3 = r3.getWidth()
            int r3 = r2 - r3
            int r2 = r1.getHeight()
            android.widget.FrameLayout r4 = r0.f19309b
            int r4 = r4.getHeight()
            int r2 = r2 - r4
            goto L_0x008f
        L_0x0074:
            int r2 = r1.getWidth()
            android.widget.FrameLayout r3 = r0.f19309b
            int r3 = r3.getWidth()
            int r2 = r2 - r3
            int r3 = r2 / 2
            int r2 = r1.getHeight()
            android.widget.FrameLayout r4 = r0.f19309b
            int r4 = r4.getHeight()
            int r2 = r2 - r4
            int r2 = r2 / r5
            goto L_0x008f
        L_0x008e:
            r2 = r3
        L_0x008f:
            android.widget.FrameLayout r4 = r0.f19309b
            int r4 = r4.getWidth()
            android.widget.FrameLayout r0 = r0.f19309b
            int r0 = r0.getHeight()
            android.graphics.Bitmap r0 = android.graphics.Bitmap.createBitmap(r1, r3, r2, r4, r0)
        L_0x009f:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.camera.view.PreviewView.getBitmap():android.graphics.Bitmap");
    }

    public int getDeviceRotationForRemoteDisplayMode() {
        return this.f396g.f19339d;
    }

    public C0063b getPreferredImplementationMode() {
        return this.f394e;
    }

    public LiveData<C0065d> getPreviewStreamState() {
        return this.f397h;
    }

    public C0064c getScaleType() {
        return this.f396g.f19336a;
    }

    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        addOnLayoutChangeListener(this.f399j);
        C5492r rVar = this.f395f;
        if (rVar != null) {
            rVar.mo11374d();
        }
    }

    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        removeOnLayoutChangeListener(this.f399j);
        C5492r rVar = this.f395f;
        if (rVar != null) {
            rVar.mo11375e();
        }
    }

    public void setDeviceRotationForRemoteDisplayMode(int i) {
        if (i != this.f396g.f19339d && mo613c()) {
            this.f396g.f19339d = i;
            C5492r rVar = this.f395f;
            if (rVar != null) {
                rVar.mo11371a();
            }
        }
    }

    public void setPreferredImplementationMode(C0063b bVar) {
        this.f394e = bVar;
    }

    public void setScaleType(C0064c cVar) {
        this.f396g.f19336a = cVar;
        C5492r rVar = this.f395f;
        if (rVar != null) {
            rVar.mo11371a();
        }
    }
}
