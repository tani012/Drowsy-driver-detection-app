package androidx.camera.view;

import p176d.p242n.C5781e;
import p176d.p242n.C5785g;
import p176d.p242n.C5786h;
import p176d.p242n.C5794o;

public class CameraXModule$1 implements C5785g {
    @C5794o(C5781e.C5782a.ON_DESTROY)
    public void onDestroy(C5786h hVar) {
        throw null;
    }
}
