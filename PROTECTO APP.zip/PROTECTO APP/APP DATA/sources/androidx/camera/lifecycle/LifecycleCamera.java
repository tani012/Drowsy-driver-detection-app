package androidx.camera.lifecycle;

import java.util.Collections;
import java.util.List;
import p176d.p195e.p201b.C5227d2;
import p176d.p195e.p201b.C5447u0;
import p176d.p195e.p201b.p202h2.C5360t;
import p176d.p195e.p201b.p206i2.C5391c;
import p176d.p242n.C5781e;
import p176d.p242n.C5785g;
import p176d.p242n.C5786h;
import p176d.p242n.C5787i;
import p176d.p242n.C5794o;

public final class LifecycleCamera implements C5785g, C5447u0 {

    /* renamed from: a */
    public final Object f382a = new Object();

    /* renamed from: b */
    public final C5786h f383b;

    /* renamed from: c */
    public final C5391c f384c;

    /* renamed from: d */
    public boolean f385d;

    /* renamed from: e */
    public boolean f386e;

    public LifecycleCamera(C5786h hVar, C5391c cVar) {
        boolean z = false;
        this.f385d = false;
        this.f386e = false;
        this.f383b = hVar;
        this.f384c = cVar;
        z = ((C5787i) hVar.mo1a()).f20306b.compareTo(C5781e.C5783b.STARTED) >= 0 ? true : z;
        C5391c cVar2 = this.f384c;
        if (z) {
            cVar2.mo11282b();
        } else {
            cVar2.mo11284d();
        }
        hVar.mo1a().mo12114a(this);
    }

    /* renamed from: f */
    public C5360t mo591f() {
        return this.f384c.f19112a.mo10972i();
    }

    /* renamed from: l */
    public C5786h mo592l() {
        C5786h hVar;
        synchronized (this.f382a) {
            hVar = this.f383b;
        }
        return hVar;
    }

    /* renamed from: m */
    public List<C5227d2> mo593m() {
        List<C5227d2> unmodifiableList;
        synchronized (this.f382a) {
            unmodifiableList = Collections.unmodifiableList(this.f384c.mo11285e());
        }
        return unmodifiableList;
    }

    /* renamed from: n */
    public void mo594n() {
        synchronized (this.f382a) {
            if (!this.f385d) {
                onStop(this.f383b);
                this.f385d = true;
            }
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:13:0x0027, code lost:
        return;
     */
    /* renamed from: o */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void mo595o() {
        /*
            r4 = this;
            java.lang.Object r0 = r4.f382a
            monitor-enter(r0)
            boolean r1 = r4.f385d     // Catch:{ all -> 0x0028 }
            if (r1 != 0) goto L_0x0009
            monitor-exit(r0)     // Catch:{ all -> 0x0028 }
            return
        L_0x0009:
            r1 = 0
            r4.f385d = r1     // Catch:{ all -> 0x0028 }
            d.n.h r2 = r4.f383b     // Catch:{ all -> 0x0028 }
            d.n.e r2 = r2.mo1a()     // Catch:{ all -> 0x0028 }
            d.n.i r2 = (p176d.p242n.C5787i) r2     // Catch:{ all -> 0x0028 }
            d.n.e$b r2 = r2.f20306b     // Catch:{ all -> 0x0028 }
            d.n.e$b r3 = p176d.p242n.C5781e.C5783b.STARTED     // Catch:{ all -> 0x0028 }
            int r2 = r2.compareTo(r3)     // Catch:{ all -> 0x0028 }
            if (r2 < 0) goto L_0x001f
            r1 = 1
        L_0x001f:
            if (r1 == 0) goto L_0x0026
            d.n.h r1 = r4.f383b     // Catch:{ all -> 0x0028 }
            r4.onStart(r1)     // Catch:{ all -> 0x0028 }
        L_0x0026:
            monitor-exit(r0)     // Catch:{ all -> 0x0028 }
            return
        L_0x0028:
            r1 = move-exception
            monitor-exit(r0)     // Catch:{ all -> 0x0028 }
            throw r1
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.camera.lifecycle.LifecycleCamera.mo595o():void");
    }

    @C5794o(C5781e.C5782a.ON_DESTROY)
    public void onDestroy(C5786h hVar) {
        synchronized (this.f382a) {
            this.f384c.mo11286f(this.f384c.mo11285e());
        }
    }

    @C5794o(C5781e.C5782a.ON_START)
    public void onStart(C5786h hVar) {
        synchronized (this.f382a) {
            if (!this.f385d && !this.f386e) {
                this.f384c.mo11282b();
            }
        }
    }

    @C5794o(C5781e.C5782a.ON_STOP)
    public void onStop(C5786h hVar) {
        synchronized (this.f382a) {
            if (!this.f385d && !this.f386e) {
                this.f384c.mo11284d();
            }
        }
    }
}
