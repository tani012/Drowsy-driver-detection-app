package androidx.camera.lifecycle;

import java.util.ArrayDeque;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import p176d.p178b.p179k.C4851q;
import p176d.p195e.p201b.C5227d2;
import p176d.p195e.p201b.C5241f2;
import p176d.p195e.p201b.p206i2.C5391c;
import p176d.p195e.p207c.C5473b;
import p176d.p242n.C5781e;
import p176d.p242n.C5785g;
import p176d.p242n.C5786h;
import p176d.p242n.C5787i;
import p176d.p242n.C5794o;

public final class LifecycleCameraRepository {

    /* renamed from: a */
    public final Object f387a = new Object();

    /* renamed from: b */
    public final Map<C0061a, LifecycleCamera> f388b = new HashMap();

    /* renamed from: c */
    public final Map<LifecycleCameraRepositoryObserver, Set<C0061a>> f389c = new HashMap();

    /* renamed from: d */
    public final ArrayDeque<C5786h> f390d = new ArrayDeque<>();

    public static class LifecycleCameraRepositoryObserver implements C5785g {

        /* renamed from: a */
        public final LifecycleCameraRepository f391a;

        /* renamed from: b */
        public final C5786h f392b;

        public LifecycleCameraRepositoryObserver(C5786h hVar, LifecycleCameraRepository lifecycleCameraRepository) {
            this.f392b = hVar;
            this.f391a = lifecycleCameraRepository;
        }

        @C5794o(C5781e.C5782a.ON_DESTROY)
        public void onDestroy(C5786h hVar) {
            LifecycleCameraRepository lifecycleCameraRepository = this.f391a;
            synchronized (lifecycleCameraRepository.f387a) {
                lifecycleCameraRepository.mo604f(hVar);
                LifecycleCameraRepositoryObserver b = lifecycleCameraRepository.mo600b(hVar);
                for (C0061a remove : lifecycleCameraRepository.f389c.get(b)) {
                    lifecycleCameraRepository.f388b.remove(remove);
                }
                lifecycleCameraRepository.f389c.remove(b);
                ((C5787i) b.f392b.mo1a()).f20305a.mo10689r(b);
            }
        }

        @C5794o(C5781e.C5782a.ON_START)
        public void onStart(C5786h hVar) {
            this.f391a.mo603e(hVar);
        }

        @C5794o(C5781e.C5782a.ON_STOP)
        public void onStop(C5786h hVar) {
            this.f391a.mo604f(hVar);
        }
    }

    /* renamed from: androidx.camera.lifecycle.LifecycleCameraRepository$a */
    public static abstract class C0061a {
    }

    /* renamed from: a */
    public void mo599a(LifecycleCamera lifecycleCamera, C5241f2 f2Var, Collection<C5227d2> collection) {
        synchronized (this.f387a) {
            boolean z = true;
            C4851q.C4862i.m15134h(!collection.isEmpty());
            C5786h l = lifecycleCamera.mo592l();
            for (C0061a aVar : this.f389c.get(mo600b(l))) {
                LifecycleCamera lifecycleCamera2 = this.f388b.get(aVar);
                C4851q.C4862i.m15164r(lifecycleCamera2);
                if (!lifecycleCamera2.equals(lifecycleCamera)) {
                    if (!lifecycleCamera2.mo593m().isEmpty()) {
                        throw new IllegalArgumentException("Multiple LifecycleCameras with use cases are registered to the same LifecycleOwner.");
                    }
                }
            }
            try {
                C5391c cVar = lifecycleCamera.f384c;
                synchronized (cVar.f19118g) {
                    cVar.f19117f = f2Var;
                }
                synchronized (lifecycleCamera.f382a) {
                    lifecycleCamera.f384c.mo11281a(collection);
                }
                if (((C5787i) l.mo1a()).f20306b.compareTo(C5781e.C5783b.STARTED) < 0) {
                    z = false;
                }
                if (z) {
                    mo603e(l);
                }
            } catch (C5391c.C5392a e) {
                throw new IllegalArgumentException(e.getMessage());
            }
        }
    }

    /* renamed from: b */
    public final LifecycleCameraRepositoryObserver mo600b(C5786h hVar) {
        synchronized (this.f387a) {
            for (LifecycleCameraRepositoryObserver next : this.f389c.keySet()) {
                if (hVar.equals(next.f392b)) {
                    return next;
                }
            }
            return null;
        }
    }

    /* renamed from: c */
    public final boolean mo601c(C5786h hVar) {
        synchronized (this.f387a) {
            for (C0061a aVar : this.f389c.get(mo600b(hVar))) {
                LifecycleCamera lifecycleCamera = this.f388b.get(aVar);
                C4851q.C4862i.m15164r(lifecycleCamera);
                if (!lifecycleCamera.mo593m().isEmpty()) {
                    return true;
                }
            }
            return false;
        }
    }

    /* renamed from: d */
    public final void mo602d(LifecycleCamera lifecycleCamera) {
        Set set;
        synchronized (this.f387a) {
            C5786h l = lifecycleCamera.mo592l();
            C5473b bVar = new C5473b(l, lifecycleCamera.f384c.f19115d);
            LifecycleCameraRepositoryObserver b = mo600b(l);
            if (b != null) {
                set = this.f389c.get(b);
            } else {
                b = new LifecycleCameraRepositoryObserver(l, this);
                set = new HashSet();
                this.f389c.put(b, set);
            }
            set.add(bVar);
            this.f388b.put(bVar, lifecycleCamera);
            l.mo1a().mo12114a(b);
        }
    }

    /* renamed from: e */
    public void mo603e(C5786h hVar) {
        ArrayDeque<C5786h> arrayDeque;
        synchronized (this.f387a) {
            if (mo601c(hVar)) {
                if (this.f390d.isEmpty()) {
                    arrayDeque = this.f390d;
                } else {
                    C5786h peek = this.f390d.peek();
                    if (!hVar.equals(peek)) {
                        mo605g(peek);
                        this.f390d.remove(hVar);
                        arrayDeque = this.f390d;
                    }
                    mo606h(hVar);
                }
                arrayDeque.push(hVar);
                mo606h(hVar);
            }
        }
    }

    /* renamed from: f */
    public void mo604f(C5786h hVar) {
        synchronized (this.f387a) {
            this.f390d.remove(hVar);
            mo605g(hVar);
            if (!this.f390d.isEmpty()) {
                mo606h(this.f390d.peek());
            }
        }
    }

    /* renamed from: g */
    public final void mo605g(C5786h hVar) {
        synchronized (this.f387a) {
            for (C0061a aVar : this.f389c.get(mo600b(hVar))) {
                LifecycleCamera lifecycleCamera = this.f388b.get(aVar);
                C4851q.C4862i.m15164r(lifecycleCamera);
                lifecycleCamera.mo594n();
            }
        }
    }

    /* renamed from: h */
    public final void mo606h(C5786h hVar) {
        synchronized (this.f387a) {
            for (C0061a aVar : this.f389c.get(mo600b(hVar))) {
                LifecycleCamera lifecycleCamera = this.f388b.get(aVar);
                C4851q.C4862i.m15164r(lifecycleCamera);
                if (!lifecycleCamera.mo593m().isEmpty()) {
                    lifecycleCamera.mo595o();
                }
            }
        }
    }
}
