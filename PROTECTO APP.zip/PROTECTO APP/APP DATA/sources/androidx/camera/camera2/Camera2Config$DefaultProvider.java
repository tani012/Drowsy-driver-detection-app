package androidx.camera.camera2;

import p176d.p178b.p179k.C4833c;
import p176d.p178b.p179k.C4836f;
import p176d.p178b.p179k.C4837g;
import p176d.p195e.p201b.C5214c1;
import p176d.p195e.p201b.p202h2.C5262c0;
import p176d.p195e.p201b.p202h2.C5371w0;

public final class Camera2Config$DefaultProvider implements C5214c1.C5216b {
    public C5214c1 getCameraXConfig() {
        C5262c0.C5265c cVar = C5262c0.C5265c.OPTIONAL;
        C4837g gVar = C4837g.f17605a;
        C4836f fVar = C4836f.f17604a;
        C4833c cVar2 = C4833c.f17599a;
        C5214c1.C5215a aVar = new C5214c1.C5215a();
        aVar.f18790a.mo11246C(C5214c1.f18784v, cVar, gVar);
        aVar.f18790a.mo11246C(C5214c1.f18785w, cVar, fVar);
        aVar.f18790a.mo11246C(C5214c1.f18786x, cVar, cVar2);
        return new C5214c1(C5371w0.m16226y(aVar.f18790a));
    }
}
